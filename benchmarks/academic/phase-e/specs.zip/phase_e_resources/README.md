# Phase E — Resource and lead-time-aware lab/studio planning

Phase E plans current coursework around student attendance, physical resource capacity, reservations, passive processing and supply lead times. It consumes Phase D forecasts and stable plans, then carries a versioned process and blocker snapshot into Phase F.

Begin with `CODEX_HANDOFF.md`. The machine-readable preparation report is `report.json`. Actual implementation results belong in `templates/implementation_report.json`.

## Specification set

| Specification | Outcome |
| --- | --- |
| `PHE-01` | Typed process time, exact resource units, calendars and reservation evidence tied to current work. |
| `PHE-02` | Joint student/resource feasibility, lead-time scheduling and supported latest-start results. |
| `PHE-03` | Stable repair after changed equipment, supplies, reservations or work scope. |
| `PHE-04` | Normal workflow integration, durable state and recoverable reservation/calendar effects. |
| `PHE-QA-01` | Actual integrated acceptance, measured accounting and upstream compatibility. |

The packet contains 28 acceptance cases, 16 synthetic scenarios, 20 invariants, eight measures and a ten-check host rubric. The source map binds the proposed work to existing process, planner, state and calendar primitives.

## Quantities that determine the plan

| Quantity | Planning meaning |
| --- | --- |
| Active labor | Student attendance and current remaining-work demand. |
| Unattended processing | Process duration with the declared equipment occupancy and run calendar. |
| Passive wait | A dependency advances on its named elapsed or operating clock. |
| Supply lead time | A supported arrival/release bound for dependent work. |
| Resource occupancy | Simultaneous quantity over an interval, including required setup, hold and cleanup. |
| Reservation support | Current evidence of access, with observation, tentative and confirmed states retained. |

Named active phases partition or explicitly override one scoped Phase D work-demand record. This mapping counts the parent work and its phase labor once. Zero wait and zero remaining demand use typed phase or eligibility records while shared positive Effort validation retains its established meaning.

The initial duration and lead-time selector uses the supplied upper bound. Unknown quantities remain explicit. Renewable resources use exact compatible capacity units. Consumable supplies retain their own quantity and arrival evidence.

## Time, access and feasibility

Occupancy uses half-open intervals. Elapsed arithmetic uses UTC instants, with local timezone and offset/fold context retained. Operating-minute lead time advances through the selected versioned calendar. Business-day inputs require their declared counting convention.

Attended setup, loading, unloading and cleanup satisfy facility access and student availability. Equipment occupancy satisfies the resource run calendar. An explicitly supported unattended operation can therefore continue while the student is elsewhere or the attended facility is closed.

A linked own reservation retains its complete reserved interval and quantity. Covered planned use is absorbed once, while unused reserved capacity still contributes to occupancy. Combined linked claims must fit the booking. Other bookings contribute their actual occupied quantity. Calendar observations retain coverage and freshness, and a study event carries its actual study-time meaning.

Backward latest-start calculation uses the same duration, calendar, capacity and lag constraints as forward feasibility. An exact single-chain derivation or complete declared finite domain can support a certified bound. A value found in a bounded candidate set keeps that search scope. Infeasibility uses a supported certificate or explicit contradiction.

The reference fixture evaluates supplied candidates. Production binds its current engine and records its actual search method and limits. Each engine uses one explicit buffer policy. The fixture follows Phase D's end-only student-window buffer applied once. Resource turnaround and process waits retain their own declared durations.

The bounded fixture uses one resource requirement per step and complete supplied placements. Integrated acceptance includes the broader supported simultaneous-resource and planning behavior. Resolved hard-feasible candidates rank ahead of unresolved hard-feasibility candidates, with conditional reservation support retained on its separate evidence axis.

## Stable change handling

The Phase D comparison order remains hard/protected validity, prioritized unmet work, changed existing blocks, start displacement, retained-block duration change and a stable tie-break. Valid accepted plans retain their identities. Equipment downtime, delayed supplies and changed reservations trigger the affected Phase C dependency closure.

Started blocks retain their full logical/provider interval. Their future remainder consumes future student capacity and current remaining-demand credit. Physical equipment occupancy follows its actual interval and operating state.

The current accepted Stage 5 workflow supplies source, owned-state and calendar behavior. Local generation receipts and external operation confirmations keep their own state. Partial resource/calendar success, uncertain outcomes, concurrent edits and restart recovery use stable operation identity and current revisions.

## Package contents

- `specs/` contains the five implementation specifications.
- `contracts/` defines process/resource models, planning policy, apply/recovery, execution capture and the Phase F handoff.
- `fixtures/` contains generic synthetic lab/studio records, candidate plans, authored expected vectors and executable checks.
- `reference/` preserves a narrow exact upstream contract slice with byte provenance.
- `prompts/` contains ordinary planning, change and recovery journeys.
- `templates/` contains active-build mappings and pending actual-run records.
- `evidence/` contains source mapping, independent review and local validation results.

The synthetic process values serve as structural test data. Actual source constraints supply operational durations and instructions in the implemented feature.

## Validation and completion

Use Python 3.11 or later. Named-zone cases use the runtime's IANA timezone database through `zoneinfo`.

```bash
python /path/to/phase_e_resources/validate_package.py --negative-controls
```

The optional `--source-root` argument checks exact bytes against a local copy of the reviewed public source. The fixture validator also runs independently.

```bash
python /path/to/phase_e_resources/fixtures/validate_fixtures.py --negative-controls
```

Preparation includes executed local structural, arithmetic and mutation checks. Product, supported-host, provider and source-test execution counters begin at zero. Implementation completion uses actual current-adapter and host evidence, including durable restart and the declared provider boundary.

## Sequential implementation

The agreed order is A → B → C → D → E → F. Give Codex one archive at a time and begin each with its `CODEX_HANDOFF.md`. Resolve each packet against the current implemented upstream interfaces. Complete its actual scoped acceptance and preserve the resulting report before continuing.

E completion validates the Phase F interface with a minimal contract consumer. F then tests the implemented group-handoff workflow against that versioned interface.
