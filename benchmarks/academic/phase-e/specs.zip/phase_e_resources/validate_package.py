#!/usr/bin/env python3
"""Validate the Phase E specification packet and bounded resource fixtures."""

import argparse
import hashlib
import json
import runpy
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


sys.dont_write_bytecode = True


SPEC_IDS = {'PHE-01', 'PHE-02', 'PHE-03', 'PHE-04', 'PHE-QA-01'}
CASE_IDS = {f'PHE-T{number:02d}' for number in range(1, 29)}
SCENARIO_IDS = {f'PHE-S{number:02d}' for number in range(1, 17)}
COMMIT = '29652557b5701df6eb9147ac232fd3c656449104'
CHECKSUM_EXCLUSIONS = {'SHA256SUMS', 'evidence/package_validation.json'}
STABILITY_ORDER = [
    'hard_and_protected_validity', 'prioritized_unmet_vector',
    'changed_existing_block_count', 'absolute_start_displacement_minutes',
    'absolute_duration_change_minutes', 'stable_tie_break'
]


def load(root, relative):
    return json.loads((root / relative).read_text(encoding='utf-8'))


def validate_structure(root):
    checks = []

    def check(identifier, condition, detail):
        checks.append({'id': identifier, 'passed': bool(condition), 'detail': detail})

    files = sorted(root.rglob('*.json'))
    for path in files:
        json.loads(path.read_text(encoding='utf-8'))
    check('json.parse', bool(files), f'Parsed {len(files)} JSON files')

    specs = [load(root, path.relative_to(root)) for path in sorted((root / 'specs').glob('*.json'))]
    spec_by_id = {item['id']: item for item in specs}
    design = load(root, 'evidence/acceptance_design_review.json')
    acceptance = load(root, 'acceptance_cases.json')
    cases = acceptance['cases']
    check('spec.identities', len(specs) == 5 and set(spec_by_id) == SPEC_IDS, 'Five unique agreed specifications')
    check('cases.identities', len(cases) == len({case['id'] for case in cases}) == 28 and {case['id'] for case in cases} == CASE_IDS, 'Twenty-eight unique actual acceptance cases')
    for spec in specs:
        ids = [item['id'] for item in spec['requirements']]
        check(spec['id'] + '.requirements', len(ids) == len(set(ids)) == 10 and all(item['detail'] for item in spec['requirements']), 'Ten distinct detailed requirements')
        check(spec['id'] + '.cases', set(spec['acceptance_cases']) <= CASE_IDS, 'Case references resolve')
        check(spec['id'] + '.dependencies', set(spec['dependencies']) <= SPEC_IDS - {spec['id']}, 'Specification dependencies resolve')
        check(spec['id'] + '.commit', spec['reviewed_public_commit'] == COMMIT, 'Pinned public source is consistent')
    check('cases.owner_links', all(case['owner_spec'] in spec_by_id and case['id'] in spec_by_id[case['owner_spec']]['acceptance_cases'] for case in cases), 'Every case links to its owner')
    check('cases.scenario_links', all(set(case['scenario_ids']) <= SCENARIO_IDS for case in cases), 'Scenario references resolve')
    check('cases.scenario_coverage', set().union(*(set(case['scenario_ids']) for case in cases)) == SCENARIO_IDS, 'All sixteen scenarios have acceptance coverage')
    check('cases.prepared', acceptance['actual_product_executions'] == acceptance['actual_host_executions'] == 0 and all(case['execution_status'] == case['verdict'] == 'not_run' and case['observed_result'] is None and not case['observed_evidence_refs'] for case in cases), 'Actual acceptance remains pending')
    originals = {case['id']: case for case in design['acceptance_cases']}
    check('cases.review_alignment', all({key: case[key] for key in originals[case['id']]} == originals[case['id']] for case in cases), 'Acceptance content matches independent review')

    scope = load(root, 'scope_and_roadmap.json')
    order = scope['implementation_order']
    check('scope.roadmap', scope['selected_phase'] == 'E' and [item['phase'] for item in scope['phase_ownership']] == list('ABCDEF'), 'Agreed roadmap and current phase are retained')
    check('scope.order', len(order) == 5 and set(order) == SPEC_IDS and all(order.index(dep) < order.index(spec['id']) for spec in specs for dep in spec['dependencies']), 'Implementation order satisfies dependencies')
    check('scope.execution', scope['actual_product_executions'] == scope['actual_host_executions'] == 0, 'Preparation has zero actual feature executions')

    contract = load(root, 'contracts/resource_process_contract.json')
    policy = load(root, 'contracts/resource_planning_policy.json')
    apply = load(root, 'contracts/reservation_apply_contract.json')
    handoff = load(root, 'contracts/phase_f_handoff.json')
    execution = load(root, 'contracts/execution_capture.json')
    host = load(root, 'contracts/host_fidelity_rubric.json')
    check('contract.invariants', contract['invariants'] == design['invariant_suggestions'] and len(contract['invariants']) == len({item['id'] for item in contract['invariants']}) == 20, 'Twenty reviewed unique invariants')
    check('contract.identity', set(contract['identity_axes']) == {'work', 'process', 'resource', 'reservation', 'plan'}, 'Typed identity layers resolve')
    check('contract.quantities', set(contract['enums']['duration_kind']) == {'active_labor', 'unattended_processing', 'passive_wait', 'supply_lead'}, 'Four duration meanings remain explicit')
    check('contract.demand_mapping', {'active_demand_scope_id', 'phase_to_work_mapping'} <= set(contract['step_fields']) and bool(contract['zero_adapter']) and bool(contract['active_demand_mapping']), 'Parent and phase demand have a single scoped mapping')
    check('contract.source_scope', {'source_refs', 'known_at', 'work_episode_id', 'revision', 'carry_forward_proof_ref'} <= set(contract['constraint_fields']), 'Constraints retain scope and version provenance')
    check('contract.resource_units', {'capacity', 'capacity_unit', 'access_calendar_ref', 'run_calendar_ref', 'coverage_horizon'} <= set(contract['resource_fields']), 'Capacity and calendar roles are explicit')
    check('contract.reservation', {'logical_reservation_id', 'logical_allocation_id', 'support_state', 'provider_revision', 'confirmation_source_ref'} <= set(contract['reservation_fields']), 'Reservation support retains exact allocation and confirmation identity')
    check('policy.reference_choices', policy['duration_selector'] == 'upper' and policy['interval_convention'] == 'half_open', 'Reference upper-bound and interval choices are exact')
    check('policy.stability', policy['comparison_order'] == STABILITY_ORDER == design['agreed_model']['stable_policy_order'], 'Prioritized service precedes churn')
    check('policy.buffer', policy['buffer_binding']['fixture_policy'] == 'end_only_per_supplied_availability_window', 'One named student-window buffer policy')
    check('policy.latest_start', set(policy['latest_start']['proof_scope']) == {'single_chain_exact', 'complete_finite_domain', 'bounded_candidate_value', 'unresolved'}, 'Latest-start proof and bounded scopes are explicit')
    check('apply.identities', {'logical_operation_id', 'attempt_id', 'logical_allocation_id', 'logical_reservation_id', 'logical_block_id', 'expected_provider_revision', 'depends_on_operation_ids'} <= set(apply['operation_identity_fields']), 'Operation identity retains dependency and expected-base evidence')
    check('apply.states', {'confirmed', 'failed', 'outcome_unknown', 'pending'} <= set(apply['provider_states']), 'External outcomes retain independent confirmation')
    check('host.rubric', len(host['checks']) == len({item['id'] for item in host['checks']}) == 10 and host['checks'] == design['host_fidelity_checks'], 'Ten reviewed host-fidelity checks')
    check('execution.levels', set(execution['execution_levels']) == {'deterministic_contract_test', 'current_adapter_integration', 'native_host_journey'}, 'Actual execution levels are distinguished')

    example = handoff['example']
    check('handoff.fields', set(handoff['record_fields']) <= set(example), 'Minimal E-to-F consumer accepts a complete synthetic basis')
    check('handoff.artifact_fields', all(set(handoff['artifact_ref_fields']) <= set(item) for item in example['required_artifact_refs']), 'Artifact references carry exact version, content and availability fields')
    check('handoff.blocker_fields', all(set(handoff['blocker_fields']) <= set(item) for item in example['blocker_refs']), 'Blockers carry affected scope and resolution evidence')
    check('handoff.conditional_evidence', example['blocker_refs'][0]['state'] == 'conditional' and example['blocker_refs'][0]['resolution_evidence_ref'] is None and example['synthetic'] and example['product_execution_count'] == 0, 'Consumer preserves unresolved access and synthetic execution scope')

    scenarios = load(root, 'fixtures/scenarios.json')
    check('fixtures.scenarios', len(scenarios['scenarios']) == 16 and {item['id'] for item in scenarios['scenarios']} == SCENARIO_IDS, 'Sixteen agreed synthetic scenarios')
    fixture_policy = load(root, 'fixtures/policy.json')
    check('fixtures.policy_mapping', fixture_policy['duration_selector'] == fixture_policy['lead_time_selector'] == policy['fixture_field_mapping']['upper'] and fixture_policy['intervals'] == policy['interval_convention'] and fixture_policy['student_buffer_policy'] == policy['buffer_binding']['fixture_policy'], 'Fixture field mapping preserves bound, interval and buffer policy')
    check('fixtures.stability_mapping', fixture_policy['candidate_order'][:-1] == policy['comparison_order'][:-1] and fixture_policy['candidate_order'][-1] == policy['fixture_field_mapping']['stable_tie_break'], 'Fixture stable candidate key maps to the declared policy')
    check('fixtures.no_product_credit', scenarios['synthetic'] and all(value == 0 for value in fixture_policy['execution_counts'].values()), 'Fixture execution counters retain zero product and provider credit')
    report = load(root, 'templates/implementation_report.json')
    summary = report['execution_summary']
    execution_keys = ['actual_product_executions', 'actual_host_executions', 'process_restarts_tested', 'provider_calls', 'confirmed_provider_effects', 'test_double_effects']
    check('templates.no_product_credit', report['phase_e_completion'] == 'prepared' and all(summary[key] == 0 for key in execution_keys) and not report['run_capture_refs'], 'Template retains zero actual execution credit')
    check('templates.case_results', len(report['case_results']) == 28 and {item['case_id'] for item in report['case_results']} == CASE_IDS and all(item['execution_status'] == item['verdict'] == 'not_run' and not item['evidence_refs'] for item in report['case_results']), 'Actual case results remain pending')
    check('templates.summary', summary['scoped_cases'] == summary['not_run'] == 28 and summary['passed'] == summary['failed'] == summary['blocked'] == 0, 'Case accounting matches pending results')
    check('templates.measures', len(report['measures']) == len({item['id'] for item in report['measures']}) == 8 and all(item['observed'] is None and item['execution_status'] == 'not_run' and not item['evidence_refs'] for item in report['measures']), 'Eight actual measures retain null observations')
    capture = load(root, 'templates/product_run_capture.json')
    check('templates.capture', capture['execution_status'] == 'not_run' and all(capture[key] is None for key in ['run_id', 'tested_commit', 'constraint_snapshot_ref', 'selected_plan_ref', 'local_receipt_ref', 'restart_read_ref', 'final_answer_ref']) and all(not capture[key] for key in ['call_records', 'provider_operation_refs', 'confirmed_effect_refs', 'test_double_effect_refs']), 'Capture contains no fabricated execution evidence')
    bindings = load(root, 'templates/active_build_bindings.json')
    check('templates.bindings', bindings['execution_status'] == 'not_run' and bindings['commit'] is None and len(bindings['bindings']) == 11 and all(item['support_status'] == 'not_checked' and item['actual_route_or_symbol'] is None for item in bindings['bindings']), 'Eleven current interfaces await active binding')
    check('templates.completion_model', report['completion_model'] == acceptance['completion_model'] == design['completion_model'] == execution['completion_model'], 'Completion rules agree throughout the packet')

    sources = load(root, 'evidence/source_bindings.json')
    capabilities = load(root, 'evidence/capability_map.json')
    source_files = sources['files']
    anchors = [anchor for item in source_files for anchor in item['reviewed_anchors']]
    anchor_ids = {anchor['id'] for anchor in anchors}
    check('source.revision', sources['reviewed_commit'] == capabilities['reviewed_commit'] == COMMIT, 'Source maps share the reviewed public pin')
    check('source.files', len(source_files) == len({item['path'] for item in source_files}) == sources['files_verified'], 'Unique source-file inventory matches recorded count')
    check('source.anchors', len(anchors) == len(anchor_ids) == sources['source_anchors'], 'Unique anchors match recorded count')
    check('source.ranges', all(1 <= anchor['start_line'] <= anchor['end_line'] <= item['line_count'] for item in source_files for anchor in item['reviewed_anchors']), 'Source anchor ranges fit their pinned files')
    check('source.hash_records', sources['all_files_match_reviewed_commit'] and all(item['local_git_blob_verified'] and item['commit'] == COMMIT and len(item['sha256']) == 64 for item in source_files), 'Exact source hash records are complete')
    check('source.static_scope', all(record[key] == 0 for record in [sources, capabilities] for key in ['product_feature_tests_executed', 'host_conversation_tests_executed', 'provider_operations_executed', 'source_test_execution_count']) and not sources['active_implementation_branch_verified'] and not sources['installed_plugin_version_verified'], 'Static source review records its actual boundary')
    check('source.capabilities', len(capabilities['capabilities']) > 0 and all(set(item['source_anchor_refs']) <= anchor_ids and set(item['owner_specs']) <= SPEC_IDS for item in capabilities['capabilities']), 'Capabilities resolve source anchors and owners')
    check('source.routes', len(capabilities['route_contracts']) > 0 and all(set(item['source_anchor_refs']) <= anchor_ids for item in capabilities['route_contracts']), 'Routes resolve source anchors')
    check('source.seams', len(capabilities['minimal_implementation_seams']) == 5 and all(set(item['source_anchor_refs']) <= anchor_ids and item['owner_spec'] in SPEC_IDS for item in capabilities['minimal_implementation_seams']), 'Five bounded seams resolve source and owner')
    required = ['README.md', 'CODEX_HANDOFF.md', 'report.json', 'evidence/package_review.json', 'evidence/fixture_adversarial_review.json', 'prompts/plan_lab_studio.md', 'prompts/explain_latest_start.md', 'prompts/repair_changed_access.md', 'prompts/recover_reservations.md']
    check('package.deliverables', all((root / name).is_file() for name in required), 'Entry points, reports and ordinary prompts exist')
    if (root / 'report.json').is_file():
        preparation = load(root, 'report.json')
        check('report.prepared', preparation['phase_e_completion'] == 'prepared' and preparation['product_execution_count'] == preparation['actual_host_execution_count'] == preparation['provider_execution_count'] == 0, 'Preparation report preserves actual execution scope')
        check('report.counts', preparation['counts']['specifications'] == 5 and preparation['counts']['acceptance_cases'] == 28 and preparation['counts']['transition_scenarios'] == 16, 'Report counts match the packet')
    return checks


def validate_checksums(root):
    expected = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file() and path.relative_to(root).as_posix() not in CHECKSUM_EXCLUSIONS}
    checks, listed = [], set()
    for line in (root / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, relative = line.split('  ', 1)
        path = Path(relative)
        safe = not path.is_absolute() and '..' not in path.parts
        exists = safe and (root / path).is_file()
        matches = exists and hashlib.sha256((root / path).read_bytes()).hexdigest() == digest
        checks.append({'id': 'checksum.' + relative, 'passed': bool(matches and relative not in listed), 'detail': 'Exact SHA-256 and safe unique relative path'})
        listed.add(relative)
    checks.append({'id': 'checksum.inventory', 'passed': listed == expected, 'detail': f'Manifest covers {len(expected)} frozen files. Manifest and regenerable package validation report are excluded.'})
    return checks


def validate_source_bytes(root, source_root):
    checks = []
    for item in load(root, 'evidence/source_bindings.json')['files']:
        path = source_root / item['path']
        matches = False
        if path.is_file():
            data = path.read_bytes()
            blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
            matches = blob == item['git_blob_sha'] and hashlib.sha256(data).hexdigest() == item['sha256']
        checks.append({'id': 'source_bytes.' + item['path'], 'passed': matches, 'detail': 'Pinned Git blob and SHA-256 verification'})
    return checks


def negative_controls(root):
    results = []
    mutations = [
        ('fabricated_product_completion', 'templates/implementation_report.json', 'templates.no_product_credit'),
        ('changed_duration_selector', 'contracts/resource_planning_policy.json', 'policy.reference_choices'),
        ('churn_before_service', 'contracts/resource_planning_policy.json', 'policy.stability')
    ]
    with tempfile.TemporaryDirectory(prefix='phase-e-package-controls-') as directory:
        work = Path(directory) / 'package'
        shutil.copytree(root, work)
        for identifier, relative, check_id in mutations:
            path = work / relative
            original = path.read_text(encoding='utf-8')
            changed = json.loads(original)
            if identifier == 'fabricated_product_completion':
                changed['phase_e_completion'] = 'complete'
                changed['execution_summary']['actual_product_executions'] = 1
            elif identifier == 'changed_duration_selector':
                changed['duration_selector'] = 'lower'
            else:
                order = changed['comparison_order']
                order[1], order[2] = order[2], order[1]
            path.write_text(json.dumps(changed), encoding='utf-8')
            checks = validate_structure(work)
            rejected = any(item['id'] == check_id and not item['passed'] for item in checks)
            results.append({'id': 'package.' + identifier, 'passed': rejected, 'detail': 'Targeted semantic rejection with checksums omitted'})
            path.write_text(original, encoding='utf-8')
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--negative-controls', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    checks = validate_structure(root) + validate_checksums(root)
    fixture = runpy.run_path(str(root / 'fixtures/validate_fixtures.py'))
    checks += [{**item, 'id': 'fixture.' + item['id']} for item in fixture['validate'](root)]
    if args.source_root:
        checks += validate_source_bytes(root, args.source_root.resolve())
    controls = []
    if args.negative_controls:
        controls = negative_controls(root) + [{**item, 'id': 'fixture.' + item['id']} for item in fixture['negative_controls'](root)]
    failed = [item for item in checks + controls if not item['passed']]
    result = {
        'schema_version': 'phase-e-package-validation.v1',
        'executed_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'passed' if not failed else 'failed',
        'checks_passed': sum(item['passed'] for item in checks), 'checks_total': len(checks),
        'negative_controls_passed': sum(item['passed'] for item in controls), 'negative_controls_total': len(controls),
        'actual_product_executions': 0, 'actual_host_executions': 0, 'provider_executions': 0,
        'source_bytes_checked': bool(args.source_root), 'checks': checks, 'negative_controls': controls
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key not in {'checks', 'negative_controls'}}))
    for item in failed:
        print(json.dumps(item))
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
