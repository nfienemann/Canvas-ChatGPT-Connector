#!/usr/bin/env python3
"""Bounded, synthetic schedule and recovery arithmetic for Phase E fixtures."""

import copy
import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo


def read(root, relative):
    return json.loads((Path(root) / relative).read_text(encoding="utf-8"))


def instant(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.utcoffset() is None:
        raise ValueError("A timezone-aware timestamp is required")
    return result.astimezone(timezone.utc)


def minutes(start, end):
    return int((end - start).total_seconds() / 60)


def quantity(value):
    return Decimal(str(value))


def number(value):
    return int(value) if value == int(value) else float(value)


def interval(row):
    return instant(row["start_at"]), instant(row["end_at"])


def overlaps(first, second):
    return first[0] < second[1] and second[0] < first[1]


def merged(rows):
    output = []
    for start, end in sorted(rows):
        if end <= start:
            continue
        if output and start <= output[-1][1]:
            output[-1] = (output[-1][0], max(end, output[-1][1]))
        else:
            output.append((start, end))
    return output


def contained(span, windows):
    return span[0] >= span[1] or any(start <= span[0] and span[1] <= end for start, end in merged(windows))


def shift_clock(anchor, amount, clock, calendars, calendar_ref=None, direction="forward"):
    """Count elapsed or declared operating minutes, preserving unknown horizons."""
    if amount is None or amount < 0:
        return None
    sign = 1 if direction == "forward" else -1
    if clock == "elapsed_minutes":
        return anchor + timedelta(minutes=sign * amount)
    if clock != "operating_minutes" or calendar_ref not in calendars:
        return None
    if amount == 0:
        return anchor
    windows = merged([interval(row) for row in calendars[calendar_ref]["windows"]])
    if sign < 0:
        windows.reverse()
    remaining = amount
    for start, end in windows:
        if sign > 0:
            cursor = max(start, anchor)
            available = max(0, minutes(cursor, end))
            if remaining <= available:
                return cursor + timedelta(minutes=remaining)
        else:
            cursor = min(end, anchor)
            available = max(0, minutes(start, cursor))
            if remaining <= available:
                return cursor - timedelta(minutes=remaining)
        remaining -= available
    return None


def validate_process(process):
    errors, unknowns = set(), set()
    steps = {row["id"]: row for row in process["steps"]}
    if len(steps) != len(process["steps"]):
        errors.add("duplicate_step_id")
    for step in steps.values():
        duration = step["run_duration"]
        low, high = duration["minimum_minutes"], duration["maximum_minutes"]
        if low is None or high is None:
            unknowns.add("duration:" + step["id"])
        elif low < 0 or high < low:
            errors.add("invalid_duration")
        if duration["clock"] != "elapsed_minutes":
            errors.add("unsupported_run_clock")
        if step["setup_minutes"] < 0 or step["cleanup_minutes"] < 0:
            errors.add("invalid_setup_cleanup")
        if step["mode"] not in {"active", "unattended"}:
            errors.add("invalid_step_mode")
        requirement = step.get("resource_requirement")
        if requirement:
            if requirement["quantity"] <= 0 or not requirement["unit"]:
                errors.add("invalid_resource_requirement")
            if step["occupancy_policy"] == "unknown":
                unknowns.add("occupancy:" + step["id"])
    edges = defaultdict(list)
    for edge in process["dependencies"]:
        if edge["from_step"] not in steps or edge["to_step"] not in steps:
            errors.add("unknown_prerequisite")
        else:
            edges[edge["from_step"]].append(edge["to_step"])
        if edge["from_anchor"] != "finish" or edge["to_anchor"] != "start":
            errors.add("unsupported_dependency_anchor")
        minimum, maximum = edge["minimum_lag_minutes"], edge["maximum_lag_minutes"]
        if minimum is None:
            unknowns.add("lag:" + edge["from_step"] + "/" + edge["to_step"])
        elif minimum < 0 or (maximum is not None and maximum < minimum):
            errors.add("invalid_lag_range")
    visited, active = set(), set()

    def visit(identifier):
        if identifier in active:
            errors.add("cyclic_dependencies")
            return
        if identifier in visited:
            return
        active.add(identifier)
        for successor in edges[identifier]:
            visit(successor)
        active.remove(identifier)
        visited.add(identifier)

    for identifier in steps:
        visit(identifier)
    return {"errors": sorted(errors), "unknowns": sorted(unknowns)}


def churn(base, blocks):
    old = {row["id"]: row for row in base}
    new = {row["id"]: row for row in blocks}
    changed, displacement, duration_change = set(old) - set(new), 0, 0
    for identifier in old.keys() & new.keys():
        old_span, new_span = interval(old[identifier]), interval(new[identifier])
        if old_span != new_span or old[identifier]["episode_id"] != new[identifier]["episode_id"]:
            changed.add(identifier)
        displacement += abs(minutes(old_span[0], new_span[0]))
        duration_change += abs(minutes(*old_span) - minutes(*new_span))
    return {
        "changed_existing_block_count": len(changed),
        "absolute_start_displacement_minutes": displacement,
        "absolute_duration_change_minutes": duration_change,
        "added_count": len(set(new) - set(old)),
        "removed_count": len(set(old) - set(new)),
    }


def candidate_key(result):
    change = result["churn"]
    return (bool(result.get("hard_unknowns")), tuple(result["prioritized_unmet_vector"]), change["changed_existing_block_count"], change["absolute_start_displacement_minutes"], change["absolute_duration_change_minutes"], result["id"])


def check_candidate(candidate, packet, process, resources, calendars, policy):
    now, deadline = instant(packet["planning_boundary"]), instant(packet["deadline_at"])
    errors, unknowns = set(), set()
    blocks, occupancies, bounds = [], [], defaultdict(list)
    booking_support = {}
    steps = {row["id"]: row for row in process["steps"] if row["scope_state"] == "current"}
    used_minutes, counts = defaultdict(int), defaultdict(int)
    passive_minutes = 0
    for row in candidate["placements"]:
        if row["step_id"] not in steps:
            errors.add("ineligible_step")
            continue
        step = steps[row["step_id"]]
        if row["episode_id"] != step["episode_id"]:
            errors.add("episode_mismatch")
        selected = step["run_duration"][policy["duration_selector"]]
        duration = row.get("run_minutes", selected)
        if duration is None:
            unknowns.add("duration:" + step["id"])
            continue
        if duration < 0:
            errors.add("invalid_duration")
            continue
        if not step["divisible"] and duration != selected:
            errors.add("indivisible_duration")
        start = instant(row["start_at"])
        run_start = start + timedelta(minutes=step["setup_minutes"])
        run_end = run_start + timedelta(minutes=duration)
        end = run_end + timedelta(minutes=step["cleanup_minutes"])
        if start < now:
            existing_started = any(old["id"].startswith(row["placement_id"] + "/") and old["episode_id"] == row["episode_id"] and interval(old)[0] <= now < interval(old)[1] for old in packet["base_blocks"])
            supported_started = row["placement_id"] in packet.get("supported_started_placement_ids", [])
            if end <= now or not (existing_started or supported_started):
                errors.add("unsupported_past_placement")
        bounds[step["id"]].append((start, end))
        used_minutes[step["id"]] += duration
        counts[step["id"]] += 1
        phases = [("setup", start, run_start), ("cleanup", run_end, end)]
        if step["mode"] == "active":
            phases.append(("active", run_start, run_end))
        else:
            passive_minutes += duration
        attended = [(phase_start, phase_end) for _, phase_start, phase_end in phases if phase_end > phase_start]
        for phase, phase_start, phase_end in phases:
            if phase_end <= phase_start:
                continue
            blocks.append({"id": row["placement_id"] + "/" + phase, "placement_id": row["placement_id"], "step_id": step["id"], "episode_id": row["episode_id"], "start_at": phase_start.isoformat(), "end_at": phase_end.isoformat()})
        if end > deadline:
            errors.add("deadline")
        requirement = step.get("resource_requirement")
        if not requirement:
            continue
        resource = resources.get(row["resource_id"])
        if resource is None:
            errors.add("unknown_resource")
            continue
        if resource["id"] not in requirement["resource_ids"] or resource["capability"] != requirement["capability"]:
            errors.add("incompatible_resource")
        if resource["capacity"]["unit"] != requirement["unit"]:
            errors.add("unit_mismatch")
        if step["occupancy_policy"] == "unknown":
            unknowns.add("occupancy:" + step["id"])
        for key, spans in [("occupancy_calendar_ref", [(start, end)]), ("run_calendar_ref", [(run_start, run_end)]), ("access_calendar_ref", attended)]:
            reference = resource.get(key)
            if reference not in calendars:
                unknowns.add(key + ":" + resource["id"])
                continue
            windows = [interval(value) for value in calendars[reference]["windows"]]
            if any(not contained(span, windows) for span in spans):
                errors.add("outside_" + key.removesuffix("_ref"))
        if any(overlaps((max(now, start), end), interval(value)) for value in resource["unavailable"]):
            errors.add("resource_unavailable")
        matching = [value for value in resource["reservations"] if value["id"] == row.get("booking_id") and value["owner_step_id"] == step["id"]]
        support = "observed_available"
        covered_booking_id = None
        if matching:
            booking = matching[0]
            support = booking["status"]
            quantity_ok = quantity(booking["quantity"]) >= quantity(requirement["quantity"]) and booking["unit"] == requirement["unit"]
            if support == "confirmed" and quantity_ok and contained((start, end), [interval(booking)]):
                covered_booking_id = booking["id"]
            elif support == "confirmed":
                errors.add("booking_scope_mismatch")
                support = "scope_mismatch"
        booking_support[step["id"]] = support
        if requirement["booking_required"] and support != "confirmed":
            unknowns.add("booking:" + step["id"])
        occupancies.append({"resource_id": resource["id"], "unit": requirement["unit"], "quantity": requirement["quantity"], "start_at": start.isoformat(), "end_at": end.isoformat(), "covered_booking_id": covered_booking_id})
    for step_id, step in steps.items():
        selected = step["run_duration"][policy["duration_selector"]]
        if used_minutes[step_id] != selected:
            errors.add("incomplete_step")
        if not step["divisible"] and counts[step_id] > 1:
            errors.add("indivisible_split")
    # Once-per-window student buffering is applied before merging supplied windows.
    buffer_minutes = packet["buffer_minutes"]
    student_windows = [(start, end - timedelta(minutes=buffer_minutes)) for start, end in map(interval, packet["student_windows"])]
    future = []
    for row in blocks:
        start, end = interval(row)
        span = (max(now, start), end)
        if span[0] >= span[1]:
            continue
        future.append((span, row["placement_id"]))
        if not contained(span, student_windows):
            errors.add("student_unavailable")
        if any(overlaps(span, interval(busy)) for busy in packet["busy"]):
            errors.add("student_busy")
    for index, (span, placement_id) in enumerate(future):
        for other, other_id in future[index + 1:]:
            if overlaps(span, other):
                errors.add("student_overlap")
            if placement_id != other_id and packet["break_minutes"]:
                first, second = sorted([span, other])
                if 0 <= minutes(first[1], second[0]) < packet["break_minutes"]:
                    errors.add("interblock_break")
    protected = [row for row in packet["base_blocks"] if row.get("protected") or interval(row)[0] < now < interval(row)[1]]
    current_blocks = {row["id"]: row for row in blocks}
    for old in packet["base_blocks"]:
        current = current_blocks.get(old["id"])
        if current and (old["episode_id"] != current["episode_id"] or old["step_id"] != current["step_id"]):
            errors.add("block_identity_rebound")
    for old in protected:
        current = current_blocks.get(old["id"])
        if current is None or interval(old) != interval(current) or old["episode_id"] != current["episode_id"]:
            errors.add("protected_block_changed")
    for resource_id, resource in resources.items():
        events = defaultdict(Decimal)
        population = [row for row in occupancies if row["resource_id"] == resource_id and row["covered_booking_id"] is None]
        for booking in resource["reservations"]:
            if booking["status"] == "confirmed":
                if booking["unit"] != resource["capacity"]["unit"]:
                    errors.add("reservation_unit_mismatch")
                population.append(booking)
                claims = defaultdict(Decimal)
                for claim in occupancies:
                    if claim["resource_id"] == resource_id and claim["covered_booking_id"] == booking["id"]:
                        left, right = interval(claim)
                        claims[left] += quantity(claim["quantity"])
                        claims[right] -= quantity(claim["quantity"])
                claimed = Decimal(0)
                for timestamp in sorted(claims):
                    claimed += claims[timestamp]
                    if claimed > quantity(booking["quantity"]):
                        errors.add("booking_capacity")
        for row in population:
            start, end = interval(row)
            start = max(now, start)
            if end <= start:
                continue
            events[start] += quantity(row["quantity"])
            events[end] -= quantity(row["quantity"])
        occupied = Decimal(0)
        for timestamp in sorted(events):
            occupied += events[timestamp]
            if occupied > quantity(resource["capacity"]["quantity"]):
                errors.add("resource_capacity")
    wait_minutes = 0
    for edge in process["dependencies"]:
        if not bounds[edge["from_step"]] or not bounds[edge["to_step"]]:
            errors.add("missing_dependency_placement")
            continue
        before = max(end for _, end in bounds[edge["from_step"]])
        after = min(start for start, _ in bounds[edge["to_step"]])
        minimum = shift_clock(before, edge["minimum_lag_minutes"], edge["clock"], calendars, edge["calendar_ref"])
        if minimum is None:
            unknowns.add("dependency_clock")
        elif after < minimum:
            errors.add("minimum_lag")
        if edge["maximum_lag_minutes"] is not None:
            maximum = shift_clock(before, edge["maximum_lag_minutes"], edge["clock"], calendars, edge["calendar_ref"])
            if maximum is None:
                unknowns.add("dependency_clock")
            elif after > maximum:
                errors.add("maximum_lag")
        wait_minutes += max(0, minutes(before, after))
    for supply in process["supplies"]:
        if not supply["source_available"] or supply["ready_at"] is None:
            unknowns.add("supply:" + supply["id"])
        elif bounds[supply["step_id"]] and min(start for start, _ in bounds[supply["step_id"]]) < instant(supply["ready_at"]):
            errors.add("supply_not_ready")
    resource_minutes, future_resource_minutes = defaultdict(Decimal), defaultdict(Decimal)
    for row in occupancies:
        start, end = interval(row)
        key = row["resource_id"] + "|" + row["unit"]
        resource_minutes[key] += quantity(row["quantity"]) * minutes(start, end)
        future_resource_minutes[key] += quantity(row["quantity"]) * max(0, minutes(max(start, now), end))
    active_minutes = sum(minutes(*span) for span, _ in future)
    demand_mapping = reconcile_active_demand(process.get("active_demand_mapping"), active_minutes, set(steps))
    if demand_mapping and demand_mapping["state"] == "unresolved":
        unknowns.add("active_demand_mapping")
    return {
        "id": candidate["id"], "violations": sorted(errors), "unknowns": sorted(unknowns), "hard_unknowns": sorted(value for value in unknowns if not value.startswith("booking:")),
        "active_minutes": active_minutes, "active_demand_mapping": demand_mapping,
        "full_active_minutes": sum(minutes(*interval(row)) for row in blocks),
        "passive_elapsed_minutes": passive_minutes, "dependency_wait_minutes": wait_minutes,
        "resource_quantity_minutes": {key: number(value) for key, value in resource_minutes.items()}, "future_resource_quantity_minutes": {key: number(value) for key, value in future_resource_minutes.items()},
        "blocks": sorted(blocks, key=lambda row: row["id"]), "occupancies": occupancies,
        "booking_support": booking_support, "protected_block_ids": sorted(row["id"] for row in protected),
        "churn": churn(packet["base_blocks"], blocks), "prioritized_unmet_vector": [0],
        "actual_observations_created": 0,
    }


def reconcile_active_demand(mapping, phase_active_minutes, step_ids):
    if mapping is None:
        return None
    applicable = set(mapping["phase_scope_refs"]) == step_ids and bool(mapping["active_demand_scope_id"])
    matched = applicable and mapping["basis"] == "phase_partition" and mapping["parent_remaining_minutes"] == phase_active_minutes
    overridden = applicable and mapping["basis"] == "explicit_phase_override" and mapping.get("override_minutes") == phase_active_minutes and bool(mapping.get("override_ref"))
    state = "partition_matched" if matched else ("scoped_override" if overridden else "unresolved")
    return {"state": state, "active_demand_scope_id": mapping["active_demand_scope_id"], "phase_active_minutes": phase_active_minutes, "combined_remaining_minutes": phase_active_minutes if matched or overridden else None, "parent_additional_minutes": 0 if matched or overridden else None}


def capacity_proof(certificate, process, resources, calendars, policy, packet=None):
    if not certificate:
        return None
    resource = resources[certificate["resource_id"]]
    steps = {row["id"]: row for row in process["steps"]}
    demand = Decimal(0)
    valid = certificate["unit"] == resource["capacity"]["unit"] and len(set(certificate["step_ids"])) == len(certificate["step_ids"])
    for identifier in certificate["step_ids"]:
        step = steps[identifier]
        requirement = step["resource_requirement"]
        valid &= step["scope_state"] == "current" and requirement["resource_ids"] == [resource["id"]] and requirement["unit"] == certificate["unit"]
        if packet:
            now = instant(packet["planning_boundary"])
            started_block = any(row["step_id"] == identifier and interval(row)[0] < now < interval(row)[1] for row in packet["base_blocks"])
            started_placement = any(row["step_id"] == identifier and row["placement_id"] in packet.get("supported_started_placement_ids", []) for candidate in packet["candidates"] for row in candidate["placements"])
            if started_block or started_placement:
                valid = False
        duration = step["run_duration"][policy["duration_selector"]]
        if duration is None or step["occupancy_policy"] != "continuous":
            valid = False
            continue
        demand += quantity(requirement["quantity"]) * (duration + step["setup_minutes"] + step["cleanup_minutes"])
    start, end = interval(certificate["window"])
    windows = [interval(row) for row in calendars[resource["occupancy_calendar_ref"]]["windows"]]
    if packet:
        now, deadline = instant(packet["planning_boundary"]), instant(packet["deadline_at"])
        eligible = [(max(now, left), min(deadline, right)) for left, right in windows if max(now, left) < min(deadline, right)]
        valid &= all(contained(span, [(start, end)]) for span in eligible)
    capacity = sum(max(0, minutes(max(start, left), min(end, right))) for left, right in merged(windows)) * quantity(resource["capacity"]["quantity"])
    # This whole-process proof applies to future, unstarted demand. A started
    # process requires an explicitly scoped future-remainder certificate.
    return {"valid": bool(valid), "resource_id": resource["id"], "unit": certificate["unit"], "required_quantity_minutes": number(demand), "available_quantity_minutes": number(capacity), "shortfall_quantity_minutes": number(max(0, demand - capacity))}


def latest_start(certificate, packet, process, evaluated, policy):
    if not certificate:
        return {"status": "unresolved", "at": None, "proof_scope": "bounded candidate set"}
    if certificate["kind"] != "serial_elapsed_chain":
        return {"status": "unresolved", "at": None, "proof_scope": "unsupported certificate"}
    chain = certificate["step_ids"]
    steps = {row["id"]: row for row in process["steps"]}
    edges = {(row["from_step"], row["to_step"]): row for row in process["dependencies"]}
    if set(chain) != set(steps) or len(chain) != len(steps) or len(edges) != len(chain) - 1:
        return {"status": "unresolved", "at": None, "proof_scope": "chain scope mismatch"}
    total = sum(steps[name]["run_duration"][policy["duration_selector"]] + steps[name]["setup_minutes"] + steps[name]["cleanup_minutes"] for name in chain)
    for before, after in zip(chain, chain[1:]):
        edge = edges.get((before, after))
        if edge is None or edge["clock"] != "elapsed_minutes":
            return {"status": "unresolved", "at": None, "proof_scope": "unsupported clock or chain"}
        total += edge["minimum_lag_minutes"]
    bound = instant(packet["deadline_at"]) - timedelta(minutes=total)
    witness = evaluated.get(certificate["witness_candidate_id"])
    supplied = next((row for row in packet["candidates"] if row["id"] == certificate["witness_candidate_id"]), None)
    first = [row for row in supplied["placements"] if row["step_id"] == chain[0]] if supplied else []
    proven = witness and not witness["violations"] and not witness["unknowns"] and len(first) == 1 and instant(first[0]["start_at"]) == bound
    if not proven:
        return {"status": "unresolved", "at": None, "candidate_upper_bound": bound.isoformat(), "proof_scope": "boundary witness failed forward constraints"}
    return {"status": "certified", "at": bound.isoformat(), "chain_elapsed_minutes": total, "proof_scope": "fixed serial elapsed chain with forward-valid boundary witness"}


def evaluate_schedule(packet, process, resource_data, policy):
    validation = validate_process(process)
    if validation["errors"] or validation["unknowns"]:
        return {"status": "invalid_inputs" if validation["errors"] else "unknown_inputs", "input_validation": validation, "selected_candidate_id": None}
    resources = {row["id"]: copy.deepcopy(row) for row in resource_data["resources"]}
    calendars = {row["id"]: row for row in resource_data["calendars"] + packet.get("calendar_additions", [])}
    for identifier, patch in packet.get("resource_patches", {}).items():
        resources[identifier].update(copy.deepcopy(patch))
    evaluated = {row["id"]: check_candidate(row, packet, process, resources, calendars, policy) for row in packet["candidates"]}
    eligible = [row for row in evaluated.values() if not row["violations"]]
    proof = capacity_proof(packet.get("capacity_certificate"), process, resources, calendars, policy, packet)
    common = {
        "candidate_count": len(evaluated), "capacity_certificate": proof,
        "rejected_candidates": {key: row["violations"] for key, row in evaluated.items() if row["violations"]},
        "historical_episode_ids": [row["episode_id"] for row in process["historical_episodes"]],
        "latest_start": latest_start(packet.get("latest_start_certificate"), packet, process, evaluated, policy),
    }
    if not eligible:
        protected = any("protected_block_changed" in row["violations"] for row in evaluated.values())
        status = "protected_conflict" if protected else "no_feasible_schedule_found"
        if proof and proof["valid"] and proof["shortfall_quantity_minutes"] > 0:
            status = "infeasible"
        return {**common, "status": status, "selected_candidate_id": None}
    selected = min(eligible, key=candidate_key)
    return {**common, **selected, "status": "provisional" if selected["unknowns"] else "feasible", "selected_candidate_id": selected["id"]}


def base_check(row):
    changed = sorted(key for key, value in row["expected"].items() if row["current"].get(key) != value)
    return {"status": "stale_base" if changed else "current_base", "changed_axes": changed, "new_effects": 0}


def project_apply(row):
    confirmed, unresolved, projection, reconciled = [], [], {}, 0
    seen = set()
    for operation in row["operations"]:
        identifier = operation["logical_operation_id"]
        if identifier in seen:
            continue
        seen.add(identifier)
        successes = [attempt for attempt in operation["attempts"] if attempt["status"] == "confirmed" and attempt.get("receipt")]
        if not successes:
            unresolved.append(identifier)
            continue
        attempt = successes[-1]
        receipt = attempt["receipt"]
        confirmed.append(identifier)
        projection[receipt["object_id"]] = {"kind": operation["kind"], "provider_revision": receipt["provider_revision"], **receipt["fields"]}
        reconciled += int(attempt.get("reconciled_existing", False))
    status = "applied" if not unresolved else ("partially_applied" if confirmed else "applying")
    return {"status": status, "local_plan_revision": row["local_plan_revision"], "confirmed_operation_ids": sorted(confirmed), "unresolved_operation_ids": sorted(unresolved), "confirmed_objects": projection, "fully_applied_objects": projection if not unresolved else None, "confirmed_effect_count": len(confirmed), "reconciled_without_create_count": reconciled, "actual_provider_calls": 0}


def evaluate(root, scenario):
    policy = read(root, "fixtures/policy.json")
    data = read(root, "fixtures/resources.json")
    calendars = {row["id"]: row for row in data["calendars"]}
    processes = {row["id"]: row for row in read(root, "fixtures/processes.json")["processes"]}
    schedules = {row["id"]: row for row in read(root, "fixtures/schedules.json")["schedules"]}
    result = {}
    if scenario.get("schedule_refs"):
        result["schedule_results"] = {name: evaluate_schedule(schedules[name], processes[schedules[name]["process_ref"]], data, policy) for name in scenario["schedule_refs"]}
    if scenario.get("clock_cases"):
        result["clock_results"] = {}
        for row in scenario["clock_cases"]:
            anchor = instant(row["anchor"])
            value = shift_clock(anchor, row["minutes"], row["clock"], calendars, row.get("calendar_ref"), row["direction"])
            output = {"at": value.isoformat() if value else None, "elapsed_minutes": abs(minutes(anchor, value)) if value else None}
            if row.get("calendar_ref"):
                output["calendar_revision"] = calendars[row["calendar_ref"]]["revision"]
            if row.get("display_timezone") and value:
                local = value.astimezone(ZoneInfo(row["display_timezone"]))
                output.update(display_at=local.isoformat(), fold=local.fold)
            result["clock_results"][row["id"]] = output
    if scenario.get("lead_cases"):
        result["lead_results"] = {}
        for row in scenario["lead_cases"]:
            output = {"state": "unknown", "earliest_ready_at": None, "latest_ready_at": None, "latest_trigger_at": None, "selected_minutes": None}
            if row["source_available"] and row["minimum_minutes"] is not None and row["maximum_minutes"] is not None:
                anchor, deadline = instant(row["anchor"]), instant(row["deadline"])
                selected = row[policy["lead_time_selector"]]
                low = shift_clock(anchor, row["minimum_minutes"], row["clock"], calendars, row.get("calendar_ref"))
                high = shift_clock(anchor, row["maximum_minutes"], row["clock"], calendars, row.get("calendar_ref"))
                latest = shift_clock(deadline, selected, row["clock"], calendars, row.get("calendar_ref"), "backward")
                if low and high and latest:
                    output.update(state="known_range", earliest_ready_at=low.isoformat(), latest_ready_at=high.isoformat(), latest_trigger_at=latest.isoformat(), selected_minutes=selected)
            result["lead_results"][row["id"]] = output
    if scenario.get("invalid_cases"):
        result["input_results"] = {row["id"]: validate_process(row["process"]) for row in scenario["invalid_cases"]}
    if scenario.get("base_checks"):
        result["base_results"] = {row["id"]: base_check(row) for row in scenario["base_checks"]}
    if scenario.get("apply_cases"):
        result["apply_results"] = {row["id"]: project_apply(row) for row in scenario["apply_cases"]}
    return result
