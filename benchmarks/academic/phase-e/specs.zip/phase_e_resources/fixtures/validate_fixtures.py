#!/usr/bin/env python3
"""Portable fixture checks and targeted semantic corruption controls."""

import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True


def read(root, relative):
    return json.loads((Path(root) / relative).read_text(encoding="utf-8"))


def validate(root, verify_hashes=True):
    root = Path(root)
    checks = []

    def check(identifier, condition, detail):
        checks.append({"id": identifier, "passed": bool(condition), "detail": detail})

    def compare(actual, expected, path):
        if isinstance(expected, dict):
            if not isinstance(actual, dict):
                check(path, False, {"expected_type": "object", "observed": actual})
                return
            for key, value in expected.items():
                if key not in actual:
                    check(path + "." + key, False, "Missing expected output")
                else:
                    compare(actual[key], value, path + "." + key)
        else:
            check(path, actual == expected, {"expected": expected, "observed": actual})

    scenarios = read(root, "fixtures/scenarios.json")["scenarios"]
    expected = read(root, "fixtures/expected.json")["results"]
    controls = read(root, "fixtures/contract_controls.json")["controls"]
    check("inventory.scenarios", [row["id"] for row in scenarios] == [f"PHE-S{number:02d}" for number in range(1, 17)], "Sixteen agreed scenario identities")
    check("inventory.expected", set(expected) == {row["id"] for row in scenarios}, "Expected result for every scenario")
    check("inventory.controls", [row["id"] for row in controls] == [f"PHE-C{number:02d}" for number in range(1, 13)], "Twelve focused control groups")
    check("inventory.synthetic", all(row.get("synthetic") is True for row in scenarios), "All scenarios are labelled synthetic")
    policy = read(root, "fixtures/policy.json")
    check("execution.boundaries", all(value == 0 for value in policy["execution_counts"].values()), policy["execution_counts"])
    model = runpy.run_path(str(root / "fixtures/reference_resources.py"))
    for scenario in scenarios:
        path = "scenario." + scenario["id"]
        try:
            compare(model["evaluate"](root, scenario), expected[scenario["id"]], path)
        except Exception as error:
            check(path + ".evaluation", False, type(error).__name__ + " " + str(error))
    try:
        checks.extend(runpy.run_path(str(root / "fixtures/control_checks.py"))["run_controls"](root))
    except Exception as error:
        check("controls.evaluation", False, type(error).__name__ + " " + str(error))
    if verify_hashes:
        for record in read(root, "fixtures/index.json")["files"]:
            path = root / record["path"]
            data = path.read_bytes() if path.exists() else b""
            check("hash." + record["path"], path.is_file() and len(data) == record["bytes"] and hashlib.sha256(data).hexdigest() == record["sha256"], "Exact fixture data bytes")
        for record in read(root, "reference/provenance.json")["files"]:
            path = root / record["path"]
            data = path.read_bytes() if path.exists() else b""
            check("reference." + record["path"], path.is_file() and len(data) == record["bytes"] and hashlib.sha256(data).hexdigest() == record["sha256"], "Exact narrow Phase D contract copy")
    return checks


def negative_controls(root):
    """Disable hashes and require each corruption's named semantic failure."""
    root = Path(root)

    def find(rows, identifier):
        return next(row for row in rows if row["id"] == identifier)

    def step(data, process_id, step_id):
        return find(find(data["processes"], process_id)["steps"], step_id)

    def schedule(data, identifier):
        return find(data["schedules"], identifier)

    def scenario(data, identifier):
        return find(data["scenarios"], identifier)

    mutations = [
        ("passive_as_active", "fixtures/processes.json", lambda data: step(data, "TYPED", "run").update(mode="active"), "scenario.PHE-S01"),
        ("cleanup_omitted", "fixtures/processes.json", lambda data: step(data, "TYPED", "run").update(cleanup_minutes=0), "scenario.PHE-S01"),
        ("capacity_reduced", "fixtures/resources.json", lambda data: find(data["resources"], "RACK")["capacity"].update(quantity=1), "scenario.PHE-S02"),
        ("lead_lower_bound_used", "fixtures/policy.json", lambda data: data.update(lead_time_selector="minimum_minutes"), "scenario.PHE-S06"),
        ("expiry_weakened", "fixtures/processes.json", lambda data: find(data["processes"], "MAX-LAG")["dependencies"][0].update(maximum_lag_minutes=61), "scenario.PHE-S07"),
        ("business_opening_shifted", "fixtures/resources.json", lambda data: find(data["calendars"], "BUSINESS")["windows"][1].update(start_at="2026-11-02T10:00:00-05:00"), "scenario.PHE-S05"),
        ("stable_block_moved", "fixtures/schedules.json", lambda data: find(schedule(data, "stable")["candidates"], "keep-valid")["placements"][0].update(start_at="2026-11-09T09:20:00-05:00"), "scenario.PHE-S09"),
        ("started_base_removed", "fixtures/schedules.json", lambda data: schedule(data, "started").update(base_blocks=[]), "scenario.PHE-S13"),
        ("parent_phase_mismatch", "fixtures/processes.json", lambda data: find(data["processes"], "TYPED")["active_demand_mapping"].update(parent_remaining_minutes=60), "control.PHE-C01"),
        ("stale_resource_erased", "fixtures/scenarios.json", lambda data: scenario(data, "PHE-S14")["base_checks"][0]["current"].update(resource="1"), "scenario.PHE-S14"),
        ("provider_revision_corrupted", "fixtures/scenarios.json", lambda data: scenario(data, "PHE-S15")["apply_cases"][1]["operations"][0]["attempts"][0]["receipt"].update(provider_revision="corrupted"), "scenario.PHE-S15"),
        ("capacity_proof_unit_mismatch", "fixtures/schedules.json", lambda data: schedule(data, "capacity-proof")["capacity_certificate"].update(unit="different-unit"), "scenario.PHE-S16"),
    ]
    checks = []
    for identifier, relative, mutate, target in mutations:
        with tempfile.TemporaryDirectory(prefix="phase-e-negative-") as temporary:
            copied = Path(temporary)
            shutil.copytree(root / "fixtures", copied / "fixtures")
            shutil.copytree(root / "reference", copied / "reference")
            path = copied / relative
            data = json.loads(path.read_text(encoding="utf-8"))
            mutate(data)
            path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
            semantic_failures = [row["id"] for row in validate(copied, verify_hashes=False) if not row["passed"] and row["id"].startswith(target)]
            checks.append({"id": "negative." + identifier, "passed": bool(semantic_failures), "detail": {"target_prefix": target, "detected_by": semantic_failures[:5], "checksum_credit": False}})
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--negative-controls", action="store_true")
    parser.add_argument("--output")
    arguments = parser.parse_args()
    checks = validate(arguments.root)
    negatives = negative_controls(arguments.root) if arguments.negative_controls else []
    report = {"schema_version": "phase-e-fixture-validation.v1", "scope": "Local bounded synthetic reference evaluator", "check_count": len(checks), "passed_count": sum(row["passed"] for row in checks), "negative_control_count": len(negatives), "negative_control_passed_count": sum(row["passed"] for row in negatives), "checks": checks, "negative_controls": negatives, "actual_product_runs": 0, "actual_host_journeys": 0, "provider_calls": 0, "confirmed_provider_effects": 0}
    if arguments.output:
        Path(arguments.output).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key not in {"checks", "negative_controls"}}, indent=2))
    return 0 if all(row["passed"] for row in checks + negatives) else 1


if __name__ == "__main__":
    raise SystemExit(main())
