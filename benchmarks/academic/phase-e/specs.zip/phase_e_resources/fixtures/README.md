# Phase E synthetic fixtures

This fixture set provides sixteen scenarios, twelve focused control groups, eleven typed processes and thirteen bounded candidate packets. All process quantities and resource records are fictional coursework inputs.

## Run the local evaluator

From the extracted package root, run the following command with Python 3.11 or later and IANA America/New_York data available to `zoneinfo`.

```bash
python fixtures/validate_fixtures.py --negative-controls
```

The importable APIs are `validate(package_root, verify_hashes=True)` and `negative_controls(package_root)`. Both return lists of checks with `id`, `passed` and `detail`. `reference_resources.py` also exposes `evaluate(package_root, scenario)` and focused calculation functions.

The evaluator validates supplied placements. The independently authored expected JSON contains explicit arithmetic and state results. It is never generated from evaluator output. The twelve corruption controls disable checksum verification and require a named semantic failure for the affected scenario or control group.

## Inputs and outputs

| File | Role |
| --- | --- |
| `policy.json` | Explicit duration selector, time, capacity, buffer and bounded proof policies |
| `resources.json` | Named-unit resources and versioned access, running, occupancy and business calendars |
| `processes.json` | Current episodes, typed active or unattended work, setup, cleanup, divisibility, dependencies and supplies |
| `schedules.json` | Supplied placements, accepted block identities, availability, change observations and scoped certificates |
| `scenarios.json` | Sixteen fixed input combinations and the clock, revision and apply records |
| `expected.json` | Independently authored expected output subsets |
| `contract_controls.json` | Expected boundary states for twelve focused groups |
| `model_inputs/` | Three plain-text inputs for later native source-ingestion and host execution |

Selected schedule outputs retain active future minutes, full logical active minutes, passive elapsed minutes, dependency waiting, physical resource quantity-minutes, booking evidence, preserved blocks and Phase D churn. Actual-effort observations remain zero for every schedule calculation.

## Arithmetic conventions

Intervals are half-open. Elapsed calculations use UTC instants. Named local timezones, offsets and daylight-saving fold remain available for display. Resource quantities use exact decimal comparisons and exact unit names.

Each placement contains a setup phase, an active or unattended running phase and a cleanup phase. Resource occupancy covers the complete interval. Attended phases consume student availability and resource access. Running follows the machine running calendar. Continuous physical occupancy follows its occupancy calendar.

The maximum duration or lead-time endpoint is the default planning selector. Unknown duration, unavailable source evidence or an incomplete calendar horizon remains explicit. The business-clock fixture counts operating minutes over supplied windows. Day units require a declared calendar-specific rule in the active implementation.

A confirmed owned reservation supplies capacity once. Its full reserved quantity remains occupied, including any amount above the immediate process requirement. Observed availability, requested booking, tentative booking and cancellation keep separate evidence states. Required booking support can remain provisional while independent timing facts remain available.

A candidate with known hard feasibility ranks ahead of one whose operating calendar or other hard condition is unresolved. Booking-only conditional support retains its separate status within the known time-and-capacity tier. The inherited Phase D unmet-work and churn ordering then applies within that tier.

The Phase D active demand mapping associates one existing remaining-work scope with its phase partition. The 65-minute parent demand and its 65 minutes of constituent work contribute 65 combined minutes. A mismatch keeps the mapping unresolved until a supported scoped override or corrected partition resolves it.

Protected started blocks retain their original full interval. Future capacity and remaining-work credit use only the future remainder. A new historical placement cannot satisfy current work demand.

## Latest start and infeasibility

The serial-chain latest-start example has 30 active minutes, a 120-minute elapsed minimum lag and 45 active minutes. Its 13:15 deadline gives a 10:00 upper-bound start. Certification requires the supplied boundary witness to pass the same forward checker for student availability, resources, releases, precedence and protected values. Other bounded searches retain unresolved latest-start status.

The capacity certificate names its resource, exact unit, mandatory process subset and permitted horizon. A necessary demand of 180 station-minutes within a 120 station-minute horizon proves a 60 station-minute shortfall under the selected duration policy. Alternatives, duplicate membership or an undersized certificate horizon invalidate that proof. An unsuccessful supplied candidate set retains `no_feasible_schedule_found` when it lacks a supported certificate.

This whole-process certificate applies to unstarted future work. A started step needs a supported future-remainder quantity over the same capacity horizon. The bounded evaluator marks its whole-process certificate inapplicable for that case while preserving the valid ongoing schedule.

## Bounded coverage

These local checks cover one resource requirement per step, supplied complete-placement candidates and a fixed serial elapsed-chain latest-start proof. They use explicit input records and synthetic provider receipts. General simultaneous-resource selection, active repository adapters, prospective forecasting quality, transactional restarts, provider calls and ordinary host conversations require the package's product acceptance cases.

Divisible fixture work uses separate supplied placement segments with setup and cleanup accounted per segment. The candidate ranking control preserves the Phase D prioritized unmet vector and churn order. The compact complete-placement examples use an all-zero unmet vector after full demand validation.

The three exact Phase D contract copies under `reference/phase_d/` provide identity, protected-block, stable-replanning and partial-confirmation context. `reference/provenance.json` records their source paths, exact bytes and hashes. `index.json` hashes the fixture data and source descriptions. The root checksum manifest covers evaluator code.

Product runs, native host journeys, provider calls and confirmed provider effects are zero for this delivered specification set. Local fixture checks and local semantic corruption checks have their own execution counts.
