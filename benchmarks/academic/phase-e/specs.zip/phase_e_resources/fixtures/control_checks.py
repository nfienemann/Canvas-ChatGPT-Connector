#!/usr/bin/env python3
"""Twelve focused synthetic boundary groups with independent expected values."""

import copy
import json
import runpy
from pathlib import Path


def run_controls(root):
    root = Path(root)
    model = runpy.run_path(str(root / "fixtures/reference_resources.py"))
    read = model["read"]
    data = read(root, "fixtures/resources.json")
    policy = read(root, "fixtures/policy.json")
    processes = {row["id"]: row for row in read(root, "fixtures/processes.json")["processes"]}
    packets = {row["id"]: row for row in read(root, "fixtures/schedules.json")["schedules"]}
    scenarios = {row["id"]: row for row in read(root, "fixtures/scenarios.json")["scenarios"]}
    actual = {}

    def evaluate(name, packet=None, process=None, resource_data=None):
        packet = packet or packets[name]
        process = process or processes[packet["process_ref"]]
        return model["evaluate_schedule"](packet, process, resource_data or data, policy)

    def result(number):
        return model["evaluate"](root, scenarios[f"PHE-S{number:02d}"])

    typed = evaluate("typed")
    mapping = processes["TYPED"]["active_demand_mapping"]
    mismatch = copy.deepcopy(mapping)
    mismatch["parent_remaining_minutes"] = 60
    override = copy.deepcopy(mismatch)
    override.update(basis="explicit_phase_override", override_minutes=65, override_ref="SYNTHETIC-OVERRIDE/E1/v1")
    map_result = model["reconcile_active_demand"]
    actual["PHE-C01"] = {
        "active_minutes": typed["active_minutes"], "passive_minutes": typed["passive_elapsed_minutes"],
        "occupied_quantity_minutes": typed["resource_quantity_minutes"]["FORM-A|station"],
        "combined_remaining_minutes": typed["active_demand_mapping"]["combined_remaining_minutes"],
        "parent_additional_minutes": typed["active_demand_mapping"]["parent_additional_minutes"],
        "mismatch_state": map_result(mismatch, 65, {"prepare", "run", "finish"})["state"],
        "override_state": map_result(override, 65, {"prepare", "run", "finish"})["state"],
        "actual_observations": typed["actual_observations_created"],
    }

    wrong_unit = copy.deepcopy(data)
    next(row for row in wrong_unit["resources"] if row["id"] == "RACK")["capacity"]["unit"] = "station"
    unit_result = evaluate("capacity", resource_data=wrong_unit)
    unit_errors = unit_result["rejected_candidates"]["staggered-setup"]
    capacity_one = copy.deepcopy(data)
    next(row for row in capacity_one["resources"] if row["id"] == "RACK")["capacity"]["quantity"] = 1
    capacity_result = evaluate("capacity", resource_data=capacity_one)
    adjacent = model["overlaps"]((model["instant"]("2026-11-09T09:00:00-05:00"), model["instant"]("2026-11-09T10:00:00-05:00")), (model["instant"]("2026-11-09T10:00:00-05:00"), model["instant"]("2026-11-09T11:00:00-05:00")))
    fractional_process = copy.deepcopy(processes["CAPACITY-PROOF"])
    for step in fractional_process["steps"]:
        step["mode"] = "unattended"
        step["resource_requirement"]["quantity"] = 0.1
    fractional_data = copy.deepcopy(data)
    next(row for row in fractional_data["resources"] if row["id"] == "FORM-A")["capacity"]["quantity"] = 0.3
    fractional = evaluate("bounded-only", process=fractional_process, resource_data=fractional_data)
    actual["PHE-C02"] = {"adjacent_overlap": adjacent, "unit_mismatch_detected": "unit_mismatch" in unit_errors, "capacity_overflow_detected": "resource_capacity" in capacity_result["rejected_candidates"]["staggered-setup"], "cleanup_in_occupied_minutes": evaluate("capacity")["resource_quantity_minutes"]["RACK|tray"], "exact_decimal_capacity_status": fractional["status"]}

    closed_run = copy.deepcopy(packets["typed"])
    closed_run["calendar_additions"] = [{"id": "CLOSED-RUN", "revision": "2", "timezone": "America/New_York", "windows": [{"start_at": "2026-11-09T09:00:00-05:00", "end_at": "2026-11-09T10:00:00-05:00"}]}]
    closed_run["resource_patches"] = {"FORM-A": {"run_calendar_ref": "CLOSED-RUN"}}
    closed_result = evaluate("typed", packet=closed_run)
    buffered = copy.deepcopy(packets["stable"])
    buffered.update(buffer_minutes=5, base_blocks=[], student_windows=[{"start_at": "2026-11-09T09:00:00-05:00", "end_at": "2026-11-09T10:00:00-05:00"}])
    buffered["candidates"] = [copy.deepcopy(packets["stable"]["candidates"][1])]
    shorter = copy.deepcopy(processes["STABLE"])
    shorter["steps"][0]["run_duration"].update(minimum_minutes=55, maximum_minutes=55)
    buffer_result = evaluate("stable", packet=buffered, process=shorter)
    actual["PHE-C03"] = {"unattended_outside_student_windows": typed["status"], "closed_machine_rejected": "outside_run_calendar" in closed_result["rejected_candidates"]["typed-valid"], "buffered_55_minute_fit": buffer_result["status"], "buffered_active_minutes": buffer_result["active_minutes"], "passive_minutes_unchanged": typed["passive_elapsed_minutes"]}

    lead = result(6)["lead_results"]
    calendars = {row["id"]: row for row in data["calendars"]}
    out_of_horizon = model["shift_clock"](model["instant"]("2026-11-02T17:00:00-05:00"), 1, "operating_minutes", calendars, "BUSINESS")
    day_unit = model["shift_clock"](model["instant"]("2026-11-02T09:00:00-05:00"), 1, "business_days", calendars, "BUSINESS")
    actual["PHE-C04"] = {"selected_lead_minutes": lead["range"]["selected_minutes"], "missing_source_state": lead["source-unavailable"]["state"], "calendar_horizon_unknown": out_of_horizon is None, "undeclared_business_day_unknown": day_unit is None, "fallback_elapsed_minutes": result(5)["clock_results"]["business-forward"]["elapsed_minutes"]}

    unavailable_witness = copy.deepcopy(packets["chain"])
    unavailable_witness["student_windows"] = [{"start_at": "2026-11-09T10:15:00-05:00", "end_at": "2026-11-09T13:15:00-05:00"}]
    witness_result = evaluate("chain", packet=unavailable_witness)
    early = copy.deepcopy(packets["max-lag"])
    early["candidates"] = [copy.deepcopy(early["candidates"][0])]
    early["candidates"][0]["placements"][1]["start_at"] = "2026-11-09T10:29:00-05:00"
    early_result = evaluate("max-lag", packet=early)
    actual["PHE-C05"] = {"max_lag_boundary_status": evaluate("max-lag")["status"], "below_minimum_rejected": "minimum_lag" in early_result["rejected_candidates"]["inclusive-boundary"], "forward_invalid_latest_status": witness_result["latest_start"]["status"], "valid_latest_status": evaluate("chain")["latest_start"]["status"]}

    split = copy.deepcopy(packets["stable"])
    split["base_blocks"] = []
    first = copy.deepcopy(split["candidates"][1]["placements"][0])
    first.update(placement_id="stable-work/part-1", run_minutes=30)
    second = copy.deepcopy(first)
    second.update(placement_id="stable-work/part-2", start_at="2026-11-09T10:00:00-05:00")
    split["candidates"] = [{"id": "split", "placements": [first, second]}]
    indivisible = evaluate("stable", packet=split)
    divisible = copy.deepcopy(processes["STABLE"])
    divisible["steps"][0]["divisible"] = True
    split_result = evaluate("stable", packet=split, process=divisible)
    unknown_occupancy = copy.deepcopy(processes["TYPED"])
    unknown_occupancy["steps"][1]["occupancy_policy"] = "unknown"
    actual["PHE-C06"] = {"indivisible_split_rejected": "indivisible_split" in indivisible["rejected_candidates"]["split"], "divisible_split_status": split_result["status"], "divisible_active_minutes": split_result["active_minutes"], "unknown_occupancy_status": evaluate("typed", process=unknown_occupancy)["status"], "cycle_errors": result(8)["input_results"]["cycle"]["errors"]}

    booking_states = {}
    for state in ["requested", "tentative", "cancelled"]:
        packet = copy.deepcopy(packets["booking"])
        packet["resource_patches"]["FORM-A"]["reservations"][0]["status"] = state
        booking_states[state] = evaluate("booking", packet=packet)["status"]
    observed = copy.deepcopy(packets["booking"])
    observed["resource_patches"]["FORM-A"]["reservations"] = []
    full_reservation = copy.deepcopy(packets["booking"])
    full_reservation["resource_patches"]["FORM-A"]["capacity"] = {"quantity": 2, "unit": "station"}
    full_reservation["resource_patches"]["FORM-A"]["reservations"][0]["quantity"] = 2
    second_process = copy.deepcopy(processes["BOOKING"])
    second_step = copy.deepcopy(second_process["steps"][0])
    second_step.update(id="other-use", mode="unattended")
    second_step["resource_requirement"]["booking_required"] = False
    second_process["steps"].append(second_step)
    other = copy.deepcopy(full_reservation["candidates"][0]["placements"][0])
    other.update(placement_id="other-use", step_id="other-use")
    other.pop("booking_id")
    full_reservation["candidates"][0]["placements"].append(other)
    reservation_result = evaluate("booking", packet=full_reservation, process=second_process)
    unknown_candidate = copy.deepcopy(packets["failure"])
    unknown_candidate["resource_patches"]["FORM-A"].update(unavailable=[], run_calendar_ref="MISSING-RUN")
    unknown_candidate["candidates"][1]["placements"][0]["start_at"] = "2026-11-09T11:00:00-05:00"
    hard_choice = evaluate("failure", packet=unknown_candidate)
    conditional = copy.deepcopy(packets["booking"])
    conditional["base_blocks"] = [{"id": "booked-work/active", "step_id": "booked-work", "episode_id": "E1", "start_at": "2026-11-09T09:00:00-05:00", "end_at": "2026-11-09T10:00:00-05:00"}]
    conditional["resource_patches"]["FORM-A"]["reservations"][0]["status"] = "requested"
    conditional["candidates"][0]["id"] = "conditional-keep"
    confirmed_alternative = copy.deepcopy(conditional["candidates"][0])
    confirmed_alternative["id"] = "confirmed-move"
    confirmed_alternative["placements"][0].update(start_at="2026-11-09T11:00:00-05:00", resource_id="FORM-B", booking_id="BOOK-2")
    conditional["candidates"].append(confirmed_alternative)
    booking_alternative = copy.deepcopy(conditional["resource_patches"]["FORM-A"]["reservations"][0])
    booking_alternative.update(id="BOOK-2", status="confirmed", start_at="2026-11-09T11:00:00-05:00", end_at="2026-11-09T12:00:00-05:00")
    conditional["resource_patches"]["FORM-B"] = {"reservations": [booking_alternative]}
    conditional_process = copy.deepcopy(processes["BOOKING"])
    conditional_process["steps"][0]["resource_requirement"]["resource_ids"].append("FORM-B")
    booking_choice = evaluate("booking", packet=conditional, process=conditional_process)
    actual["PHE-C07"] = {"confirmed_own_booking_status": evaluate("booking")["status"], "observed_only_status": evaluate("booking", packet=observed)["status"], "pending_statuses": booking_states, "larger_owned_reservation_retained": "resource_capacity" in reservation_result["rejected_candidates"]["booking-confirmed"], "hard_unknown_winner": hard_choice["selected_candidate_id"], "booking_conditional_winner": booking_choice["selected_candidate_id"]}

    completed = copy.deepcopy(processes["STABLE"])
    completed["steps"][0]["scope_state"] = "completed"
    empty = copy.deepcopy(packets["stable"])
    empty["base_blocks"] = []
    empty["candidates"] = [{"id": "completed-empty", "placements": []}]
    complete_result = evaluate("stable", packet=empty, process=completed)
    recurrence = evaluate("recurrence")
    past = copy.deepcopy(packets["stable"])
    past["base_blocks"] = []
    past["candidates"] = [copy.deepcopy(past["candidates"][1])]
    past["candidates"][0]["placements"][0]["start_at"] = "2026-11-09T07:00:00-05:00"
    past_result = evaluate("stable", packet=past)
    actual["PHE-C08"] = {"completed_active_minutes": complete_result["active_minutes"], "completed_actual_observations": complete_result["actual_observations_created"], "reopened_current_minutes": recurrence["active_minutes"], "retained_historical_episodes": recurrence["historical_episode_ids"], "stale_episode_state": result(12)["base_results"]["episode-changed"]["status"], "unsupported_past_rejected": "unsupported_past_placement" in past_result["rejected_candidates"]["keep-valid"]}

    started = evaluate("started")
    block = started["blocks"][0]
    actual["PHE-C09"] = {"full_active_minutes": started["full_active_minutes"], "future_active_minutes": started["active_minutes"], "future_resource_quantity_minutes": started["future_resource_quantity_minutes"]["FORM-A|station"], "original_start_at": block["start_at"], "protected_conflict_status": evaluate("started-conflict")["status"], "actual_observations": started["actual_observations_created"]}

    base = copy.deepcopy(packets["stable"]["base_blocks"])
    retained = copy.deepcopy(base)
    retained[0].update(start_at="2026-11-09T09:30:00-05:00", end_at="2026-11-09T10:15:00-05:00")
    changed = model["churn"](base, retained)
    low = {"id": "keep", "prioritized_unmet_vector": [30, 0], "churn": {"changed_existing_block_count": 0, "absolute_start_displacement_minutes": 0, "absolute_duration_change_minutes": 0}}
    high = {"id": "serve-priority", "prioritized_unmet_vector": [0, 30], "churn": {"changed_existing_block_count": 1, "absolute_start_displacement_minutes": 60, "absolute_duration_change_minutes": 0}}
    removed = model["churn"](base, [])
    actual["PHE-C10"] = {"kept_candidate": evaluate("stable")["selected_candidate_id"], "moved_resized_changed_count": changed["changed_existing_block_count"], "moved_minutes": changed["absolute_start_displacement_minutes"], "matched_duration_change_minutes": changed["absolute_duration_change_minutes"], "removed_duration_change_minutes": removed["absolute_duration_change_minutes"], "priority_winner": min([low, high], key=model["candidate_key"])["id"]}

    apply = result(15)["apply_results"]
    duplicate = copy.deepcopy(scenarios["PHE-S15"]["apply_cases"][1])
    duplicate["operations"].append(copy.deepcopy(duplicate["operations"][1]))
    replay = model["project_apply"](duplicate)
    actual["PHE-C11"] = {"partial_state": apply["partial"]["status"], "partial_fully_applied": apply["partial"]["fully_applied_objects"], "recovered_state": apply["recovered"]["status"], "replay_effect_count": replay["confirmed_effect_count"], "reconciled_without_create": apply["recovered"]["reconciled_without_create_count"], "confirmed_calendar_revision": apply["recovered"]["fully_applied_objects"]["EVENT-1"]["provider_revision"], "stale_axes": [row["changed_axes"][0] for row in result(14)["base_results"].values()], "actual_provider_calls": replay["actual_provider_calls"]}

    alternative = copy.deepcopy(processes["CAPACITY-PROOF"])
    alternative["steps"][0]["resource_requirement"]["resource_ids"].append("FORM-B")
    alternative_result = evaluate("capacity-proof", process=alternative)
    outside_scope = copy.deepcopy(packets["capacity-proof"])
    outside_scope["deadline_at"] = "2026-11-09T12:00:00-05:00"
    outside_scope["calendar_additions"][0]["windows"][0]["end_at"] = "2026-11-09T12:00:00-05:00"
    outside_result = evaluate("capacity-proof", packet=outside_scope)
    started_proof = copy.deepcopy(packets["started"])
    started_proof["deadline_at"] = "2026-11-09T10:00:00-05:00"
    started_proof["capacity_certificate"] = {"resource_id": "FORM-A", "step_ids": ["started-work"], "window": {"start_at": "2026-11-09T09:30:00-05:00", "end_at": "2026-11-09T10:00:00-05:00"}, "unit": "station"}
    started_proof_result = evaluate("started", packet=started_proof)
    actual["PHE-C12"] = {"proved_status": evaluate("capacity-proof")["status"], "proved_shortfall": evaluate("capacity-proof")["capacity_certificate"]["shortfall_quantity_minutes"], "bounded_status": evaluate("bounded-only")["status"], "alternative_invalidates_proof": alternative_result["capacity_certificate"]["valid"] is False, "outside_window_invalidates_proof": outside_result["capacity_certificate"]["valid"] is False, "started_whole_process_proof_inapplicable": started_proof_result["capacity_certificate"]["valid"] is False, "started_future_plan_status": started_proof_result["status"]}

    checks = []
    controls = read(root, "fixtures/contract_controls.json")["controls"]

    def compare(observed, expected, path):
        if isinstance(expected, dict):
            for key, value in expected.items():
                if key not in observed:
                    checks.append({"id": path + "." + key, "passed": False, "detail": "Missing observed key"})
                else:
                    compare(observed[key], value, path + "." + key)
        else:
            checks.append({"id": path, "passed": observed == expected, "detail": {"expected": expected, "observed": observed}})

    for control in controls:
        compare(actual[control["id"]], control["expected"], "control." + control["id"])
    return checks
