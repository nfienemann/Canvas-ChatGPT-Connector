# Synthetic process notes

Every duration and resource below is a fictional coursework planning input. These notes describe scheduling quantities for a generic prototype exercise.

## Prototype sequence

The current work episode is E1. Preparation takes 30 minutes of active student work. A generic forming run has 10 minutes of attended setup, 120 minutes of unattended running and 5 minutes of attended cleanup. Finishing takes 20 minutes of active student work.

Preparation finishes before setup begins. The station remains occupied through setup, running and cleanup. Finishing begins after cleanup. Total active work is 65 minutes. The run contributes 120 passive elapsed minutes and the station is occupied for 135 minutes.

The existing Phase D remaining-work scope assigns 65 active minutes to this episode. The phase partition accounts for that same scope once. The schedule records intended work. It supplies no observed actual-effort measurement.

## Separate lead-time example

A fictional material preparation delay ranges from 60 to 180 elapsed minutes. The planning default selects 180 minutes and retains both endpoints. A release at 09:00 therefore has a ready window from 10:00 to 12:00. A required ready time of 15:00 implies a latest trigger of 12:00 under that upper-bound policy.

Another lead-time source is intentionally unavailable. Its duration and latest trigger remain unresolved. Independent known process and resource facts stay usable.

## Freshness example

A fictional prepared component may be used between 30 and 60 minutes after preparation finishes. The maximum is inclusive. Both endpoints refer to elapsed instants from predecessor finish to successor start. The sample preparation ends at 10:00. Starting use at 11:00 is admissible. Starting at 11:01 exceeds the declared window.
