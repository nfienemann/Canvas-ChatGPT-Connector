# Synthetic resource and availability notes

## Forming stations

FORM-A and FORM-B each provide one named station unit and share the explicit capability generic_forming. The current process explicitly permits either resource in the equipment-failure scenario. INCOMPATIBLE supplies generic_imaging and is outside that permitted alternative set.

Attended access and unattended running have separate calendars. Resource occupancy is continuous through the setup, running and cleanup phases. A student can leave during unattended running when the declared machine running and occupancy calendars permit the interval. Student availability applies to attended work.

The default November 9 access window is 08:00 through 18:00 in America/New_York. The machine running and occupancy windows cover 00:00 through 23:59 that day. These finite windows are explicit fixture horizons.

## Rack capacity

RACK has two tray units. Each fictional job consumes one tray during its complete setup, running and cleanup interval. A job uses 10 minutes for setup, 60 for unattended running and 10 for cleanup. Staggering starts at 09:00 and 09:10 permits the attended portions to alternate. Each tray remains occupied for 80 minutes.

All intervals are half-open. One resource occupancy ending at 10:00 and another starting at 10:00 are adjacent. Exact named unit matching applies. Decimal quantities use exact decimal arithmetic for capacity comparisons.

## Operating lead-time calendar

Calendar BUSINESS revision 1 uses America/New_York. It opens Friday October 30, 2026 from 09:00 through 17:00 and Monday November 2 from 09:00 through 17:00. Other intervals in the supplied horizon are closed.

Starting at Friday 16:00 and counting 120 operating minutes reaches Monday 10:00. The weekend crosses the daylight-saving fall-back transition, producing 4,020 elapsed UTC minutes. The supplied horizon ends Monday at 17:00. A longer calculation extending past the supplied horizon stays unresolved.

Student buffering uses the Phase D end-only-per-supplied-window policy. The buffer is applied once to each student window. Setup, cleanup and declared interblock breaks keep their separate quantities.
