# Synthetic change and recovery notes

## Equipment and supplies

The accepted plan has a flexible work block from 09:00 through 10:00 and a protected unrelated block from 13:00 through 13:30. FORM-A becomes unavailable from 09:00 through 11:00. FORM-B is an explicitly compatible alternative. Moving the resource assignment to FORM-B preserves both student block intervals.

A separate supply revision changes the material ready time from 09:00 to 11:00. Its 60-minute work block can move to 11:00 through 12:00 under the current noon deadline. The same logical block identity survives this move.

## Revision and started work

Episode E1 was completed with 30 active minutes. A changed requirement opens E2 with 45 active minutes of current work. The completed episode remains historical. A proposal based on E1 requires rebasing to E2.

A separate protected block originally spans 09:00 through 10:00. At a 09:30 planning boundary, its full logical interval remains 60 minutes and its future occupied remainder is 30 minutes. An outage beginning at 09:45 creates an explicit conflict with this protected commitment.

## Partial provider confirmation

Accepted local plan revision 4 has one calendar move and one reservation operation. MOVE-1 has a confirmed receipt for EVENT-1 at provider revision c2. RESERVE-1 has an outcome-unknown response. The current result retains one confirmed effect and one unresolved logical operation.

After a synthetic restart, receipt reconciliation finds RESERVATION-1 at provider revision r2 under the same logical operation identity. The recovered projection contains both actual confirmed revisions. The reconciliation contributes one confirmed reservation effect without a duplicate create.

These records are supplied fixture data. Provider calls, product runs and native host journeys are zero during specification preparation.
