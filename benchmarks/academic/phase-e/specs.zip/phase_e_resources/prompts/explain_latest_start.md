# Explain the latest useful start

Using the current resource-aware plan, how late can I start the preparation and still meet the deadline? Account for the stated waiting time, equipment windows, setup and cleanup. Show the source of the timing values and whether the result is an exact bound or the best supported option from the evaluated choices.
