# Repair changed equipment or supply access

The supplied update changes the equipment slot or supply arrival for this assignment. Reconcile it with the current work and accepted plan, keep useful commitments, and repair the affected sequence. Show what moved and why, any current blocker, and whether an explicitly compatible alternative helps.
