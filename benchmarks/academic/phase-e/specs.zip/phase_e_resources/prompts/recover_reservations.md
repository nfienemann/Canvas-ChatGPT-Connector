# Retrieve and recover the current plan

Retrieve the latest saved plan and the results of the interrupted resource and calendar update. Show the reservations and study blocks that are confirmed, the operations still unresolved, and the next step supported by the current workflow. Use the existing operation identities when reconciling the interrupted result.
