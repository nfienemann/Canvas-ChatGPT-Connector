# Plan the current sequence

Use the supplied synthetic coursework, current work episode, resource calendars and reservation records. Plan the remaining lab or studio sequence around my available study time. Show when I need to be present, what can run while I do other work, and which preparation or supply actions need an earlier start. Keep my current protected blocks. Tell me which equipment slots are confirmed and which still depend on booking.
