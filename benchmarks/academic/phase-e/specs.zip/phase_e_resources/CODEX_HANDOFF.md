# Phase E implementation handoff

Implement the five PHE specifications against the active A–D and Stage 6 build. The user has accepted Stage 5 as complete. Current source, state, calendar and intent behavior supplies the operating baseline.

## 1. Bind the current build

Read repository instructions. Record branch, commit, dirty diff fingerprint, runtime, host and actual schemas in `templates/active_build_bindings.json`. Resolve the pinned source map to current routes and symbols. Credit already-supported requirements with executed evidence from that build.

Existing `ProcessScope.resource_ids` identifies source documents/work. Introduce a typed physical-resource association through the existing model seam. Existing `Effort` and `WorkEstimate` require positive active minutes. Zero wait and completed remaining demand belong in typed phase or current eligibility records.

Bind Phase C work episodes and requirement/artifact versions, Phase D forecasts and protected blocks, process DAG/feasibility, current persistence and provider receipts before adding storage or routes.

## 2. Represent the process and its evidence

Implement `PHE-01` using `contracts/resource_process_contract.json`.

Represent student attendance, elapsed process time, operating-clock waits and physical resource occupancy independently. Bind named active phases to one scoped Phase D demand as a declared partition or supported override. Include setup and cleanup exactly once in the relevant labor and occupancy totals.

Resources have stable identity, exact capacity units, operating/access calendars, coverage horizon and supported reservation operations. Confirmed reservations link the exact quantity, interval, owner scope and current provider or supplied confirmation evidence. Normalize aliases before counting demand.

Use named dependency milestones and explicit lag clocks. Preserve range bounds, source/knowledge time and selected bound. Missing calendars, ambiguous business-day rules and unknown quantities remain attributable to the affected decision.

## 3. Extend feasibility and latest-start planning

Implement `PHE-02` with one selected engine and named time/buffer policy. The existing planner and process simulator differ in buffering. Bind the chosen policy consistently and apply it once.

Validate attended intervals against student availability and facility access. Validate physical occupancy against capacity and run windows. Keep indivisible operations continuous. Retain the entire own booking and absorb covered linked use once. Check all linked claims against its interval and simultaneous quantity, preserving residual reserved capacity.

Use the upper bound as the initial reference choice for known ranges. Advance elapsed waits in UTC and operating-minute waits through their versioned calendars. Evaluate minimum and maximum lag at the named endpoints.

A latest-start claim requires the same constraints as forward checking. Retain its exact proof scope or bounded candidate scope. Use supported capacity certificates and explicit contradictions for infeasibility, and retain search limits where applicable.

## 4. Repair affected commitments

Implement `PHE-03` through Phase C change impact and Phase D stable repair. Preserve a valid covering accepted plan. Compare prioritized service before churn. Keep logical block/allocation identities across supported moves and retain split/merge parentage.

Exercise downtime, compatible alternate equipment, late supply, lost booking, changed work episodes and unavailable sources. Recompute the affected dependency closure. Protect current locks, started blocks and applicable student edits.

For a started block, preserve the full logical/provider interval while reserving and crediting only its future remainder in future student planning. Physical occupancy follows its actual state. A conflicting protected block retains an explicit conflict result and the current resolution workflow.

## 5. Integrate and recover operations

Implement `PHE-04` using current Stage 5 and Phase D behavior. Persist one coherent local generation with expected bases and operation intent. Track reservation and study-calendar effects individually with stable logical operation and attempt IDs.

Bind actual resource-provider capabilities. A resource with observation-only support can produce a concrete reservation requirement and consume a supplied scoped confirmation. Actual booking operations use the current supported adapter and its receipts.

Reconcile uncertain creates before replay. Recover partial results after restart. Recheck current work, plan, calendar and provider revisions during apply or compensation, preserving later user edits. Report confirmed state and pending operations from the saved generation.

Produce a concrete ordinary answer with attended sessions, waiting periods, equipment, advance actions, latest-start support and current access status. Keep detailed traces inspectable through current evidence fields.

## 6. Execute acceptance and close the packet

Run local package and fixture validation, then all 28 scoped cases against the current implementation. Use the execution capture contract, eight measures and ten host checks. Preserve exact current requests, tool responses, selected plans, before/after state, restarts, receipts and final answers.

Run focused existing process/DAG/feasibility/planning/state/calendar tests plus applicable A–D and Stage 6 cases. Record each execution boundary and keep failed, blocked and pending cases visible. Regression comparisons identify the earlier executed baseline.

Fill `templates/implementation_report.json` with actual results. Deliver the minimal implementation diff, active mapping, reproducible commands, captures and outstanding scoped gaps.

E completion includes a versioned `contracts/phase_f_handoff.json` example validated by a minimal contract consumer. The implemented Phase F workflow consumes the same current interface during F acceptance.

## Queue order

Finish A, B, C, D and E in that order before starting the Phase F archive. Each set uses the current upstream implementation and the previous set's completed report. This archive is the E work item in that sequence.
