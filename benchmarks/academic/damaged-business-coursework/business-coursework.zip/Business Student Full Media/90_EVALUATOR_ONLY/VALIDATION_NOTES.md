# Validation and test boundaries

The collection contains 6 fictional courses, 48 detailed assessments, 3,338 records in 14 primary datasets, and 73 evaluator scenarios (64 course scenarios and 9 optional edge cases).

Source identifiers, assignment references, 16-week schedules, rubric totals, grade weights, timezone offsets, dataset widths and dictionary coverage were checked. Accounting transactions and statement totals reconcile. Marketing rates, operations counts, survey missingness, strategy scores and finance scenario controls were independently calculated during authoring. Missing numeric grades remain distinct from posted zero scores.

The 6 workbooks contain 386 formula cells across 26 sheets. Each workshop was tested by changing an input, observing dependent calculations, and restoring the input. All saved formula cells had non-error cached values. Non-additive sums are explicitly unavailable instead of being presented as business totals. Source dates are typed spreadsheet dates.

The 6 editable decks have 84 slides. Their XML packages, geometry and round-trip import were checked; the PDF copies were produced from the final PPTX files. PDFs, slides, Word report pages, figures and workbook previews received visual review. Opt-in scanned schedules intentionally have no text layer.

These checks establish properties of the delivered files. They do not establish that CanvasBridge has imported or successfully processed them. Run the included prompts against the selected imports, keep the evaluator folder out of that input selection, and compare actual results with expected outcomes. Native desktop Microsoft Office was not used.

The included portable JSON is a fixture schema, not a claimed `independent-academic-1` API contract. Use the TXT source companions when testing ordinary source-grounded reading. No file in this collection is an application authorization record.
