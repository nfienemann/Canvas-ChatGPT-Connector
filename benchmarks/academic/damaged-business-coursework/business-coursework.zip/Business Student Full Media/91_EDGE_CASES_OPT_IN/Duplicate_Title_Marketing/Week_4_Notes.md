# Week 4 Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID EDGE-TITLE-MARKETING

In this Marketing source, conversion rate is converted visits divided by assigned visits. A matching filename does not imply matching contents or course identity.
