# Week 4 Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID EDGE-TITLE-OPERATIONS

In this Operations source, fill rate is demand units filled immediately divided by demanded units. A matching filename does not imply matching contents or course identity.
