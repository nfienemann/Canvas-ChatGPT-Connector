# Optional source handling fixtures

These files intentionally exercise incomplete evidence, scanned content, repeated names, ambiguous dates, grade states and embedded instruction text. They are separate from the ordinary course library. Import only the fixture you intend to test and its needed comparison source. Expected outcomes are in the evaluator folder.

The scanned PDFs contain rasterized schedule pages with no text layer. The long supplier catalog is synthetic source material, not an external quotation or purchase authorization. Nothing in this folder grants application access or academic-assistance permission.
