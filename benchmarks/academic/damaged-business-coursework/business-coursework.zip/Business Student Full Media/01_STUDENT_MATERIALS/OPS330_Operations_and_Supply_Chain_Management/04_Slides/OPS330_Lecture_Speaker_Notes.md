# Operations and Supply Chain Management Lecture Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Slide 1 is the cover. These notes accompany the editable deck and its PDF.

## Slide 2 Process boundaries and flow units

An operations analysis begins by identifying the process, the flow unit and the boundary. In a repair cell, the flow unit might be one backpack repair job. The boundary might begin when the item is accepted and end when it is ready for return. If another analyst begins the clock when a technician starts work, the two turnaround measures answer different questions. Neither is automatically wrong, but comparing them without a definition produces a misleading claim. State whether waiting, transport, inspection and rework are included. Map the sequence before calculating capacity. Lumen Trail's teaching cell has intake, repair and inspection. Intake verifies the request and records the item. Repair performs the work. Inspection checks the result before release. A process map should identify queues and routing choices as well as activities. A job that returns from inspection to repair consumes additional work. Ignoring that loop understates required capacity. The course's initial capacity example deliberately excludes rework to establish a baseline, then asks students to examine the limitation.

- Define when the repair clock starts and ends
- One job is the baseline flow unit
- Include queues and rework in the process map

## Slide 3 Stage capacity and bottlenecks

For a resource with a fixed available time, theoretical capacity is available time divided by processing time per unit. If one intake worker has four hundred twenty usable minutes per day and needs six minutes per job, intake can process seventy jobs per day under the stated assumptions. One repair technician needing eighteen minutes per job can process about twenty-three and one-third jobs. Inspection at six minutes per job can again process seventy. The smallest stage capacity constrains the line when each job visits each stage once. The bottleneck is therefore repair in this baseline. Adding an intake worker does not raise the line's theoretical throughput while repair remains constrained. Two repair technicians provide eight hundred forty repair minutes and a theoretical capacity of about forty-six and two-thirds jobs per day, assuming they can work in parallel without sharing another limiting resource. That assumption should be checked. A single specialized sewing machine, restricted workspace or required supervisor approval can prevent labor capacity from translating into system capacity.

- Capacity equals usable time divided by work per unit
- The baseline repair stage is the bottleneck
- Extra nonbottleneck labor may not raise throughput

## Slide 4 Utilization and planning reserve

Utilization compares flow or workload with available capacity for the same period and unit. At forty jobs per day, the two-technician repair stage would use forty divided by forty-six and two-thirds, about eighty-five point seven percent of its theoretical capacity. This ratio does not guarantee a three-day turnaround. Arrival variation, repair complexity and unplanned interruptions can create queues even when average demand is below average capacity. A resource that is exactly fully utilized on average has no room to absorb a temporary surge without delay. Available minutes should be defined carefully. If the four hundred twenty minutes already exclude breaks, subtracting the same break time again double-counts it. A separate planning reserve for variability is a different assumption and should be labeled. Reserving fifteen percent of the two technicians' usable time leaves seven hundred fourteen minutes, enough for about thirty-nine point seven eighteen-minute jobs. That is slightly below the forty-job planning demand. This does not prove that the reserve is correct; it shows why apparently comfortable average capacity can become tight under a more cautious operating assumption.

- Two repair technicians provide 840 usable minutes
- Forty jobs use 720 repair minutes
- A separate 15 percent reserve leaves 714 minutes

## Slide 5 Flow time and work in process

Little's Law relates average work in process, average throughput and average flow time when the system is stable and the measurements use consistent boundaries. If a stable process completes forty jobs per day and average flow time is three days, average work in process is one hundred twenty jobs. The law is an accounting relationship, not a prescription to create more inventory. If arrivals persistently exceed completions, work in process grows and a single stable average is not an adequate description. Do not substitute active touch time for total flow time. A job requiring eighteen minutes of repair work may spend several days in a queue, in transport or awaiting inspection. The completed-job file records both touch minutes and elapsed turnaround days for this reason. It also omits still-open work. A mean computed only among completed jobs can look good while difficult unfinished jobs accumulate. A sound recommendation pairs capacity arithmetic with a current queue census and a definition of the service promise. The calculations guide investigation; they do not replace observation of the whole process.

- Use consistent process boundaries
- Touch time differs from elapsed flow time
- Stable averages are required for Little's Law

## Slide 6 Cycle stock and safety stock

Inventory can buffer the timing difference between supply and demand, but it also uses cash, space and handling effort. The appropriate policy depends on the item, the replenishment process and the cost of being wrong. A repair kit that prevents many jobs from starting can have high operational importance despite a modest purchase price. Conversely, stocking a rarely used specialized part may tie up resources for months. Define the service consequence of a shortage rather than treating every unit of inventory as equally valuable or equally wasteful. Distinguish cycle stock from safety stock. Cycle stock arises because replenishment occurs in batches. Safety stock responds to uncertainty in demand, lead time or both. Ordering more frequently can reduce average cycle stock while increasing ordering effort or transportation cost. It does not necessarily solve supplier unreliability. A model that combines these effects should state which costs are included and which constraints are ignored. The introductory formulas in this course are decision aids under explicit assumptions, not universal instructions for every supply chain.

- Batch ordering creates cycle stock
- Uncertainty motivates safety stock
- Service consequences differ across items

## Slide 7 Economic order quantity

The basic economic order quantity balances annual ordering cost with annual holding cost. With annual demand D, ordering cost S per order and annual holding cost H per unit, the model's order quantity is the square root of two times D times S divided by H. In the case, the stipulated planning inputs are twelve thousand four hundred eighty kits per year, forty-two dollars per order and six dollars per kit per year. All units must be consistent. Dividing by a monthly holding cost while using annual demand would produce an incorrect quantity. The formula assumes a simplified setting with known average demand, fixed order cost, constant per-unit holding cost and no binding quantity constraints. Purchase discounts, minimum order quantities, perishability and storage capacity can change the choice. The calculated quantity is usually not a practical integer or carton multiple. Compare feasible rounded alternatives using the same cost model rather than treating the decimal answer as operationally sacred. Report the model quantity, the selected feasible quantity and any reason the selected amount differs.

- Keep annual demand and holding units consistent
- The basic model balances ordering and holding costs
- Check carton sizes and other real constraints

## Slide 8 Reorder point and lead-time uncertainty

A reorder point asks when to place an order. Under a continuous-review teaching model, inventory position includes on-hand stock plus on-order stock minus backorders. Using only on-hand units can trigger duplicate replenishment when a large order is already in transit. Expected lead-time demand is mean daily demand multiplied by mean lead time, provided both use the same day convention. A calendar-day lead time cannot be mixed silently with working-day demand. State whether the process operates every day or only on scheduled workdays. For independent day-to-day demand and independent variable lead time, a common approximation uses mean lead time times demand variance plus squared mean demand times lead-time variance as the variance of lead-time demand. The case supplies forty-eight kits per working day, a daily standard deviation of twelve, a five-working-day mean lead time and a two-working-day lead-time standard deviation for this scenario. Multiply the resulting standard deviation by the stated service factor, 1.65, to obtain modeled safety stock. Add expected lead-time demand to obtain the modeled reorder point.

- Use inventory position, including open orders
- Keep working and calendar days distinct
- Unknown receipt times remain unknown

## Slide 9 Demand and censored sales

A forecast is an estimate of future demand conditional on available information and a method. It is not a commitment that demand will equal the point estimate. Operations planning often needs a range or a set of plausible demand conditions because the cost of too much capacity differs from the cost of too little. Begin with the planning horizon and the decision. Staffing next week, ordering a long-lead part and buying a machine require different horizons. A highly detailed daily forecast may not be useful for a decision that must be made six months earlier. Define the demand observation before selecting a model. Sales can be censored by stockouts: if fifty units were requested but only forty were available, forty sales understate demand. The course demand file records requests, fulfilled units and unfilled units separately. It therefore allows students to see how using fulfilled units alone can suppress the apparent demand level. In another setting, lost requests may not be observed. A report must identify that limitation instead of treating the sales history as a complete record of what customers wanted.

- Requested demand can exceed fulfilled demand
- A stockout can hide demand in sales history
- Define the planning horizon before forecasting

## Slide 10 Forecast evaluation

A naive forecast uses the most recent observation. A moving average smooths recent observations over a stated window. Exponential smoothing weights recent information more heavily through a chosen smoothing parameter. These methods provide useful baselines because their assumptions and calculations are easy to inspect. A more complex model should improve a decision-relevant evaluation, not merely fit past data more closely. Keep the data used to choose the method separate from a later holdout used to assess it, and preserve time order when future information would not have been available. Forecast error is actual demand minus forecast demand under the convention used in this course. Mean error shows directional bias, while mean absolute error shows average error magnitude without cancellation. A mean error near zero can coexist with large positive and negative misses. Percentage errors require care when actual demand is zero or very small. Choose an error measure consistent with the operating consequence and state the denominator. Do not compare a daily error measure with a monthly one as though they were the same scale.

- Preserve time order in development and holdout data
- Mean error measures bias
- Absolute error measures magnitude without cancellation

## Slide 11 Quality measures and denominators

Quality must be defined relative to the customer's requirement and the process's purpose. For a backpack repair, a cosmetically neat seam may still fail if it cannot carry the expected load. A job completed quickly may still require rework. State the acceptance criteria, the inspection point and the unit of analysis. A defect, a defective job and a customer complaint are different counts. One job can contain several defects, and a complaint may reflect a service issue that inspection did not measure. Mixing these units makes rates difficult to interpret. The course repair log records whether each completed job required rework and whether it met a three-calendar-day promise. These are two separate binary measures. The denominator for each descriptive job rate is the number of completed jobs in the extract, provided the field is observed for every included job. A completed-job rate should not be presented as the performance of all arrivals if open jobs are excluded. A late unfinished job can disappear from that denominator until it eventually completes, making a snapshot look better than the customer's current experience.

- Defects and defective jobs are different counts
- Completed-only rates omit unfinished jobs
- A service promise needs a measurable boundary

## Slide 12 Improvement and root-cause evidence

A root-cause investigation begins with a specific problem statement. Instead of saying quality is poor, state that a defined fraction of zipper repairs required correction during a given period. Map the process, examine the work instructions, inspect materials and ask where the defect first becomes detectable. Repeatedly asking why can organize inquiry, but it is not proof. A plausible story about rushed technicians remains a hypothesis until observations support it. Avoid assigning blame from an aggregate rate that may reflect job complexity or material differences. Test a change on a bounded scale and define success before implementation. For example, a standardized zipper-alignment check might reduce rework but add inspection time. Measure both effects so an improvement in one metric does not hide deterioration elsewhere. Keep the prechange and postchange observation windows comparable where possible. If staffing, job mix and the inspection rule all change together, a simple before-and-after difference cannot isolate the contribution of the checklist. The course emphasizes evidence sufficient for the claim, not an automatic demand for a randomized trial in every operating setting.

- A plausible explanation remains a hypothesis
- Measure benefits and operating side effects
- Preserve original promises and timestamps

## Slide 13 A bounded operating recommendation

Open purchase orders retain unknown realized lead times. I would summarize completed receipts and show open-order age separately rather than entering zeros for the missing receipts. A long outstanding order can be absent from the completed-only average and still represent an important current risk. The quoted five-calendar-day promise is a source expectation, not a guaranteed observation. Supplier comparisons also need attention to order size and timing before assigning causes to the observed differences. The next action is to establish daily tracking of arrivals, completions, open queue age and technician minutes, then reconcile kit inventory position with outstanding orders. The subscription membership cap remains unresolved because repairs per member and the allocation of capacity among work sources are unknown. My contribution to this fictional team work is the process analysis and inventory scenario. A portfolio version should preserve those limits, identify every dataset as synthetic and avoid claiming that the recommendation was implemented or produced actual cost savings.

- Verify equipment and a current queue census
- Track supplier open-order age
- Set an enrollment guardrail after measuring service use

## Slide 14 Source data excerpt

The final exhibit shows the first five records and first five fields of OPS330_Repair_Job_Log.csv. It is a labeled excerpt, not the complete dataset. Use the CSV or full text mirror for calculation and complete coverage.

| job_id | arrival_date | repair_type | touch_minutes | turnaround_days |
| --- | --- | --- | --- | --- |
| JOB-00001 | 2026-08-01 | zipper | 21 | 1 |
| JOB-00002 | 2026-08-01 | seam | 15 | 2 |
| JOB-00003 | 2026-08-01 | strap | 24 | 2 |
| JOB-00004 | 2026-08-01 | buckle | 9 | 3 |
| JOB-00005 | 2026-08-01 | zipper | 24 | 4 |
