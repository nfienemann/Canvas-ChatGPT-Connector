# Operations and Supply Chain Management

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330 | Fall 2026

## Purpose

This fictional undergraduate course examines how organizations translate demand into reliable delivery. Students analyze process capacity, bottlenecks, queues, inventory, forecasting, quality and supplier reliability using a hypothetical repair cell at Lumen Trail Outfitters. The course links calculations with decisions about staffing, replenishment and service promises. Students practice defining flow units and time boundaries, preserving missing data, and distinguishing observed performance from modeled scenarios. Several files intentionally contain partial evidence, including completed jobs without open work and supplier orders that have not arrived by the reporting cutoff. The objective is an operating recommendation that can be traced to assumptions and revised when evidence changes. All people, companies, records and policies in the packet are synthetic teaching material.

## Learning outcomes

- Map a process and identify its limiting resource.
- Calculate capacity, utilization and stable flow relationships with consistent units.
- Apply basic inventory models while stating their assumptions.
- Evaluate forecast errors using time-ordered evidence.
- Interpret quality and supplier metrics with appropriate denominators.
- Design practical operating guardrails and communicate uncertainty.

## Scope

Includes distinct working-day inventory scenario and calendar-day historical files, open purchase orders with unknown lead times, completed-only job extract, explicit older word-count template, revised deadline, observed discussion posts, posted missing zero and excused work.
