# OPS330 Repair Job Log

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-DATA1

## Dataset scope

600 completed synthetic jobs arriving over sixty calendar days. This completed-job extract contains no record of still-open jobs, so it is not a complete work-in-process census.

Records: 600. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| job_id | string |  | Unique fictional completed repair job. |
| arrival_date | date |  | Arrival date in the sixty-day observation window. |
| repair_type | category |  | Primary repair class. |
| touch_minutes | integer | minutes/job | Active work minutes, excluding waiting. |
| turnaround_days | integer | calendar days | Calendar elapsed days from arrival to completed repair. |
| within_3day_promise | integer |  | 1 when turnaround is at most three calendar days; 0 otherwise. |
| rework_required | integer |  | 1 if an additional correction was required before completion. |
| channel | category |  | Observed arrival channel, not randomized. |
