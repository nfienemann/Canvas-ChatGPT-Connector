# OPS330 Daily Kit Demand

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-DATA2

## Dataset scope

120 daily rows for a separate historical demand exercise. Requested demand is observed even when capacity is reached; fulfilled demand alone would understate requests. Annual inventory parameters in C01 are stipulated planning assumptions, not automatically estimated from these calendar-day rows.

Records: 120. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| date | date |  | Synthetic observation date; each date is one independent teaching row. |
| requested_kits | integer | kits/day | Recorded requests for repair kits; includes unfilled requests. |
| fulfilled_kits | integer | kits/day | Requests filled that day, limited to available kits. |
| unfilled_kits | integer | kits/day | Recorded requests not filled that day; no automatic carryover assumed. |
| available_daily_kits | integer | kits/day | Teaching availability ceiling for the day. |
| supplier_transit_cost_usd_per_kit | number | USD/kit | Observed synthetic transit cost per kit, not total landed cost. |
