# OPS330 Supplier Order Receipts

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-DATA3

## Dataset scope

90 purchase orders with an October 29 cutoff. Open orders intentionally retain blank receipt dates and blank realized lead times. Summary of completed receipts alone may exclude still-open long delays.

Records: 90. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| purchase_order_id | string |  | Unique fictional purchase order. |
| ordered_date | date |  | Order placement date. |
| supplier | category |  | Fictional supplier A or B. |
| quantity_kits | integer | kits | Ordered repair kits. |
| received_date | date or blank |  | Receipt date if received by the October 29 observation cutoff. |
| observed_lead_days | integer or blank | calendar days | Calendar days from order to receipt; unknown for open orders. |
| status | category |  | received or open at the cutoff. |
| promised_lead_days | integer | calendar days | Quoted five-calendar-day lead time, not a guaranteed observed value. |
