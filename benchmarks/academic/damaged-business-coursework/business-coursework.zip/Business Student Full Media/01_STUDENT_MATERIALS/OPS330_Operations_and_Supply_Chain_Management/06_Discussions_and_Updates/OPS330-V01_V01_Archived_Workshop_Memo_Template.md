# Archived Workshop Memo Template

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID OPS330-V01 | OPS330 | Issued 2026-10-20 | Assessments OPS330-A05

## Archived length guidance

Version distributed October 20, 2026. The workshop memo template asks for 1200 to 1500 words excluding exhibits and uses the standard 100-point case rubric. Include a recommendation, calculation exhibit and limitations section. This template predates the October 28 clarification.

## Workshop structure

State the decision, map the process, identify the bottleneck and summarize the inventory scenario. Use original source identifiers and retain the units of every input. The template is included as an older source for document reconciliation. Consult the dated instructor clarification and current assignment brief before deciding which word range governs the final submission.
