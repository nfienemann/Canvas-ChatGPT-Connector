# Forecast Error Reflection

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A08 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Use the daily demand data to explain why fulfilled units can understate requested demand when availability is limited. Calculate total requested, fulfilled and unfilled units for the supplied observation window.

Build a simple naive or moving-average forecast using only earlier observations. Reserve later dates for evaluation, state the forecast-error sign convention and report both directional bias and an error-magnitude measure.

Explain how a forecast error would affect a staffing or replenishment decision. Identify one reason a more complex model might fail to improve the decision even if it fits the observed history more closely.

The fictional grade record explicitly marks this assignment missing with a posted score of zero. Count that zero when computing the current grade and keep it separate from blank ungraded work.

## Required submission

- Reflection PDF
- Forecast calculations

## Format and assessment conditions

Format: PDF response with any calculation file listed below. Word limit: 700 to 900 words. Estimated preparation time: 3 hours.

Deadline: 2026-10-18T23:59:00-04:00. Points possible: 100. Grade category: Methods.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-R03
