# Repair Pilot Operating Plan

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A06 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Design an operating plan for a bounded repair pilot that can be revised as evidence accumulates. Define intake criteria, work allocation, service measurement and an escalation process for jobs at risk of missing their promise.

Specify daily measures for arrivals, completions, queue age, available work minutes, kit inventory position and open-order age. Explain which measures are already in the supplied files and which require a new process.

Compare at least two feasible responses to demand above capacity, including their implementation delay and service consequences. Do not assign precise probabilities to scenarios unless the evidence supports them.

Submit a team report, six-slide briefing and individual contribution statement. Assistance is limited to brainstorming alternatives and clarifying an outline. The assessed analysis, prose and briefing must be created by the team under this fictional policy.

## Required submission

- Operating plan report
- Six-slide briefing
- Team contribution statement

## Format and assessment conditions

Format: PDF report and PPTX briefing. Word limit: 1800 to 2400 words and 6 slides. Estimated preparation time: 10 hours.

Deadline: 2026-12-07T17:00:00-05:00. Points possible: 100. Grade category: Project.

## Academic assistance policy

Brainstorming alternatives and checking outline clarity only. No generative drafting of assessed analysis, prose or slides.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-C01
- OPS330-R03
- OPS330-N02
