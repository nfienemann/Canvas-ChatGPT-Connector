# Individual Operations Assessment

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A07 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Apply the concepts listed in the coverage guide to new process, inventory and supplier scenarios. The assessment tests reasoning and calculations rather than memorization of an actual company's facts.

Show units, denominators and intermediate calculations where they clarify the method. State when a result depends on stability, independence or a consistent time boundary.

One handwritten reference sheet and a nonnetworked calculator are permitted in this fictional assessment. AI assistance, networked messaging and generated answers are prohibited during the timed work.

Use voluntary practice before the assessment to test your understanding. Newly generated practice examples must not be described as the instructor's actual exam or predicted exam content.

## Required submission

- Individual answer booklet

## Format and assessment conditions

Format: Individual in-class paper answer booklet. Word limit: Timed individual responses. Estimated preparation time: 5 hours.

Deadline: 2026-11-16T15:15:00-05:00. Points possible: 100. Grade category: Exam.

## Academic assistance policy

No AI assistance during the assessment. One handwritten reference sheet and a nonnetworked calculator are permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-E01
