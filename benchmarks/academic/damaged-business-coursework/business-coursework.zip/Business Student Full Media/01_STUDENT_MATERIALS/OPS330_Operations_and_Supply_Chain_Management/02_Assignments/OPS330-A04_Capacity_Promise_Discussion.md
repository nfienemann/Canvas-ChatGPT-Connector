# Capacity Promise Discussion

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A04 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Evaluate whether average theoretical capacity above average demand establishes a guaranteed three-day service promise. Use the baseline repair-cell assumptions and distinguish touch time from elapsed turnaround.

Identify an important missing observation and propose a practical operating guardrail. Explain whether the guardrail is an observed fact or a management threshold that still requires approval.

Post the initial response by October 22 and two substantive replies by October 25. Replies should examine an assumption, a measurement boundary or a consequence for the decision.

The supplied excerpt verifies one initial post and two replies by Riley. It does not provide a numeric grade or a complete server-side discussion history. Preserve the distinction between observed participation and posted grading.

## Required submission

- Initial post
- Two substantive replies

## Format and assessment conditions

Format: Discussion platform text. Word limit: 250 to 350 word initial post and two substantive replies. Estimated preparation time: 2 hours.

Deadline: 2026-10-25T23:59:00-04:00. Points possible: 100. Grade category: Discussion.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-D01
- OPS330-R01
