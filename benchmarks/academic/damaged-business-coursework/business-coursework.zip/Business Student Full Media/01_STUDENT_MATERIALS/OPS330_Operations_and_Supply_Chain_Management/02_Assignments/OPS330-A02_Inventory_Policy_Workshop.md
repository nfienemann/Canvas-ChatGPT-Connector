# Inventory Policy Workshop

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A02 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Use the stipulated annual demand, ordering cost and holding cost in R02 to calculate the basic economic order quantity. Explain the model assumptions and the practical reason an operational quantity may need rounding.

Compute expected lead-time demand, the approximate lead-time-demand standard deviation, safety stock and reorder point using the working-day inputs. Show each meaningful step and do not mix calendar-day observations with those scenario parameters.

Explain the distinction between inventory on hand and inventory position. Use an explicitly labeled hypothetical example to show how ignoring an order already in transit can trigger duplicate replenishment.

Compare the meaning of a cycle service probability with a unit fill rate. State one missing business constraint that should be checked before adopting the calculated policy.

## Required submission

- Inventory calculation workbook
- Methods note PDF

## Format and assessment conditions

Format: PDF response with any calculation file listed below. Word limit: 700 to 900 words plus calculations. Estimated preparation time: 4 hours.

Deadline: 2026-09-27T23:59:00-04:00. Points possible: 100. Grade category: Methods.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-R02
