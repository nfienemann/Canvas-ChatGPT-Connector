# Quality Observation Exercise

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A03 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Define a repair-quality requirement and an observation unit. Distinguish a defect count, a defective-job count and a customer complaint count so the proposed metric has a defensible denominator.

Propose a bounded observation plan that records both rework and elapsed service time. Explain how the measurement could be biased if only completed jobs are included or if different inspectors use different criteria.

Identify a plausible root-cause hypothesis and the additional observation needed to test it. A compelling narrative is not evidence that a particular worker or supplier caused a quality problem.

This item is excused for Riley in the fictional record. Exclude it from the grade denominator. It remains available as voluntary practice and should not be represented as a missing zero.

## Required submission

- Observation plan PDF

## Format and assessment conditions

Format: PDF response with any calculation file listed below. Word limit: 600 to 800 words. Estimated preparation time: 2 hours.

Deadline: 2026-10-11T23:59:00-04:00. Points possible: 100. Grade category: Methods.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-R04
