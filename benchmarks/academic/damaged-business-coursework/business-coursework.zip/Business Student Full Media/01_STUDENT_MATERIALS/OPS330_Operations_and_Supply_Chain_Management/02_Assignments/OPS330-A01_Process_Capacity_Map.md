# Process Capacity Map

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A01 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Map the three-stage repair process using the baseline assumptions from R01. Define the flow unit, the start and finish of the process and the resources used at each stage. Show where waiting and rework could occur even though the baseline excludes them.

Calculate theoretical capacity for intake, repair and inspection with one repair technician. Identify the bottleneck and explain why adding a second intake worker would not change the baseline line capacity.

Calculate the effect of a second repair technician and state the assumption that allows the two workers to add capacity. Identify a shared resource that could invalidate that assumption and explain what evidence would be needed.

Write a recommendation that distinguishes capacity from a guaranteed service promise. Include all units and retain the calculation inputs in an editable exhibit.

## Required submission

- Process map and memo PDF
- Capacity calculation file

## Format and assessment conditions

Format: PDF memo with the exhibits listed below. Word limit: 800 to 1000 words. Estimated preparation time: 4 hours.

Deadline: 2026-09-13T23:59:00-04:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-R01
