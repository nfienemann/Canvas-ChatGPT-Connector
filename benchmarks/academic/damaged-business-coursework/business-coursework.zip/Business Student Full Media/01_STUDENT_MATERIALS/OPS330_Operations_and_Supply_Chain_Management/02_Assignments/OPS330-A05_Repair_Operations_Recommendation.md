# Repair Operations Recommendation

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

OPS330-A05 | OPS330 | Issued for fictional Fall 2026 semester

## Assignment requirements

Recommend a staffing and replenishment approach for the hypothetical repair cell. Define the process boundary and distinguish this regional operating scenario from the marketing experiment and consolidated company financial accounts.

Calculate baseline stage capacities, the bottleneck and two-technician utilization. Analyze the fifteen-percent reserve and thirty-minute work-content scenarios separately before discussing any combined stress condition. Label every assumption and preserve the usable-minute definition.

Calculate economic order quantity, modeled safety stock and reorder point from the stipulated working-day inputs. Summarize the completed repair jobs and supplier receipts while retaining the unknown lead times of open orders. Explain why the observation files cannot establish the current queue or a membership cap.

Provide a decision, an owner for the missing evidence and an operating guardrail. The current brief requires 1600 to 2000 words; the older 1200 to 1500 word template is superseded by N02. N01 moves the deadline from November 4 to November 6 at 17:00 America/New_York.

## Required submission

- Recommendation memo PDF
- Editable calculations
- Data and assumption appendix

## Format and assessment conditions

Format: PDF memo with the exhibits listed below. Word limit: 1600 to 2000 words excluding exhibits. Estimated preparation time: 8 hours.

Deadline: 2026-11-06T17:00:00-05:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- OPS330-C01
- OPS330-R01
- OPS330-R02
- OPS330-R04
- OPS330-N01
- OPS330-N02
