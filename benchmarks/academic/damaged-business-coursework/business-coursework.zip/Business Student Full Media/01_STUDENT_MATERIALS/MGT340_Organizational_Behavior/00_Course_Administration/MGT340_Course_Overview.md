# Organizational Behavior

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340 | Fall 2026

## Purpose

Organizational Behavior examines how people interpret work, coordinate interdependent tasks, respond to management decisions, and participate in organizational change. This fictional upper-level course combines conceptual readings with a sustained case about the people side of a campus repair pilot. Students practice distinguishing motivation from resource constraints, evaluating survey evidence, designing coordination routines, and explaining implementation tradeoffs. The emphasis is on defensible diagnosis and bounded recommendations rather than memorized labels. Work includes individual memos, a team proposal, discussion participation, and an independent case exam. The course packet contains a voluntary employee panel, a short work-observation log, fictional interview excerpts, a sample student proposal, and feedback. All records are synthetic and are intended for educational demonstrations and software testing.

## Learning outcomes

- Distinguish motivation ability resources and coordination as explanations of performance.
- Analyze interdependence conflict and decision rights in a service team.
- Interpret ordinal survey responses with explicit denominators and limitations.
- Design a bounded implementation trial with outcomes and balancing measures.
- Evaluate stakeholder concerns without treating disagreement as a personal defect.
- Attribute team contributions accurately and distinguish proposals from measured outcomes.

## Scope

All materials are original and fictional. Old and revised requirements are deliberately retained with explicit precedence. No actual employee, student, or institution records are represented.
