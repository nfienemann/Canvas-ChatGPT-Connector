# Survey Interpretation Exercise

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-A02 | MGT340 | Issued for fictional Fall 2026 semester

## Assignment requirements

Analyze the supplied fictional employee panel. Report the number of respondents and the answered-item denominator for each measure you discuss. Keep missing observations distinct from neutral scores and from the absence of a respondent record.

Present at least one response distribution and one descriptive comparison across teams. If you show an average for an ordered response scale, label it as a teaching simplification. Explain why the voluntary panel does not support a company-wide prevalence estimate.

Compare one survey pattern with the work-observation dataset. State whether the sources measure the same construct and whether their agreement establishes a causal explanation. Propose a follow-up that would reduce a specific uncertainty.

Submit both the written interpretation and the reproducible calculations. In the fictional grade export this task is explicitly marked missing with a posted zero. This is different from an ungraded submission with a blank score.

## Required submission

- Interpretation memo
- Reproducible calculations

## Format and assessment conditions

Format: PDF plus analysis workbook. Word limit: 700 to 900 words. Estimated preparation time: 3 hours.

Deadline: 2026-10-04T23:59:00-04:00. Points possible: 100. Grade category: Applied analyses.

## Academic assistance policy

Mechanical proofreading permitted; the student must perform the analysis and write the interpretation independently.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Measurement and inference (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- MGT340-R03
- MGT340-C01
