# Motivation Diagnosis Memo

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-A01 | MGT340 | Issued for fictional Fall 2026 semester

## Assignment requirements

Analyze a fictional repair team whose ticket completions fell after an incentive change. Use MGT340-R01 to distinguish motivation from ability, resources, and coordination. State one leading explanation and one plausible alternative before proposing a management response.

Explain the expected relationship between effort, the measured performance, and the proposed consequence. Identify a point where the relationship could fail. Do not assume that a larger payment will solve a problem caused by missing parts or unclear authority.

Propose a bounded intervention with an owner and an observation window. Identify an outcome and a balancing measure. Describe one finding that would lead you to revise your initial explanation rather than defend it regardless of the evidence.

Submit a clearly organized memo with source identifiers and a short limitations paragraph. The grading record contains a posted score of 88 out of 100. Feedback on a later assignment does not change that posted score.

## Required submission

- Decision memo
- One-paragraph limitations statement

## Format and assessment conditions

Format: DOCX or PDF. Word limit: 900 to 1100 words. Estimated preparation time: 4 hours.

Deadline: 2026-09-20T23:59:00-04:00. Points possible: 100. Grade category: Applied analyses.

## Academic assistance policy

Mechanical proofreading permitted; substantive drafting or rewriting with generative assistance prohibited.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Motivation diagnosis (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- MGT340-R01
