# Final Repair Pilot People Plan

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-A07 | MGT340 | Issued for fictional Fall 2026 semester

## Assignment requirements

Develop the diagnostic proposal into a people and implementation plan for a bounded repair pilot. Explain which recommendations changed after feedback and why. Keep commercial authorization and staffing assumptions visible.

Assign responsibility for handoffs, exception decisions, and customer communication. Specify the training and review routines, their resource costs, and how staff can surface problems. Address one substantive concern from each role represented in the case.

Use the supplied datasets to motivate questions and measures without claiming that the proposed intervention has already worked. Present two outcome measures, one balancing measure, and a rule for pausing or revising the plan.

Follow MGT340-N01 and MGT340-N02 for the revised due date and report length. Submit the team report and each student's separate contribution reflection. The older rubric remains in the packet for version comparison, but its date and word range are superseded.

## Required submission

- Team final report
- Individual contribution reflection
- Evidence and measurement appendix

## Format and assessment conditions

Format: Team PDF plus individual reflection. Word limit: 1800 to 2200 words excluding tables references and contribution appendix. Estimated preparation time: 10 hours.

Deadline: 2026-11-16T23:59:00-05:00. Points possible: 100. Grade category: Team project.

## Academic assistance policy

Brainstorming alternatives and discussing concepts permitted; substantive outlines, drafting, and rewriting of the assessed report are not permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Implementation and learning design (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- MGT340-R04
- MGT340-C01
- MGT340-F01
- MGT340-N01
- MGT340-N02
- MGT340-P01
