# Individual Case Exam

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-A06 | MGT340 | Issued for fictional Fall 2026 semester

## Assignment requirements

Prepare using the four assigned readings and the Lumen Trail case. The exam evaluates explanation, diagnosis, and application rather than memorized framework labels.

During the assessment, write three independent analyses of a new scenario. You may use printed course readings and one page of your own notes. The precise assessed questions are not included in the review packet.

Support each analysis with a mechanism, relevant evidence, and a limitation. A confident recommendation without an explanation of how it would work will receive limited credit.

The exam begins at 1:00 PM America/New_York on November 6 and lasts 75 minutes. Generative assistance, collaboration, and outside drafting are prohibited for the assessed response. Voluntary preparation questions remain available before the exam.

## Required submission

- Three independent in-class analyses

## Format and assessment conditions

Format: In-class handwritten response. Word limit: Three short analyses in 75 minutes. Estimated preparation time: 5 hours.

Deadline: 2026-11-06T13:00:00-05:00. Points possible: 100. Grade category: Exam.

## Academic assistance policy

No generative assistance, collaboration, or outside drafting during the assessment.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Independent case reasoning (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- MGT340-R01
- MGT340-R02
- MGT340-R03
- MGT340-R04
- MGT340-E01
