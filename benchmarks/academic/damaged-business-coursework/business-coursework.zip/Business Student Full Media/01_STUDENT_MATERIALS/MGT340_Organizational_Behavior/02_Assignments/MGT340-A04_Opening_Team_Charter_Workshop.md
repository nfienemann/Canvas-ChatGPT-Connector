# Opening Team Charter Workshop

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-A04 | MGT340 | Issued for fictional Fall 2026 semester

## Assignment requirements

Work with a small group to identify decision rights and escalation routes for a fictional service team. Focus on a specific recurring decision rather than writing general values statements.

Map the roles that create information, approve commitments, and communicate changes. Discuss where interdependence creates a need for a shared routine.

Produce a short charter that could guide an ordinary workday. Include one example showing what happens when two roles disagree about a commitment.

The fictional student record marks Riley excused from this workshop. Exclude the item from graded denominators according to the syllabus policy. The absence of a numerical score must not be interpreted as a zero.

## Required submission

- Workshop charter

## Format and assessment conditions

Format: In-class worksheet. Word limit: Not applicable. Estimated preparation time: 1 hours.

Deadline: 2026-09-14T10:00:00-04:00. Points possible: 100. Grade category: Participation.

## Academic assistance policy

Collaborative classroom discussion permitted; no external drafting needed.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Usable team expectations (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- MGT340-R02
