# Repair Pilot Diagnostic Proposal

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-A03 | MGT340 | Issued for fictional Fall 2026 semester

## Assignment requirements

Recommend a diagnostic trial for the Lumen Trail repair pilot. Use the case interviews, survey, and observation log to identify a plausible mechanism and a serious alternative explanation. Keep the proposed trial separate from a decision to launch the commercial service.

Specify what would change in the work, who would own the change, and what evidence the trial would produce. Explain the cost of the proposed routine in staff time. A process change that depends on unspecified additional work is incomplete.

Define two measures and one balancing measure. Explain which uncertainty each measure addresses. Identify an observable condition that would lead the sponsor to revise or stop the trial.

Submit one team proposal and an activity-based contribution log. The packet includes a fictional sample by Riley and teammates plus formative feedback. No numerical grade has been posted as of October 29, so the blank score must remain unknown.

## Required submission

- Team proposal
- Contribution log
- Individual contribution paragraph

## Format and assessment conditions

Format: Team DOCX and contribution log. Word limit: 1000 to 1400 words. Estimated preparation time: 6 hours.

Deadline: 2026-10-26T23:59:00-04:00. Points possible: 100. Grade category: Team project.

## Academic assistance policy

Concept explanation and brainstorming permitted; all submitted prose must be independently drafted by the named student authors.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Organizational diagnosis (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- MGT340-R02
- MGT340-R03
- MGT340-C01
