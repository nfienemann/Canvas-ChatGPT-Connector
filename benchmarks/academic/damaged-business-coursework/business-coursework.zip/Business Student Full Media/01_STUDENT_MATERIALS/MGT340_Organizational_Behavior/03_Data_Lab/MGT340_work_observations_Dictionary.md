# MGT340 work observations

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-DATA2

## Dataset scope

84 team-day observations. Scheduled less direct, rework, and waiting is other scheduled activity, not automatically idle time. No job-complexity field is available.

Records: 84. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| date | ISO date | calendar day | Synthetic work-sampling date, including a limited weekend event schedule. |
| team | string | category | Fictional observed function. |
| scheduled_minutes | integer | minutes | Observed scheduled minutes, not a payroll record. |
| direct_minutes | integer | minutes | Minutes classified as direct task work. |
| rework_minutes | integer | minutes | Minutes classified as repeating or correcting work. |
| waiting_minutes | integer | minutes | Minutes classified as waiting for information or parts. |
| handoffs | integer | count | Recorded transfers of work or information. |
