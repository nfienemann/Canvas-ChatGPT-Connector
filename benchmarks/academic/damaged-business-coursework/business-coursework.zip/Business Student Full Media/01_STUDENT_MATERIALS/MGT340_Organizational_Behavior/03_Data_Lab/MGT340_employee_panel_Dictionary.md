# MGT340 employee panel

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MGT340-DATA1

## Dataset scope

108 fictional voluntary-panel responses. Ordered-scale means are permitted only as an explicitly labeled teaching simplification. Missing item values are blank.

Records: 108. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| respondent_id | string | identifier | Invented respondent key; not an employee number. |
| team | string | category | Fictional function in the voluntary panel. |
| tenure_months | integer | months | Synthetic tenure at the snapshot. |
| clarity_1to5 | integer | ordered category | Higher values indicate greater reported role clarity. |
| voice_1to5 | integer or blank | ordered category | Higher values indicate greater reported comfort speaking up; blank is missing. |
| autonomy_1to5 | integer | ordered category | Higher values indicate greater reported discretion. |
| overload_1to5 | integer or blank | ordered category | Higher values indicate greater reported overload; blank is missing. |
| sample_type | string | category | All records are a voluntary panel; no population sampling claim. |
