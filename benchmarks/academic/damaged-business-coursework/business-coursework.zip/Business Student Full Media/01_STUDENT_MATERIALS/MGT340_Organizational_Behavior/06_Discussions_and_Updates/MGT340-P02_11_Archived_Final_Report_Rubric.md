# Archived Final Report Rubric

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID MGT340-P02 | MGT340 | Issued 2026-09-21 | Assessments MGT340-A07

## Original handout retained for comparison

Archived instructional handout for MGT340-A07. Original report length: 1,500 to 1,800 words, excluding tables and references. Original due date: November 13, 2026 at 11:59 PM America/New_York. Criteria: diagnosis 30 points, evidence and interpretation 30 points, feasibility and tradeoffs 25 points, communication and attribution 15 points. This document is preserved in the course packet to support version comparison.

The later announcements MGT340-N01 and MGT340-N02 revise the deadline and word range respectively. A reader who encounters this handout alone should not assume it is the latest requirement. The document has no statement changing the assistance policy. Its existence does not resolve whether a specific proposed activity is permitted.
