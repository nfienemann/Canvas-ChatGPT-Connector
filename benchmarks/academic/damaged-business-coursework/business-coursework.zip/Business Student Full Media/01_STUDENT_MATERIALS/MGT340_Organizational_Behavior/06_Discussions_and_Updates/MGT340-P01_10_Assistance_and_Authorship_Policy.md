# Assistance and Authorship Policy

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID MGT340-P01 | MGT340 | Issued 2026-08-31 | Assessments MGT340-A01, MGT340-A02, MGT340-A06, MGT340-A07

## Scope and permitted activities

This is a fictional course policy supplied as test content. It is not a real instructor authorization, an institutional approval, or an application permission record. In the simulated course, students may use ordinary reference tools and generative assistance for voluntary practice that is not submitted for credit. For MGT340-A07, assistance is limited to brainstorming alternative explanations and discussing the supplied concepts. Students must independently draft their report, choose the recommendation, and perform the final evidence checks.

MGT340-A06 is an individual in-class assessment. Generative assistance, collaboration, and outside drafting are prohibited for the assessed response. Students may prepare beforehand using the listed readings and voluntary practice questions. Mechanical proofreading is permitted for MGT340-A01 and MGT340-A02, but substantive rewriting, argument generation, and invented sources are not. Where a task-specific instruction is stricter, the task-specific instruction controls. Silence about an activity is not an affirmative permission.

## Team evidence and portfolio reuse

Students must identify their own contributions to group work. A contribution log records who did an activity and when, while an individual reflection explains what the student learned and can defend. The report's presence in a student's folder does not prove sole authorship. For a portfolio, the fictional course permits a brief retrospective summary of MGT340-A03 after feedback, provided it is labeled a simulated class project and distinguishes proposed outcomes from measured results. The final team report's public release status remains unknown. Do not assume that permission to submit it for grading includes permission to publish every teammate's work.
