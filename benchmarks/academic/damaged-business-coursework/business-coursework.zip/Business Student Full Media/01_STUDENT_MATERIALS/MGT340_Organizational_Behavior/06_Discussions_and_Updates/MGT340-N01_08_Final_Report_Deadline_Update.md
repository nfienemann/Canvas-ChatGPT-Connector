# Final Team Report Deadline Update

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID MGT340-N01 | MGT340 | Issued 2026-10-21 | Assessments MGT340-A07

## Revised deadline

The final team report MGT340-A07 is now due Monday, November 16, 2026, at 11:59 PM America/New_York. The earlier course schedule lists Friday, November 13. This dated announcement supersedes that date for MGT340-A07 only. The in-class case exam remains November 6 at 1:00 PM. The three-day extension does not change the project scope or the contribution-log requirement.

Upload one report per team and a separate individual contribution reflection from each student. A teammate's report upload does not establish that your individual reflection was submitted. The course packet contains no verified submission record for the final report because the deadline is in the future relative to the October 29 snapshot.
