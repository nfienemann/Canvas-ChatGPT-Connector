# Final Report Length Clarification

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID MGT340-N02 | MGT340 | Issued 2026-10-23 | Assessments MGT340-A07, MGT340-A08

## Current requirement and archived rubric

For MGT340-A07, submit 1,800 to 2,200 words of report text, excluding tables, references, and the contribution appendix. The assignment instructions reflect this range. The archived rubric handout MGT340-P02 still states 1,500 to 1,800 words. Use this dated clarification for the length requirement. The rubric's four criteria and point allocations remain unchanged.

No deadline has been set for the career reflection MGT340-A08. A date will be announced after the project presentations. Do not infer a due date from the week in which reflection is discussed. Participation in the optional voluntary practice prompts is allowed under the course policy, but that permission does not authorize drafting the restricted in-class exam.
