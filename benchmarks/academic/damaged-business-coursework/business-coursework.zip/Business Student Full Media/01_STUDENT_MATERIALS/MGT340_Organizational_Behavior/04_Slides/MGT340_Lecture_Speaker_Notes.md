# Organizational Behavior Lecture Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Slide 1 is the cover. These notes accompany the editable deck and its PDF.

## Slide 2 Performance has several causes

Begin with the fictional decline in completed repairs. Ask students to generate at least three explanations before suggesting an incentive. A missing component, a more complex job mix, and an unclear priority rule could all reduce completion counts without a decline in effort. Explain why a diagnosis should name an observable mechanism. The point is not to make every explanation equally likely. The point is to identify what evidence would distinguish them. A manager can make a provisional decision while preserving uncertainty. Connect this to the first memo: students should recommend a bounded response and state what finding would change their view.

- Effort is only one input to performance
- Check resources ability and coordination
- Select evidence that distinguishes explanations

## Slide 3 Effort performance and consequences

Use a repair ticket bonus to walk through the three links. If assignment complexity determines most of the count, employees may not expect additional effort to improve the measure. If managers routinely make exceptions, the link between measured performance and reward may be unclear. If the reward is a supervisory role that the employee does not want, the consequence may have low value. Emphasize that this is a conceptual diagnostic tool. Students should not multiply invented psychological scores and present the result as a scientifically measured motivation level. Ask what conversation or operational record could help assess each link in this fictional setting.

- Can effort change the measured result?
- Will performance produce the promised consequence?
- Does the consequence matter to the employee?

## Slide 4 Work design and fairness

Autonomy can mean choosing the sequence of approved repairs while preserving the required customer-consent process. Competence requires opportunities to practice and feedback that explains how to improve. Connection includes knowing how one's work affects colleagues and being able to obtain help. Then introduce three fairness questions: what outcome was allocated, how the decision was made, and how people were treated. Equal payments do not settle every fairness question when jobs differ. A polite explanation does not make an arbitrary process fair. Ask students which part of the system their proposed intervention actually changes and which concern it leaves unresolved. Ask students to defend a concrete example.

- Give discretion within clear boundaries
- Provide practice and useful feedback
- Examine outcomes procedures and treatment

## Slide 5 Interdependent work

Follow a fictional backpack from campus sales to customer support, repair inspection, parts selection, and return. At each handoff, ask what information the next role needs. A promise made early can become impossible after inspection, so the process needs an owner for changing and communicating the commitment. Local measures can create conflict: sales can meet enrollment goals while repairs accumulate an unmanageable queue. The team should therefore discuss system outcomes and the conditions under which local decisions are made. A team charter becomes useful when it resolves these recurring decisions. A statement that everyone will communicate respectfully is insufficient by itself.

- Map the repair from request to return
- Identify who can change a commitment
- Measure the overall result as well as local speed

## Slide 6 Conflict and a decision process

Present the disagreement about a five-business-day turnaround. Part of the disagreement concerns what the service should promise, and part concerns who may make the promise. Neither description requires assuming that the participants dislike one another. Explain how unresolved process conflict can become personal over time. A meeting should have a clear question, relevant evidence, and an agreed route to a decision. Written input may help some participants, but the facilitator should consider preparation time and access. Productive conflict is not merely the existence of disagreement. It is disagreement that contributes information and reasoning to a decision without making participation needlessly costly.

- Separate task process and relationship issues
- Ask what evidence would change a position
- Give quieter contributors a usable route to participate

## Slide 7 Voice and accountability

Use a technician who reports a questionable repair as the example. The manager needs to address the immediate issue and later examine whether the process was followed and whether it was usable. Punishing the reporting act can reduce the information available next time. This does not require ignoring deliberate misconduct or abandoning quality standards. A rise in reports after a channel opens can reflect better visibility, worse work, or both. Ask students for an independent quality observation that could help. Connect the discussion to the supplied own-post excerpts and remind students that the packet does not contain classmates' full discussion histories.

- Encourage reports of problems
- Maintain a clear work standard
- Interpret a rise in reports carefully

## Slide 8 Survey scales and missing responses

The survey uses five ordered response categories. Explain why the distance between adjacent categories is not directly measured. For this teaching exercise, students may report a mean if they label the simplification, but a distribution often communicates the pattern more honestly. Missingness is item-specific: a respondent can answer clarity and skip voice. Replacing a blank with a midpoint silently changes the meaning of the record. Ask students to calculate the number answering voice and overload separately. Then ask whether a voluntary panel can support a company-wide prevalence claim. The correct limitation should influence the language of the recommendation, not appear only in a footnote.

- Ordered categories do not guarantee equal intervals
- Blank answers remain missing
- State the denominator for every share

## Slide 9 Triangulation and causal restraint

Compare overload responses with waiting minutes. Both may support investigating coordination, but they do not measure identical constructs. Overload can include emotional demands and perceived control, whereas the log records broad activity categories during a short period. Complex repairs could produce both waiting and overload, creating a competing explanation. The sources may also share assumptions about how work is classified. Ask students to design a follow-up that records job type and part availability. The aim is a more informative next decision. Students should avoid treating the number of documents that repeat a story as the number of independent tests of that story.

- Survey reports experience
- Observation records selected activity
- Agreement does not by itself establish a cause

## Slide 10 A pilot must test a defined idea

A pilot can fail to test its intended idea when essential preparation is missing. If staff receive no training, the trial may test their ability to improvise rather than the proposed process. A successful pilot can also be misleading if it accepts only easy jobs or depends on an unusually experienced manager. Define the mechanism under study and the conditions needed to evaluate it. Record overtime, preferential access to parts, and other exceptions. Ask students to distinguish the two-week handoff trial from the six-week commercial service pilot. These are related decisions with different evidence requirements and different authority. Ask students to defend a concrete example.

- Specify scope resources and duration
- Record exceptions and hidden extra work
- Explain where results may generalize

## Slide 11 Measures and decision rules

For a handoff form, information completeness and clarification requests are close to the proposed mechanism. Completion time and customer complaints are broader outcomes. Overtime is a useful balancing measure because a routine may appear to improve service by transferring work to employees. A stop or pause condition should be concrete enough to use. It need not pronounce the whole concept a failure. Pausing enrollment while resolving unsupported promises can protect the learning process. Ask students what threshold their evidence can justify and what requires additional operations analysis. A useful plan is explicit about both its decision rules and their limits.

- Pair mechanism measures with outcomes
- Add a balancing measure
- State what triggers pause or revision

## Slide 12 Team authorship and portfolio claims

The sample proposal names the work performed by Riley, Sam, and Noor. A contribution log helps a reader understand these roles, but it is not independent proof of hours or equal learning. Each student should be able to defend the reasoning they claim. For a portfolio, Riley may describe designing a measurement plan and analyzing a fictional survey. Riley cannot say that the plan reduced rework because the trial never occurred. The public release status of the final team report remains unknown. Explain how a useful project summary can be written without claiming sole authorship or publishing another person's work without an established permission basis.

- Use contribution records to attribute work
- Separate proposed from measured outcomes
- Do not equate access with publication permission

## Slide 13 Current requirements and unknowns

Use this slide to practice source reconciliation. The archived handout retains November 13 and 1500 to 1800 words. The later announcements identify the same assignment and explicitly revise those requirements. The final report therefore follows November 16 and 1800 to 2200 words, excluding the stated supporting material. The in-class exam remains November 6 and has a separate assistance restriction. No source gives a due date for the optional career reflection. A schedule topic is not enough to manufacture one. Ask students to cite the source identifiers and preserve the unknown rather than silently placing every task on a calendar. Ask students to defend a concrete example.

- Final report due November 16 at 11:59 PM
- Current word range is 1800 to 2200
- Career reflection date remains unannounced

## Slide 14 Source data excerpt

The final exhibit shows the first five records and first five fields of MGT340_employee_panel.csv. It is a labeled excerpt, not the complete dataset. Use the CSV or full text mirror for calculation and complete coverage.

| respondent_id | team | tenure_months | clarity_1to5 | voice_1to5 |
| --- | --- | --- | --- | --- |
| SYN-MGT-001 | Repair East | 6 | 2 | Unknown |
| SYN-MGT-002 | Repair West | 13 | 3 | 4 |
| SYN-MGT-003 | Customer Support | 20 | 4 | 4 |
| SYN-MGT-004 | Campus Sales | 27 | 2 | 3 |
| SYN-MGT-005 | Logistics | 34 | 4 | 2 |
