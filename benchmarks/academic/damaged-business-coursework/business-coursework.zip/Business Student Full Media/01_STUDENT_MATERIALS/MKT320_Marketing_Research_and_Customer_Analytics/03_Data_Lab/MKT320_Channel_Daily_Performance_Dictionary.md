# MKT320 Channel Daily Performance

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-DATA3

## Dataset scope

96 channel-day rows for a distinct September sales exercise. These rows are not joinable to the October repair-signup experiment and are not consolidated company financial statements.

Records: 96. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| date | date |  | Observed channel day; 24 dates and four channels. |
| channel | category |  | Marketing channel; audiences and attribution differ. |
| impressions | integer |  | Recorded impressions, not unique people. |
| clicks | integer |  | Recorded clicks, not necessarily unique visitors. |
| orders | integer |  | Attributed orders under a synthetic last-touch rule. |
| spend_usd | number | USD | Allocated advertising spend. |
| booked_revenue_usd | number | USD | Booked order value before fulfillment and returns. |
