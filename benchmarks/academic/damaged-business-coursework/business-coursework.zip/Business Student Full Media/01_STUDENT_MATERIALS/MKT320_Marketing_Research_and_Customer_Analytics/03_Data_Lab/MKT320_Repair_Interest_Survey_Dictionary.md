# MKT320 Repair Interest Survey

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-DATA2

## Dataset scope

180 voluntary responses; no probability sampling frame, no causal identification, no population market-size claim. Missing price values are deliberately retained.

Records: 180. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| respondent_id | string |  | One unique fictional survey response. |
| recruitment_channel | category |  | Voluntary recruitment source; a convenience sample. |
| prior_repair_user | integer |  | Self-reported prior repair use, 1 yes and 0 no. |
| repair_importance_1to5 | integer |  | Ordinal importance from 1 not important to 5 very important. |
| stated_monthly_price_usd | number or blank | USD/month | Maximum stated price; blank is item nonresponse and must not become zero. |
| role | category |  | Fictional respondent role. |
| followup_opt_in | integer |  | Consent for a fictional follow-up interview; not permission for unrelated use. |
