# MKT320 Repair Landing Experiment

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-DATA1

## Dataset scope

Random assignment is stipulated in the case design, not inferred from this CSV. Exactly 400 eligible unique visitors per arm; follow-up complete at 48 hours. Interest signup is the primary outcome. These are fictional observations.

Records: 800. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| visitor_id | string |  | Unique fictional visitor; one exposure per row. |
| variant | category |  | Randomized landing page arm, A control or B repair guarantee wording. |
| exposure_date | date |  | Calendar date of exposure in America/New_York. |
| acquisition_channel | category |  | Observed acquisition source; not randomized. |
| visitor_status | category |  | New or returning before exposure; not a causal intervention. |
| signup | integer |  | 1 if the visitor registered interest within 48 hours; 0 otherwise. |
| expected_contribution_usd | number | USD | Teaching assumption of 19 USD expected contribution per interest signup, not realized revenue. |
| acquisition_cost_usd | number | USD | Allocated synthetic acquisition cost per exposure. |
