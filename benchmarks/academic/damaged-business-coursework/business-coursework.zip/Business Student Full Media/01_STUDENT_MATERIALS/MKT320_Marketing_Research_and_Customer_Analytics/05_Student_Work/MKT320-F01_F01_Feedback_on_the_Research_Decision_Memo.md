# Feedback on the Research Decision Memo

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID MKT320-F01 | MKT320 | Issued 2026-10-27 | Assessments MKT320-A05

## What the draft establishes

Riley, the draft correctly keeps interest registration, paid membership and recorded merchandise orders separate. The distinction is essential to this case because the three files do not describe one linked customer funnel. Your five-percentage-point estimate and fifty-percent relative lift use the right denominators. The normal-approximation interval is consistent with the course method. You also retain the negative one-hundred-twenty-dollar scenario result instead of allowing the positive response effect to erase the implementation cost.

The recommendation is proportionate to the evidence. A capped paid pilot targets the uncertainty between interest and economic viability, and your portfolio paragraph limits authorship to the marketing analysis. Preserve those boundaries in the final version. The case narrative, rather than the CSV alone, supplies random assignment and complete follow-up. Cite both sources wherever you make the causal claim so the reader can distinguish design assumptions from observed counts.

## Revisions before submission

Add a small survey exhibit with the valid price count, missing count and the distribution of stated prices. Your current prose describes the correct handling but does not show the numeric summary. Include a compact channel table with total spend, attributed orders and overall cost per order. The method is clear, but a reviewer should be able to verify at least one completed calculation without opening another file.

Make the pilot decision rule more concrete. You can propose a threshold as an explicitly labeled management assumption, but do not write as though operations has already approved it. State who must set the enrollment cap and which missing cost estimate would change your recommendation. The report should also specify that the ninety-five-percent interval is a teaching approximation for independent fixed-sample observations. Your current discussion largely does this; one concise note beside the displayed interval would make it easier to read.

This is formative feedback on a synthetic example. No numeric assignment score has been posted for MKT320-A05. A visible feedback document is not evidence that the work has a recorded grade, and the final submission receipt is not present in this corpus.
