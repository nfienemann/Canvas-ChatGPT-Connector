# Marketing Research and Customer Analytics

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320 | Fall 2026

## Purpose

This fictional undergraduate course develops the ability to turn marketing decisions into answerable research questions. Students examine measurement, sampling, experimental design, survey interpretation and channel reporting through a proposed repair subscription at Lumen Trail Outfitters. The central task is to make claims that match the design and the available evidence. Students work with separate visitor, survey and channel-day datasets, preserve their units and observation windows, and translate findings into feasible next actions. The course emphasizes calculation transparency, causal restraint and honest reporting of uncertainty. It also requires clear distinctions among interest, payment, service use and profit. All cases, people, policies and observations are synthetic teaching material, and no real recruitment or business contact is required.

## Learning outcomes

- Translate a management decision into a defined research question.
- Evaluate measurement validity, sampling coverage and missing data.
- Calculate and interpret experimental effect sizes with uncertainty.
- Distinguish descriptive attribution from causal incrementality.
- Design a feasible follow-up study with a decision rule.
- Communicate individual contribution and evidence limits in a portfolio.

## Scope

Three separate synthetic datasets intentionally have different units and periods. Dated announcement supersedes original memo date. Partial discussion evidence, blank grades, excused work and posted zero test uncertainty handling.
