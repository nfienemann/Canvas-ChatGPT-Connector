# Marketing Research and Customer Analytics Lecture Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Slide 1 is the cover. These notes accompany the editable deck and its PDF.

## Slide 2 Management decisions and research questions

Lumen Trail Outfitters is considering a repair subscription for students who own commuter backpacks. The manager asks whether customers want it. That question hides several different decisions. The business could test a monthly subscription, sell individual repairs, bundle one annual repair into a new backpack, or postpone all three. A useful research brief identifies which decision the evidence will change, which population matters, when the decision must be made, and what the consequences of a wrong choice would be. A survey about general environmental attitudes does not directly answer which offer can support a viable service. Separate a management problem from a research question. The management problem is choosing a limited pilot. A research question might be whether a repair guarantee increases completed interest registrations among eligible campus visitors. Another might be how many repairs each paying member requests. These require different methods and observation periods. Before collecting data, describe the target quantity in ordinary language. Specify its numerator, denominator, unit and time window. This makes hidden disagreements visible while they are still inexpensive to fix.

- Name the choice the manager controls
- Define population, outcome and observation window
- State what result would change the decision

## Slide 3 Constructs and operational definitions

Perceived durability, trust and willingness to pay are constructs. A construct is an idea that cannot be observed directly in the same way as a completed transaction. A questionnaire item is one attempt to measure it. Asking whether someone agrees that a backpack is dependable may capture familiarity, brand preference or politeness as well as perceived durability. Several carefully chosen items can reveal inconsistent responses, but adding items does not automatically make a measure valid. Begin with the construct definition and then explain why each item represents it. Operational definitions must be stable across groups. In the repair experiment, an interest signup is a completed registration within 48 hours of a visitor's first assigned exposure. It is not a paid subscription, a qualified lead, a completed repair or a retained member. Counting partially completed forms in one arm would change the outcome definition. Likewise, a missing questionnaire answer is an unknown response. Coding missing willingness to pay as zero would make nonresponse look like an explicit refusal to pay and bias the average downward.

- Interest signup is not a paid subscription
- Stable definitions enable comparisons
- Blank response is an unknown value

## Slide 4 Sampling and recruitment

A sampling frame is the list or mechanism through which eligible people can enter a sample. A campus email list can exclude commuters who ignore university email. A repair event can overrepresent students whose bags already need repair. A social post can overrepresent engaged followers. A large convenience sample can describe its respondents precisely while still representing the wider population poorly. Sample size reduces random sampling uncertainty under a suitable design; it does not remove systematic coverage or self-selection problems. Record recruitment channel because it helps diagnose these limits. Compare response patterns by channel without assuming the differences identify causes. People choose their channels, and the same unobserved enthusiasm may influence both recruitment and willingness to pay. Weighting requires credible population totals and assumptions about response mechanisms. Inventing weights to force a desired demographic balance creates apparent sophistication without evidence. When the sampling frame is unavailable, state that limitation and use the results to refine a pilot rather than claiming the entire campus is ready to buy.

- A convenience sample describes its respondents
- A larger sample does not remove coverage bias
- Record recruitment channel and nonresponse

## Slide 5 Random assignment and representation

An experiment compares outcomes under deliberately assigned conditions. For Lumen Trail's landing page study, eligible visitors are randomly assigned to A, the existing service description, or B, a repair guarantee description. The causal question is the effect of offering that wording on interest signup among the visitors eligible during the study. It does not automatically concern paid subscriptions, all students, other prices or other seasons. State the intervention and the comparison before seeing outcomes because changing the question after looking at the data can make a chance pattern seem planned. Random assignment aims to make the groups comparable on average, including characteristics the researcher did not measure. It does not guarantee that every observed characteristic will match exactly in one sample. Random sampling serves a different purpose: it concerns representation of a larger population. A randomized experiment conducted among voluntary website visitors can support a causal comparison within that setting while still having limited population coverage. Both claims should appear separately in a report. Neither can be inferred merely because a spreadsheet contains columns named control and treatment.

- Random assignment supports a within-study causal comparison
- Random sampling concerns population representation
- Neither is established by a column label

## Slide 6 Visitor units and outcome windows

Choose the assignment unit to match the intervention and likely spillovers. Individual visitors are appropriate when one person's page exposure is unlikely to change another person's outcome. A campus-wide sign or a residence-hall message may require assignment by group. Repeated visits create a further problem: if one person sees both versions, treatment is no longer stable. The synthetic experiment uses one unique visitor, one assigned arm and one retained exposure per row. Its case narrative stipulates that arm assignment persisted during the 48-hour follow-up window. Analyze visitors in their assigned groups when estimating the effect of the offer. Dropping people who disliked the wording or who did not finish the page would condition on behavior that might be caused by treatment. Record implementation failures separately and explain their implications. If an outage prevents outcome collection for one arm, a clean-looking conversion rate does not repair the missing evidence. A report must distinguish a true zero signup from an unavailable outcome. The supplied clean teaching dataset stipulates complete outcome collection; that assumption is part of the design evidence.

- One retained exposure per unique visitor
- Keep visitors in their assigned groups
- Observe registrations within 48 hours

## Slide 7 Absolute and relative lift

With 40 signups among 400 A visitors and 60 among 400 B visitors, the rates are 10 percent and 15 percent. The absolute difference is 5 percentage points. The relative increase is 50 percent because the five-point change is divided by the ten-percent baseline. Saying the increase is 50 percentage points would be wrong. Report both the event counts and denominators so the reader can reconstruct the rates. An attractive relative number can otherwise hide a small baseline or an impractical expected gain. Uncertainty belongs beside the estimate. For an introductory large-sample calculation with independent observations, the standard error of a difference in proportions is the square root of the sum of p times one minus p divided by sample size for each arm. A normal-approximation interval adds and subtracts 1.96 standard errors. This is a teaching approximation, not a universal guarantee; small counts, clustered assignment, repeated observations or adaptive stopping require methods matched to the design. Explain the method rather than displaying an interval without its assumptions.

- A has 40 signups among 400 visitors
- B has 60 signups among 400 visitors
- Five percentage points is a 50 percent relative increase

## Slide 8 Uncertainty and analysis choices

Declare a primary outcome before launch. If the team inspects many segments, several funnel stages and many stopping dates, the probability of finding an impressive pattern by chance grows. Segment analyses can still be useful as exploratory work, provided they are labeled and used to design a follow-up. A subgroup with ten visitors should not carry the same evidential weight as the full experiment. Avoid selecting the one attractive segment while suppressing the rest, and retain the planned analysis even when it disappoints the sponsor. An experiment can end because it reaches its planned sample, its scheduled window closes, or a safety or implementation condition requires stopping. Repeatedly checking for a favorable result and stopping at the first success changes the statistical procedure. In this course, use the stipulated fixed 800-visitor sample. Report the primary result, its uncertainty and a business interpretation. The company still needs evidence about payment, fulfillment and retention. A causal lift in interest can justify another test without justifying a full commercial launch.

- Report counts, estimate and interval together
- Use a method matched to assignment and observations
- Label unplanned subgroup work as exploratory

## Slide 9 Segments and usable decisions

Segmentation divides a market into groups that may respond differently to an offer or require different service. A useful segment has a clear definition, can be reached through an available channel and supports a meaningful operating choice. Labeling customers as eco enthusiasts provides little value if the company cannot identify them before purchase or if the label simply restates their observed purchase. Begin with the decision: a repair subscription may need a different offer for frequent campus commuters than for occasional online buyers, but that difference needs evidence and a feasible way to act. Distinguish descriptive segments from predictive rules and causal interventions. A description says that respondents recruited at a repair event report higher interest. A prediction estimates which future people are likely to register. A causal claim says that moving someone into a condition changes their behavior. The same table does not establish all three. Recruitment channel may be associated with interest because already interested people attend repair events. Spending money to recreate the event might or might not produce the same response among a broader audience.

- Define the segment before targeting
- Separate description, prediction and causation
- Use fields available at the decision time

## Slide 10 Survey response limits

The supplied survey records a five-point importance item and a stated maximum monthly price. The importance scale is ordinal: five is above four, but the distance between four and five is not necessarily the same as the distance between one and two. Showing the distribution preserves more information than a single average. A price response is numeric but hypothetical. It can be affected by question wording, social desirability and a respondent's desire to encourage the service. Treat stated price as one input to offer design, not as a guaranteed future transaction. Missing price responses remain blank. Report the number of valid responses used in an average and compare missingness across observed groups. Replacing blank values with zero changes the estimand from the mean among respondents who provided a price to a mixture of prices and assumed refusals. Dropping incomplete records without describing the loss can also mislead. If nonresponse is related to uncertainty about the service, the available answers may overstate confidence. A clear report describes the available sample before deciding whether a summary is decision useful.

- Importance is an ordinal rating
- Stated price is hypothetical
- Report valid and missing response counts

## Slide 11 Aggregation and attribution

An overall rate should generally use the matching totals. If one channel has one order from ten clicks and another has ninety-nine orders from nine hundred ninety clicks, the combined rate is one hundred divided by one thousand. Averaging channel percentages with equal weights answers a different question and can give a small channel disproportionate influence. The same principle applies to cost per order: total spend divided by total orders is the overall acquisition cost under the dataset's definitions. Retain channel-level results when they explain meaningful differences. Time aggregation requires care as well. The daily performance dataset covers twenty-four September dates across four channels. Summing its booked revenue is appropriate for that observation window. It is not an annual revenue estimate without an explicit extrapolation assumption, and it is not the company income statement. Some costs may occur earlier than an attributed order. If one channel's conversions are delayed, comparing only same-day conversions can distort the conclusion. Define the attribution window, observation period and accounting treatment before presenting a combined number.

- Overall cost per order uses matching totals
- Last touch is an attribution convention
- The next dollar can differ from the average dollar

## Slide 12 Pilot contribution economics

For the repair landing-page example, the synthetic assumption is nineteen dollars of expected contribution per interest signup. That value is a modeling input, not observed cash. At the observed sample size, twenty additional signups imply three hundred eighty dollars of expected incremental contribution. If implementing the offer costs five hundred dollars for the same scope, the resulting incremental estimate is negative one hundred twenty dollars. A statistically detectable lift can therefore be economically unattractive under the stated cost assumptions. The recommendation can still be to continue learning if the experiment reduces a consequential uncertainty or if implementation costs will fall at a larger scale. State that reasoning openly. Do not disguise a learning objective as established profitability. A good memo presents the causal result, the economic assumptions, a sensitivity to the uncertain contribution value, and a decision rule for the next stage. It also identifies evidence still needed, such as actual payments and service utilization. Metrics become useful when the reader can trace how they change an action.

- Twenty additional signups at 19 USD imply 380 USD
- Subtract the 500 USD implementation assumption
- Interest lift alone does not establish profitability

## Slide 13 The next evidence decision

The paid pilot should begin only after an operations owner sets an enrollment cap and a service promise that can be measured. At minimum, record completed payments, repair requests per enrolled member, turnaround time, refunds and cancellations over a predeclared period. Set decision thresholds before viewing those outcomes. The experiment's interest metric remains useful for recruitment, but the next stage must observe behavior closer to the business model. Team members should retain a record of design changes so a later analyst can tell a real improvement from a changed definition. My contribution to this fictional team assignment is the marketing analysis and this memo. I did not design the operations model or calculate a consolidated company valuation. A portfolio adaptation could show the question, the observed experiment result, the scenario economics and the proposed next study. It should label all data as synthetic and avoid claiming that the recommendation produced actual revenue. The strongest result of this analysis is a better specified decision and a clear account of what evidence remains unavailable.

- Measure actual payments and service use
- Set a capacity cap and a stopping rule
- Keep synthetic analysis claims proportionate

## Slide 14 Source data excerpt

The final exhibit shows the first five records and first five fields of MKT320_Repair_Landing_Experiment.csv. It is a labeled excerpt, not the complete dataset. Use the CSV or full text mirror for calculation and complete coverage.

| visitor_id | variant | exposure_date | acquisition_channel | visitor_status |
| --- | --- | --- | --- | --- |
| EXP-A-0001 | A | 2026-10-05 | organic_search | new |
| EXP-A-0002 | A | 2026-10-05 | campus_email | new |
| EXP-A-0003 | A | 2026-10-05 | paid_search | new |
| EXP-A-0004 | A | 2026-10-05 | campus_email | new |
| EXP-A-0005 | A | 2026-10-05 | organic_search | new |
