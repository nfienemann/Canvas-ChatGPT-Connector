# Research Brief and Measurement Plan

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A01 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Choose a precise research question for Lumen Trail's proposed repair offer. Define the decision, target population, observation unit, outcome and time window. Distinguish the business choice from the information needed to make it.

Draft a short measurement plan with three questionnaire items or behavioral measures. Explain which construct each measure represents and identify a plausible alternative interpretation. Include a missing-response option where appropriate.

Describe a feasible sampling approach and identify coverage and self-selection limitations. Do not claim that a convenience sample becomes representative merely because it is large. Explain how the design would change the recommendation you can make.

Conclude with a decision rule and a brief account of what the proposed study cannot answer. The work is a design exercise using fictional people; do not recruit anyone or collect actual personal data.

## Required submission

- Research brief PDF
- Measurement appendix
- Assistance disclosure

## Format and assessment conditions

Format: PDF memo with the exhibits listed below. Word limit: 800 to 1000 words. Estimated preparation time: 4 hours.

Deadline: 2026-09-13T23:59:00-04:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-R01
