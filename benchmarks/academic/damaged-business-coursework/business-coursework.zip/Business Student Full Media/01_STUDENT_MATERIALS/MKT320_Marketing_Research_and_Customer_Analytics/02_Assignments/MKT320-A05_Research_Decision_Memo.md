# Research Decision Memo

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A05 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Prepare a decision memo on whether Lumen Trail should fund a capped paid repair-subscription pilot. Analyze the landing experiment, voluntary survey and channel dashboard as distinct evidence sources. Do not invent customer-level links among the files.

Verify the primary experiment counts, calculate absolute and relative lift with uncertainty, and explain the causal scope supported by the stipulated design. Use source identifiers for both the design narrative and data file.

Evaluate the hypothetical nineteen-dollar contribution and five-hundred-dollar implementation cost. Show the incremental contribution result and break-even contribution per additional signup. Identify the paid-demand and operating-cost evidence that remains unavailable.

Recommend a next step with a decision rule, owner and measurement plan. Attribute your own work accurately in any portfolio version. The October 26 announcement supersedes the original October 30 deadline; the current due date is November 2 at 23:59 America/New_York.

## Required submission

- Decision memo PDF
- Editable calculation workbook
- Source and contribution appendix

## Format and assessment conditions

Format: PDF memo with the exhibits listed below. Word limit: 1400 to 1800 words excluding exhibits. Estimated preparation time: 7 hours.

Deadline: 2026-11-02T23:59:00-05:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-C01
- MKT320-R02
- MKT320-R03
- MKT320-R04
- MKT320-N01
