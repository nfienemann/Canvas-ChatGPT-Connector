# Individual Research Methods Assessment

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A07 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Demonstrate the concepts listed in the coverage guide using new scenarios. The assessment covers measurement, sampling, experiments, effect sizes, uncertainty and channel reporting. It does not require knowledge of an actual company.

Show the denominators and units in all calculations. Interpret numerical results in relation to the stated population and outcome, and distinguish a causal claim from an observational association.

You may bring one handwritten reference sheet and use a nonnetworked calculator under this fictional assessment rule. AI tools, messaging and generated answers are prohibited during the timed assessment.

Prepare through voluntary practice before the assessment. The review questions are practice examples rather than a leaked or predicted exam. Do not present generated practice as instructor-authored assessment content.

## Required submission

- Individual in-class answer booklet

## Format and assessment conditions

Format: Individual in-class paper answer booklet. Word limit: Timed individual responses. Estimated preparation time: 5 hours.

Deadline: 2026-11-12T10:15:00-05:00. Points possible: 100. Grade category: Exam.

## Academic assistance policy

No AI assistance during the assessment. One handwritten reference sheet and a nonnetworked calculator are permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-E01
