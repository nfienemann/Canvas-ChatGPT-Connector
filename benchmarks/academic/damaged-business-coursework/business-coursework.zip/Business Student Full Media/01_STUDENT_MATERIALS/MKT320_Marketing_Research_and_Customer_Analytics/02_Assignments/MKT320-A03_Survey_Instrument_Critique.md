# Survey Instrument Critique

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A03 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Review the repair-survey fields and propose two wording improvements that reduce ambiguity. Explain whether each issue concerns measurement, sampling or both. Retain the original field definition alongside your proposed revision.

Identify one double-barreled question that could plausibly arise in this context and rewrite it into separate items. This invented example should be clearly labeled and must not be presented as a quotation from a supplied instrument.

Describe how missing stated-price responses should be recorded and summarized. Explain what would be assumed if an analyst replaced every blank with zero. Provide a denominator example without inventing observed responses.

This assignment is excused for Riley in the fictional grade record. The instructions remain available for optional practice. An excused item is excluded from its category denominator rather than counted as a zero.

## Required submission

- Critique PDF

## Format and assessment conditions

Format: PDF response with any calculation file listed below. Word limit: 600 to 800 words. Estimated preparation time: 2 hours.

Deadline: 2026-10-04T23:59:00-04:00. Points possible: 100. Grade category: Methods.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-R01
- MKT320-R03
