# Paid Pilot Research Design Project

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A06 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Design the next stage of evidence collection for the proposed subscription. Specify a practical participant definition, offer, comparison, observation period and primary outcome that is closer to economic viability than interest alone.

Explain how the proposed study will record payments, repair utilization, turnaround time and cancellations. Distinguish measured outcomes from management assumptions, and state what information an operations owner must provide before enrollment begins.

Set a proposed expansion, revision or stopping rule before any new outcomes are observed. Explain the cost of a false positive and a false negative for this decision, and identify at least one potential implementation failure.

Submit a team report and six-slide briefing with a contribution statement for each fictional team role. This is a design proposal using synthetic data; no live recruitment or contact is required. Generative assistance is restricted to brainstorming questions and outline clarity, not drafting assessed prose or recommendations.

## Required submission

- Research design report
- Six-slide briefing
- Team contribution statement

## Format and assessment conditions

Format: PDF report and PPTX briefing. Word limit: 1800 to 2200 words and 6 slides. Estimated preparation time: 10 hours.

Deadline: 2026-12-04T17:00:00-05:00. Points possible: 100. Grade category: Project.

## Academic assistance policy

Brainstorming research questions and checking outline clarity only. No generative drafting of assessed analysis, prose or slides.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-C01
- MKT320-N02
- MKT320-P01
