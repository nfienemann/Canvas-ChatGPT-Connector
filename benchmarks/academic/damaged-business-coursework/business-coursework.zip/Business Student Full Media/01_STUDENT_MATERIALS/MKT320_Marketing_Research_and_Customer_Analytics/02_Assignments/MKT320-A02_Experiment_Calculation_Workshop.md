# Experiment Calculation Workshop

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A02 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Use the eight-hundred-row landing-page dataset and verify that visitor identifiers are unique. Count the assigned visitors and registrations in each arm before computing any rates. Preserve the fixed assignment groups described in R02.

Calculate each signup rate, absolute difference, relative difference and the course normal-approximation interval. Show formulas and input counts in an editable calculation file. State the assumptions under which the interval is informative.

Write a short interpretation that distinguishes interest registration from paid subscription. Explain which facts support a causal comparison and which facts limit generalization. The presence of an arm label in a file is not enough to establish randomization.

Include one sensitivity calculation using a different hypothetical contribution per incremental signup. Label the changed value as a scenario and preserve the original case assumption for comparison.

## Required submission

- Calculation workbook
- Methods explanation PDF

## Format and assessment conditions

Format: PDF response with any calculation file listed below. Word limit: 500 to 700 words plus calculations. Estimated preparation time: 3 hours.

Deadline: 2026-10-18T23:59:00-04:00. Points possible: 100. Grade category: Methods.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-R02
- MKT320-C01
