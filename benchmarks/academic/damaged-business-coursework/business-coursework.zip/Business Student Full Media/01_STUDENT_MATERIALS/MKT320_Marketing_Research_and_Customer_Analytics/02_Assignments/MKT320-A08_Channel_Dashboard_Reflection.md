# Channel Dashboard Reflection

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A08 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Summarize the September channel dataset with total spend, attributed orders, booked revenue and overall cost per order. Explain the unit of each row and preserve the distinction between impressions, clicks and unique people.

Compare the aggregate ratio with an unweighted average of channel ratios and state the different question answered by each. Use matching totals for the overall operating metric.

Identify one reason last-touch attribution may mislead a budget reallocation decision and propose an experiment or staged change that would produce stronger evidence.

The fictional record explicitly shows this assignment as missing with a posted score of zero. Preserve that zero when calculating the current grade. This differs from the blank ungraded score for the discussion.

## Required submission

- Reflection PDF
- Calculation exhibit

## Format and assessment conditions

Format: PDF response with any calculation file listed below. Word limit: 700 to 900 words. Estimated preparation time: 3 hours.

Deadline: 2026-10-18T23:59:00-04:00. Points possible: 100. Grade category: Methods.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-R04
