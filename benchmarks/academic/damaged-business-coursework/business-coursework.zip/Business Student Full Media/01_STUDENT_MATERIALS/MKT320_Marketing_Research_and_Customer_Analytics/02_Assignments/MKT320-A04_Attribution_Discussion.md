# Attribution Discussion

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

MKT320-A04 | MKT320 | Issued for fictional Fall 2026 semester

## Assignment requirements

Respond to the director's proposed budget transfer using the distinction between attributed performance and incremental impact. State one valid descriptive conclusion and one claim that the dashboard cannot establish.

Use the correct rate denominator and explain why average performance need not equal the performance of the next dollar spent. A response should connect the limitation to an actual budget decision.

Post the initial response by October 23 and two replies by October 25. Each reply should ask a question or add analysis about design, measurement or a decision consequence. A generic agreement does not meet the reply requirement.

The supplied excerpt contains Riley's initial post and one reply and is explicitly partial. Use that evidence to report observed participation without claiming complete submission or definite noncompletion.

## Required submission

- Initial post
- Two substantive replies

## Format and assessment conditions

Format: Discussion platform text. Word limit: 250 to 350 word initial post and two substantive replies. Estimated preparation time: 2 hours.

Deadline: 2026-10-25T23:59:00-04:00. Points possible: 100. Grade category: Discussion.

## Academic assistance policy

Calculation explanations and mechanical editing are permitted with disclosure. Students must perform and verify the analysis and write the assessed recommendation themselves.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Question and decision (20 points)

Excellent: Defines the exact decision, population and usable comparison.

Adequate: States a decision but leaves one boundary unclear.

Needs work: Describes a topic without a decision.

## Evidence and calculations (35 points)

Excellent: Uses the correct unit, denominator and reproducible calculations with source identifiers.

Adequate: Calculations are mostly sound with a limited documentation gap.

Needs work: Errors alter the conclusion or source provenance is absent.

## Interpretation and uncertainty (25 points)

Excellent: Distinguishes supported findings, assumptions, uncertainty and plausible alternatives.

Adequate: Identifies an important limitation but does not connect it to the decision.

Needs work: Treats association or one point estimate as certainty.

## Recommendation and presentation (20 points)

Excellent: Provides a feasible recommendation, owner and decision trigger in a readable document.

Adequate: Recommendation is reasonable but implementation or writing needs precision.

Needs work: Recommendation is unsupported or required components are missing.

## Assigned sources

- MKT320-D01
- MKT320-R04
