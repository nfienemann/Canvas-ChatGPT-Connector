# Research Memo Deadline Revision

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID MKT320-N01 | MKT320 | Issued 2026-10-26 | Assessments MKT320-A05

## Revised date

Posted October 26, 2026 at 09:00 America/New_York by Dr. Maren Sol. The Research Decision Memo MKT320-A05 deadline moves from October 30 at 23:59 to November 2 at 23:59 America/New_York. The new local time uses UTC minus five hours because daylight saving time ends before the revised deadline. The October 30 date in the original weekly schedule is superseded for this assignment only.

The deliverables and rubric do not change. Submit the memo and calculation workbook as two files. An uploaded draft or instructor feedback is not a final submission receipt. The final submission status remains unknown in the supplied local-source package unless a separate receipt is provided.
