# Business Strategy and Ethics Lecture Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Slide 1 is the cover. These notes accompany the editable deck and its PDF.

## Slide 2 Strategy requires choices

Ask students to distinguish a goal from a strategy. Growth states a desired result but does not identify whom the company serves or how it will deliver value. Use the repair subscription to identify a customer problem, a bounded offer, and the activities required. A fast-turnaround promise has implications for intake, parts, staffing, and communication. A credible alternative must receive comparable detail. Otherwise the preferred proposal wins because it is the only option the author has developed. Invite students to state one thing the company would choose not to promise. That tradeoff often reveals whether the proposal is coherent or merely an accumulation of attractive features.

- Specify the customer problem and offer
- Align activities with the promise
- Name the tradeoff and the alternative

## Slide 3 Customer value and activity fit

Compare a customer who needs an urgent repair with one who values predictable access over time. Their needs may lead to different service designs even if their demographic labels are similar. A subscription is a mechanism, not automatically the best solution to a repair problem. Ask whether a one-time service could provide the same benefit with less complexity. Then connect the offer to the work system. Adding a feature can undermine the original promise if it consumes scarce capacity. Activity fit asks how choices reinforce or obstruct one another. Students should support the proposed fit with an explanation rather than relying on a broad sustainability or loyalty claim.

- Different needs imply different offers
- Recurring access may not suit infrequent use
- Delivery choices must support the claimed benefit

## Slide 4 Assumptions and evidence

The statement that customers like repair is too vague to guide a test. A more useful assumption specifies an eligible group, an offer, and the behavior relevant to a decision. The threshold should come from a stated decision need or teaching assumption. A six-week pilot can observe early usage but cannot directly establish annual renewal. Interest expressed in an interview may not predict payment under the real conditions. Ask students to identify a direct measure and a convenient proxy for one assumption. Then discuss how using the proxy should limit the claim. The objective is a learning plan that changes a decision, not a collection of impressive-looking metrics.

- Write assumptions that evidence could challenge
- Match the observation window to the claim
- Separate interest from actual acceptance

## Slide 5 Stakeholders and affected interests

Map customers, employees, campus partners, and the sponsor. For each, describe a mechanism of benefit or cost. A list of names without those mechanisms cannot guide a tradeoff. The sponsor may have formal power while a customer bears immediate inconvenience from a failed repair promise. This does not mean every interest receives identical weight. It means the decision requires a reasoned account that can be explained to affected people. Ask whose perspective is absent from the packet and how that absence affects confidence. Remind students that the interview excerpts are fictional perspectives, not representative survey findings or verified statements from real people.

- Identify how each group is affected
- Separate power from exposure
- Examine whose information is missing

## Slide 6 Ethical perspectives test the recommendation

Apply consequences, duties, and fairness to the same promotional claim. A broad launch may create more immediate access while also exposing more customers to unsupported promises. A favorable expected total benefit does not automatically settle whether the organization respects its commitments. A fair process should offer a reasonable way to correct errors. Students should identify where the perspectives agree and where they create tension. The goal is not to attach three labels to the memo. A useful analysis suggests a practical design change, such as clearer eligibility or a pause process, and explains which concern that change addresses and which tradeoff remains.

- Compare expected benefits and harms
- Examine commitments and meaningful choice
- Assess allocation and a route to challenge errors

## Slide 7 Weighted matrix arithmetic

Walk through one panel-option combination. Six weights sum to one, and each weighted contribution equals weight times score. The option comparison averages four panel totals. Explain that the scores are ordered classroom judgments and the decimal result is not a financial return or a measured utility. Arithmetic can be correct while the criteria or scores are poorly justified. Ask students to inspect criterion definitions and look for overlap. Feasibility can affect economics, so the same staffing concern may appear twice. The calculation helps expose assumptions and disagreements. It does not remove the need to explain why the model is suitable for the decision.

- Multiply each criterion weight by its score
- Sum within each panel and option
- Average the four panel totals

## Slide 8 Prerequisites and compensating scores

A weighted sum allows strong performance on one criterion to offset weak performance elsewhere. That can be appropriate for preferences but unsuitable for a prerequisite. In the fictional charter, a functioning consent process and supported customer promise must be verified before enrollment. An attractive learning score cannot replace those conditions. The model can identify a preferred direction while the recommendation remains conditional. Ask students which source establishes the prerequisite and what record would demonstrate satisfaction. A draft advertisement and an analyst's favorable conclusion do not create authorization. This distinction is central to the course's treatment of source authority and governance.

- A weighted sum permits tradeoffs
- Some conditions must be satisfied first
- A high rank does not establish launch readiness

## Slide 9 Sensitivity reveals dependence

A useful sensitivity analysis should challenge a material assumption rather than make a cosmetic change. If five percentage points move from learning value to feasibility, state the reason and recompute every option using the same rule. If the ranking changes, identify the value judgment or uncertain fact responsible. If it does not change, explain that stability does not validate the original scores or verify prerequisites. Students should avoid searching for a combination that supports their preferred answer and then presenting that combination as neutral. The final memo should make the dependence visible enough that a reviewer can disagree with an assumption and see the consequence.

- Change a disputed assumption for a reason
- Keep weights normalized
- Explain whether the decision changes

## Slide 10 Practice records and their limits

The intake log contains simulated review examples. Consent can be complete, incomplete, or not reviewed. The last category cannot be reclassified as a refusal or as confirmed absence. Unsupported promises and outside-scope repairs can occur in the same record, so adding counts overstates unique affected records. Ask students to calculate the intersection of complete consent, a supported promise, and an eligible scope. Then discuss what that calculation means. It describes the supplied practice records. It does not estimate real customer prevalence, willingness to pay, repair cost, or commercial service turnaround. The response-time field belongs to the tabletop exercise and must retain that meaning.

- Not reviewed is an unresolved status
- Issue categories overlap
- Tabletop evidence does not establish demand

## Slide 11 Governance and responsible exit

The sponsor owns the decision, but named reviewers examine intake and capacity evidence. This division helps avoid a situation where everyone assumes someone else checked an unresolved condition. A decision log should record the evidence, conclusion, and remaining conditions. Then discuss exit. Stopping new enrollments does not erase accepted repairs or customer expectations. The plan needs an owner for current obligations and a communication process for participants. Reversibility therefore includes more than stopping expenditure. Ask students how the exit design affects the ethical argument and the operational feasibility of the pilot. These connections make the strategy coherent across the document.

- Name the enrollment decision owner
- Identify evidence reviewers
- Preserve obligations when enrollment pauses

## Slide 12 Project attribution and evidence of impact

Riley recalculated the base matrix and analyzed the practice-record intersection. Teammates developed other parts of the argument. A portfolio can accurately describe these contributions and the conditional recommendation. It cannot claim sole authorship or a real improvement in revenue, customer satisfaction, or product longevity. The project has not been implemented. Permission to access a team report also does not establish permission to publish it. The fictional course permits a limited retrospective summary of one's own contribution after feedback, while the full final report's release status remains unknown. Good communication makes the work understandable without enlarging the claim beyond the evidence.

- Describe the analytical work actually performed
- Attribute team contributions accurately
- Keep simulated and measured outcomes distinct

## Slide 13 Current requirements and source authority

Practice reconciling the documents. The archived handout lists November 23 and PDF only. N01 revises the deadline for A07 to November 30, and N02 adds the calculation workbook while preserving the word range. Neither announcement changes the brainstorming-only assistance rule. The unapproved promotional draft uses claims that exceed the fictional charter and is included for critique. Its later date does not give it greater authority than the approved charter. A reader must evaluate scope, status, and explicit revision language, not just choose whichever document is newest. The supplied packet still contains no completed enrollment approval or actual commercial results. Ask students to defend a concrete example.

- Final memo due November 30 at 11:59 PM
- Submit both PDF and XLSX files
- Draft advertising does not amend the charter

## Slide 14 Source data excerpt

The final exhibit shows the first five records and first five fields of STR410_decision_matrix.csv. It is a labeled excerpt, not the complete dataset. Use the CSV or full text mirror for calculation and complete coverage.

| panel | option | criterion | weight | score_1to5 |
| --- | --- | --- | --- | --- |
| Customer panel | Defer launch | Customer usefulness | 0.25 | 1 |
| Customer panel | Defer launch | Operational feasibility | 0.2 | 5 |
| Customer panel | Defer launch | Unit economics | 0.15 | 4 |
| Customer panel | Defer launch | Learning value | 0.15 | 1 |
| Customer panel | Defer launch | Customer protection | 0.15 | 5 |
