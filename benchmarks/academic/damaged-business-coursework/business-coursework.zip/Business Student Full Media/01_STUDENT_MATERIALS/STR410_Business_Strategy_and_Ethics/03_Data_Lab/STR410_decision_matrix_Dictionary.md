# STR410 decision matrix

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-DATA1

## Dataset scope

72 structured judgment rows. Sum weighted contributions per panel-option, then average four panel totals. Charter prerequisites remain separate from compensating scores.

Records: 72. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| panel | string | category | One of four fictional stakeholder rating panels. |
| option | string | category | Deferral, limited pilot, or broad launch. |
| criterion | string | category | Defined classroom evaluation dimension. |
| weight | decimal | share | Criterion weight; six weights sum to one per panel-option. |
| score_1to5 | integer | ordered judgment | Classroom judgment from one to five, not measured utility. |
| weighted_points | decimal | model points | Weight multiplied by score; recompute rather than treat as independent evidence. |
