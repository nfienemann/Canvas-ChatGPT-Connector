# STR410 tabletop intake log

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-DATA2

## Dataset scope

84 fictional tabletop records. Categories overlap. No demand, profitability, actual enrollment, or customer-satisfaction evidence is present.

Records: 84. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| practice_id | string | identifier | Invented tabletop example key, not a customer ID. |
| campus | string | category | One of two fictional campuses. |
| review_date | ISO date | calendar day | Date assigned to the simulated review. |
| consent_status | string | category | Complete, incomplete, or not_reviewed; unknown is not refusal. |
| promise_status | string | category | Whether the practice promise is supported by the proposed process. |
| repair_scope | string | category | Whether the example is eligible under the proposed scope. |
| review_minutes | integer | minutes | Tabletop review processing time, not repair turnaround. |
