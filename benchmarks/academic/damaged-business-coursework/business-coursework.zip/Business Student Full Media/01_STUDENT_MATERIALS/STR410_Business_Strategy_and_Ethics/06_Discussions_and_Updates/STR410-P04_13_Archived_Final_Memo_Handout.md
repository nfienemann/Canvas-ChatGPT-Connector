# Archived Final Strategy Memo Handout

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID STR410-P04 | STR410 | Issued 2026-09-21 | Assessments STR410-A07

## Original instructions retained for comparison

Original instructions for STR410-A07: submit a 2,000 to 2,500 word PDF memo by November 23, 2026 at 11:59 PM America/New_York. Include exhibits showing the base decision matrix and a sensitivity analysis. The original handout required PDF only and did not require a separate calculation workbook.

This handout remains in the packet for source-version testing. STR410-N01 later changes the due date to November 30. STR410-N02 later requires both the PDF memo and an XLSX workbook. The word range and substantive argument requirements remain unchanged. Neither announcement changes the brainstorming-only assistance policy.
