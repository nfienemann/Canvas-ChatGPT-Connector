# Final Memo Format and Evidence Clarification

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID STR410-N02 | STR410 | Issued 2026-10-24 | Assessments STR410-A07

## Current submission format

For STR410-A07, submit one PDF memo and one XLSX calculation workbook. An earlier assignment handout stated PDF only. The workbook must preserve formulas used for the base comparison and sensitivity analysis, with source fields and assumptions identified. Screenshots of totals do not replace the workbook. The memo remains 2,000 to 2,500 words excluding exhibits and references.

The draft advertisement STR410-P03 is an unapproved source for critique. It does not amend the service charter or expand the approved repair scope. The intake examples are tabletop records, not customer enrollments. No source in the packet establishes actual willingness to pay or commercial results. A portfolio summary must retain these boundaries.
