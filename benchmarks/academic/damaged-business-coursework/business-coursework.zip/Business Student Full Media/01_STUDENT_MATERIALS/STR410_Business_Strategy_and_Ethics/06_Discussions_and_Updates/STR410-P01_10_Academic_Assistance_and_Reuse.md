# Academic Assistance and Reuse Policy

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID STR410-P01 | STR410 | Issued 2026-08-31 | Assessments STR410-A01, STR410-A06, STR410-A07, STR410-A08

## Task-specific assistance

This fictional policy is source material for testing, not real institutional or application authorization. In the simulated course, voluntary practice with original questions is permitted. STR410-A07 permits brainstorming of alternatives and discussion of ethical concepts. Students must independently create the assessed outline, perform the calculations, and draft the final memo. Permission to brainstorm is not permission to generate a substantive outline or submission text.

STR410-A06 is an individual in-class exam with no generative assistance, collaboration, or outside drafting of the assessed response. Printed readings and one page of personal notes are permitted. STR410-A01 and STR410-A08 permit mechanical proofreading only after the student has completed a draft. A document's availability does not establish permission for every use, and silence about an activity does not grant it.

## Portfolio and group attribution

After feedback on STR410-A03, a student may prepare a short retrospective description of their own contribution, identifying the project as simulated and naming the contribution accurately. The final team report's public-release status is not recorded. Do not infer permission to publish the full report from the ability to access it. A portfolio may discuss the construction of a decision model and a conditional recommendation. It must not imply that the business adopted the recommendation or that the proposed benefits were measured.
