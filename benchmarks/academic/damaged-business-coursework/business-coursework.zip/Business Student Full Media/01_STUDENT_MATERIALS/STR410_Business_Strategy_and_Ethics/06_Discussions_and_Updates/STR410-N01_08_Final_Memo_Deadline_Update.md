# Final Strategy Memo Deadline Update

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID STR410-N01 | STR410 | Issued 2026-10-22 | Assessments STR410-A07

## Revised final deadline

STR410-A07 is now due Monday, November 30, 2026 at 11:59 PM America/New_York. The original course schedule listed November 23. This announcement supersedes that date for the final strategy memo only. Presentations remain December 7 and December 9, and the individual case exam remains November 9 at 3:00 PM.

The extension allows time to incorporate a sensitivity analysis and an updated governance plan. It does not authorize additional forms of generative assistance. The task-specific policy remains brainstorming only, with students independently producing the assessed outline, calculations, and prose.
