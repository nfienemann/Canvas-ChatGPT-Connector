# Business Strategy and Ethics

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410 | Fall 2026

## Purpose

Business Strategy and Ethics develops the ability to make and defend organizational choices under uncertainty. This fictional senior-level course connects value propositions, activity fit, stakeholder reasoning, decision models, and governance through a sustained case about a proposed campus repair subscription. Students compare feasible alternatives, identify assumptions, calculate a transparent weighted matrix, and examine the limits of compensating scores when a prerequisite applies. The course emphasizes honest interpretation of evidence and the difference between a preferred direction and authorization to act. Assignments include individual case memos, discussion, a team proposal, a final recommendation, and an independent case exam. The packet contains invented stakeholder interviews, tabletop intake records, sample student work, feedback, and conflicting document versions for controlled source-reconciliation tests. All organizations, policies, and records are synthetic.

## Learning outcomes

- Translate organizational goals into coherent strategic choices and tradeoffs.
- Compare feasible alternatives using explicit assumptions and evidence.
- Apply stakeholder and ethical reasoning to the same decision.
- Calculate and interpret a weighted matrix with normalized sensitivity analysis.
- Distinguish prerequisites from compensating preferences and recommendations from approvals.
- Design governance and exit processes that preserve existing obligations.
- Communicate individual contribution and uncertainty accurately in project and portfolio work.

## Scope

All materials are original fictional teaching content. The service charter is hypothetical, not a legal claim or real authorization. Explicit document conflicts are retained for controlled testing.
