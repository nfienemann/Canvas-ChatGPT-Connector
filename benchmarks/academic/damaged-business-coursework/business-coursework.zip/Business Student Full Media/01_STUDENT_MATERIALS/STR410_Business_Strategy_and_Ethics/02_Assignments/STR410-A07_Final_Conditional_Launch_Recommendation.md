# Final Conditional Launch Recommendation

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A07 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Develop the proposal into a final recommendation comparing all three options. Explain how the feedback changed the analysis. State the preferred direction and the conditions that must be satisfied before action.

Include the base decision model and a meaningful normalized sensitivity analysis. Discuss overlapping criteria and the limits of structured judgment scores. Preserve formulas in the workbook so the calculation can be inspected.

Address the strongest ethical objection, identify review responsibilities, and describe an exit process that preserves existing customer obligations. Use the intake log only for claims its design can support.

Follow STR410-N01 for the revised November 30 deadline and STR410-N02 for the PDF-plus-XLSX format. The older handout remains for version comparison. Submit a contribution log and an individual paragraph describing the reasoning each author can defend.

## Required submission

- PDF decision memo
- XLSX formula workbook
- Contribution log
- Individual contribution paragraph

## Format and assessment conditions

Format: PDF memo and XLSX calculation workbook. Word limit: 2000 to 2500 words excluding exhibits and references. Estimated preparation time: 12 hours.

Deadline: 2026-11-30T23:59:00-05:00. Points possible: 100. Grade category: Project.

## Academic assistance policy

Brainstorming alternatives and discussing concepts only; no substantive outline, drafting, rewriting, or calculation generation for the assessed submission.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Integrated strategic recommendation (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-C01
- STR410-F01
- STR410-N01
- STR410-N02
- STR410-P01
- STR410-P02
