# Decision Reflection

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A08 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Reflect on a strategic judgment that changed after examining the proposal feedback. Identify the original assumption and the evidence or argument that challenged it.

Explain how the revised judgment changes an action, a condition, or the next evidence collection. A reflection that only restates the feedback does not show the student's reasoning.

Distinguish your own contribution from the team's shared work. Avoid claiming that a hypothetical recommendation produced actual commercial or social outcomes.

This item is ungraded in the October 29 snapshot. The posted 82 on the earlier proposal does not transfer to this reflection. Keep its numerical score unknown until a source establishes one.

## Required submission

- Individual reflection

## Format and assessment conditions

Format: Individual DOCX. Word limit: 600 to 800 words. Estimated preparation time: 3 hours.

Deadline: 2026-10-28T23:59:00-04:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Mechanical proofreading only after an independently completed draft.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Reflective strategic judgment (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-F01
- STR410-L01
- STR410-P01
