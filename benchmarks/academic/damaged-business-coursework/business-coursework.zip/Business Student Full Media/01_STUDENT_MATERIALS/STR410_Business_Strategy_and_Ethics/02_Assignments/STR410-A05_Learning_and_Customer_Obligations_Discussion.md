# Learning and Customer Obligations Discussion

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A05 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Discuss whether a bounded pilot can ethically expose participants to uncertain service outcomes. Distinguish learning questions from basic prerequisites for enrollment.

Address a strong argument for proceeding and a strong argument for delay. Explain which uncertainty belongs inside the pilot and which should be addressed before asking customers to participate.

Post an initial response by October 18 at 11:59 PM and one substantive reply by October 19 at 11:59 PM America/New_York. A reply must add reasoning, an example, or a meaningful challenge.

Only Riley's own fictional entries are supplied in the packet. Use them to discuss this snapshot without inventing peer content or a broader participation history.

## Required submission

- Initial post
- Substantive reply

## Format and assessment conditions

Format: Initial post and substantive reply. Word limit: 250 to 350 words plus 100 to 150 word reply. Estimated preparation time: 2 hours.

Deadline: 2026-10-19T23:59:00-04:00. Points possible: 100. Grade category: Discussion.

## Academic assistance policy

Brainstorming permitted; final post and reply must be independently written.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Learning and obligations argument (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-R02
- STR410-R04
- STR410-D01
