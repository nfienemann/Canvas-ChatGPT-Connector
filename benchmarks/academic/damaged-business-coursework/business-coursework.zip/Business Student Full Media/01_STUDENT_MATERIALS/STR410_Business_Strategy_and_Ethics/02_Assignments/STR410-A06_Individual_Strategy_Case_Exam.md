# Individual Strategy Case Exam

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A06 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Prepare with the four readings, the case, the charter, and the decision-matrix method. The assessment tests application to a new scenario rather than recall of a model name.

Write two analyses independently during the scheduled session. You may use printed readings and one page of personal notes. The review packet contains voluntary practice, not the actual questions.

Support each recommendation with a comparative argument, an evidence limitation, and a condition that would change the decision. Explain the role of prerequisites when using numerical models.

The exam starts at 3:00 PM America/New_York on November 9 and lasts 75 minutes. Generative assistance, collaboration, and outside drafting are prohibited for the assessed response.

## Required submission

- Two independent analyses

## Format and assessment conditions

Format: Independent in-class response. Word limit: Two analyses in 75 minutes. Estimated preparation time: 6 hours.

Deadline: 2026-11-09T15:00:00-05:00. Points possible: 100. Grade category: Exam.

## Academic assistance policy

No generative assistance, collaboration, or outside drafting of the assessed response.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Independent strategic reasoning (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-R01
- STR410-R02
- STR410-R03
- STR410-R04
- STR410-E01
