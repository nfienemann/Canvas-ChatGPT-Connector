# Strategy Proposal and Decision Matrix

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A03 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Compare deferral, a limited pilot, and a broad launch using the supplied case and decision matrix. Recalculate the weighted totals and explain what the numerical comparison represents.

Distinguish a preferred option from the satisfaction of charter prerequisites. Identify the evidence needed before customer enrollment and the role that owns the decision.

Address one important stakeholder objection and include an initial exit plan. State the limitations of the supplied practice records and avoid claims about demand or profitability that the packet cannot support.

Submit a team proposal and a contribution log. The sample proposal and feedback are fictional. The posted grade for this assignment is 82 out of 100 and does not apply to the later reflection.

## Required submission

- Team proposal
- Calculation workbook
- Contribution log

## Format and assessment conditions

Format: Team DOCX and calculation workbook. Word limit: 1200 to 1500 words. Estimated preparation time: 7 hours.

Deadline: 2026-10-12T23:59:00-04:00. Points possible: 100. Grade category: Project.

## Academic assistance policy

Brainstorming and concept discussion permitted; team authors must independently draft assessed content and perform calculations.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Comparative strategic judgment (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-R01
- STR410-R02
- STR410-R03
- STR410-C01
