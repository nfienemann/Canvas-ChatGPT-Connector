# Strategy Choice Memo

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A01 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Analyze the proposed repair subscription as a set of choices rather than a general growth goal. Identify a customer problem, a bounded offer, and the activities required to deliver it.

Compare the proposal with a credible alternative such as one-time repairs or a preparation period before enrollment. Describe each alternative at a comparable level of detail so the preferred option is not favored by presentation alone.

State three assumptions that could change the recommendation. Identify what evidence would test each assumption and which questions cannot be answered in a short pilot.

Submit a clear recommendation with tradeoffs and limitations. The fictional grade record contains a posted 87 out of 100. Mechanical proofreading is permitted after the student completes the argument, but substantive generative drafting is not.

## Required submission

- Decision memo
- Assumption table

## Format and assessment conditions

Format: Individual PDF. Word limit: 900 to 1100 words. Estimated preparation time: 4 hours.

Deadline: 2026-09-20T23:59:00-04:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Mechanical proofreading only after an independently completed draft.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Coherent strategic choices (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-R01
