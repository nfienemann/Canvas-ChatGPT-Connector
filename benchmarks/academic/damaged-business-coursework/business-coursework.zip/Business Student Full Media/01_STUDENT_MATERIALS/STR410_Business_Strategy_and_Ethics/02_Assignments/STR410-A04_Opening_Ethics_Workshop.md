# Opening Ethics Workshop

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A04 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Discuss a fictional service promise that creates benefits for some participants and risks for others. Identify affected interests before selecting an ethical perspective.

Compare how consequences, commitments, and fairness change the questions you ask. Avoid assuming that one perspective removes the need to examine facts.

Produce a short group note explaining one unresolved disagreement and the evidence that would help address it. The aim is reasoned discussion, not a unanimous slogan.

Riley is marked excused in the fictional record. Exclude this item from grading denominators. A blank numerical score for an excused task is not a zero.

## Required submission

- Workshop note

## Format and assessment conditions

Format: In-class worksheet. Word limit: Not applicable. Estimated preparation time: 1 hours.

Deadline: 2026-09-14T15:00:00-04:00. Points possible: 100. Grade category: Discussion.

## Academic assistance policy

Collaborative classroom discussion permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Reasoned ethical comparison (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-R02
