# Stakeholder and Claims Analysis

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

STR410-A02 | STR410 | Issued for fictional Fall 2026 semester

## Assignment requirements

Evaluate the ethical quality of the proposed service communication using the stakeholder reading and the fictional charter. Identify who may benefit, who may bear costs, and which claims require support.

Apply at least two ethical perspectives to the same decision. Explain where they agree or conflict rather than presenting disconnected definitions. Address the strongest reasonable objection to your recommendation.

Compare the unapproved promotional language with the charter's scope. Identify specific mismatches and propose a revision strategy that would align the offer with what the organization can support.

The supplied status is missing, but the grade field is blank. No posted zero is evidenced for this item. Keep the missing-work status separate from a numerical grade assumption when calculating scenarios.

## Required submission

- Stakeholder analysis
- Claims comparison

## Format and assessment conditions

Format: Individual PDF. Word limit: 1000 to 1200 words. Estimated preparation time: 4 hours.

Deadline: 2026-10-04T23:59:00-04:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Concept discussion permitted; assessed prose must be independently written.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Ethical reasoning and claims (30 points)

Excellent: Makes a defensible claim, distinguishes facts from assumptions, and explicitly addresses the strongest contrary explanation.

Adequate: States a plausible claim and uses relevant material, but leaves one important assumption or alternative unexplored.

Needs work: Relies on assertion, a framework label, or evidence that does not support the stated claim.

## Evidence and interpretation (30 points)

Excellent: Uses traceable exhibits, correct denominators, appropriate uncertainty, and accurate source identifiers.

Adequate: Uses relevant exhibits with mostly correct interpretation but incomplete traceability or limited attention to uncertainty.

Needs work: Confuses source populations, treats unknown observations as zero, or invents evidence.

## Feasibility and tradeoffs (25 points)

Excellent: Explains implementation ownership, limits, costs of the alternative, and an observable condition for revising the recommendation.

Adequate: Proposes feasible actions but omits a responsibility, tradeoff, or decision threshold.

Needs work: Offers broad aspirations without a practicable action or a way to judge the result.

## Communication and attribution (15 points)

Excellent: Uses clear structure, follows the current submission requirements, and attributes individual and team contributions accurately.

Adequate: Communicates the main argument but includes minor organization, formatting, or attribution gaps.

Needs work: Obscures the argument or misrepresents another contributor's work.

## Assigned sources

- STR410-R02
- STR410-P02
- STR410-P03
