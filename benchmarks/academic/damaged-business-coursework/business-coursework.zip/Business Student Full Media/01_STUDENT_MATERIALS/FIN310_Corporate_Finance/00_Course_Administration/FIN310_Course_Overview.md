# Corporate Finance

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310 | Fall 2026

## Purpose

This fictional undergraduate course develops practical capital-budgeting and financial-decision skills through an original repair-program investment case. Students learn to place cash flows on a timeline, distinguish relevant costs from sunk costs and unchanged allocations, calculate operating and terminal cash flows, and interpret NPV, IRR, and payback. The course emphasizes transparent assumptions and reproducible models. Demand sensitivity, working-capital treatment, and communication of uncertainty are integrated into the project rather than treated as optional appendices. Students also learn to distinguish forecast value from realized business impact and to preserve individual and team authorship in a portfolio. The packet provides a full semester schedule, four substantial readings, structured fictional datasets, a sample student draft, feedback, and realistic source conflicts. No inputs are market quotes or real financial advice.

## Learning outcomes

- Construct correctly timed project cash flows.
- Distinguish sunk costs, opportunity costs, and incremental spending.
- Calculate and reconcile operating and terminal cash flows.
- Interpret NPV, IRR, and payback within their limits.
- Design and explain sensitivity comparisons.
- Communicate conditional recommendations and honest authorship.

## Scope

Intentional fixtures: November 6 original deadline corrected to November 8; unresolved 1000-1400 versus 800-1000 word range; ungraded discussion with bounded own-entry excerpts; undated optional clinic; annual versus uniform-monthly cash-flow timing. All post-November-1 deadline offsets are -05:00.
