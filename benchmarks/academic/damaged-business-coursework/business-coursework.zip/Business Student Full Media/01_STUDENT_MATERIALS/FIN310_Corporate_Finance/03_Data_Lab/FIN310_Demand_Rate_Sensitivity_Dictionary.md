# FIN310 Demand Rate Sensitivity

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-DATA2

## Dataset scope

Nine demand multipliers crossed with nine discount rates. These are deterministic scenarios, not empirical observations or probabilities.

Records: 81. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| scenario_id | string | not applicable | Unique calculated-grid row key. |
| demand_multiplier | number | ratio | Multiplier on every year of Base revenue; variable costs scale with revenue. |
| annual_discount_rate | number | fraction per year | Annual rate used with year-end cash flows. |
| npv_usd | number | USD | NPV including the time-zero 200000 USD outflow. |
| year_one_cash_flow_usd | number | USD | Operating cash flow in year one. |
| year_five_cash_flow_usd | number | USD | Operating cash flow plus 42500 terminal recovery. |
