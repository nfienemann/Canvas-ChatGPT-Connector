# FIN310 Monthly Project Forecast

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-DATA1

## Dataset scope

Uniform monthly allocation of fictional annual project forecasts. This is not observed seasonality. Assigned NPV uses annual totals at year end, plus a separate time-zero outflow of 200000 USD.

Records: 120. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| scenario | string | not applicable | Base or Downside; Downside uses 80% of Base revenue. |
| year | integer | year | Project year 1-5; no historical calendar date is implied. |
| project_month | integer | month | Sequential month 1-60 within each scenario. |
| revenue_usd | number | USD | Annual revenue allocated evenly over twelve months. |
| variable_cost_usd | number | USD | 55% of monthly revenue. |
| fixed_cost_usd | number | USD | 18000 annual cost divided by twelve; includes lost rent. |
| depreciation_usd | number | USD | 36000 annual depreciation divided by twelve. |
| modeled_tax_usd | number | USD | 25% of operating income under fictional tax assumptions. |
| operating_cash_flow_usd | number | USD | After-tax operating income plus depreciation. |
| terminal_cash_flow_usd | number | USD | 42500 in month 60 only: after-tax salvage plus working-capital recovery. |
| total_cash_flow_usd | number | USD | Operating plus terminal flows; excludes the time-zero 200000 outflow. |
