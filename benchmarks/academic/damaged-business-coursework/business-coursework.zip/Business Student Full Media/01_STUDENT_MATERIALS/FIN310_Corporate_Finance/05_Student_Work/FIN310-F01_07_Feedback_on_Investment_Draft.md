# Feedback on the Investment Memo Draft

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID FIN310-F01 | FIN310 | Issued 2026-10-29 | Assessments FIN310-A03

## Calculation and recommendation

The draft correctly treats the equipment and working-capital investment at time zero, excludes the sunk prototype cost, and includes the lost-rent opportunity within the stated fixed-cost total. The operating cash flows and terminal additions are separated clearly. The recommendation is conditional and does not claim a realized commercial outcome. Retain the explanation that the monthly file is a uniform allocation and that the assigned valuation uses year-end cash flows. This is an important timing distinction that many draft models overlook.

Improve the risk section by using the phrase demand-only downside consistently. The current scenario does not include a higher variable-cost share, a capacity step, delayed collections, or a lower salvage value. A reader might otherwise assume it represents the full range of adverse outcomes. You may propose a second stress scenario, but label any new assumptions and keep it separate from the supplied Downside. Do not add an invented probability to make the scenario appear statistically grounded.

## Before submission

The memo should display a compact annual cash-flow table so that the reviewer can see each year's contribution to the result. Include the original inputs or cross-references to them, not just final NPV and IRR values. Explain why a positive base result can coexist with a negative demand stress, and connect the requested market evidence to the modeled threshold. The payback interpolation convention is stated correctly; keep it subordinate to NPV in the recommendation.

There is an unresolved source conflict about length: the current assignment brief states 1000-1400 words, while the archived rubric says 800-1000 words. The deadline correction addresses timing only and does not resolve the length conflict. Ask the fictional instructor to clarify before final submission rather than silently treating a date change as a length-policy change. This feedback is a draft review, not a posted numeric grade. The synthetic gradebook therefore leaves the case score blank as of the reference timestamp.
