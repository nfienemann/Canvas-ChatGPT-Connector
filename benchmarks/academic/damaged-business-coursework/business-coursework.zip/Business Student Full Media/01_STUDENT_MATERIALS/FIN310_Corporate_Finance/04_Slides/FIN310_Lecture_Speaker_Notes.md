# Corporate Finance Lecture Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Slide 1 is the cover. These notes accompany the editable deck and its PDF.

## Slide 2 Cash-flow timeline

A capital-budgeting problem begins with the timing and sign of cash flows. Mark the decision date as time zero and place each expected payment or receipt on a timeline. A payment today and an equal receipt five years later are not interchangeable because the resources committed today have an opportunity cost. The discount rate expresses the required return used to compare amounts at different dates under the model's assumptions. The classroom repair proposal uses an annual rate of twelve percent and year-end operating cash flows. The initial investment includes equipment and working capital. In this proposal, $180,000 of equipment and $20,000 of working capital are committed at time zero, producing a $200,000 initial outflow. Do not discount that outflow as though it occurs at the end of year one. Doing so would understate its present cost and overstate project value. The first operating inflow arrives at the end of year one under the stated convention. Source: FIN310-R01. Have students identify which statements are inputs, calculations, and proposed actions.

- Time zero contains the initial commitment
- Operating cash flows occur at year end
- Timing changes the valuation

## Slide 3 Net present value

The present value of a cash flow received t years from now is the cash flow divided by one plus the discount rate raised to t. Net present value adds the present values of all project cash flows, including the initial outflow. A positive NPV means the modeled project exceeds the required return on the stated assumptions. It does not guarantee that actual cash flows will equal the forecast or that the project fits every strategic constraint. Use a consistent sign convention. Equipment purchases and working-capital commitments are negative, while operating inflows and recoveries are positive. Some spreadsheet NPV functions treat the first supplied cash flow as occurring one period in the future. In that common convention, calculate the discounted value of years one through five and then add the time-zero outflow separately. A model that shifts every cash flow by one year can appear internally neat while answering the wrong timing question. Source: FIN310-R01. Have students identify which statements are inputs, calculations, and proposed actions.

- Discount each future flow by its period
- Add the time-zero outflow separately
- Positive NPV is conditional on assumptions

## Slide 4 Relevant costs

Depreciation is not an operating cash payment, but it can affect modeled taxes. The case uses straight-line depreciation of the $180,000 equipment over five years, with zero book value at the end. Annual depreciation is $36,000. Calculate earnings before interest and tax as revenue less variable cash costs, fixed cash costs, and depreciation. Apply the fictional twenty-five percent tax assumption, then add depreciation back to obtain operating cash flow. An equivalent expression is after-tax operating cash contribution plus the depreciation tax shield. Both approaches should give the same result when assumptions are consistent. This packet assumes tax effects can be used in the modeled year and does not analyze actual tax rules or a company's tax position. Treat the rate and treatment as pedagogical inputs. Do not present the case's formula as advice about the tax consequences of a real equipment purchase. Source: FIN310-R02. Have students identify which statements are inputs, calculations, and proposed actions.

- Exclude unrecoverable prototype spending
- Include foregone rental income
- Exclude unchanged overhead allocations

## Slide 5 Operating cash flow

The project commits $20,000 of working capital at time zero. That amount supports inventory and receivables net of operating payables in the simplified model. It remains constant during the project and is fully released at the end of year five. The commitment is an initial cash outflow, and the recovery is a terminal inflow. It is neither a depreciation expense nor an annual charge of $20,000. More detailed projects may need changing working-capital balances, but this case explicitly uses a constant amount. The equipment is expected to sell for $30,000 at the end of year five. With zero book value and the fictional twenty-five percent tax assumption, the after-tax salvage proceeds are $22,500. Add the $20,000 working-capital recovery separately, giving $42,500 of terminal cash flow in addition to year-five operating cash flow. Omitting either recovery understates NPV; counting the pre-tax and after-tax salvage amounts together overstates it. Source: FIN310-R02. Have students identify which statements are inputs, calculations, and proposed actions.

- Calculate operating income after depreciation
- Apply the fictional tax assumption
- Add noncash depreciation back

## Slide 6 Working capital

The project model excludes loan proceeds, interest, and principal repayments because it evaluates operating investment cash flows using a supplied required return. Mixing financing payments into that cash-flow stream without changing the valuation framework can count financing effects inconsistently. The company may still need a separate funding plan to determine whether it can meet cash commitments. Economic attractiveness and near-term funding feasibility are related but distinct questions. Keep an inclusion table beside the model. List equipment, working capital, incremental operating costs, lost rent, taxes, and terminal recoveries as included items. List the unrecoverable prototype cost and unchanged allocated headquarters overhead as excluded, with reasons. This table makes the model auditable and gives the decision-maker a clear place to challenge an assumption. If a later source changes one item's cash consequence, update the model and document the change rather than relying on the earlier label. Source: FIN310-R02. Have students identify which statements are inputs, calculations, and proposed actions.

- Commit 20000 USD at time zero
- Hold the balance constant in this model
- Recover it separately at year five

## Slide 7 Terminal proceeds

An incremental cash flow is a change caused by accepting the project relative to the stated alternative. Begin by describing the organization with the project and without the project. Include only the differences relevant to that comparison. A cost can appear in an accounting statement without being incremental to the decision. Conversely, an opportunity cost can matter even if no new invoice is created. The repair proposal compares launching the five-year program with not launching it. The company has already spent $12,000 on a prototype study. That amount cannot be recovered under either alternative and is therefore a sunk cost in this decision. Excluding it from incremental NPV does not mean it never mattered or should be hidden from the project history. It means the current accept-or-reject choice cannot change that past cash flow. Keep the historical study cost in a contextual note, outside the incremental cash-flow calculation. Source: FIN310-R02. Have students identify which statements are inputs, calculations, and proposed actions.

- Salvage is 30000 USD before modeled tax
- After-tax salvage is 22500 USD
- Working-capital release adds 20000 USD

## Slide 8 Sensitivity grid

A one-way sensitivity analysis changes one input while holding the others constant. It can show whether NPV responds strongly to a revenue multiplier, a discount rate, or a cost assumption. A two-way table changes two inputs and reports the combined modeled result. The supplied sensitivity CSV crosses demand multipliers with discount rates. It is a calculated scenario grid, not a dataset of actual market observations or repeated business experiments. The grid must be interpreted with its held-constant assumptions. Changing demand while keeping the variable-cost share constant assumes costs scale proportionately with revenue. Keeping fixed costs constant assumes no capacity step within the modeled range. Those assumptions may fail if volume becomes very high or low. A table with many cells does not automatically represent every plausible operating state. Explain which relationships are built into it and which are omitted. Source: FIN310-R03. Have students identify which statements are inputs, calculations, and proposed actions.

- Demand multiplier and discount rate vary
- Other relationships remain fixed
- Grid cells are calculated scenarios

## Slide 9 Demand-only downside

A scenario changes a coherent set of assumptions. A downside might combine weaker demand, slower collections, and higher input costs if those conditions plausibly occur together. This course's supplied Downside scenario is deliberately narrow: revenue is twenty percent below Base in every year, while the other model inputs are unchanged. That definition allows a clean comparison, but it is not a comprehensive stress test. Label it accurately rather than calling it the worst possible outcome. When comparing scenarios, keep the calculation method consistent. A difference caused by moving cash flows to a different period is not purely a demand effect. State whether terminal salvage and working-capital recovery change with the scenario. In this packet they remain fixed. The model therefore assumes those recoveries still occur under lower demand. A decision-maker could reasonably challenge that assumption, but the challenge should be evaluated as a new scenario rather than silently mixed into the existing one. Source: FIN310-R03. Have students identify which statements are inputs, calculations, and proposed actions.

- Revenue falls twenty percent in every year
- Variable costs scale with revenue
- Fixed and terminal assumptions stay unchanged

## Slide 10 IRR and NPV

A forecast IRR is not a realized investor return, and a positive forecast NPV is not measured profit delivered by a student project. The sample report in this packet analyzes fictional assumptions. A portfolio summary may describe the methods, model construction, sensitivity analysis, and communication. It may not claim that a real company invested, saved money, or achieved the forecast. This distinction protects the credibility of the work and makes the student's actual contribution clearer. The same care applies to team authorship. If a team supplied market assumptions and one student built the cash-flow model, describe those roles separately. Do not imply sole authorship of the entire case. The supplied authorship note identifies Riley as responsible for model calculations and the finance memo, with the fictional team providing scenario framing. An evidence-based portfolio can still demonstrate substantial skill without inventing a client outcome or expanding the student's role. Source: FIN310-R04. Have students identify which statements are inputs, calculations, and proposed actions.

- IRR is a percentage threshold
- NPV is modeled value in dollars
- Scale and timing can change rankings

## Slide 11 Payback convention

Begin with the decision and the condition attached to it. Then present the base result, the most consequential downside comparison, and the assumptions that explain the difference. Follow with the information needed before commitment and the person or function that would obtain it. Keep the numerical model and the recommendation connected: if demand drives the downside, request demand evidence rather than a generic additional financial review. End by distinguishing facts supplied by the case, deterministic calculations, and proposed actions. The equipment amount, revenue series, and tax treatment are fictional inputs. NPV and IRR are calculations from those inputs. A pilot, updated quote, or staged authorization is a proposal. This classification allows a reviewer to challenge the right part of the argument and prevents a polished memo from overstating the certainty or implementation status of the analysis. Source: FIN310-R04. Have students identify which statements are inputs, calculations, and proposed actions.

- Simple payback ignores discounting
- Fractional years need an interpolation rule
- Later value still matters

## Slide 12 Evidence before commitment

A forecast states what would follow if specified assumptions hold. It is not a record of realized performance. The repair proposal's base case supplies annual revenue, a variable-cost share, fixed costs, an equipment investment, working capital, and a terminal value. The resulting NPV is conditional on those inputs. An analyst should make that dependency visible rather than presenting a precise dollar result as a measure of certainty. Precision in calculation and confidence in assumptions are different properties. Start by identifying which assumptions are uncertain and which are contractually or physically constrained in the case. Demand may be poorly observed, while an equipment quote may be relatively well specified. Even a quote may expire or omit installation. The packet does not supply a probability distribution for demand or a binding equipment contract. Do not invent those sources. A useful risk discussion names the missing evidence and how it could affect the decision. Source: FIN310-R03. Have students identify which statements are inputs, calculations, and proposed actions.

- Validate paid demand and labor needs
- Confirm the complete equipment amount
- Do not invent a pilot option value

## Slide 13 Financial communication

The internal rate of return is a discount rate that makes NPV equal to zero for the specified cash flows. The repair proposal has one initial negative flow followed by positive flows, so its conventional pattern supports a straightforward IRR interpretation in this exercise. More complicated sign patterns can produce multiple or unhelpful IRR results. Do not assume a software function's returned number is always the unique economically meaningful answer. IRR is a percentage and NPV is a dollar value, so they answer different questions. Projects with different scales or timing can rank differently under the two measures. If the task is to select between mutually exclusive projects, examine the actual comparison and the value created at the appropriate required return. In this packet, only the repair proposal versus no investment is quantified. Any comparison with another expansion project requires that project's own cash flows and scope. Source: FIN310-R04. Have students identify which statements are inputs, calculations, and proposed actions.

- Separate inputs calculations and proposals
- Preserve individual and team contributions
- Forecast value is not realized impact

## Slide 14 Source data excerpt

The final exhibit shows the first five records and first five fields of FIN310_Monthly_Project_Forecast.csv. It is a labeled excerpt, not the complete dataset. Use the CSV or full text mirror for calculation and complete coverage.

| scenario | year | project_month | revenue_usd | variable_cost_usd |
| --- | --- | --- | --- | --- |
| Base | 1 | 1 | 13333.333333333334 | 7333.333333333334 |
| Base | 1 | 2 | 13333.333333333334 | 7333.333333333334 |
| Base | 1 | 3 | 13333.333333333334 | 7333.333333333334 |
| Base | 1 | 4 | 13333.333333333334 | 7333.333333333334 |
| Base | 1 | 5 | 13333.333333333334 | 7333.333333333334 |
