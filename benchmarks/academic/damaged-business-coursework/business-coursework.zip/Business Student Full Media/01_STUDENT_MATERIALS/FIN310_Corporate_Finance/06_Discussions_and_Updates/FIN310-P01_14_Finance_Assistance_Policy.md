# Finance Assistance and Authorship Policy

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID FIN310-P01 | FIN310 | Issued 2026-08-31

## Assistance by activity

Voluntary practice may use tutoring and generated practice problems. FIN310-A03 permits brainstorming about model structure, assumptions, and evidence needs only; generated analytical paragraphs, model answers, and submission drafts are prohibited. The individual midterm and final prohibit generative AI and outside assistance during the assessment. Other assignments permit conceptual tutoring and mechanical proofreading unless their own instructions are stricter.

## Authorship and permission boundary

For the fictional repair-team project, Riley Chen owns the model calculations and finance memo, while the team contributed scenario framing. Preserve those roles in any portfolio description. These synthetic policy passages are source documents for interpretation tests and do not grant application access or constitute a real instructor authorization record.
