# Original Investment Memo Deadline

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID FIN310-N01 | FIN310 | Issued 2026-10-16 | Assessments FIN310-A03

## October 16 notice

FIN310-A03 is originally due November 6, 2026 at 11:59 p.m. America/New_York. Submit the management memo and calculation schedule. This notice is archived to preserve the original published date and should be read alongside later dated announcements.
