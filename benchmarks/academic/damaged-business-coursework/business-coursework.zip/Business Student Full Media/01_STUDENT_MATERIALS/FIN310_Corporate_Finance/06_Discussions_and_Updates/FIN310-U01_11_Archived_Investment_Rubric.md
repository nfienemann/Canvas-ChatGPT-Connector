# Archived Investment Memo Rubric

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID FIN310-U01 | FIN310 | Issued 2026-09-15 | Assessments FIN310-A03

## Archived September 15 version

This archived rubric states a memo length of 800-1000 words excluding schedules. It allocates 35 points to incremental cash-flow treatment, 25 to valuation calculations, 25 to risk and decision reasoning, and 15 to communication. It remains available for comparison. The current assignment brief states 1000-1400 words. No source in this packet explicitly resolves that length conflict, so a requirements review should flag it rather than silently merge the two ranges.
