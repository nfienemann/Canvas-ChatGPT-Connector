# Investment Memo Deadline Correction

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID FIN310-N02 | FIN310 | Issued 2026-10-27 | Assessments FIN310-A03

## October 27 instructor correction

FIN310-A03 is moved from November 6 to November 8, 2026 at 11:59 p.m. America/New_York. This supersedes the original deadline in FIN310-N01 for this assessment only. November 8 uses Eastern Standard Time, UTC minus five hours. This notice changes the deadline only; it does not revise word limits, rubric criteria, or assistance permissions.
