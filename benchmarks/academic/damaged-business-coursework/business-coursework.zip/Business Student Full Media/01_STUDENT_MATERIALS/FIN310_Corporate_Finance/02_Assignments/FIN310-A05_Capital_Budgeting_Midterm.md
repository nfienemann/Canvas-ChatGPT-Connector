# Capital Budgeting Midterm

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-A05 | FIN310 | Issued for fictional Fall 2026 semester

## Assignment requirements

The midterm covers cash-flow timing, present value, incremental-cost classification, depreciation in the supplied tax model, and working-capital treatment. It uses new fictional amounts and assesses methods rather than memorization of the repair proposal's totals.

For every valuation, show the timeline and identify the initial outflow separately from future inflows. Explain which costs are excluded and why. A bare spreadsheet result without the cash-flow structure is not an acceptable substitute for the requested reasoning.

The assessment was held October 15 during the regular class period and ended at 2:15 p.m. America/New_York. It was an individual no-AI assessment. The synthetic gradebook records 78 out of 100; no item-level response data or actual examination questions are supplied in this packet.

For review, use the posted score as a historical result and identify the topics needing practice from available feedback rather than inventing missed questions. Voluntary preparation and concept review after the assessment are permitted. The past no-AI assessment rule does not prohibit discussing the underlying concepts in an authorized voluntary study session.

## Required submission

- Completed examination; historical assessment

## Format and assessment conditions

Format: In-class paper examination. Word limit: Calculations and short explanations. Estimated preparation time: 6 hours.

Deadline: 2026-10-15T14:15:00-04:00. Points possible: 100. Grade category: Midterm.

## Academic assistance policy

No generative AI or outside assistance during the assessment. Voluntary concept review permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Incremental cash flows (35 points)

Excellent: All included and excluded items have correct timing and explicit reasons.

Adequate: Most treatment is correct with one limited omission.

Needs work: Sunk costs, opportunity costs, timing, or recoveries are materially wrong.

## Valuation calculations (25 points)

Excellent: NPV, IRR, and supporting schedules are reproducible and consistent.

Adequate: Core results are correct with minor missing checks.

Needs work: Wrong references, signs, or timing change the result.

## Risk and decision reasoning (25 points)

Excellent: Recommendation follows from sensitivity and specific evidence needs.

Adequate: Risk discussion is sensible but incompletely connected to the decision.

Needs work: Forecast assumptions are presented as certain or realized outcomes.

## Communication (15 points)

Excellent: Memo is clear, scoped, and transparent about authorship.

Adequate: Meaning is clear with minor ambiguity or unnecessary detail.

Needs work: Presentation obscures assumptions or overstates contribution.

## Assigned sources

- FIN310-R01
- FIN310-R02
