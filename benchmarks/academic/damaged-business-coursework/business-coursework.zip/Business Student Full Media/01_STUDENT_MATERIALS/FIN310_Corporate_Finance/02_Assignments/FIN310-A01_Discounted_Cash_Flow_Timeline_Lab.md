# Discounted Cash Flow Timeline Lab

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-A01 | FIN310 | Issued for fictional Fall 2026 semester

## Assignment requirements

Build a timeline for an investment with a time-zero outflow and five unequal annual inflows. Use the repair-case convention to distinguish the initial equipment and working-capital commitment from the first operating receipt. Label every period and sign before calculating present values.

Calculate present value by discounting each future flow separately. Show the period exponent, discount rate, and resulting present value. Explain why moving the initial outflow into the first discounted period would answer a different question and overstate the modeled project value.

Recalculate the schedule with a higher discount rate while holding cash flows constant. Explain the direction of the change in present value and identify which later flows are most affected. Do not choose a rate solely because it produces a preferred conclusion.

Submit a reproducible worksheet with a short explanation of the timing assumptions. Conceptual tutoring is permitted, but the submitted calculations and interpretation must be individual. The supplied rate is a fictional classroom input and should not be described as a current market estimate.

## Required submission

- Cash-flow timeline
- Two present-value schedules
- Timing explanation

## Format and assessment conditions

Format: Calculation worksheet and short explanation. Word limit: 400-600 words. Estimated preparation time: 3 hours.

Deadline: 2026-09-20T23:59:00-04:00. Points possible: 100. Grade category: Labs.

## Academic assistance policy

Conceptual tutoring and mechanical proofreading only; no generated submitted answers.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Incremental cash flows (35 points)

Excellent: All included and excluded items have correct timing and explicit reasons.

Adequate: Most treatment is correct with one limited omission.

Needs work: Sunk costs, opportunity costs, timing, or recoveries are materially wrong.

## Valuation calculations (25 points)

Excellent: NPV, IRR, and supporting schedules are reproducible and consistent.

Adequate: Core results are correct with minor missing checks.

Needs work: Wrong references, signs, or timing change the result.

## Risk and decision reasoning (25 points)

Excellent: Recommendation follows from sensitivity and specific evidence needs.

Adequate: Risk discussion is sensible but incompletely connected to the decision.

Needs work: Forecast assumptions are presented as certain or realized outcomes.

## Communication (15 points)

Excellent: Memo is clear, scoped, and transparent about authorship.

Adequate: Meaning is clear with minor ambiguity or unnecessary detail.

Needs work: Presentation obscures assumptions or overstates contribution.

## Assigned sources

- FIN310-R01
