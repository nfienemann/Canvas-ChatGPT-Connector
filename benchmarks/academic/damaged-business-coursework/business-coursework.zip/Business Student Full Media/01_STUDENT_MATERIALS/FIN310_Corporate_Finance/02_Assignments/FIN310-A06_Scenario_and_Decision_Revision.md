# Scenario and Decision Revision

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-A06 | FIN310 | Issued for fictional Fall 2026 semester

## Assignment requirements

Extend the repair analysis with one clearly defined scenario beyond the supplied demand-only Downside. Choose a plausible combination of assumptions and explain why they should change together. Label new values as analyst assumptions unless the packet supplies supporting evidence.

Keep the original Base and Downside definitions intact for comparison. Show which inputs change in the new scenario, which remain fixed, and how the cash-flow method stays consistent. Do not quietly alter terminal recovery or timing while describing the comparison as a pure demand effect.

Recalculate NPV and explain whether the revised result changes the recommendation or the information needed before commitment. If you propose a staged pilot, identify the missing cost and decision inputs that would be required for a numerical option analysis. A qualitative recommendation is acceptable when the data do not support a valuation.

Submit a concise revision with a reproducible scenario worksheet. Preserve the student and team authorship roles from the case. The goal is to improve the decision reasoning, not to produce the largest possible number of scenarios or to select assumptions that guarantee a preferred answer.

## Required submission

- One additional labeled scenario
- Comparison with supplied cases
- Revised recommendation and evidence needs

## Format and assessment conditions

Format: DOCX revision and scenario worksheet. Word limit: 800-1100 words. Estimated preparation time: 6 hours.

Deadline: 2026-11-22T23:59:00-05:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Conceptual tutoring and mechanical proofreading permitted; scenario choice and submitted analysis must be individual.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Incremental cash flows (35 points)

Excellent: All included and excluded items have correct timing and explicit reasons.

Adequate: Most treatment is correct with one limited omission.

Needs work: Sunk costs, opportunity costs, timing, or recoveries are materially wrong.

## Valuation calculations (25 points)

Excellent: NPV, IRR, and supporting schedules are reproducible and consistent.

Adequate: Core results are correct with minor missing checks.

Needs work: Wrong references, signs, or timing change the result.

## Risk and decision reasoning (25 points)

Excellent: Recommendation follows from sensitivity and specific evidence needs.

Adequate: Risk discussion is sensible but incompletely connected to the decision.

Needs work: Forecast assumptions are presented as certain or realized outcomes.

## Communication (15 points)

Excellent: Memo is clear, scoped, and transparent about authorship.

Adequate: Meaning is clear with minor ambiguity or unnecessary detail.

Needs work: Presentation obscures assumptions or overstates contribution.

## Assigned sources

- FIN310-R03
- FIN310-R04
- FIN310-C01
- FIN310-F01
