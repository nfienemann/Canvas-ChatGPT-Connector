# Relevant Cash Flow Classification Lab

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-A02 | FIN310 | Issued for fictional Fall 2026 semester

## Assignment requirements

Create an inclusion table for the equipment commitment, initial working capital, prototype study, lost rent, incremental administration, headquarters allocation, depreciation, salvage, and working-capital recovery. State whether each item belongs in incremental cash flow and explain the reason using the with-project comparison.

Calculate first-year operating income, modeled taxes, and operating cash flow from the case's fictional assumptions. Show depreciation separately so a reviewer can see its noncash nature and tax effect. Reproduce the same result with the equivalent operating-contribution approach as an independent check.

Calculate the terminal addition at the end of year five. Keep after-tax salvage separate from working-capital recovery and explain why neither should be added twice. State the assumption about zero terminal book value and the limited pedagogical scope of the tax treatment.

Submit the classification table and calculations in a readable format. Preserve the difference between a past cost that cannot change and a future opportunity cost caused by the project. Do not treat every expense allocation as incremental merely because it appears in a management report.

## Required submission

- Inclusion and exclusion table
- Year-one operating cash flow
- Terminal recovery schedule

## Format and assessment conditions

Format: DOCX explanation and calculation worksheet. Word limit: 600-800 words. Estimated preparation time: 4 hours.

Deadline: 2026-10-04T23:59:00-04:00. Points possible: 100. Grade category: Labs.

## Academic assistance policy

Conceptual tutoring and mechanical proofreading permitted; final calculations and reasoning are individual.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Incremental cash flows (35 points)

Excellent: All included and excluded items have correct timing and explicit reasons.

Adequate: Most treatment is correct with one limited omission.

Needs work: Sunk costs, opportunity costs, timing, or recoveries are materially wrong.

## Valuation calculations (25 points)

Excellent: NPV, IRR, and supporting schedules are reproducible and consistent.

Adequate: Core results are correct with minor missing checks.

Needs work: Wrong references, signs, or timing change the result.

## Risk and decision reasoning (25 points)

Excellent: Recommendation follows from sensitivity and specific evidence needs.

Adequate: Risk discussion is sensible but incompletely connected to the decision.

Needs work: Forecast assumptions are presented as certain or realized outcomes.

## Communication (15 points)

Excellent: Memo is clear, scoped, and transparent about authorship.

Adequate: Meaning is clear with minor ambiguity or unnecessary detail.

Needs work: Presentation obscures assumptions or overstates contribution.

## Assigned sources

- FIN310-R02
- FIN310-C01
