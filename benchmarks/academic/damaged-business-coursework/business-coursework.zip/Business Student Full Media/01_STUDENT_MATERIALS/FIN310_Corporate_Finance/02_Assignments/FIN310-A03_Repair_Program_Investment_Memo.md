# Repair Program Investment Memo

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-A03 | FIN310 | Issued for fictional Fall 2026 semester

## Assignment requirements

Evaluate the five-year repair proposal against the quantified no-project alternative. Construct the complete incremental-cash-flow schedule and calculate Base NPV, IRR, and a clearly defined simple-payback estimate. Recalculate NPV for the supplied demand-only Downside scenario using the same timing and tax assumptions.

Lead the memo with a conditional recommendation and support it with the assumptions that drive the result. Explain the treatment of the prototype study, rental opportunity, existing overhead allocation, working capital, and terminal salvage. A correct final NPV without reproducible treatment of these items is insufficient.

Identify the evidence needed before commitment, especially where the demand stress changes the conclusion. You may recommend a pilot or staged decision, but do not invent a numerical option value when the case supplies no pilot cost or contingent decision model. Preserve the distinction between a forecast and a realized outcome.

The corrected deadline is November 8 at 11:59 p.m. America/New_York. The current brief states 1000-1400 words, while the archived rubric states 800-1000; the packet does not explicitly resolve that conflict. Brainstorming about structure and evidence is permitted, but generated analytical paragraphs, model answers, and submission drafts are prohibited. The sample draft is a fictional demonstration artifact.

## Required submission

- Management memo
- Annual cash-flow schedule
- Base and Downside valuation
- Explicit assumptions and authorship statement

## Format and assessment conditions

Format: DOCX memo and XLSX or CSV cash-flow schedule. Word limit: 1000-1400 words excluding schedules. Estimated preparation time: 8 hours.

Deadline: 2026-11-08T23:59:00-05:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Brainstorming about model structure, assumptions, and evidence only. No generated analytical paragraphs, model answers, or submission drafts.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Incremental cash flows (35 points)

Excellent: All included and excluded items have correct timing and explicit reasons.

Adequate: Most treatment is correct with one limited omission.

Needs work: Sunk costs, opportunity costs, timing, or recoveries are materially wrong.

## Valuation calculations (25 points)

Excellent: NPV, IRR, and supporting schedules are reproducible and consistent.

Adequate: Core results are correct with minor missing checks.

Needs work: Wrong references, signs, or timing change the result.

## Risk and decision reasoning (25 points)

Excellent: Recommendation follows from sensitivity and specific evidence needs.

Adequate: Risk discussion is sensible but incompletely connected to the decision.

Needs work: Forecast assumptions are presented as certain or realized outcomes.

## Communication (15 points)

Excellent: Memo is clear, scoped, and transparent about authorship.

Adequate: Meaning is clear with minor ambiguity or unnecessary detail.

Needs work: Presentation obscures assumptions or overstates contribution.

## Assigned sources

- FIN310-R01
- FIN310-R02
- FIN310-R03
- FIN310-R04
- FIN310-C01
- FIN310-N02
- FIN310-U01
