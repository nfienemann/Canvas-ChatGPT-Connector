# Finance Vocabulary Entry Reflection

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-A08 | FIN310 | Issued for fictional Fall 2026 semester

## Assignment requirements

Define a cash flow, a reporting period, and an opportunity cost in your own words. Use a fictional example to distinguish a payment already made from a future consequence of a decision. No personal financial data is required.

Explain why a percentage return and a dollar value answer different questions. The purpose is to establish vocabulary before formal calculations. A numerical example may be simple, provided its timing and units are clear.

Riley Chen is excused from this entry reflection in the synthetic course record. The score remains blank and the item is excluded from the Labs earned-point and possible-point totals. The exemption does not create a zero or a new makeup obligation.

A planning tool should preserve the historical item without treating it as actionable missing work. If the exemption status is absent from another export, it should identify incomplete evidence rather than assume that a blank score establishes noncompletion.

## Required submission

- No submission required while excused

## Format and assessment conditions

Format: Short text reflection. Word limit: 200-300 words. Estimated preparation time: 1 hours.

Deadline: 2026-09-06T23:59:00-04:00. Points possible: 100. Grade category: Labs.

## Academic assistance policy

Voluntary concept practice permitted; this item is excused.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Incremental cash flows (35 points)

Excellent: All included and excluded items have correct timing and explicit reasons.

Adequate: Most treatment is correct with one limited omission.

Needs work: Sunk costs, opportunity costs, timing, or recoveries are materially wrong.

## Valuation calculations (25 points)

Excellent: NPV, IRR, and supporting schedules are reproducible and consistent.

Adequate: Core results are correct with minor missing checks.

Needs work: Wrong references, signs, or timing change the result.

## Risk and decision reasoning (25 points)

Excellent: Recommendation follows from sensitivity and specific evidence needs.

Adequate: Risk discussion is sensible but incompletely connected to the decision.

Needs work: Forecast assumptions are presented as certain or realized outcomes.

## Communication (15 points)

Excellent: Memo is clear, scoped, and transparent about authorship.

Adequate: Meaning is clear with minor ambiguity or unnecessary detail.

Needs work: Presentation obscures assumptions or overstates contribution.

## Assigned sources

- FIN310-R01
