# Comprehensive Finance Final

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

FIN310-A07 | FIN310 | Issued for fictional Fall 2026 semester

## Assignment requirements

The final covers the explicit concepts in FIN310-E01: time value, relevant cash flows, NPV, IRR, payback, working capital, terminal value, sensitivity, and evidence limits. It uses a new fictional case. Market-based cost-of-capital estimation and real tax compliance are outside the supplied coverage.

Construct the timeline before calculating. Show enough intermediate steps to distinguish an arithmetic error from a wrong assumption or classification. The exam may ask whether a conclusion is supported, so identify the boundary of the evidence rather than filling every missing field with an invented value.

The final begins at 1:00 p.m. and ends at 3:00 p.m. on December 17 in Bay 310. It is an individual no-AI assessment. A basic calculator and the instructor-approved formula sheet are permitted. The packet contains practice questions but no actual final-exam questions.

Prepare by explaining the relationships among operating income, taxes, depreciation, and cash flow. Practice changing one model input and predicting the direction of the result before calculating. A study plan should preserve the final's local timezone and avoid scheduling required preparation after the assessment ends.

## Required submission

- Completed final examination

## Format and assessment conditions

Format: In-class paper examination. Word limit: Calculations and short explanations. Estimated preparation time: 9 hours.

Deadline: 2026-12-17T15:00:00-05:00. Points possible: 100. Grade category: Final.

## Academic assistance policy

No generative AI or outside assistance during the final. Voluntary preparation permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Incremental cash flows (35 points)

Excellent: All included and excluded items have correct timing and explicit reasons.

Adequate: Most treatment is correct with one limited omission.

Needs work: Sunk costs, opportunity costs, timing, or recoveries are materially wrong.

## Valuation calculations (25 points)

Excellent: NPV, IRR, and supporting schedules are reproducible and consistent.

Adequate: Core results are correct with minor missing checks.

Needs work: Wrong references, signs, or timing change the result.

## Risk and decision reasoning (25 points)

Excellent: Recommendation follows from sensitivity and specific evidence needs.

Adequate: Risk discussion is sensible but incompletely connected to the decision.

Needs work: Forecast assumptions are presented as certain or realized outcomes.

## Communication (15 points)

Excellent: Memo is clear, scoped, and transparent about authorship.

Adequate: Meaning is clear with minor ambiguity or unnecessary detail.

Needs work: Presentation obscures assumptions or overstates contribution.

## Assigned sources

- FIN310-E01
- FIN310-R01
- FIN310-R02
- FIN310-R03
- FIN310-R04
