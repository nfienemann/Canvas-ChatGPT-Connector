# Financial Accounting Lecture Notes

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Slide 1 is the cover. These notes accompany the editable deck and its PDF.

## Slide 2 Reporting entity and period

A financial statement is a claim about a particular entity during a particular period. Before calculating anything, identify whose resources and obligations are included. The Lumen Trail campus pop-up used in this course is an instructional operating unit. Its ledger is neither the complete company nor an estimate of the company. Treating a profitable unit as evidence that every channel is profitable would extend the evidence beyond its boundary. A second boundary is time. September performance includes activities earned or incurred during September even when related cash moves in August or October. The accounting equation states that assets equal liabilities plus equity. Assets are resources controlled by the reporting entity, liabilities are obligations, and equity is the residual interest. The equation is maintained by recording each transaction with equal total debits and credits. Debit does not mean beneficial, and credit does not mean harmful. A debit increases many asset and expense accounts, while a credit Source: ACC201-R01. Ask students to identify the evidence boundary before presenting a calculation.

- The case covers one campus operating unit
- September activity differs from opening balances
- Consolidated company conclusions need more evidence

## Slide 3 Debit and credit structure

Imagine that the pop-up receives $720 for ten backpacks delivered today. If there is no remaining delivery obligation, both cash and revenue increase by $720. If the customer instead promises to pay next month, accounts receivable increases and revenue is still recognized in the instructional example. Collection later exchanges a receivable for cash. It does not create revenue a second time. A cash balance therefore cannot independently reveal revenue, and revenue cannot independently reveal cash available for payroll. An advance creates a different timing pattern. Suppose a campus club pays $1,200 for a future workshop. At collection, cash increases and an unearned-revenue liability increases. The workshop has not yet occurred. When the agreed service is performed, the liability is reduced and revenue is recognized. This course uses simple single-performance examples. More complex contracts require additional analysis; do not import the simple rule into a multi-stage arrangement without examining what has been promised. Source: ACC201-R01. Ask students to identify the evidence boundary before presenting a calculation.

- Each journal entry balances
- Account type determines the direction of change
- Balanced entries can still be misclassified

## Slide 4 Credit sales and collections

A $1,200 insurance premium for twelve months initially creates a prepaid asset in our simplified case. One month of coverage consumes $100 of that asset and records $100 of insurance expense. Paying the full premium in September does not make all twelve months a September expense. Equipment follows a related allocation idea. A useful asset can support several reporting periods, so depreciation allocates its depreciable amount over an assumed useful life. Depreciation is an expense without a same-period cash payment. Inventory provides the link between selling activity and cost of goods sold. When a backpack is sold, record the sales transaction and the reduction in inventory separately. If the selling price is $72 and the assigned inventory cost is $30, revenue is $72, cost of goods sold is $30, and gross profit is $42. Gross profit is not net income because wages, rent, insurance, and other operating costs still matter. A balanced journal entry can Source: ACC201-R01. Ask students to identify the evidence boundary before presenting a calculation.

- Revenue can precede cash collection
- Collection reduces an existing receivable
- Do not recognize the same sale twice

## Slide 5 Prepayments and accruals

A reliable close begins by reconciling source documents to journal entries, then checking that journal entries post to the intended accounts. Prepare an unadjusted trial balance, record supported adjustments, and prepare an adjusted trial balance. A trial balance tests equality of debits and credits. It does not establish that every transaction was recorded, that an estimate is reasonable, or that a transaction belongs to the reporting entity. Missing equal-sided entries leave a trial balance balanced. For this course, retain journal IDs when you aggregate transactions. An explanation such as cash rose because sales increased is too broad if collections, borrowing, and owner contributions also affected cash. Instead, identify the relevant entries and classify each movement. State whether a conclusion comes from source data, a calculation, or an assumption. When an invoice is missing, report the missing evidence rather than fabricating a supporting amount to make the reconciliation look complete. Source: ACC201-R01. Ask students to identify the evidence boundary before presenting a calculation.

- Insurance begins as a prepaid asset
- Coverage consumption creates expense
- Unpaid utilities create expense and a payable

## Slide 6 Inventory purchase and sale

Inventory management asks how many items are available, whereas financial reporting also asks what cost belongs to those items. A unit reconciliation begins with opening units, adds receipts, subtracts units sold and other documented reductions, and arrives at ending units. A dollar reconciliation follows a similar flow using assigned costs. Agreement in dollars does not prove agreement in units. Two products can have different costs, and a mistaken product code can preserve a dollar total while misrepresenting the physical stock. The campus pop-up ledger provides aggregate inventory dollars. Its sales register identifies backpacks and bottles, but opening inventory quantities and receipt quantities are not provided by product. You can reconcile the ledger's inventory dollar balance. You cannot reconstruct a complete physical count by product from this evidence. A strong analyst distinguishes a calculation that is supported from one that would need additional source fields. This limitation is intentional in the case and should appear in Source: ACC201-R02. Ask students to identify the evidence boundary before presenting a calculation.

- Receipts add inventory and payables
- Sales recognize assigned cost of goods sold
- Physical quantities need separate controls

## Slide 7 Margin and markup

In the supplied instructional sales register, a backpack sells for $72 and carries an assigned unit cost of $30. A bottle sells for $26 and carries an assigned unit cost of $8. Gross margin percentage equals gross profit divided by revenue. Markup on cost equals gross profit divided by cost. The denominators differ, so the two percentages cannot be substituted for one another. State the numerator and denominator before interpreting either percentage. Product mix changes total margin even when no individual price or cost changes. A week with more bottle sales can have a different aggregate margin percentage than a week with more backpack sales. The appropriate aggregate calculation is total gross profit divided by total revenue. Averaging individual product percentages without revenue weights answers a different question. This becomes especially misleading when one product has many low-value orders and another has fewer high-value orders. Source: ACC201-R02. Ask students to identify the evidence boundary before presenting a calculation.

- Gross margin divides by revenue
- Markup divides by cost
- Aggregate margin uses matching dollar totals

## Slide 8 Product mix

Purchasing inventory normally exchanges cash for inventory or creates a payable in these exercises. The purchase is not itself cost of goods sold. The expense arises when inventory is sold or another supported reduction is recognized. A business can therefore buy more inventory than it sells and experience a cash squeeze during a profitable period. Conversely, selling inventory purchased earlier can generate cash without an equally large current-period purchase payment. Consider a supplier delivery of $2,400 bought on account. The entry increases inventory and accounts payable by $2,400. Later, a $1,000 supplier payment reduces cash and accounts payable. Neither event alone changes revenue or cost of goods sold. If $900 of the delivered inventory is eventually sold, the sale entry reduces inventory and records $900 of cost of goods sold. Preserve these distinctions when classifying the ledger and when explaining why profit and cash differ. Source: ACC201-R02. Ask students to identify the evidence boundary before presenting a calculation.

- Prices and unit costs may stay fixed
- Changing quantities changes aggregate margin
- Do not average percentages without the right weights

## Slide 9 Statement connections

A current ratio compares current assets with current liabilities. It can indicate a short-term resource buffer, but it does not guarantee that assets will turn into cash before obligations fall due. Inventory may move slowly, receivables may be overdue, and a favorable closing balance may reflect unusual activity just before the reporting date. A ratio should lead to a question about timing and quality, not replace that question with a universal pass-or-fail threshold. A decision memo should show the most consequential measures, describe their source boundaries, and connect them to a practical action. For example, a profitable month with rising inventory may justify a receiving and reorder review. It does not automatically justify a company-wide expansion. Compare periods only when definitions, scope, and accounting methods are consistent. This packet contains one instructional month, so claims about trends, seasonality, or annual performance require additional evidence that the packet does not supply. Source: ACC201-R03. Ask students to identify the evidence boundary before presenting a calculation.

- Income changes retained earnings
- Distributions reduce equity
- Contra assets reduce the related asset balance

## Slide 10 Profit and cash

The income statement measures revenues and expenses over a period. The balance sheet presents assets, liabilities, and equity at a date. The closing process connects them because the period's income changes retained earnings, subject to distributions and other explicitly identified changes. A positive income figure is compatible with a falling cash balance when customers have not paid, inventory has increased, or cash was used to acquire equipment. A rising cash balance is compatible with a loss when borrowing or owner contributions provide cash. For the pop-up exercise, opening retained earnings is $15,000, contributed capital is $60,000, and the September owner distribution is $1,500. Ending retained earnings therefore equals $15,000 plus September net income less $1,500. The distribution is not an operating expense. It reduces equity and cash. Misclassifying it as an expense would understate net income while potentially preserving the balance sheet equation, which illustrates why arithmetic checks need classification checks alongside them. Source: ACC201-R03. Ask students to identify the evidence boundary before presenting a calculation.

- Receivables separate sales from collections
- Inventory can absorb operating cash
- Depreciation is a noncash expense

## Slide 11 Evidence limits

Different source documents support different assertions. A supplier invoice supports a claim that a supplier requested payment. A receiving record supports a claim that specified goods arrived. A bank record supports a cash movement. Matching all three can support a stronger conclusion than any one source alone. A typed narrative saying the delivery occurred is evidence of someone's statement, not independent verification that the goods were received in the stated quantity and condition. The class ledger includes transaction descriptions and source IDs, but no underlying bank images or signed receiving slips. You can verify that the provided rows balance and recompute the reported totals. You cannot claim to have audited physical existence, customer collectability, or supplier authenticity. This distinction should be visible in the language of your report. Write that the supplied ledger reconciles, rather than that the company's records are proven accurate in every respect. Source: ACC201-R04. Ask students to identify the evidence boundary before presenting a calculation.

- Ledger equality is an arithmetic check
- Source authenticity is a separate question
- Missing evidence remains unknown

## Slide 12 Proportionate controls

A mismatch can arise from a harmless timing difference, a data-entry mistake, a missing document, or intentional manipulation. The existence of a discrepancy does not identify which explanation is correct. Start by preserving the original values, recording the difference, and locating the source that could resolve it. Ask a specific question, such as whether a receipt dated October 1 belongs to a September delivery, rather than making an accusation based solely on the mismatch. Uncertainty is also different from a known zero. A blank grade, missing count sheet, or unknown payment date does not mean no work was completed, no inventory exists, or no payment occurred. Use a missing-data marker and explain the needed follow-up. Avoid replacing blanks with zero to simplify a spreadsheet unless the task explicitly defines zero as the correct business meaning. A computationally tidy table can still distort the evidence if it collapses these states. Source: ACC201-R04. Ask students to identify the evidence boundary before presenting a calculation.

- Name the failure mode and owner
- Keep evidence and an exception response
- Small teams need feasible review procedures

## Slide 13 Management recommendation

The unit incurs small stall operating expenses throughout the month and pays September salaries of $6,000 and rent of $2,800. It purchases twelve months of insurance for $1,200 and records one month of insurance expense, $100. The remaining $1,100 is prepaid insurance at September 30. It also records $1,100 of utilities incurred but unpaid. The utilities entry is necessary even though there is no corresponding September bank withdrawal. All of these assumptions are part of the simplified operating-unit example. The owner receives a $1,500 distribution. Treat it as a reduction in equity, not as a wage or operating expense. The case excludes income tax, sales tax, interest, returns, discounts, inventory impairment, and parent allocations. These exclusions keep the close manageable and must be stated when interpreting net income. They do not imply that such items are unimportant in real organizations. Your report should describe the result as the instructional unit's net income under the stated Source: ACC201-C01. Ask students to identify the evidence boundary before presenting a calculation.

- State the source boundary
- Connect each follow-up to a decision
- Do not infer a trend from one month

## Slide 14 Source data excerpt

The final exhibit shows the first five records and first five fields of ACC201_Journal_Lines.csv. It is a labeled excerpt, not the complete dataset. Use the CSV or full text mirror for calculation and complete coverage.

| journal_id | line_id | date | account | debit_usd |
| --- | --- | --- | --- | --- |
| J0001 | J0001-L1 | 2026-09-01 | Cash | 45000 |
| J0001 | J0001-L2 | 2026-09-01 | Inventory | 30000 |
| J0001 | J0001-L3 | 2026-09-01 | Equipment | 24000 |
| J0001 | J0001-L4 | 2026-09-01 | Accumulated depreciation | 0 |
| J0001 | J0001-L5 | 2026-09-01 | Accounts payable | 0 |
