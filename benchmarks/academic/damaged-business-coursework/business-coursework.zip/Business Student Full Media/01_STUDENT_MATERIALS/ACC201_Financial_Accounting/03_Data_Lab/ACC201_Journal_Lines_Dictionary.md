# ACC201 Journal Lines

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-DATA1

## Dataset scope

Synthetic opening balances and September journal lines for a fictional campus pop-up unit. Opening entry J0001 is included for balances but excluded from current-period transaction counts.

Records: 783. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| journal_id | string | not applicable | One balanced entry; repeated across its component lines. |
| line_id | string | not applicable | Unique source-row key; use this for duplicate checks. |
| date | string | not applicable | Transaction or adjustment date in ISO format. |
| account | string | not applicable | Instructional account name. |
| debit_usd | number | USD | Debit amount; zero when no debit on this line. |
| credit_usd | number | USD | Credit amount; zero when no credit on this line. |
| description | string | not applicable | Source narrative; not independent proof of occurrence. |
| currency | string | not applicable | USD for every record. |
