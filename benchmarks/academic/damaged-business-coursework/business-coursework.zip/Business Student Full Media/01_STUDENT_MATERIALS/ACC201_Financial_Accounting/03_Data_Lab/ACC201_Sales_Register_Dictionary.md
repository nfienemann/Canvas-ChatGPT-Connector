# ACC201 Sales Register

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-DATA2

## Dataset scope

Independent sales control. It contains no opening stock quantities or supplier receipt quantities.

Records: 120. All rows are fabricated. The CSV is authoritative for typed source values. A blank cell means missing unless a field definition says otherwise. Do not infer external population representativeness.

## Field definitions

| Field | Type | Unit | Definition |
| --- | --- | --- | --- |
| sale_id | string | not applicable | Unique order key referenced in ledger descriptions. |
| date | string | not applicable | Sale date; date alone is not unique. |
| product | string | not applicable | Backpack or Bottle. |
| quantity | number | units | Units sold on the order. |
| unit_price_usd | number | USD | Fixed fictional selling price per unit. |
| unit_cost_usd | number | USD | Assigned instructional inventory cost per unit. |
| payment_terms | string | not applicable | cash or credit; not actual collection status. |
| revenue_usd | number | USD | Quantity multiplied by unit price. |
| cost_of_goods_sold_usd | number | USD | Quantity multiplied by assigned unit cost. |
