# Close Report Deadline Correction

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

Source ID ACC201-N02 | ACC201 | Issued 2026-10-10 | Assessments ACC201-A03

## October 10 instructor correction

The deadline for ACC201-A03 is moved from October 18 to October 20, 2026 at 11:59 p.m. America/New_York. This dated instructor notice supersedes the September 25 deadline notice for this assignment only. The memo length and required schedules are unchanged. The assignment detail in the synthetic course inventory reflects the corrected deadline. No later deadline should be inferred for other assignments.
