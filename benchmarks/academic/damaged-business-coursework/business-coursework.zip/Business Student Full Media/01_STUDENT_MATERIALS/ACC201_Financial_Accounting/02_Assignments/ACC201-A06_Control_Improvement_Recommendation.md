# Control Improvement Recommendation

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-A06 | ACC201 | Issued for fictional Fall 2026 semester

## Assignment requirements

Choose two weaknesses that the source packet actually supports and propose proportionate controls for the pop-up. Identify the failure mode, the person performing the control, the reviewer, the frequency, and the retained evidence. Do not claim that an absent document proves fraud.

Explain how each proposed control would detect or prevent a particular error. Describe one limitation that would remain after implementation. Your design must be feasible for a small operating unit with limited staffing and should identify any compensating review when full segregation is impractical.

Include a short exception-log template containing an item ID, observed evidence, uncertainty, action owner, and next step. Use two invented examples clearly labeled as examples rather than events found in the real case. A complete log should preserve unresolved issues instead of automatically marking them safe after a deadline.

Conclude with an implementation order and a reason for that order. The recommendation should be driven by the consequences and evidence in the packet. Generic control lists without connection to the case will receive limited credit even if every listed control is sensible in another setting.

## Required submission

- Two-control recommendation
- Exception-log template
- Implementation sequence

## Format and assessment conditions

Format: DOCX recommendation. Word limit: 700-900 words. Estimated preparation time: 5 hours.

Deadline: 2026-11-15T23:59:00-05:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Conceptual tutoring and mechanical proofreading permitted; final recommendation must be individual.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Accounting treatment (35 points)

Excellent: Accounts, periods, and classifications are correct and explained.

Adequate: Most treatments are correct with one limited classification error.

Needs work: Timing or classifications materially distort the result.

## Reproducibility (30 points)

Excellent: Schedules trace to stable source IDs and independent controls.

Adequate: Totals are reproducible with minor missing references.

Needs work: Unsupported totals or missing reconciliation prevent review.

## Interpretation (20 points)

Excellent: Recommendation follows from scope, evidence, and stated limits.

Adequate: Recommendation is reasonable but incompletely qualified.

Needs work: Recommendation overstates the evidence or ignores a material limit.

## Communication (15 points)

Excellent: Writing is concise, labeled, and accessible to the intended reader.

Adequate: Organization is usable with minor ambiguity.

Needs work: Unclear labels or unsupported wording obstruct interpretation.

## Assigned sources

- ACC201-R04
- ACC201-C01
- ACC201-F01
