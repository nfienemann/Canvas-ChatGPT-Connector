# Accrual Transaction Exercise

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-A01 | ACC201 | Issued for fictional Fall 2026 semester

## Assignment requirements

Record six transactions covering cash sales, credit sales, advance collections, inventory purchases, prepaid insurance, and an owner distribution. For each transaction identify the reporting entity and the timing assumption before selecting accounts. Use the illustrative amounts in ACC201-R01 and invent no additional activity.

Show the debit and credit lines separately and explain why each account changes. A balanced entry alone is insufficient when the account classification is wrong. Include a short statement about the difference between a revenue event and the collection of an existing receivable.

Prepare a miniature accounting-equation reconciliation after the six entries. Preserve the starting assumptions and show how cumulative changes affect assets, liabilities, and equity. If a transaction cannot be recorded without an assumption, label that assumption beside the entry instead of hiding it in the conclusion.

Submit a single readable PDF with your explanations. The numerical examples are voluntary practice until you submit this exercise. Conceptual tutoring is permitted, but the account choices and explanations in the submitted worksheet must be your own. Cite the course reading identifiers used to check your reasoning.

## Required submission

- Six journal entries
- Accounting equation check
- Timing explanations

## Format and assessment conditions

Format: PDF worksheet. Word limit: 300-500 words of explanations. Estimated preparation time: 3 hours.

Deadline: 2026-09-13T23:59:00-04:00. Points possible: 100. Grade category: Exercises.

## Academic assistance policy

Conceptual tutoring and mechanical proofreading only; no generated submitted answers.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Accounting treatment (35 points)

Excellent: Accounts, periods, and classifications are correct and explained.

Adequate: Most treatments are correct with one limited classification error.

Needs work: Timing or classifications materially distort the result.

## Reproducibility (30 points)

Excellent: Schedules trace to stable source IDs and independent controls.

Adequate: Totals are reproducible with minor missing references.

Needs work: Unsupported totals or missing reconciliation prevent review.

## Interpretation (20 points)

Excellent: Recommendation follows from scope, evidence, and stated limits.

Adequate: Recommendation is reasonable but incompletely qualified.

Needs work: Recommendation overstates the evidence or ignores a material limit.

## Communication (15 points)

Excellent: Writing is concise, labeled, and accessible to the intended reader.

Adequate: Organization is usable with minor ambiguity.

Needs work: Unclear labels or unsupported wording obstruct interpretation.

## Assigned sources

- ACC201-R01
