# September Close Management Memo

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-A03 | ACC201 | Issued for fictional Fall 2026 semester

## Assignment requirements

Prepare the September close for the fictional campus pop-up using the journal and sales-register files. Reconcile every journal entry before aggregating account balances. The operating-unit boundary and September reporting period are mandatory. Do not turn these records into consolidated company statements or annual forecasts.

Present an income statement, balance-sheet summary, retained-earnings bridge, and cash reconciliation. Separate the owner distribution from operating expenses. Explain the insurance, depreciation, and utilities adjustments with enough detail that a manager can understand why profit and cash differ.

Recommend the next step for evaluating a winter campus stall. Link each requested piece of information to a specific decision. A recommendation that approves expansion solely because the cash balance rose is insufficient. Identify the missing physical-inventory evidence and the lack of a winter-event forecast.

Submit the memo and reproducible schedules. The corrected deadline is October 20, as stated in ACC201-N02. Brainstorming about structure and evidence needs is permitted, but generative AI may not write analytical paragraphs or draft this assessed memo. The supplied student sample is a fictional demonstration artifact, not permission to copy it.

## Required submission

- Management memo
- Four reconciled schedules
- Source-ID trail and limitation statement

## Format and assessment conditions

Format: DOCX memo and XLSX or CSV schedules. Word limit: 900-1200 words excluding schedules. Estimated preparation time: 7 hours.

Deadline: 2026-10-20T23:59:00-04:00. Points possible: 100. Grade category: Cases.

## Academic assistance policy

Brainstorming about structure and evidence only. No generated analysis paragraphs or submission drafting.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Accounting treatment (35 points)

Excellent: Accounts, periods, and classifications are correct and explained.

Adequate: Most treatments are correct with one limited classification error.

Needs work: Timing or classifications materially distort the result.

## Reproducibility (30 points)

Excellent: Schedules trace to stable source IDs and independent controls.

Adequate: Totals are reproducible with minor missing references.

Needs work: Unsupported totals or missing reconciliation prevent review.

## Interpretation (20 points)

Excellent: Recommendation follows from scope, evidence, and stated limits.

Adequate: Recommendation is reasonable but incompletely qualified.

Needs work: Recommendation overstates the evidence or ignores a material limit.

## Communication (15 points)

Excellent: Writing is concise, labeled, and accessible to the intended reader.

Adequate: Organization is usable with minor ambiguity.

Needs work: Unclear labels or unsupported wording obstruct interpretation.

## Assigned sources

- ACC201-R01
- ACC201-R02
- ACC201-R03
- ACC201-C01
- ACC201-N02
