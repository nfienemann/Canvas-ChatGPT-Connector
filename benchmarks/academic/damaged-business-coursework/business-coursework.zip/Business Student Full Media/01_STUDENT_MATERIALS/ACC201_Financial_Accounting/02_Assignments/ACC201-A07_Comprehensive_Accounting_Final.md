# Comprehensive Accounting Final

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-A07 | ACC201 | Issued for fictional Fall 2026 semester

## Assignment requirements

The final integrates accrual entries, inventory, adjusting entries, statement preparation, cash interpretation, and evidence quality. It uses a new fictional operating-unit dataset rather than requiring memorization of the September totals. Preparation should emphasize relationships and reproducible methods.

Show the accounting equation and the relevant account movement for each calculation. Clearly identify the reporting period and distinguish an observed value from an assumption. The examination may ask which additional source would resolve an uncertainty, so do not treat every missing field as an arithmetic problem.

The final begins at 10:00 a.m. and ends at noon on December 16 in Bay 201. This is an individual no-AI assessment. A basic calculator and the instructor-approved handwritten reference sheet are permitted. The synthetic packet supplies no actual final-exam questions.

Use the voluntary review packet to practice explanations before the assessment. Any preparation plan should account for the other course deadlines without scheduling work after the final's completion time. If a source does not contain a particular final-exam detail, preserve that uncertainty rather than inventing a rule.

## Required submission

- Completed final examination

## Format and assessment conditions

Format: In-class paper exam. Word limit: Calculations and short explanations. Estimated preparation time: 10 hours.

Deadline: 2026-12-16T12:00:00-05:00. Points possible: 100. Grade category: Final.

## Academic assistance policy

No generative AI or outside assistance during the final. Voluntary practice beforehand permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Accounting treatment (35 points)

Excellent: Accounts, periods, and classifications are correct and explained.

Adequate: Most treatments are correct with one limited classification error.

Needs work: Timing or classifications materially distort the result.

## Reproducibility (30 points)

Excellent: Schedules trace to stable source IDs and independent controls.

Adequate: Totals are reproducible with minor missing references.

Needs work: Unsupported totals or missing reconciliation prevent review.

## Interpretation (20 points)

Excellent: Recommendation follows from scope, evidence, and stated limits.

Adequate: Recommendation is reasonable but incompletely qualified.

Needs work: Recommendation overstates the evidence or ignores a material limit.

## Communication (15 points)

Excellent: Writing is concise, labeled, and accessible to the intended reader.

Adequate: Organization is usable with minor ambiguity.

Needs work: Unclear labels or unsupported wording obstruct interpretation.

## Assigned sources

- ACC201-R01
- ACC201-R02
- ACC201-R03
- ACC201-R04
