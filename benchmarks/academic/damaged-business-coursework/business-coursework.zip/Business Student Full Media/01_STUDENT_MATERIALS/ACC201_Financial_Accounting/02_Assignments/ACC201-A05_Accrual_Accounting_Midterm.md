# Accrual Accounting Midterm

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-A05 | ACC201 | Issued for fictional Fall 2026 semester

## Assignment requirements

Prepare for an individual examination covering readings R01 through R04 and the accounting mechanics of case C01. Review accrual timing, inventory and gross margin, adjusting entries, statement connections, and controls. The explicit review guide lists the limits of coverage.

During the examination, show journal entries and calculation steps. A correct total with an unsupported account treatment will not receive full credit. Explain any assumption that is needed because a question does not supply a fact. Do not import facts from another course's case without instruction.

The assessment takes place during a special Friday examination sitting from 9:00 to 10:15 a.m. on October 30. This sitting is separate from the ordinary Monday and Wednesday meetings. No generative AI, messaging, or outside assistance is permitted during the assessment. Voluntary preparation beforehand may use tutoring and the course practice guide.

Bring a basic calculator and the one-page handwritten reference sheet permitted by the fictional course policy. Do not reproduce prepared answers to undisclosed exam questions. The review questions are practice material rather than a claim to reveal the actual examination items.

## Required submission

- Completed examination
- Allowed handwritten reference sheet

## Format and assessment conditions

Format: In-class paper exam. Word limit: Short answers and calculations. Estimated preparation time: 6 hours.

Deadline: 2026-10-30T10:15:00-04:00. Points possible: 100. Grade category: Midterm.

## Academic assistance policy

No generative AI or outside assistance during the assessment. Voluntary preparation permitted.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Accounting treatment (35 points)

Excellent: Accounts, periods, and classifications are correct and explained.

Adequate: Most treatments are correct with one limited classification error.

Needs work: Timing or classifications materially distort the result.

## Reproducibility (30 points)

Excellent: Schedules trace to stable source IDs and independent controls.

Adequate: Totals are reproducible with minor missing references.

Needs work: Unsupported totals or missing reconciliation prevent review.

## Interpretation (20 points)

Excellent: Recommendation follows from scope, evidence, and stated limits.

Adequate: Recommendation is reasonable but incompletely qualified.

Needs work: Recommendation overstates the evidence or ignores a material limit.

## Communication (15 points)

Excellent: Writing is concise, labeled, and accessible to the intended reader.

Adequate: Organization is usable with minor ambiguity.

Needs work: Unclear labels or unsupported wording obstruct interpretation.

## Assigned sources

- ACC201-E01
- ACC201-R01
- ACC201-R02
- ACC201-R03
- ACC201-R04
