# Inventory and Margin Exercise

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201-A02 | ACC201 | Issued for fictional Fall 2026 semester

## Assignment requirements

Use the sales-register product prices and assigned costs to calculate gross profit per unit, gross margin percentage, and markup on cost for each product. Clearly label each denominator. Explain why the two percentage measures differ even though they use the same dollar gross profit.

Create a simple comparison using two hypothetical product mixes while holding the individual prices and costs constant. Keep the mixes distinct from the actual September sales register, and label them as illustrative assumptions. Calculate the aggregate margin using total gross profit divided by total revenue.

Explain why the supplied register cannot establish ending physical units for each product. Identify the opening-stock and receipt fields that would be needed. Your answer should distinguish missing physical-count evidence from the available inventory-dollar roll-forward.

Submit the calculation file together with a short explanation. Preserve formulas or show the calculation steps so a reviewer can reproduce the results. Do not present a simple average of product margin percentages as the company's aggregate margin unless you explicitly explain the different question that average answers.

## Required submission

- Product-level margin table
- Two labeled mix illustrations
- Inventory-evidence limitations

## Format and assessment conditions

Format: PDF worksheet and CSV calculations. Word limit: 400-600 words. Estimated preparation time: 3 hours.

Deadline: 2026-09-27T23:59:00-04:00. Points possible: 100. Grade category: Exercises.

## Academic assistance policy

Conceptual tutoring and mechanical proofreading only; submitted calculations remain individual.

## Rubric

Rubric criteria below sum to the stated points possible. Read each criterion together with the assignment requirements.

## Accounting treatment (35 points)

Excellent: Accounts, periods, and classifications are correct and explained.

Adequate: Most treatments are correct with one limited classification error.

Needs work: Timing or classifications materially distort the result.

## Reproducibility (30 points)

Excellent: Schedules trace to stable source IDs and independent controls.

Adequate: Totals are reproducible with minor missing references.

Needs work: Unsupported totals or missing reconciliation prevent review.

## Interpretation (20 points)

Excellent: Recommendation follows from scope, evidence, and stated limits.

Adequate: Recommendation is reasonable but incompletely qualified.

Needs work: Recommendation overstates the evidence or ignores a material limit.

## Communication (15 points)

Excellent: Writing is concise, labeled, and accessible to the intended reader.

Adequate: Organization is usable with minor ambiguity.

Needs work: Unclear labels or unsupported wording obstruct interpretation.

## Assigned sources

- ACC201-R02
- ACC201-C01
