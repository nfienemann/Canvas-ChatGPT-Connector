# Financial Accounting

SYNTHETIC COURSEWORK - all people, organizations, records and policies are fictional

ACC201 | Fall 2026

## Purpose

This fictional undergraduate course introduces financial accounting through the records of a small operating unit. Students learn to distinguish a reporting entity from its owners, classify transactions, apply accrual timing, reconcile inventory dollars, prepare connected financial statements, and explain why profit differs from cash. The course emphasizes reproducible calculations and the quality of supporting evidence rather than memorization of account names alone. A campus pop-up case provides journal lines, a sales register, a sample management report, and instructor feedback. Students also evaluate proportionate internal controls and communicate uncertainty to a non-specialist manager. The packet covers a full semester schedule with four substantial core readings and several assessed and voluntary activities. All people, organizations, transactions, grades, and policies are fabricated for software demonstrations.

## Learning outcomes

- Identify reporting boundaries and periods.
- Record balanced journal entries with correct classifications.
- Reconcile inventory dollars and distinguish physical-count evidence.
- Prepare connected statements and a cash bridge.
- Evaluate controls and evidence limits.
- Communicate source-grounded recommendations.

## Scope

The original October 18 close deadline is deliberately preserved in N01; N02 and A03 use the corrected October 20 date. The own-post export is intentionally incomplete for reply verification. These are source-evidence fixtures, not real student records.
