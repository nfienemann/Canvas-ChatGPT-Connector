#!/usr/bin/env python3
"""Check the extracted synthetic collection using only the Python standard library."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest['files']:
    path=(root/item['path']).resolve()
    if not path.is_relative_to(root):
        errors.append(item['path']+': unsafe manifest path');continue
    if not path.is_file():
        errors.append(item['path']+': missing');continue
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    if digest!=item['sha256']:errors.append(item['path']+': checksum differs')
if errors:
    print('\n'.join(errors));print(str(len(errors))+' discrepancy/discrepancies');sys.exit(1)
print('Verified '+str(len(manifest['files']))+' files against their SHA-256 checksums.')
print('The manifest and SHA256SUMS.txt do not hash themselves. Extra files are allowed when combining collections.')
