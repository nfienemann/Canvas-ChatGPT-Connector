# CanvasBridge Business Coursework Collection

Six original fictional undergraduate business courses for demonstrations and testing.

## Start here

Extract this archive beside the other sample library. Keep the unique `CanvasBridge_Business_Coursework_v1` root folder. You can copy this folder into your combined collection without overwriting the other pack's files.

Use `01_STUDENT_MATERIALS` for ordinary source import. Start with one course and add the shared policy and company brief when useful. Keep `90_EVALUATOR_ONLY` outside the import selection when you want an unbiased test. `91_EDGE_CASES_OPT_IN` contains deliberate edge cases to add one at a time.

All people, institutions, companies, academic records, datasets and policies are invented. This pack contains no Rowan course material, real student records, copied commercial cases or real-world results. Sample student work is labeled as fictional classroom work.

## Courses

| Code | Course | Assessments | Dataset rows |
| --- | --- | ---: | ---: |
| ACC201 | Financial Accounting | 8 | 903 |
| FIN310 | Corporate Finance | 8 | 201 |
| MGT340 | Organizational Behavior | 8 | 192 |
| MKT320 | Marketing Research and Customer Analytics | 8 | 1076 |
| OPS330 | Operations and Supply Chain Management | 8 | 810 |
| STR410 | Business Strategy and Ethics | 8 | 156 |

Each course includes a syllabus, 16-week schedule, detailed assignment briefs and rubrics, substantial original readings, a case, lecture slides with teaching notes, structured data and dictionaries, a sample student report, feedback, discussion evidence, and dated announcements. The collection is a complete **demo source set**, not a claim to replace an accredited full-semester curriculum or textbook.

## Time and source conventions

The fictional semester runs August 31 through December 18, 2026. The default analysis timestamp is **October 29, 2026 at noon America/New_York**. Re-anchor explicitly if testing another time. Most earlier dates use UTC-04:00; dates after the November 1 clock change use UTC-05:00. IDs beginning with a course code are stable source labels within this pack, not Canvas course IDs or opaque tool document IDs.

Opening-semester syllabi and schedules can retain a superseded date. Read the later dated announcement before deciding a current deadline. Do not treat every discrepancy as a bug: the evaluator files record the intended conflicts and the evidence that resolves or leaves them open. Scores, receipts and discussion participation are distinct evidence.

## Import and compatibility

PDF, DOCX, PPTX, XLSX, TXT and Markdown files provide a variety of source formats. CSV and JSON files are portable source-data companions. Full TXT mirrors are included for CSV data, and PDF versions accompany slides so the sources remain useful where a format or visual renderer is unavailable. The image-only PDFs are opt-in visual extraction tests.

Use the formats your installed independent importer currently accepts. Resolve imported document IDs and hashes from CanvasBridge after import; do not pass the pack's filenames or source labels as opaque tool IDs. File generation and local validation are complete, but this pack has **not** been imported into your running CanvasBridge instance. Native reading, policy evaluation, portfolio generation, structured grades and scheduling remain separate runtime capabilities to test.

The `Portable_Academic_Records.json` files use this pack's `business-coursework-fixture-1` schema. They are not advertised as an `independent-academic-1` tool contract or an API request. The connected tool descriptions name that independent dataset format, but its full schema was not available here. The companion TXT records support source-grounded reading and manual fixture conversion without inventing a plugin contract. A calendar proposal is not a calendar write.

## Workbook use

Each course workbook preserves the provided source rows, computes descriptive statistics with editable formulas, and includes a separate voluntary calculation workshop. Workshop values are explicitly independent hypothetical examples, not replacements for the course case. Yellow input cells can be changed to demonstrate recalculation. CSV values and dictionaries remain available for inspection outside Excel.

## Testing and reuse

Read `DEMO_PROMPTS.md` for guided prompts and `90_EVALUATOR_ONLY` for expected outcomes. The manifest records file hashes and source identities. Run the included verifier to check ZIP contents and checksums after moving or combining the collection. The verification report distinguishes content checks from live application tests that were not performed.

You may modify and redistribute these original synthetic materials for demonstrations, tests and educational prototypes. Keep the synthetic disclosure when sharing. Refer to `REUSE_NOTICE.txt` for the full note.
