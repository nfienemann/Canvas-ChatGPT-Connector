# Phase A — Integration baseline and demonstration benchmark

This spec set establishes a reproducible baseline for the current CanvasBridge academic intelligence path. It maps the integrated interfaces, exercises one controlled coursework packet and records findings, coverage, source handoffs and manual work.

Phase A belongs to the expansion roadmap A–F. The existing Stages 1–6 supply its foundations. Stage 5 is accepted complete by the user's direction and supplies the current operating behavior.

## Specification set

| Specification | Implementation outcome |
| --- | --- |
| `specs/PHA-01.json` | Current-build bindings for intake, reading, notes, requirements, host evidence and available planning/state interfaces. |
| `specs/PHA-02.json` | A controlled native presentation fixture with exact ground truth and corrected and missing-deck variants. |
| `specs/PHA-03.json` | Four actual native attempts, source-to-host captures, finding scores and measured manual interventions. |
| `specs/PHA-QA-01.json` | Reproducibility checks, a completed baseline report and evidence-backed handoff into Phase B. |

Begin with `CODEX_HANDOFF.md`. `report.json` records package preparation and validation. The execution templates initialize product observations to `not_run` with null measurements.

## The benchmark

BenchLink is a fictional pitch for campus equipment booking. Each complete packet contains a brief, a seven-slide PowerPoint with native speaker notes, versioned references and a synthetic measured rehearsal record. All source facts and organizations are synthetic.

| Packet | Controlled content |
| --- | --- |
| Baseline | Missing required limitations/validation section, archived v1 applied to an explicitly current-source claim, and a 455-second rehearsal against a 420-second maximum. |
| Corrected | Required section present, current v2 evidence with 22 of 120 rounded to 18%, and a 410-second rehearsal. |
| Missing deck | Three baseline supporting files with the deck deliberately absent. The rehearsal retains its original version and exact deck hash. |

The baseline's timing overage is 35 seconds. The corrected rehearsal has a 10-second margin. The baseline's archived source is accurately cited, which provides a positive control for citation resolution while current-source applicability fails. A coordinator fact appears only in speaker notes.

The missing-deck case makes the section and current-source deck findings unevaluable. Its retained rehearsal can still support arithmetic attributed to the named recorded run.

## Bounded execution

The minimum matrix contains the first baseline attempt, one matched baseline repeat, one corrected attempt and one missing-deck attempt. A single baseline planning probe records the existing handoff and any manual task translation. Every run uses a fresh equivalent host context and case-bound imported IDs. Isolated fixture inventory or test-harness source selection keeps each packet's content controlled. Actual starting-state differences are captured.

Sixteen acceptance cases cover the run identity, fixture integrity, intake, notes, three target findings, controls, gaps, planning, manual work, repeat behavior, observable state and handoff. Twelve scorecard measures retain their own units and denominators.

Phase completion requires actual core-path execution and an honest, reproducible record. A completed Phase A baseline may contain product misses or unsupported downstream capabilities. An unexercised core path retains a prepared, partial or blocked status according to the recorded evidence.

The full-input baseline keeps three expected findings in its denominator, including any misses caused by dropped supplied content. Corrected-control scoring records assessed coverage as well as false allegations. An empty response leaves its checks unassessed.

## Integration observations

The public-source map covers 30 files and 72 anchors at commit `29652557b5701df6eb9147ac232fd3c656449104`, checked on November 5, 2026. The implementing process binds these candidates to the active branch and installed tool schemas.

| Observed seam | Baseline capture |
| --- | --- |
| The historical local reader returns up to five parts per call. | Follow actual continuation for the seven-slide deck and record every returned content hash. |
| Native notes are retained in extraction, while local output flattens them into numbered parts. | Measure actual notes content and locator fidelity at both reader and host boundaries. |
| Independent requirements review performs mechanical checks. | Capture the source excerpts actually delivered to the host for qualitative interpretation. |
| Current planning consumes modeled work and effort. | Record any native findings-to-plan bridge and any manual translation. |
| Existing benchmark helpers provide fingerprints and timings. | Reuse their capture machinery with the Phase A completion model. |

Historical source observations identify candidate integration work. Current product results come from the actual captured attempts.

Host evidence is captured at the observable boundary, such as the submitted tool response and final answer. Unexposed internal context assembly is recorded with its observation limit.

## Package contents

- `specs/` contains four implementation specifications.
- `fixtures/cases/` contains the three model-facing packet variants.
- `fixtures/oracle.json` and `fixtures/index.json` contain evaluator ground truth and exact file identities.
- `fixtures/previews/` contains all fourteen rendered slide previews.
- `prompts/` contains neutral review, missing-deck and planning tasks.
- `contracts/` defines capture fields and scoring rules.
- `templates/` contains unexecuted current-build, run, finding, intervention, gap and report records.
- `evidence/` contains source review, fixture checks, acceptance-design review and package checks.

The evaluator supplies only the case's declared model-input files, runner context and neutral task to the review host. The oracle is consulted after the actual native output has been captured.

## Validate the supplied package

Python 3.11 or later is sufficient for validation of the frozen packet.

```bash
python /path/to/phase_a_baseline/validate_package.py
```

Add `--negative-controls` to exercise the six intentional-tamper controls. The optional `--source-root` argument verifies the thirty reviewed source files against a local checkout of the pinned public commit.

The fixture validator can also run independently.

```bash
python /path/to/phase_a_baseline/fixtures/validate_fixtures.py
```

Canonical exported bytes define this fixture version. The included build inputs reproduce content and layout through Artifact Tool. A new export records its own byte hashes. `fixtures/README.md` provides the build and inspection details.

## Phase B handoff

The final implementation report carries the actual requirement IDs, artifact identities, source locators, supported findings, observed remaining-work output and manual transitions into persistent assignment readiness. `scope_and_roadmap.json` records the remaining B–F sequence and `templates/gap_register.json` provides the evidence fields for follow-up work.
