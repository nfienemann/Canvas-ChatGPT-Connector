# Phase A implementation handoff

Implement the four specifications in `specs/` against the active CanvasBridge checkout. Deliver one reproducible current-product baseline for the supplied synthetic presentation packet. Use the accepted current Stage 5 behavior as the operating context.

## 1. Bind the active implementation

Read the repository's instructions. Capture the actual branch, commit, worktree fingerprint, relevant component revisions, runtime and exposed tool schemas in a copy of `templates/current_build_bindings.json`.

Use `evidence/capability_map.json` and `evidence/source_bindings.json` as the pinned public-source map. Resolve their symbols against the active implementation. Close already-supported requirements with evidence and keep the adapter/capture changes small.

The primary route is the active independent-materials flow for the four synthetic input files. Historical candidate tools are `list_local_documents`, `get_local_document_status`, `read_local_document` and `run_independent_academic_workflow`. Save the actual import request and resulting identifiers.

For the reviewed local reader, the first deck request uses `document_id`, `start_part=1` and `limit=5`. The next request uses the returned `next_part`. Compare returned `content_hash` values and capture per-part truncation. The current installed schema determines the actual calls.

The historical independent workflow permits five distinct documents and one selected range of up to five parts per document. Its per-part text handoff is capped at 4,000 characters. Full local reads use a different 18,000-character per-part cap. Record both the actual selected ranges and the excerpts visible to the host. A seven-slide deck needs coverage beyond the first workflow range.

The requirements result provides mechanical checks. Observe the normal orchestration's delivery of the brief, deck bodies, notes, references and rehearsal record to the host. Preserve the native outcome before a linked assisted attempt supplies any missing excerpts.

## 2. Validate the canonical fixtures

Run the package validator from any working directory.

```bash
python /path/to/phase_a_baseline/validate_package.py
```

Use the canonical files listed in `fixtures/index.json`. Its relative source paths resolve from `fixtures/`. Keep each case's model-facing files together and use their exact hashes. The packet is small enough to inspect directly.

The evaluator oracle records three baseline issues, four assignment requirements, citation and notes controls, corrected evidence and a declared missing-deck condition. The expected facts remain in the evaluator context. Capture the source inventory and prompt actually supplied to the review host.

## 3. Capture four native attempts

Create a new run-evidence directory outside the frozen spec package. Copy the templates into it and follow `run_matrix.json`.

| Run | Packet | Task |
| --- | --- | --- |
| `baseline_01` | `baseline` | `prompts/review_packet.md` |
| `baseline_02` | Same baseline bytes in an equivalent fresh context | `prompts/review_packet.md` |
| `corrected_01` | `corrected` | `prompts/review_packet.md` |
| `missing_deck_01` | `missing_deck` plus declared missing context | `prompts/missing_deck.md` |

Use fresh equivalent host contexts and case-bound imported IDs for all four attempts. An isolated fixture inventory or test-harness source selection keeps earlier decks outside the missing-deck case. Inspect the actual transcript for out-of-case retrieval and replay any affected comparison with the declared source selection.

Preserve ordered exact requests, raw responses, submitted source excerpts and the actual final host answer. Each reference needs retrievable content and its hash. Record the observable handoff boundary and its observation-support level. Internal host context or use can remain unexposed with a reason while the visible handoff supplies capture evidence. Record actual route failures and source coverage. An interface failure after the request reaches the product is an observed outcome. A setup or transport blocker is recorded at that boundary.

Keep the first native attempt as the baseline. If useful diagnosis requires manual extraction, pasting, source labeling or task construction, capture a linked `assisted_diagnostic` attempt and log each intervention. Measure human active time only when a timing method is actually used.

After `baseline_01`, make the single planning probe through the current supported interface. The prompt provides a fixed synthetic work window. Record unavailable inputs and any newly supplied task or effort values. Record observable state and receipts through existing interfaces, including unavailable observation support.

## 4. Adjudicate actual outputs

Use `contracts/scoring_rules.json` after freezing each native result. Record the claim text, source coverage, returned locators and evaluator decision.

The baseline supported-finding denominator is three. Dropped supplied content remains part of the end-to-end miss count. Keep semantic recognition and evidence support visible.

For the corrected case, record all three defect classes, assessed coverage and false allegations. A supported clearance requires an actual assessment with usable evidence. A silent or unrelated response leaves the checks unassessed.

For the missing-deck case, assess the declared absence, the two unavailable deck properties and the separately attributed rehearsal arithmetic. The original rehearsal's hash association identifies which recorded version it describes.

Review extra asserted defects against the actual packet. Retain genuinely supported additional findings and identify unsupported claims or suggestions. Use exact counts, denominators and units.

Compare the baseline pair semantically, including source coverage and manual work. One pair records a sample of two runs. The corrected variant measures response to changed input within its own run context.

## 5. Finish the baseline and Phase B handoff

Complete every case in `acceptance_cases.json` with capture evidence and an actual verdict. The sixteen cases assess baseline integrity. Their product measurements record observed quality.

Use `templates/baseline_report.json` for the execution report. Complete Phase A when the core current intake/read/review path has actually been exercised, all four attempts are captured, scoring is traceable and the handoff is reproducible. Preserve measured product gaps in the report.

Create each gap from a concrete request, output and user-visible effect. Identify its smallest component, current reuse point, reproduction and closure evidence. A regression claim needs an earlier comparable executed baseline.

Carry current requirement IDs, artifact versions, supported evidence, findings, remaining-work output and manual transitions into Phase B. The roadmap file provides the ownership of revision propagation, forecasting, resources and group handoffs.

## Completion artifacts

- Current-build bindings and actual interface inventory.
- Four native run captures and any linked assisted attempts.
- Actual source, host-input and final-answer evidence with hashes.
- Completed sixteen-case report and twelve-measure scorecard.
- Manual intervention ledger and matched-repeat comparison.
- One current planning handoff observation.
- Relevant existing regression results for any changed adapter/capture code.
- Reproduction instructions and an evidence-backed gap register for Phase B and later phases.
