#!/usr/bin/env python3
"""Validate the frozen Phase A specification package using Python's standard library."""

import argparse
import hashlib
import json
import runpy
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path


CHECKSUM_EXCLUSIONS = {"SHA256SUMS", "evidence/package_validation.json"}
SPEC_IDS = {"PHA-01", "PHA-02", "PHA-03", "PHA-QA-01"}
CASE_IDS = {f"PHA-T{number:02d}" for number in range(1, 17)}
COMMIT = "29652557b5701df6eb9147ac232fd3c656449104"


def read_json(root, relative):
    return json.loads((root / relative).read_text(encoding="utf-8"))


def validate_structure(root):
    checks = []

    def check(identifier, condition, detail):
        checks.append({"id": identifier, "passed": bool(condition), "detail": detail})

    json_paths = sorted(root.rglob("*.json"))
    for path in json_paths:
        json.loads(path.read_text(encoding="utf-8"))
    check("json.parse", bool(json_paths), f"Parsed {len(json_paths)} JSON files")

    specs = [json.loads(path.read_text(encoding="utf-8")) for path in sorted((root / "specs").glob("*.json"))]
    spec_by_id = {spec["id"]: spec for spec in specs}
    check("spec.identities", len(specs) == 4 and set(spec_by_id) == SPEC_IDS, "Four unique agreed specification IDs")
    acceptance = read_json(root, "acceptance_cases.json")
    cases = acceptance["cases"]
    case_by_id = {case["id"]: case for case in cases}
    check("acceptance.identities", len(cases) == 16 and set(case_by_id) == CASE_IDS, "Sixteen unique ordered acceptance cases")
    check("acceptance.prepared", acceptance["actual_product_executions"] == 0 and all(case["execution_status"] == "not_run" and case["capture_verdict"] == "not_run" for case in cases), "Prepared acceptance records claim zero product executions")
    for spec in specs:
        identifier = spec["id"]
        requirement_ids = [item["id"] for item in spec["requirements"]]
        check(f"{identifier}.requirements", len(requirement_ids) >= 8 and len(requirement_ids) == len(set(requirement_ids)), "Unique detailed requirements")
        check(f"{identifier}.case_refs", set(spec["acceptance_cases"]) <= CASE_IDS, "All case references resolve")
        check(f"{identifier}.dependencies", set(spec["dependencies"]) <= SPEC_IDS - {identifier}, "Dependencies reference another supplied spec")
        check(f"{identifier}.inputs", all((root / path).exists() for path in spec["inputs"]), "Referenced package inputs exist")
        check(f"{identifier}.commit", spec["reviewed_public_commit"] == COMMIT, "Pinned source baseline is consistent")
    check("acceptance.owners", all(case["owner_spec"] in spec_by_id and case["id"] in spec_by_id[case["owner_spec"]]["acceptance_cases"] for case in cases), "Every acceptance owner links its case")
    check("acceptance.coverage", set().union(*(set(spec["acceptance_cases"]) for spec in specs)) == CASE_IDS, "The specifications cover all sixteen cases")

    scope = read_json(root, "scope_and_roadmap.json")
    check("scope.roadmap", [item["phase"] for item in scope["phase_sequence"]] == list("ABCDEF"), "The selected expansion roadmap is A through F")
    check("scope.bounds", scope["bounded_core"]["minimum_native_run_count"] == 4 and scope["bounded_core"]["case_count"] == 3 and scope["bounded_core"]["planted_baseline_issues"] == 3, "Four native attempts across three variants and three planted issues")

    matrix = read_json(root, "run_matrix.json")
    expected_runs = {"baseline_01", "baseline_02", "corrected_01", "missing_deck_01"}
    check("matrix.identities", len(matrix["runs"]) == 4 and {item["run_id"] for item in matrix["runs"]} == expected_runs, "Four unique planned native runs")
    fixture_index = read_json(root, "fixtures/index.json")
    fixture_cases = {item["case_id"] for item in fixture_index["cases"]}
    check("matrix.case_refs", all(item["case_id"] in fixture_cases for item in matrix["runs"]), "Run cases resolve to the fixture index")
    check("matrix.prompts", all((root / item["prompt_ref"]).is_file() for item in matrix["runs"]) and (root / matrix["planning_probe"]["prompt_ref"]).is_file(), "All neutral task prompts exist")
    check("matrix.prepared", all(item["execution_status"] == "not_run" and item["capture_ref"] is None for item in matrix["runs"]), "Run matrix remains unexecuted")

    scoring = read_json(root, "contracts/scoring_rules.json")
    mapping = scoring["issue_mapping"]
    check("scoring.baseline_denominator", mapping["baseline"]["positive_denominator"] == 3 and mapping["baseline_repeat"]["positive_denominator"] == 3, "Both complete-packet runs retain three target positives")
    check("scoring.corrected_denominator", mapping["corrected"]["negative_denominator"] == 3, "Three corrected defect classes")
    check("scoring.missing_scope", mapping["missing_deck"]["unevaluable_current_deck_issue_ids"] == ["PA-F01", "PA-F02"] and mapping["missing_deck"]["timing_denominator"] == 1, "Two missing-deck properties and one recorded-timing claim")
    check("scoring.unassessed", "unassessed" in scoring["outcome_model"]["product_results"]["finding_status"], "Executed silence has an unassessed disposition")
    oracle = read_json(root, "fixtures/oracle.json")
    oracle_by_case = {item["case_id"]: item for item in oracle["cases"]}
    check("scoring.oracle_issues", mapping["baseline"]["positive_issue_ids"] == oracle_by_case["baseline"]["expected_finding_ids"], "Scoring issue IDs match the independent oracle")
    check("scoring.oracle_controls", mapping["missing_deck"]["coverage_finding_id"] in oracle_by_case["missing_deck"]["expected_finding_ids"] and mapping["missing_deck"]["timing_finding_id"] in oracle_by_case["missing_deck"]["expected_finding_ids"], "Missing-deck scoring references resolve")
    measures = scoring["measures"]
    check("scoring.measures", len(measures) == 12 and len({item["id"] for item in measures}) == 12, "Twelve uniquely named measures")
    check("scoring.prepared", all(item["observed"] is None and item["execution_status"] == "not_run" for item in measures), "Expected values have zero observed product credit")

    capture = read_json(root, "contracts/capture_contract.json")
    baseline_template = read_json(root, "templates/baseline_report.json")
    run_template = read_json(root, "templates/run_capture.json")
    check("templates.zero_execution", baseline_template["phase_a_completion"] == "prepared" and baseline_template["execution_summary"]["actual_product_executions"] == 0 and baseline_template["run_records"] == [], "The template contains no actual run claims")
    check("templates.phase_enum", capture["phase_a_completion_values"] == scoring["outcome_model"]["phase_completion"]["allowed_values"], "Phase-status enums agree")
    check("templates.execution_enum", run_template["execution_status"] in capture["execution_status_values"] and run_template["execution_status"] == "not_run", "Run execution starts at not_run")
    check("templates.null_measurements", all(item["observed"] is None for item in baseline_template["scorecard"]) and all(value is None for key, value in run_template["runtime_observations"].items() if key != "unmeasured_reason"), "Prepared observed measures remain null")
    check("templates.acceptance", {item["case_id"] for item in baseline_template["acceptance_results"]} == CASE_IDS, "The final report template covers every acceptance case")
    check("templates.opaque_host", run_template["host_handoff_observation"]["host_internal_receipt"] is None and "host_observation_rule" in capture, "Opaque host internals have explicit unavailable support")

    bindings = read_json(root, "evidence/source_bindings.json")
    capabilities = read_json(root, "evidence/capability_map.json")
    files = bindings["files"]
    anchors = [anchor for item in files for anchor in item["reviewed_anchors"]]
    anchor_ids = {anchor["id"] for anchor in anchors}
    check("source.commit", bindings["reviewed_commit"] == capabilities["reviewed_commit"] == COMMIT, "Both source records share the checked commit")
    check("source.inventory", len(files) == bindings["files_verified"] == 30 and len({item["path"] for item in files}) == 30, "Thirty unique source files")
    check("source.anchors", len(anchors) == len(anchor_ids) == 72, "Seventy-two unique source anchors")
    check("source.ranges", all(1 <= anchor["start_line"] <= anchor["end_line"] <= item["line_count"] for item in files for anchor in item["reviewed_anchors"]), "Every anchor is within its declared source file")
    check("source.verification_record", bindings["all_files_match_reviewed_commit"] and all(item["local_git_blob_verified"] for item in files), "The preparation source-review record reports all Git blobs verified")
    check("source.execution_labels", bindings["product_feature_tests_executed"] == capabilities["product_feature_tests_executed"] == 0 and not bindings["active_implementation_branch_verified"], "Pinned static review carries zero current-product executions")
    check("source.capabilities", len(capabilities["capabilities"]) == 13 and all(set(item["source_anchor_refs"]) <= anchor_ids for item in capabilities["capabilities"]), "Thirteen source-bound capabilities resolve their anchors")

    if (root / "report.json").is_file():
        report = read_json(root, "report.json")
        check("report.preparation", report["product_execution_count"] == 0 and report["phase_a_completion"] == "prepared", "Delivery report accurately identifies package preparation")
    return checks


def validate_checksums(root):
    checks = []
    manifest_path = root / "SHA256SUMS"
    expected_files = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file() and str(path.relative_to(root)) not in CHECKSUM_EXCLUSIONS}
    listed = set()
    for line in manifest_path.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        path = Path(relative)
        safe = not path.is_absolute() and ".." not in path.parts
        exists = safe and (root / path).is_file()
        valid = exists and hashlib.sha256((root / path).read_bytes()).hexdigest() == digest
        checks.append({"id": f"checksum.{relative}", "passed": bool(valid and relative not in listed), "detail": "SHA-256 and unique safe relative path"})
        listed.add(relative)
    checks.append({"id": "checksum.inventory", "passed": listed == expected_files, "detail": f"Manifest covers {len(expected_files)} frozen files. The manifest and regenerable package-validation report are excluded."})
    return checks


def validate_source_bytes(root, source_root):
    checks = []
    for item in read_json(root, "evidence/source_bindings.json")["files"]:
        path = source_root / item["path"]
        matches = False
        if path.is_file():
            data = path.read_bytes()
            blob = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
            matches = blob == item["git_blob_sha"] and hashlib.sha256(data).hexdigest() == item["sha256"]
        checks.append({"id": f"source_bytes.{item['path']}", "passed": matches, "detail": "Exact pinned Git blob and SHA-256 verification"})
    return checks


def package_negative_controls(root):
    results = []
    with tempfile.TemporaryDirectory(prefix="phase-a-package-controls-") as directory:
        work = Path(directory) / "package"
        shutil.copytree(root, work)
        path = work / "templates/baseline_report.json"
        original = path.read_text(encoding="utf-8")
        changed = json.loads(original)
        changed["execution_summary"]["actual_product_executions"] = 1
        changed["phase_a_completion"] = "complete"
        path.write_text(json.dumps(changed), encoding="utf-8")
        checks = validate_structure(work)
        results.append({"id": "fabricated_prepared_execution", "passed": any(item["id"] == "templates.zero_execution" and not item["passed"] for item in checks)})
        path.write_text(original, encoding="utf-8")
        path = work / "contracts/scoring_rules.json"
        changed = read_json(work, "contracts/scoring_rules.json")
        changed["issue_mapping"]["baseline"]["positive_denominator"] = 2
        path.write_text(json.dumps(changed), encoding="utf-8")
        checks = validate_structure(work)
        results.append({"id": "reduced_positive_denominator", "passed": any(item["id"] == "scoring.baseline_denominator" and not item["passed"] for item in checks)})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--source-root", type=Path, help="Optional checkout of the pinned public commit for exact source-byte verification")
    parser.add_argument("--negative-controls", action="store_true")
    parser.add_argument("--report", type=Path, help="Optional JSON output path outside the frozen checksum scope")
    args = parser.parse_args()
    root = args.root.resolve()
    checks = validate_structure(root) + validate_checksums(root)
    fixture_validator = runpy.run_path(str(root / "fixtures/validate_fixtures.py"))
    fixture_checks = fixture_validator["validate"](root / "fixtures")
    checks += [{**item, "id": "fixture." + item["id"]} for item in fixture_checks]
    if args.source_root:
        checks += validate_source_bytes(root, args.source_root.resolve())
    controls = []
    if args.negative_controls:
        controls = package_negative_controls(root) + fixture_validator["negative_controls"](root / "fixtures")
    passed = all(item["passed"] for item in checks + controls)
    result = {
        "schema_version": "phase-a-package-validation.v1",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "pass" if passed else "fail",
        "product_execution_count": 0,
        "summary": {"checks": len(checks), "passed": sum(item["passed"] for item in checks), "fixture_checks": len(fixture_checks), "negative_controls": len(controls), "negative_controls_passed": sum(item["passed"] for item in controls), "source_bytes_rechecked": args.source_root is not None},
        "checksum_exclusions": sorted(CHECKSUM_EXCLUSIONS),
        "checks": checks, "negative_controls": controls
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], **result["summary"], "product_execution_count": 0, "failed_checks": [item["id"] for item in checks + controls if not item["passed"]]}, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
