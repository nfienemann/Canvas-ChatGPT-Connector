Using the findings from the completed review and the current supported planning workflow, show the remaining work for this synthetic assignment and a proposed next work session.

For this planning exercise, the synthetic clock is November 5, 2026 at 12:00 UTC and the available work window is 14:00–15:00 UTC that day. This is a proposed session. Keep source-backed tasks, supplied constraints and introduced effort estimates explicit.

Record any additional work records or effort values needed by the current planning interface, together with how they were derived. Explain the available output and any missing input that limits the plan.
