# Phase F — Artifact-grounded group handoffs

Phase F connects explicit responsibilities to current coursework artifacts and a concrete next action. It uses the A–E evidence, work, planning and resource interfaces to produce a durable packet, retain responses on their original subject and reconcile changes accurately.

Begin with `CODEX_HANDOFF.md`. The preparation report is `report.json`, and actual implementation results belong in `templates/implementation_report.json`.

## Specification set

| Specification | Outcome |
| --- | --- |
| `PHF-01` | Explicit participant/responsibility identity and exact current handoff scope. |
| `PHF-02` | Artifact-grounded packets with action-specific readiness and attributable responses. |
| `PHF-03` | Equivalent/material change, reassignment, recurrence and response applicability. |
| `PHF-04` | Durable normal workflows, current exports and recoverable supported delivery. |
| `PHF-QA-01` | Actual integrated acceptance and a complete A–F assignment journey. |

The package includes 28 acceptance cases, 16 synthetic scenarios, 20 invariants, eight measures and a ten-check host rubric. Source bindings identify pinned-source candidate seams to inspect first.

## What the current handoff conveys

| State | Evidence it carries |
| --- | --- |
| Responsibility | The explicitly assigned or declared contributor, role and current work scope. |
| Artifact readiness | Current criterion assessment, exact artifact/requirement versions and coverage. |
| Next-action readiness | Whether the actual requested review, integration or execution prerequisites are supported. |
| Resource conditions | E blockers scoped to transfer, the requested action or later execution. |
| Export/delivery | The actual payload, created artifact or supported delivery effect and its receipt. |
| Response | The named actor's reported or observed response, original basis and current applicability. |

An accessible draft can be ready for a scoped review while its artifact assessment is `needs_work`. An integration action can require specific satisfied criteria. A later equipment blocker stays visible with the step it affects.

The default acknowledgment policy is optional. A response becomes a required action prerequisite only when the current task explicitly says so. Packet preparation and artifact assessment continue with their own evidence and current states.

## Exact versions and useful continuity

Every packet snapshot retains its exact work episode, requirement/artifact versions, responsibility assignment, recipient set and requested action. Relevant E conditions retain their current process and plan references. Transport formatting can change while the semantic basis stays the same.

Responses preserve the original actor, recorder, event time, knowledge time and packet basis. Direct observations and relayed declarations retain their actual source basis. Applicability has four outcomes.

- `current_exact` matches the current semantic subject and participant/action scope.
- `carried_equivalent` uses full Phase C dependency correspondence with the same assignment, recipient, action and episode.
- `historical` belongs to a materially different or superseded subject.
- `unresolved` lacks the evidence needed to establish current applicability.

A proven equivalent file move or relevant-content revision can carry an assessment or response forward. Original assessment and response times remain intact. Material edits, reassignment and recurring work preserve earlier facts while deriving the current packet and next action.

## Current integration path

The core workflow saves a packet, returns the current JSON/Markdown export payload and records supplied response evidence. Existing supported delivery adapters can provide their actual effects through the accepted Stage 5 workflow.

The pinned process export returns a payload. Each export records `output_kind`. A requested downloadable artifact uses the active host/artifact adapter and records the actual content hash, locator and creation receipt. A local save, export, delivery confirmation and acknowledgment each retain their own evidence.

Participants and responsibility can come from supplied project artifacts or explicit declarations. An existing roster adapter can supply its current records. Storage ownership, responsible contributor, acknowledging actor and recorder have separate fields. The current durable process store holds history, with the existing revision and replay mechanisms.

## Contents

- `specs/` contains five implementation specifications.
- `contracts/` defines typed handoffs, readiness/applicability, operations, execution capture and A–F integration.
- `fixtures/` contains generic group-coursework artifacts, supplied assessments and response records, authored expectations and checks.
- `reference/` preserves exact narrow B/C/E contracts with byte provenance.
- `prompts/` contains ordinary preparation, response, change and recovery journeys.
- `templates/` contains active-build bindings and pending actual-run reports.
- `evidence/` contains source mapping, independent review and local validation.

The bounded evaluator projects supplied assessment and transition records into one-action packets. Native Markdown files support exact content hash and evidence-locator checks. Actual content assessment, current state persistence and host behavior are exercised during implementation acceptance.

## Validation and completion

Use Python 3.11 or later.

```bash
python /path/to/phase_f_handoffs/validate_package.py --negative-controls
```

The optional `--source-root` argument checks exact pinned source bytes. The fixture validator also runs independently.

```bash
python /path/to/phase_f_handoffs/fixtures/validate_fixtures.py --negative-controls
```

Executed preparation checks cover local packet structure, evidence references, bounded transitions and deliberate corruptions. Product, supported-host, provider and source-test execution counters begin at zero. Actual completion requires current integrated cases, real durable restart and retained host answers at the declared capability boundary.

## Sequential implementation

The agreed order is A → B → C → D → E → F. Start this archive after Phase E acceptance. Resolve it against the actual implemented upstream interfaces and use each preceding report as the current baseline.

F closes the roadmap with one actual assignment journey through intake, readiness, change impact, forecasting, resource planning and the current group handoff. The report retains the exact upstream outputs, final packet and supported next action.
