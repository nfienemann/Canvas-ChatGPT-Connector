# Reconcile a changed deliverable

The supplied artifact or responsibility update changes this group handoff. Reconcile the current packet, preserve the assessments and responses supported by equivalent evidence, and identify what the current recipient should do next. Show the changed version, current owner and any response that now belongs to an earlier basis.
