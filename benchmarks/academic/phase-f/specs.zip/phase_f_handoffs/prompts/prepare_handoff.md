# Prepare a current handoff

Use the supplied group coursework, responsibility notes and current artifact versions. Prepare a handoff for the stated recipient with the exact file and sections to use, what the evidence supports, the specific next action and any relevant blocker. Keep the current personal progress, artifact readiness and requested action visible with their actual basis.
