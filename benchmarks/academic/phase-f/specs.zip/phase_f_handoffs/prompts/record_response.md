# Record a supplied response

Record the response in the supplied teammate message against the packet and version it refers to. Preserve who responded and that I supplied this message. Show whether the response applies to the current handoff and whether the next action has any explicit response prerequisite.
