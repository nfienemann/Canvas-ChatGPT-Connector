# Retrieve and recover the handoff

Retrieve the latest saved packet and the result of the interrupted export or supported delivery. Show the current artifact, requested action, supplied responses and confirmed output. Reconcile any unresolved operation using its existing identity, and preserve changes made since the earlier attempt.
