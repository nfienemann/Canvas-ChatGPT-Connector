# Synthetic coursework requirements and supplied roles

R1 requires a written prototype summary.
R2 requires the agreed comparison table and an explanation of bounded limitations.

The supplied responsibility record names member A as the artifact contributor and member B as the intended reviewer.
Member B owns action REVIEW-1, which reviews the written summary and can begin with R1 supported.
ASSEMBLE-1 requires R1 and R2 plus its declared process conditions.

Storage belongs to the existing personal principal. These participant labels are explicit supplied coursework identities.
