# Synthetic prototype draft

Prototype summary. The coursework demonstration compares two fictional enclosure layouts.

Evidence appendix. The comparison table will be added after the current review.

Known limit. This draft supports review of the written prototype summary.
