#!/usr/bin/env python3
"""Twelve focused groups with independently authored boundary expectations."""

import copy
import hashlib
import json
from pathlib import Path
import runpy


def run_controls(root):
    root = Path(root)
    model = runpy.run_path(str(root / "fixtures/reference_handoffs.py"))
    records = model["read"](root, "fixtures/records.json")
    policy = model["read"](root, "fixtures/policy.json")
    scenarios = model["index"](model["read"](root, "fixtures/scenarios.json")["scenarios"])
    actual = {}

    def find(rows, identifier):
        return next(row for row in rows if row.get("ref", row.get("id")) == identifier)

    def fixture(number, identifier):
        case = find(scenarios[f"PHF-S{number:02d}"]["cases"], identifier)
        return model["evaluate_case"](root, case, records, policy)

    def project(selection=None, data=None, rebind=False):
        supplied = copy.deepcopy(data or records)
        selected = {**supplied["base_selection"], **(selection or {})}
        if rebind:
            find(supplied["bases"], selected["basis_ref"])["payload"] = model["semantic_payload"](selected, supplied)
        return model["evaluate_case"](root, {"id": "control", "selection": selection or {}}, supplied, policy)

    baseline = project()
    conflict_data = copy.deepcopy(records)
    find(conflict_data["assessments"], "AS-R1")["status"] = "conflict"
    conflict = project({"assessment_refs": ["AS-R1"]}, conflict_data)
    failed_data = copy.deepcopy(records)
    find(failed_data["assessments"], "AS-R1")["status"] = "needs_work"
    known_failed = project({"assessment_refs": ["AS-R1"], "inventory_coverage": "partial"}, failed_data)
    optional_data = copy.deepcopy(records)
    find(optional_data["requirements"], "REQ-v1")["rows"][1]["required"] = False
    optional = project({"assessment_refs": ["AS-R1"]}, optional_data)
    excluded_data = copy.deepcopy(records)
    for criterion in find(excluded_data["requirements"], "REQ-v1")["rows"]:
        criterion.update(applicability="not_applicable", applicability_basis="SUPPLIED-CONDITION/EXCLUDED")
    excluded = project(data=excluded_data)
    actual["PHF-C01"] = {"conflict_precedes_unknown": conflict["artifact_readiness"], "known_gap_precedes_unknown": known_failed["artifact_readiness"], "optional_unknown_status": optional["artifact_readiness"], "supported_zero_applicable_status": excluded["artifact_readiness"], "incomplete_inventory_status": fixture(4, "incomplete-inventory")["artifact_readiness"]}

    bad_locator = copy.deepcopy(records)
    find(bad_locator["assessments"], "AS-R1")["evidence"].update(line_start=5, line_end=5)
    locator_result = project(data=bad_locator)
    bad_hash = copy.deepcopy(records)
    find(bad_hash["artifacts"], "ART-v1")["content"]["sha256"] = "0" * 64
    hash_result = project(data=bad_hash)
    contradictory = copy.deepcopy(records)
    second = copy.deepcopy(find(contradictory["assessments"], "AS-R1"))
    second.update(id="AS-R1-CONTRADICTORY", status="needs_work")
    contradictory["assessments"].append(second)
    conflict_assessments = project({"assessment_refs": ["AS-R1", "AS-R1-CONTRADICTORY", "AS-R2"]}, contradictory)
    reversed_assessments = project({"assessment_refs": ["AS-R1-CONTRADICTORY", "AS-R1", "AS-R2"]}, contradictory)
    actual["PHF-C02"] = {"wrong_locator_state": locator_result["requirement_states"]["R1"], "independent_row_preserved": locator_result["requirement_states"]["R2"], "wrong_hash_readiness": hash_result["artifact_readiness"], "wrong_version_readiness": fixture(3, "wrong-artifact-version")["artifact_readiness"], "contradictory_assessment_status": conflict_assessments["artifact_readiness"], "assessment_order_independent": conflict_assessments["artifact_readiness"] == reversed_assessments["artifact_readiness"]}

    authorship = copy.deepcopy(records)
    find(authorship["artifacts"], "ART-v1")["authorship_hint"] = "SYNTHETIC-MEMBER-C"
    author_result = project(data=authorship)
    no_assignment_evidence = copy.deepcopy(records)
    find(no_assignment_evidence["responsibilities"], "RESP-1")["source_ref"] = ""
    unsupported = project(data=no_assignment_evidence)
    principal_recorder = copy.deepcopy(records)
    find(principal_recorder["acknowledgments"], "ACK-1")["recorded_by"] = records["base_selection"]["storage_principal"]
    recorder_result = project({"ack_refs": ["ACK-1"]}, principal_recorder)
    actual["PHF-C03"] = {"authorship_hint_keeps_supplied_owner": author_result["responsible_actor"], "missing_responsibility_evidence": unsupported["next_action_state"], "ambiguous_identity_state": fixture(2, "ambiguous-responsibility")["next_action_state"], "storage_principal_remains_separate": baseline["storage_principal"] != baseline["responsible_actor"], "separate_storage_recorder_ack": recorder_result["current_ack_state"]}

    draft = fixture(5, "done-still-needs-work")
    empty_prerequisites = copy.deepcopy(records)
    find(empty_prerequisites["actions"], "REVIEW-1").update(requirement_ids=[], evidence_basis=[])
    missing_review_input = project({"artifact_availability": "unavailable"}, empty_prerequisites, rebind=True)
    ack_required = copy.deepcopy(records)
    find(ack_required["actions"], "REVIEW-1")["requires_accepted_ack"] = True
    required_ack_result = project(data=ack_required, rebind=True)
    actual["PHF-C04"] = {"done_declaration": draft["personal_progress"], "done_artifact_readiness": draft["artifact_readiness"], "draft_review_action": draft["next_action_state"], "partial_review_action": fixture(4, "partial-review")["next_action_state"], "empty_completion_prerequisites_missing_input": missing_review_input["next_action_state"], "explicit_ack_prerequisite": required_ack_result["next_action_state"], "optional_ack_default": baseline["next_action_state"]}

    unsupported_ack = copy.deepcopy(records)
    find(unsupported_ack["acknowledgments"], "ACK-1")["evidence_basis"] = "inferred_from_delivery"
    unsupported_ack_result = project({"ack_refs": ["ACK-1"]}, unsupported_ack)
    group_both = project({"responsibility_ref": "RESP-GROUP", "basis_ref": "BASIS-GROUP", "ack_refs": ["ACK-GROUP-B", "ACK-GROUP-C"]})
    actual["PHF-C05"] = {"received_state": fixture(7, "received")["current_ack_state"], "accepted_state": fixture(7, "accepted")["current_ack_state"], "changes_requested_state": fixture(7, "changes-requested")["current_ack_state"], "delivery_without_ack": fixture(8, "delivered-without-ack")["current_ack_state"], "unsupported_ack_applicability": unsupported_ack_result["ack_applicability"]["ACK-1"], "one_member_group_state": fixture(2, "explicit-member-scope")["current_ack_state"], "all_explicit_members_state": group_both["current_ack_state"], "all_explicit_members_count": group_both["current_ack_count"]}

    alias = fixture(9, "alias-only")
    accepted = fixture(7, "accepted")
    formatting = project({"ack_refs": ["ACK-1"], "transport_revision": "99"})
    unversioned_action = copy.deepcopy(records)
    find(unversioned_action["actions"], "REVIEW-1")["description"] = "Perform a materially different action"
    changed_action = project({"ack_refs": ["ACK-1"]}, unversioned_action)
    actual["PHF-C06"] = {"alias_semantic_hash_preserved": alias["semantic_basis_hash"] == accepted["semantic_basis_hash"], "formatting_semantic_hash_preserved": formatting["semantic_basis_hash"] == accepted["semantic_basis_hash"], "formatting_payload_hash_changes": formatting["export_payload_hash"] != accepted["export_payload_hash"], "material_version_ack": fixture(10, "material-artifact")["ack_applicability"]["ACK-1"], "action_meaning_change_state": changed_action["next_action_state"], "changed_basis_export": changed_action["export_packet"]}

    equivalent = fixture(9, "equivalent-revision")
    partial = fixture(9, "partial-equivalence")
    mixed_proofs = project({"artifact_ref": "ART-equivalent", "basis_ref": "BASIS-EQUIVALENT", "proof_refs": ["PROOF-EQUIVALENT", "PROOF-PARTIAL"], "ack_refs": ["ACK-1"]})
    actual["PHF-C07"] = {"full_equivalence_readiness": equivalent["artifact_readiness"], "full_equivalence_ack": equivalent["ack_applicability"]["ACK-1"], "original_assessed_at": equivalent["assessed_at"]["R1"], "partial_equivalence_readiness": partial["artifact_readiness"], "partial_equivalence_ack": partial["ack_applicability"]["ACK-1"], "supported_partial_row": partial["requirement_states"]["R1"], "unsupported_partial_row": partial["requirement_states"]["R2"], "full_proof_wins_over_partial": mixed_proofs["ack_applicability"]["ACK-1"]}

    reopened = fixture(12, "reopened-episode")
    actual["PHF-C08"] = {"reassigned_owner_readiness": fixture(11, "owner-reassigned")["artifact_readiness"], "reassigned_owner_ack": fixture(11, "owner-reassigned")["ack_applicability"]["ACK-1"], "reassigned_recipient_ack": fixture(11, "recipient-reassigned")["ack_applicability"]["ACK-1"], "reopened_personal_progress": reopened["personal_progress"], "historical_personal_progress": reopened["historical_progress"], "reopened_ack": reopened["ack_applicability"]["ACK-1"]}

    informational = copy.deepcopy(records)
    info_blocker = {"blocker_id": "INFO-MACHINE", "revision": "1", "affected_step_id": "review-output", "scope": "downstream_execution", "state": "blocked"}
    find(informational["process_contexts"], "E-CLEAR")["blockers"].append(info_blocker)
    info_result = project({"ack_refs": ["ACK-1"]}, informational)
    requested = copy.deepcopy(records)
    request_blocker = {**info_blocker, "blocker_id": "REQUESTED-CONDITION", "scope": "requested_action"}
    find(requested["process_contexts"], "E-CLEAR")["blockers"].append(request_blocker)
    request_result = project(data=requested, rebind=True)
    stale_transfer = copy.deepcopy(records)
    find(stale_transfer["process_contexts"], "E-TRANSFER")["scope_state"] = "stale"
    stale_result = project({"process_context_ref": "E-TRANSFER", "basis_ref": "BASIS-TRANSFER"}, stale_transfer, rebind=True)
    actual["PHF-C09"] = {"blocked_downstream_artifact": fixture(6, "downstream-blocked")["artifact_readiness"], "blocked_downstream_transfer": fixture(6, "downstream-blocked")["transfer_status"], "informational_downstream_action": info_result["next_action_state"], "informational_downstream_ack": info_result["current_ack_state"], "informational_downstream_basis_preserved": info_result["semantic_basis_hash"] == accepted["semantic_basis_hash"], "requested_action_state": request_result["next_action_state"], "requested_action_changes_basis": request_result["semantic_basis_hash"] != baseline["semantic_basis_hash"], "stale_transfer_action": stale_result["next_action_state"], "stale_process_artifact": fixture(13, "stale-process-context")["artifact_readiness"]}

    stale_save = copy.deepcopy(scenarios["PHF-S14"]["save_cases"][0])
    current_save = copy.deepcopy(stale_save)
    current_save["expected_bases"] = copy.deepcopy(current_save["current_bases"])
    saved = model["apply_save"](current_save)
    replay = copy.deepcopy(current_save)
    replay["before"] = saved["current_record"]
    replay["receipts"] = [{"logical_operation_id": replay["logical_operation_id"], "desired_revision": replay["desired_revision"], "intent_fingerprint": replay["intent_fingerprint"]}]
    replayed = model["apply_save"](replay)
    collision = copy.deepcopy(replay)
    collision["intent_fingerprint"] = "DIFFERENT-SAVE-INTENT"
    actual["PHF-C10"] = {"stale_save_state": model["apply_save"](stale_save)["status"], "current_save_state": saved["status"], "current_save_effects": saved["new_effects"], "manual_note_preserved": saved["current_record"]["manual_note"], "replay_state": replayed["status"], "replay_new_effects": replayed["new_effects"], "changed_intent_state": model["apply_save"](collision)["status"]}

    contradictory_ack = copy.deepcopy(records)
    other_ack = copy.deepcopy(find(contradictory_ack["acknowledgments"], "ACK-1"))
    other_ack.update(id="ACK-CONTRADICTORY", ref="ACK-CONTRADICTORY", state="changes_requested", known_at="2026-11-05T21:00:00Z")
    contradictory_ack["acknowledgments"].append(other_ack)
    ack_conflict = project({"ack_refs": ["ACK-1", "ACK-CONTRADICTORY"]}, contradictory_ack)
    alias_ack = copy.deepcopy(records)
    alias_row = copy.deepcopy(find(alias_ack["acknowledgments"], "ACK-1"))
    alias_row["ref"] = "ACK-ALIAS"
    alias_ack["acknowledgments"].append(alias_row)
    alias_result = project({"ack_refs": ["ACK-1", "ACK-ALIAS"]}, alias_ack)
    recovery = copy.deepcopy(scenarios["PHF-S15"]["operation_cases"][1])
    recovery["operations"].append(copy.deepcopy(recovery["operations"][2]))
    recovered = model["project_operations"](recovery)
    conflicting_receipt = copy.deepcopy(recovery)
    conflicting_receipt["operations"][-1]["receipt"] = "DIFFERENT-RECEIPT"
    receipt_conflict = model["project_operations"](conflicting_receipt)
    actual["PHF-C11"] = {"contradictory_current_ack": ack_conflict["current_ack_state"], "alias_ack_state": alias_result["current_ack_state"], "alias_ack_count": alias_result["current_ack_count"], "late_old_ack_current_state": fixture(14, "late-old-ack")["current_ack_state"], "retracted_ack_current_state": fixture(14, "retracted")["current_ack_state"], "recovered_effect_count": recovered["supplied_confirmed_effects"], "recovered_reconciliation_count": recovered["reconciled_without_send"], "conflicting_receipt_ids": receipt_conflict["conflicting_operation_ids"], "delivery_creates_acknowledgments": recovered["acknowledgments_created"]}

    packet = accepted["export_packet"]
    roundtrip = json.loads(json.dumps(packet))
    payload_hash = hashlib.sha256(json.dumps(packet, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    actual["PHF-C12"] = {"output_kind": accepted["export_output_kind"], "artifact_locator": accepted["export_artifact_locator"], "roundtrip_exact": roundtrip == packet, "payload_hash_matches": payload_hash == accepted["export_payload_hash"], "frozen_artifact_version": packet["basis"]["payload"]["artifact"]["version"], "versioned_evidence_count": len(packet["evidence"]), "export_without_ack_state": fixture(8, "exported-only")["current_ack_state"], "actual_product_runs": accepted["actual_product_runs"], "actual_host_journeys": accepted["actual_host_journeys"], "provider_calls": accepted["provider_calls"]}

    checks = []

    def compare(observed, expected, path):
        if isinstance(expected, dict):
            for key, value in expected.items():
                if key not in observed:
                    checks.append({"id": path + "." + key, "passed": False, "detail": "Missing observed key"})
                else:
                    compare(observed[key], value, path + "." + key)
        else:
            checks.append({"id": path, "passed": observed == expected, "detail": {"expected": expected, "observed": observed}})

    for control in model["read"](root, "fixtures/contract_controls.json")["controls"]:
        compare(actual[control["id"]], control["expected"], "control." + control["id"])
    return checks
