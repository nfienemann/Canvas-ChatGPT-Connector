# Phase F synthetic handoff fixtures

The fixture set contains sixteen scenarios, twelve focused control groups and thirty-two supplied packet selections. Four native Markdown inputs describe a fictional coursework artifact, its revised and incomplete variants, and the supplied requirements and responsibility record.

## Run the local checks

From the extracted package root, run the following command with Python 3.11 or later.

```bash
python fixtures/validate_fixtures.py --negative-controls
```

`validate(package_root, verify_hashes=True)` and `negative_controls(package_root)` return lists of checks with `id`, `passed` and `detail`. The reference evaluator exposes `evaluate(package_root, scenario)` and `evaluate_case(package_root, case, records=None, policy=None)`. The control module exposes `run_controls(package_root)`.

The expected JSON contains independently authored state subsets. Its preparation generator never imports or calls the evaluator. The twelve semantic corruption controls disable manifest checks and require a named scenario failure, preserving separate credit for byte integrity and behavior.

## Supplied records

| File | Role |
| --- | --- |
| `records.json` | Immutable artifact versions, requirement sets, assessments, explicit responsibilities, one next action, packet bases, acknowledgment records, equivalence proofs and Phase E conditions |
| `scenarios.json` | Sixteen scenarios selecting supplied records, plus local save and optional delivery-operation observations |
| `expected.json` | Independently authored readiness, response applicability and transition expectations |
| `policy.json` | Readiness precedence, response states, dependency scope, knowledge cutoff and execution boundaries |
| `contract_controls.json` | Expected results for twelve focused boundary groups |
| `model_inputs/` | Four native Markdown inputs with exact content hashes and evidence line locators |

The local projection checks exact artifact identity, version, content hash, assignment, work episode, criterion binding and native evidence locator. Readiness judgments themselves come from the supplied synthetic assessment records. Actual source interpretation and current host behavior are implementation acceptance work.

## Independent state axes

Artifact readiness follows the inherited Phase B ordering of conflict, needs_work, unknown and ready. Required inventory completeness and criterion-local coverage remain explicit. A supported known finding retains its result while unrelated missing evidence stays localized.

The next action has an explicit owner, required input artifact and relevant criteria. An incomplete draft can support a review of its available written summary. A review action with no completion criteria still needs its declared input artifact. Personal done declarations retain their work episode and their original history.

Storage principal, responsible contributor, intended recipients, action owner, acknowledgment actor and acknowledgment recorder have separate fields. Responsibility requires the supplied assignment source reference. An authorship hint has no assignment effect. A relayed response can be recorded by the explicit storage principal while retaining the actual named respondent and its supplied response evidence.

The core export is a JSON payload with `output_kind` equal to `payload`, a reproducible payload hash and a null artifact locator. Saved state, payload availability, optional provider delivery and recipient acknowledgment each retain their own supplied observations.

## Semantic packet basis

The frozen basis includes the assignment, episode, requirement revision, artifact identity/version/content, responsibility revision, recipient population, action meaning, required inputs and governing process conditions. Display aliases and transport formatting keep their own fields.

A current selection that disagrees with its frozen basis returns `requires_rebase` and suppresses the inconsistent export payload. The production adapter maps this bounded state to the package's unknown state with the rebase reason. Compatible artifact assessments remain available independently.

Full Phase C equivalence can carry a supported assessment and applicable acknowledgment to the selected basis. The local proof case covers equal whole-body content across an artifact version change, with equivalent governing requirements and full relevant dependency coverage. It retains the original `assessed_at` and separately records proof time. Partial coverage supports its proven criterion while acknowledgment correspondence remains unresolved.

Material artifact or requirement changes, reassignment, a new episode and changed governing action conditions preserve earlier acknowledgments as historical. Contradictory current assessment records produce conflict. Contradictory independent current responses produce conflict unless an explicit supplied supersession resolves the applicable records.

## Recipient acknowledgment

The supplied response states are received, accepted_for_next_step and changes_requested. Applicability is current_exact, carried_equivalent, historical or unresolved. The knowledge cutoff excludes later observations. Explicit revisions, retractions and supersession govern response continuity. Arrival order alone does not choose between conflicting current responses.

An explicit group recipient snapshot has a per-member response view. One member's acknowledgment produces a partial group result. Acknowledgment gates the next action only when its actual declared prerequisite requires acceptance.

## Phase E conditions

Blockers bind to the affected step and one of transfer, requested_action or downstream_execution scope. A transfer or requested-action blocker governs the corresponding operation. Downstream conditions govern execution when that action requires process context. Informational downstream conditions remain visible while a separate review can proceed, and they retain their proper dependency scope.

Stale governing process observations produce unknown current action conditions. Artifact readiness keeps its own current evidence result. The fixture explicitly checks the requested_action scope alongside transfer and downstream execution.

## Local transitions and supplied recovery

The save projection compares expected and current bases, retains the student's unrelated manual note and deduplicates a matching logical request and intent fingerprint. A reused request identity with a different intent produces an operation conflict.

The optional delivery records exercise confirmed, outcome-unknown, duplicate and conflicting receipts. A recovered receipt can establish the existing effect under the same logical operation identity. These projections create zero acknowledgment records and perform zero provider calls.

## Bounded coverage

The evaluator projects one selected artifact and one supplied next action per packet. It supports an explicit small recipient population, complete and partial authored evidence, supplied revisions and a narrow full-body equivalence proof. It performs native Markdown byte and locator checks, payload roundtrips and in-memory transition arithmetic.

Implementation acceptance covers active raw-source adapters and model bindings, current durable process storage, real restarted retrieval, richer criterion-relevant equivalence, actual export payload responses, optional existing-provider effects and ordinary host conversations. Product runs, native host journeys, provider calls and confirmed provider effects are zero during specification preparation.

Five exact contract copies provide the narrow Phase B, Phase C and final Phase E reference context. `reference/provenance.json` names the source paths and hashes. The final E archive is `CanvasBridge_Phase_E_Resource_Lead_Time_Specs.zip`, with SHA256 `07395db2215214d78c6f7a657dd625f56f2ae4d481daa45fa8f63f42623a73a0`.

The frozen reference evaluator SHA256 is `2ea03b8a51e3eeaaec55aaa52c2570a9c62692d299c832939ea7d82f9ccb319b`. `evidence/fixture_validation.json` records the local run counts and individual checks. The root manifest also covers evaluator and control code.
