#!/usr/bin/env python3
"""Validate bounded Phase F records, expected projections and corruption controls."""

import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import sys
import tempfile


sys.dont_write_bytecode = True


def read(root, relative):
    return json.loads((Path(root) / relative).read_text(encoding='utf-8'))


def validate(root, verify_hashes=True):
    root = Path(root)
    checks = []

    def check(identifier, condition, detail):
        checks.append({'id': identifier, 'passed': bool(condition), 'detail': detail})

    def compare(actual, expected, path):
        if isinstance(expected, dict):
            if not isinstance(actual, dict):
                check(path, False, {'expected_type': 'object', 'observed': actual})
                return
            for key, value in expected.items():
                if key not in actual:
                    check(path + '.' + key, False, 'Missing expected output')
                else:
                    compare(actual[key], value, path + '.' + key)
        else:
            bool_type_matches = not isinstance(expected, bool) and not isinstance(actual, bool) or type(actual) is type(expected)
            check(path, actual == expected and bool_type_matches, {'expected': expected, 'observed': actual})

    scenarios = read(root, 'fixtures/scenarios.json')['scenarios']
    expected = read(root, 'fixtures/expected.json')['results']
    controls = read(root, 'fixtures/contract_controls.json')['controls']
    check('inventory.scenarios', [row['id'] for row in scenarios] == [f'PHF-S{number:02d}' for number in range(1, 17)], 'Sixteen agreed scenario identities')
    check('inventory.expected', set(expected) == {row['id'] for row in scenarios}, 'One authored expected result for every scenario')
    check('inventory.controls', [row['id'] for row in controls] == [f'PHF-C{number:02d}' for number in range(1, 13)], 'Twelve focused control groups')
    check('inventory.synthetic', all(row.get('synthetic') is True for row in scenarios), 'Every scenario is synthetic')
    records = read(root, 'fixtures/records.json')
    for collection in ['artifacts', 'requirements', 'responsibilities', 'actions', 'assessments', 'bases', 'acknowledgments', 'equivalence_proofs', 'process_contexts']:
        identifiers = [row.get('ref', row.get('id')) for row in records[collection]]
        check('inventory.' + collection, bool(identifiers) and all(identifiers) and len(identifiers) == len(set(identifiers)), 'Unique stable lookup references')
    policy = read(root, 'fixtures/policy.json')
    check('execution.boundaries', all(type(value) is int and value == 0 for value in policy['execution_counts'].values()), policy['execution_counts'])
    model = runpy.run_path(str(root / 'fixtures/reference_handoffs.py'))
    for scenario in scenarios:
        path = 'scenario.' + scenario['id']
        try:
            compare(model['evaluate'](root, scenario), expected[scenario['id']], path)
        except Exception as error:
            check(path + '.evaluation', False, type(error).__name__ + ' ' + str(error))
    try:
        checks.extend(runpy.run_path(str(root / 'fixtures/control_checks.py'))['run_controls'](root))
    except Exception as error:
        check('controls.evaluation', False, type(error).__name__ + ' ' + str(error))
    if verify_hashes:
        for record in read(root, 'fixtures/index.json')['files']:
            path = root / record['path']
            data = path.read_bytes() if path.is_file() else b''
            check('hash.' + record['path'], path.is_file() and len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], 'Exact fixture data bytes')
        for record in read(root, 'reference/provenance.json')['files']:
            path = root / record['path']
            data = path.read_bytes() if path.is_file() else b''
            check('reference.' + record['path'], path.is_file() and len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], 'Exact narrow B/C/E reference bytes')
    return checks


def negative_controls(root):
    """Corrupt supplied facts and require semantic detection with manifests disabled."""
    root = Path(root)

    def find(rows, identifier):
        return next(row for row in rows if row.get('ref', row.get('id')) == identifier)

    mutations = [
        ('criterion_outcome_changed', 'fixtures/records.json', lambda data: find(data['assessments'], 'AS-R2').update(status='needs_work'), 'scenario.PHF-S01'),
        ('inventory_incomplete', 'fixtures/records.json', lambda data: find(data['requirements'], 'REQ-v1').update(inventory_coverage='partial'), 'scenario.PHF-S01'),
        ('responsibility_source_removed', 'fixtures/records.json', lambda data: find(data['responsibilities'], 'RESP-1').update(source_ref=None), 'scenario.PHF-S01'),
        ('artifact_unavailable', 'fixtures/records.json', lambda data: find(data['artifacts'], 'ART-v1').update(availability='unavailable'), 'scenario.PHF-S01'),
        ('action_requires_response', 'fixtures/records.json', lambda data: find(data['actions'], 'REVIEW-1').update(requires_accepted_ack=True), 'scenario.PHF-S01'),
        ('response_actor_changed', 'fixtures/records.json', lambda data: find(data['acknowledgments'], 'ACK-1').update(acknowledged_by='SYNTHETIC-MEMBER-A'), 'scenario.PHF-S07'),
        ('response_source_removed', 'fixtures/records.json', lambda data: find(data['acknowledgments'], 'ACK-1').update(evidence_ref=None), 'scenario.PHF-S07'),
        ('response_after_cutoff', 'fixtures/records.json', lambda data: find(data['acknowledgments'], 'ACK-1').update(known_at='2026-11-06T22:00:00Z'), 'scenario.PHF-S07'),
        ('carry_extent_removed', 'fixtures/records.json', lambda data: find(data['equivalence_proofs'], 'PROOF-EQUIVALENT').update(covered_dependencies=[]), 'scenario.PHF-S09'),
        ('response_retraction_removed', 'fixtures/records.json', lambda data: find(data['acknowledgments'], 'ACK-RETRACT-v2').update(retracted=False), 'scenario.PHF-S14'),
        ('stale_save_erased', 'fixtures/scenarios.json', lambda data: find(data['scenarios'], 'PHF-S14')['save_cases'][0].update(current_bases={'packet': '3', 'responsibility': '1'}), 'scenario.PHF-S14'),
        ('unconfirmed_delivery_promoted', 'fixtures/scenarios.json', lambda data: find(data['scenarios'], 'PHF-S15')['operation_cases'][0]['operations'][2].update(status='confirmed', receipt='CORRUPTED-CONFIRMATION'), 'scenario.PHF-S15')
    ]
    checks = []
    for identifier, relative, mutate, target in mutations:
        with tempfile.TemporaryDirectory(prefix='phase-f-negative-') as temporary:
            copied = Path(temporary)
            shutil.copytree(root / 'fixtures', copied / 'fixtures')
            shutil.copytree(root / 'reference', copied / 'reference')
            path = copied / relative
            data = json.loads(path.read_text(encoding='utf-8'))
            mutate(data)
            path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
            detected = [row['id'] for row in validate(copied, verify_hashes=False) if not row['passed'] and row['id'].startswith(target)]
            checks.append({'id': 'negative.' + identifier, 'passed': bool(detected), 'detail': {'target_prefix': target, 'detected_by': detected[:5], 'checksum_credit': False}})
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', nargs='?', default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument('--negative-controls', action='store_true')
    parser.add_argument('--output')
    args = parser.parse_args()
    checks = validate(args.root)
    negatives = negative_controls(args.root) if args.negative_controls else []
    report = {
        'schema_version': 'phase-f-fixture-validation.v1',
        'scope': 'Local bounded synthetic handoff record projection',
        'check_count': len(checks), 'passed_count': sum(row['passed'] for row in checks),
        'negative_control_count': len(negatives), 'negative_control_passed_count': sum(row['passed'] for row in negatives),
        'checks': checks, 'negative_controls': negatives,
        'actual_product_runs': 0, 'actual_host_journeys': 0, 'provider_calls': 0, 'confirmed_provider_effects': 0
    }
    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in report.items() if key not in {'checks', 'negative_controls'}}, indent=2))
    for item in checks + negatives:
        if not item['passed']:
            print(json.dumps(item))
    return 0 if all(row['passed'] for row in checks + negatives) else 1


if __name__ == '__main__':
    raise SystemExit(main())
