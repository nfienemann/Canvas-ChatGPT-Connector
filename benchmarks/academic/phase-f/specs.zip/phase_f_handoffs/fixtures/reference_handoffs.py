#!/usr/bin/env python3
"""Bounded projection of supplied artifact-grounded handoff records."""

import copy
from datetime import datetime
import hashlib
import json
from pathlib import Path


def read(root, relative):
    return json.loads((Path(root) / relative).read_text(encoding="utf-8"))


def index(rows):
    return {row.get("ref", row.get("id")): row for row in rows}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def artifact_binding(artifact):
    return {"artifact_id": artifact["artifact_id"], "version": artifact["version"], "content_hash": artifact["content"]["sha256"], "scope_locator": artifact["scope_locator"]}


def semantic_payload(selection, records):
    requirement = index(records["requirements"])[selection["requirement_ref"]]
    artifact = index(records["artifacts"])[selection["artifact_ref"]]
    responsibility = index(records["responsibilities"])[selection["responsibility_ref"]]
    action = index(records["actions"])[selection["action_ref"]]
    process = index(records["process_contexts"])[selection["process_context_ref"]]
    conditions = [{key: row[key] for key in ["blocker_id", "revision", "affected_step_id", "scope", "state"]} for row in process["blockers"] if row["affected_step_id"] == action["step_id"] and (row["scope"] in {"transfer", "requested_action"} or action["requires_process_context"])]
    if process["scope_state"] != "current" and (action["requires_process_context"] or conditions):
        conditions.append({"process_context_state": process["scope_state"], "step_id": action["step_id"]})
    return {
        "assignment_id": selection["assignment_id"], "episode_id": selection["episode_id"],
        "requirements": {"id": requirement["id"], "revision": requirement["revision"]},
        "artifact": artifact_binding(artifact),
        "responsibility": {key: responsibility[key] for key in ["id", "revision", "responsible_actor", "recipient_ids"]},
        "action": {key: action[key] for key in ["id", "revision", "owner_id", "description", "requirement_ids", "step_id", "requires_process_context", "requires_accepted_ack", "evidence_basis", "required_input_artifact_ids"]},
        "conditions": conditions,
    }


def proof_applies(proof, before, after, dependencies):
    if not proof["equivalent"] or not set(dependencies).issubset(proof["covered_dependencies"]):
        return False
    # The compact fixture proves a whole-body artifact version change with equal
    # bytes and equivalent governing premises. Other comparisons need active C.
    if before["artifact"]["content_hash"] != after["artifact"]["content_hash"]:
        return False
    if any(before[key] != after[key] for key in ["assignment_id", "episode_id", "requirements"]):
        return False
    if before["artifact"]["artifact_id"] != after["artifact"]["artifact_id"] or before["artifact"]["scope_locator"] != after["artifact"]["scope_locator"]:
        return False
    if "responsibility" in dependencies and before["responsibility"] != after["responsibility"]:
        return False
    if "action" in dependencies and before["action"] != after["action"]:
        return False
    if "conditions" in dependencies and before["conditions"] != after["conditions"]:
        return False
    return True


def evidence_valid(root, artifact, assessment, availability):
    if availability != "available" or assessment["coverage"] != "complete":
        return False
    path = Path(root) / artifact["content"]["path"]
    if not path.is_file():
        return False
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != artifact["content"]["sha256"]:
        return False
    evidence = assessment["evidence"]
    lines = data.decode("utf-8").splitlines()
    first, last = evidence["line_start"], evidence["line_end"]
    if not (1 <= first <= last <= len(lines)) or evidence["scope_locator"] != artifact["scope_locator"]:
        return False
    return "\n".join(lines[first - 1:last]) == evidence["excerpt"]


def readiness(root, selection, records, payload):
    requirement = index(records["requirements"])[selection["requirement_ref"]]
    artifact = index(records["artifacts"])[selection["artifact_ref"]]
    assessments = index(records["assessments"])
    bases, proofs = index(records["bases"]), index(records["equivalence_proofs"])
    states, evidence, carried, assessed_at, reasons = {}, [], [], {}, {}
    required_states, unknown_applicability = [], False
    available = selection.get("artifact_availability", artifact["availability"])
    scope_matches = requirement["assignment_id"] == artifact["assignment_id"] == selection["assignment_id"]
    for criterion in requirement["rows"]:
        status, reason, selected = "unknown", "assessment_missing", None
        candidates = {assessments[name]["id"]: assessments[name] for name in selection["assessment_refs"] if assessments[name]["requirement_id"] == criterion["id"]}
        valid_assessments = []
        for assessment in candidates.values():
            direct = assessment["assignment_id"] == selection["assignment_id"] and assessment["episode_id"] == selection["episode_id"] and assessment["requirement_ref"] == selection["requirement_ref"] and assessment["artifact_binding"] == payload["artifact"]
            carried_here = False
            if not direct:
                for proof_id in selection["proof_refs"]:
                    proof = proofs[proof_id]
                    before, after = bases[proof["from_basis_ref"]]["payload"], bases[proof["to_basis_ref"]]["payload"]
                    dependencies = ["assignment", "episode", "requirement:" + criterion["id"], "artifact:body"]
                    from_requirement = index(records["requirements"])[assessment["requirement_ref"]]
                    before_match = before["artifact"] == assessment["artifact_binding"] and before["assignment_id"] == assessment["assignment_id"] and before["episode_id"] == assessment["episode_id"] and before["requirements"] == {"id": from_requirement["id"], "revision": from_requirement["revision"]}
                    if assessment["id"] in proof["assessment_refs"] and before_match and after == payload and proof_applies(proof, before, after, dependencies):
                        carried_here = True
            if scope_matches and (direct or carried_here) and evidence_valid(root, artifact, assessment, available):
                selected = assessment
                status, reason = assessment["status"], "current_evidence" if direct else "equivalent_dependency_proof"
                if carried_here:
                    carried.append(assessment["id"])
                valid_assessments.append(assessment)
            elif not valid_assessments:
                reason = "unavailable_or_unmatched_evidence"
        if len({row["status"] for row in valid_assessments}) > 1:
            status, reason = "conflict", "conflicting_current_assessments"
        if criterion["applicability"] == "unknown":
            status, reason = "unknown", "unknown_applicability"
            unknown_applicability |= criterion["required"]
        elif criterion["applicability"] == "not_applicable":
            supported = bool(criterion.get("applicability_basis"))
            status, reason = ("not_applicable", "supported_exclusion") if supported else ("unknown", "unsupported_exclusion")
            unknown_applicability |= criterion["required"] and not supported
        if criterion["required"] and criterion["applicability"] == "applicable":
            required_states.append(status)
        states[criterion["id"]], reasons[criterion["id"]] = status, reason
        if selected is not None and status not in {"unknown", "not_applicable"}:
            times = sorted({row["assessed_at"] for row in valid_assessments})
            assessed_at[criterion["id"]] = times[0] if len(times) == 1 else times
            for assessed in valid_assessments:
                evidence.append({"requirement_id": criterion["id"], "assessment_id": assessed["id"], "artifact_id": artifact["artifact_id"], "artifact_version": artifact["version"], "content_hash": artifact["content"]["sha256"], "path": artifact["content"]["path"], **assessed["evidence"]})
    inventory = selection.get("inventory_coverage", requirement["inventory_coverage"])
    if "conflict" in required_states:
        aggregate = "conflict"
    elif "needs_work" in required_states:
        aggregate = "needs_work"
    elif "unknown" in required_states or unknown_applicability or inventory != "complete" or not requirement["rows"]:
        aggregate = "unknown"
    else:
        aggregate = "ready"
    return {"artifact_readiness": aggregate, "requirement_states": states, "requirement_reasons": reasons, "evidence": evidence, "evidence_count": len(evidence), "carried_assessment_ids": sorted(set(carried)), "assessed_at": assessed_at}


def acknowledgments(selection, records, payload, basis_consistent, policy):
    registry = index(records["acknowledgments"])
    bases, proofs = index(records["bases"]), index(records["equivalence_proofs"])
    selected = [registry[name] for name in selection["ack_refs"] if datetime.fromisoformat(registry[name]["known_at"].replace("Z", "+00:00")) <= datetime.fromisoformat(policy["knowledge_cutoff"].replace("Z", "+00:00"))]
    by_identity, collisions = {}, set()
    for row in selected:
        key = (row["id"], row["revision"])
        semantic_row = {key: value for key, value in row.items() if key != "ref"}
        previous = {field: value for field, value in by_identity.get(key, {}).items() if field != "ref"}
        if key in by_identity and canonical(previous) != canonical(semantic_row):
            collisions.add(row["id"])
        by_identity[key] = row
    latest = {}
    for row in by_identity.values():
        if row["id"] not in latest or row["revision"] > latest[row["id"]]["revision"]:
            latest[row["id"]] = row
    applicability, retracted, current = {}, [], []
    for identifier, row in latest.items():
        if row["retracted"]:
            retracted.append(identifier)
            applicability[identifier] = "historical"
            continue
        before = bases[row["basis_ref"]]["payload"]
        actor_supported = row["acknowledged_by"] in before["responsibility"]["recipient_ids"] and row["recorded_by"] in records["members"] + [selection["storage_principal"]] and bool(row["evidence_ref"]) and row["evidence_basis"] in policy["ack_evidence_bases"]
        if identifier in collisions or not basis_consistent or not actor_supported or row["state"] not in policy["ack_states"]:
            applicability[identifier] = "unresolved"
            continue
        state = "current_exact" if before == payload else "historical"
        if state == "historical":
            for proof_id in selection["proof_refs"]:
                proof = proofs[proof_id]
                if proof["from_basis_ref"] == row["basis_ref"] and bases[proof["to_basis_ref"]]["payload"] == payload and proof["equivalent"]:
                    state = "carried_equivalent" if proof_applies(proof, before, payload, policy["semantic_dependency_keys"]) else "unresolved"
                    if state == "carried_equivalent":
                        break
        applicability[identifier] = state
        if state in {"current_exact", "carried_equivalent"}:
            current.append(row)
    members = payload["responsibility"]["recipient_ids"]
    by_member = {member: "none" for member in members}
    current_rows, conflicts = {}, {}
    for member in members:
        responses = [row for row in current if row["acknowledged_by"] == member]
        superseded = {row["supersedes_ack_id"] for row in responses if row.get("supersedes_ack_id")}
        responses = [row for row in responses if row["id"] not in superseded]
        if len({row["state"] for row in responses}) > 1:
            by_member[member] = "conflict"
            conflicts[member] = sorted(row["id"] for row in responses)
        elif responses:
            chosen = min(responses, key=lambda value: value["id"])
            by_member[member] = chosen["state"]
            current_rows[member] = chosen
    states = set(by_member.values())
    aggregate = "conflict" if "conflict" in states else (next(iter(states)) if len(states) == 1 else ("partial" if states else "none"))
    return {"current_ack_state": aggregate, "ack_by_member": by_member, "ack_applicability": applicability, "current_ack_count": len(current_rows), "current_ack_provenance": list(current_rows.values()), "ack_conflicts": conflicts, "retracted_ack_ids": sorted(retracted), "historical_ack_ids": sorted(key for key, value in applicability.items() if value == "historical")}


def blocker_status(rows):
    states = {row["state"] for row in rows}
    for state in ["blocked", "unknown", "conditional"]:
        if state in states:
            return state
    return "ready"


def evaluate_case(root, case, records=None, policy=None):
    records = records or read(root, "fixtures/records.json")
    policy = policy or read(root, "fixtures/policy.json")
    selection = {**copy.deepcopy(records["base_selection"]), **copy.deepcopy(case.get("selection", {}))}
    payload = semantic_payload(selection, records)
    basis = index(records["bases"])[selection["basis_ref"]]
    basis_consistent = payload == basis["payload"]
    view = readiness(root, selection, records, payload)
    ack = acknowledgments(selection, records, payload, basis_consistent, policy)
    responsibility = index(records["responsibilities"])[selection["responsibility_ref"]]
    action = index(records["actions"])[selection["action_ref"]]
    process = index(records["process_contexts"])[selection["process_context_ref"]]
    relevant = [row for row in process["blockers"] if row["affected_step_id"] == action["step_id"]]
    transfer = blocker_status([row for row in relevant if row["scope"] == "transfer"])
    requested_action = blocker_status([row for row in relevant if row["scope"] == "requested_action"])
    downstream = blocker_status([row for row in relevant if row["scope"] == "downstream_execution"])
    if process["scope_state"] != "current":
        if action["requires_process_context"] or any(row["scope"] == "downstream_execution" for row in relevant):
            downstream = "unknown"
        if any(row["scope"] == "transfer" for row in relevant):
            transfer = "unknown"
        if any(row["scope"] == "requested_action" for row in relevant):
            requested_action = "unknown"
    action_states = [view["requirement_states"].get(identifier, "unknown") for identifier in action["requirement_ids"]]
    identity_valid = responsibility["identity_state"] == "explicit" and bool(responsibility["source_ref"]) and responsibility["responsible_actor"] in records["members"] and bool(responsibility["recipient_ids"]) and all(member in records["members"] for member in responsibility["recipient_ids"]) and action["owner_id"] in records["members"] and responsibility["assignment_id"] == selection["assignment_id"]
    artifact = index(records["artifacts"])[selection["artifact_ref"]]
    input_path = Path(root) / artifact["content"]["path"]
    input_available = action["required_input_artifact_ids"] == [artifact["artifact_id"]] and selection.get("artifact_availability", artifact["availability"]) == "available" and input_path.is_file() and hashlib.sha256(input_path.read_bytes()).hexdigest() == artifact["content"]["sha256"]
    governing_downstream = downstream if action["requires_process_context"] else "ready"
    if not identity_valid:
        action_state = "needs_identity"
    elif not basis_consistent:
        action_state = "requires_rebase"
    elif "blocked" in {transfer, requested_action, governing_downstream}:
        action_state = "blocked"
    elif "conflict" in action_states:
        action_state = "conflict"
    elif "needs_work" in action_states:
        action_state = "needs_work"
    elif not input_available or "unknown" in action_states or "unknown" in {transfer, requested_action, governing_downstream} or not set(action["requirement_ids"]).issubset(action["evidence_basis"]):
        action_state = "unknown"
    elif "conditional" in {transfer, requested_action, governing_downstream}:
        action_state = "conditional"
    elif action["requires_accepted_ack"] and ack["current_ack_state"] != "accepted_for_next_step":
        action_state = "waiting_ack"
    else:
        action_state = "ready"
    progress = selection["personal_progress"]
    current_progress = progress["state"] if progress["episode_id"] == selection["episode_id"] else "unset"
    result = {
        **view, **ack, "basis_id": basis["id"], "basis_consistent": basis_consistent,
        "semantic_basis_hash": hashlib.sha256(canonical(payload).encode()).hexdigest(),
        "storage_principal": selection["storage_principal"], "responsible_actor": responsibility["responsible_actor"],
        "recipient_ids": responsibility["recipient_ids"], "action_owner": action["owner_id"], "next_action": action["description"],
        "next_action_state": action_state, "transfer_status": transfer, "requested_action_status": requested_action, "downstream_execution_status": downstream,
        "relevant_blocker_ids": [row["blocker_id"] for row in relevant],
        "personal_progress": current_progress, "historical_progress": progress["state"] if current_progress == "unset" else None,
        "local_packet_state": selection["local_packet_state"], "export_state": selection["export_state"] if basis_consistent else "requires_rebase", "delivery_state": selection["delivery_state"],
        "actual_product_runs": 0, "actual_host_journeys": 0, "provider_calls": 0,
    }
    result["export_packet"] = {"schema_version": "phase-f-bounded-export.v1", "basis": copy.deepcopy(basis), "semantic_basis_hash": result["semantic_basis_hash"], "transport_revision": selection["transport_revision"], "artifact_readiness": result["artifact_readiness"], "evidence": copy.deepcopy(result["evidence"]), "next_action": {"id": action["id"], "owner_id": action["owner_id"], "description": action["description"], "state": action_state}, "responsibility": copy.deepcopy(payload["responsibility"]), "acknowledgment_state": ack["current_ack_state"], "delivery_state": result["delivery_state"]}
    if not basis_consistent:
        result["export_packet"] = None
    result["export_output_kind"] = "payload"
    result["export_payload_hash"] = hashlib.sha256(canonical(result["export_packet"]).encode()).hexdigest() if basis_consistent else None
    result["export_artifact_locator"] = None
    return result


def apply_save(row):
    before = copy.deepcopy(row["before"])
    for receipt in row["receipts"]:
        if receipt["logical_operation_id"] == row["logical_operation_id"]:
            same_intent = receipt["desired_revision"] == row["desired_revision"] and receipt["intent_fingerprint"] == row["intent_fingerprint"]
            return {"status": "replayed" if same_intent else "operation_conflict", "current_record": before, "changed_axes": [], "new_effects": 0}
    changed = sorted(key for key, value in row["expected_bases"].items() if row["current_bases"].get(key) != value)
    if changed:
        return {"status": "stale_base", "changed_axes": changed, "new_effects": 0, "current_record": before}
    before["packet_revision"] = row["desired_revision"]
    return {"status": "saved", "changed_axes": [], "new_effects": 1, "current_record": before}


def project_operations(row):
    grouped = {}
    conflicts = set()
    for operation in row["operations"]:
        previous = grouped.get(operation["id"])
        if previous and (previous["kind"] != operation["kind"] or (previous["status"] == operation["status"] == "confirmed" and previous.get("receipt") != operation.get("receipt"))):
            conflicts.add(operation["id"])
        if previous is None or operation["status"] == "confirmed":
            grouped[operation["id"]] = operation
    confirmed = [value for value in grouped.values() if value["status"] == "confirmed" and value.get("receipt") and value["id"] not in conflicts]
    unresolved = [value for value in grouped.values() if value not in confirmed]
    delivery = [value for value in grouped.values() if value["kind"] == "existing_provider_delivery"]
    delivery_status = "not_requested" if not delivery else ("confirmed" if all(value in confirmed for value in delivery) else "outcome_unknown")
    return {"local_saved": any(value["kind"] == "local_save" for value in confirmed), "export_available": any(value["kind"] == "local_export" for value in confirmed), "delivery_status": delivery_status, "unresolved_operation_ids": sorted(value["id"] for value in unresolved), "conflicting_operation_ids": sorted(conflicts), "supplied_confirmed_effects": len(confirmed), "reconciled_without_send": sum(value.get("reconciled_existing", False) for value in confirmed), "acknowledgments_created": 0, "actual_provider_calls": 0}


def evaluate(root, scenario):
    records = read(root, "fixtures/records.json")
    policy = read(root, "fixtures/policy.json")
    result = {}
    if scenario.get("cases"):
        result["case_results"] = {case["id"]: evaluate_case(root, case, records, policy) for case in scenario["cases"]}
    if scenario.get("save_cases"):
        result["save_results"] = {row["id"]: apply_save(row) for row in scenario["save_cases"]}
    if scenario.get("operation_cases"):
        result["operation_results"] = {row["id"]: project_operations(row) for row in scenario["operation_cases"]}
    return result
