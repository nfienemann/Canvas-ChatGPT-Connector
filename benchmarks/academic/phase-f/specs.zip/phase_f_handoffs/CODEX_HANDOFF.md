# Phase F implementation handoff

Implement the five PHF specifications against the active completed A–E build and Stage 6 observations. The user has accepted Stage 5 as complete. Existing source, owned-state, intent and supported external actions supply the operating baseline.

## 1. Bind the active implementation

Read repository instructions and capture branch, commit, dirty diff fingerprint, runtime, actual tool schemas and host in `templates/active_build_bindings.json`. Resolve the pinned source map to the active B/C evidence and work records, E process handoff and durable process store.

Inspect closed academic, request and graph types before adding a compatible typed extension. Existing external entity kinds cover courses, assignments and documents. Use a scoped member identity type or the current equivalent. Current `StudentEntry.author` retains its self-authored discussion meaning.

Use B/C logical artifact identity and alias correspondence when an import produces a new document ID for the same content. Bind current exact-version assessment through the active B/C interface. Current in-memory evidence sessions supply their available observations, while durable packet history uses the owned process store.

## 2. Bind responsibility and the packet subject

Implement `PHF-01` with explicit participant identity, source-backed assignment/declaration and a concrete requested action. Keep storage principal, responsible contributor, intended recipient, acknowledging actor and recorder distinct.

Create immutable exact packet snapshots with a semantic basis and separate transport revision. Bind current episode, selected requirement inventory, artifact/version/fingerprint, responsibility assignment, recipient set, requested action and relevant E conditions. Preserve source coverage and unresolved identity or content locally.

## 3. Produce an action-specific handoff

Implement `PHF-02` using `contracts/handoff_readiness_policy.json`.

Reuse B criterion precedence and complete selected inventory. Evaluate the requested action's explicit prerequisites independently. An accessible incomplete draft can support review, while integration can require named satisfied criteria and current inputs.

Show exact artifact links and locators, current criterion gaps, responsible person, recipient, next action, expected output and relevant timing. Apply E conditions according to their transfer, requested-action or downstream scope.

Record responses with their actual actor, recorder, evidence basis and exact original packet subject. Acknowledgment is optional unless an explicit current action prerequisite requires it. Preserve per-member results for a supplied recipient set.

## 4. Reconcile changes and responses

Implement `PHF-03` through current C correspondence and work reconciliation. Equivalent carry-forward covers the complete relevant dependency extent, preserving original assessed_at and response times with separate validation evidence.

Derive response applicability as current_exact, carried_equivalent, historical or unresolved. Carry requires unchanged responsibility, recipient, action and episode. Reassignment preserves unchanged artifact assessment while recomputing ownership and response applicability. Recurring obligations follow current C episode rules.

Deduplicate logical observations, apply valid correction/retraction revisions at the knowledge cutoff, and retain late old-basis responses historically. Conflicting evidence stays attributable. Use current expected bases and preserve later user edits when rebasing an affected proposal.

## 5. Save, export and recover

Implement `PHF-04` through existing durable state and operations. The core path is a saved packet plus current JSON/Markdown payload export and supplied response evidence.

The pinned `export_academic_process_records` returns payload content. Record `output_kind`, exact content hash and response/record reference. When a downloadable artifact is requested, use the active host/artifact adapter and capture its actual file identity, checksum, locator and receipt.

Existing external delivery uses the current supported adapter, recipient resolution and user intent. Record actual local/export/delivery effects independently from readiness and acknowledgment. Preserve partial success and uncertain outcomes.

Recover via stable operation identity and current receipt/owned-output lookup. Recheck state before retry or compensation, and preserve unrelated later work. Supersession retires obsolete intent while uncertain earlier effects retain their reconciliation identity.

## 6. Execute acceptance and close A–F

Run package, fixture and deliberate-corruption checks, then all 28 cases against the current implementation. Use actual current adapters, durable restart and supported-host journeys. Retain exact requests, responses, artifact/assessment records, packet snapshots, before/after state, operation receipts and final answers.

Fill the eight measures with actual populations and denominators. Review all applicable host checks. Run focused existing process/evidence/state/source/export tests and relevant A–E and Stage 6 acceptance. Record failed, blocked and pending work with its actual cause.

Execute the end-to-end journey in `contracts/roadmap_integration_contract.json`. Trace one current assignment through actual A–E outputs into F, then apply a relevant change and retrieve the reconciled current packet with historical responses intact.

Deliver the minimal implementation diff, active bindings, completed implementation report, reproducible commands, retained captures and a usable final handoff example.

## Queue order

This archive is the final F work item in A → B → C → D → E → F. Start with the completed Phase E report and bind its actual handoff interface. The five PHF specifications run in their listed dependency order.
