# Phase D synthetic forecast and schedule fixtures

The fixture set contains sixteen independently authored scenarios and twelve supplemental control groups. Recorded coursework history, work declarations, estimate baselines, calendar inputs and provider outcomes are synthetic. Actual product, host and calendar-provider execution counts are zero.

## Run the local checks

Use Python 3.11 or later with an IANA timezone database available to the standard-library `zoneinfo` module. The runtime must resolve `America/New_York`. The calculations use exact rational arithmetic and explicit timezone offsets.

```bash
python /path/to/phase_d_forecasting/fixtures/validate_fixtures.py --negative-controls
```

`validate(root)` returns local check records. `negative_controls(root)` verifies that deliberate changes are detected through semantic checks with hash checking disabled for those mutations.

## Scenario coverage

| Scenarios | Input and expected behavior |
| --- | --- |
| PHD-S01–S04 | Cold start, compatible history, sparse or incomplete measurements, explicit zero, corrections and interval union. |
| PHD-S05–S08 | Remaining-work scope, reopened episodes, issue-time history, future evaluation and scoped overrides. |
| PHD-S09–S12 | Stable refresh, additional work, earlier deadlines and newly observed busy intervals. |
| PHD-S13–S16 | Episode-aware calendar identity, capacity shortfall, the daylight-saving fold and partial provider recovery. |

## Forecast policy

The declared cohort uses student, task family, scope kind and baseline-policy identity. Each training unit has complete observed actual work and a positive frozen uncalibrated baseline point. Canonical pairing, duplicate removal and overlapping-scope grouping precede selection of the twenty most recent independent units. Final selection orders completion time descending and stable training-unit identity ascending.

The factor is `(3 + n × median(actual / baseline point)) / (3 + n)`, with one for empty history. The factor scales the original baseline once. For active positive work, publication floors the lower endpoint with a minimum of one, rounds the upper endpoint upward, and rounds a defined point half-up within that finalized range. Exact fractions remain visible. The default planning budget is the upper endpoint. A range-only current estimate retains a null point. An unknown estimate retains unknown demand. Completed or explicitly zero-remaining work has zero active demand.

Current scoped user estimates control effective publication. History support, the model suggestion and the user's choice remain individually attributable. Later corrections support newly issued forecasts and labeled restatements. The prospective control preserves the earlier issue-time population.

## Candidate schedule policy

The evaluator scores the supplied bounded candidate sets. It checks current task and episode identity, availability, busy intervals, deadlines, single-student nonoverlap and protected block values. Valid candidates are compared by prioritized unmet minutes, unique changed base blocks, absolute start displacement, matched-retained duration change and a stable key. Added and removed block IDs have separate counts.

The fixture binds the `end_only_per_supplied_availability_window` policy. A configured buffer trims each supplied window's end once. Interblock breaks have their own parameter. Started blocks retain their full logical/provider interval while only the future remainder supplies current remaining-work capacity.

Capacity certificates carry their source coverage and numerical bound. A bounded candidate failure retains `no_feasible_schedule_found` when a broader infeasibility result has not been established. Provider controls distinguish local plan intent, individually confirmed changes, unresolved operations and a fully confirmed calendar projection.

## Files and execution scope

- `history.json` contains nineteen frozen history examples with explicit observation revisions and knowledge times.
- `schedules.json` contains eight constraint packets and bounded candidate sets.
- `scenarios.json` selects the source scopes and test-authored operations for each scenario.
- `policy.json` freezes the reference policy choices and ordering.
- `expected.json` contains independently authored numerical and transition expectations.
- `contract_controls.json` describes the twelve focused boundary groups.
- `model_inputs/` supplies concise student-facing source descriptions for native journeys.
- `reference_forecasting.py` evaluates the authored observations and candidate sets.
- `control_checks.py` exercises the additional boundary cases.
- `index.json` records exact fixture-data hashes. The root checksum manifest covers code as well.

Native journeys use selected source histories, current work and calendar constraints through the active product adapters. The current planner generates its own candidates in those journeys. The bounded candidate arrays support deterministic adapter acceptance. Evaluators compare captured product and host results with the supplied expectations after execution.

The six exact reference files preserve Phase C work-episode semantics and Stage 6 actual/forecast evaluation definitions. Their original hashes and source paths are in `reference/provenance.json`.

## Logical field mapping

| Fixture field | Logical contract field |
| --- | --- |
| `user_id` | `student_scope` |
| `episode_id` | `work_episode_id` |
| `scope_id` | Declared actual or remaining-work scope |
| `baseline_policy` | `baseline_policy_version` |
| `history_support` | Support of the selected personal history |
| `support` | Effective forecast support, including current override or unknown baseline |
| `block_id` | `logical_block_id` |
| `provider_revision` | Observed provider revision |
| `duration_total` | Explicit recorded actual-duration basis |
| `active_interval` | Explicit active-interval basis |

Unknown observation coverage can retain the reason `actual_measurement_unavailable`. Forecast, calendar and source-level reasons retain their specific scope. Production binding records actual wire fields and schema versions before feature acceptance.
