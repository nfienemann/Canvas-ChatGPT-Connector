# Synthetic student work history

The work records belong to SYNTHETIC-STUDENT-D. The reading examples H-R1, H-R2 and H-R3 each began with a frozen uncalibrated point estimate of 40 minutes. Their recorded completed active work was 40, 50 and 60 minutes. H-R2 also retains a previously personalized published point of 44 minutes. The original baseline remains available in its forecast record.

Additional records describe partial coverage, unfinished work, unavailable measurements, a range without a point, an explicit zero, a corrected duration, overlapping active sessions and a zero baseline. Each record retains its own source identity, work interval, completion declaration, coverage and knowledge times in `fixtures/history.json`.

For H-REMAINING, the student recorded 30 minutes before the remaining-work forecast. The explicitly measured remaining scope took another 50 minutes. The earlier session keeps its original scope.

H-PRIOR-EPISODE records 30 minutes and a done declaration for BL-WORK-PA-R01/E1. The current reopened obligation is BL-WORK-PA-R01/E2 with system-default open progress. The current episode has no actual-duration observation yet.

H-ASOF includes an initial duration and a later correction. H-FUTURE completes after the forecast cutoff. Other examples belong to a different student, task family, scope kind or baseline policy. Use the exact selected records and timestamps from the scenario's history IDs.
