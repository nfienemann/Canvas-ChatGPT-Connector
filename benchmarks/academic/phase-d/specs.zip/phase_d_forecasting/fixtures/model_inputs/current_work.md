# Synthetic current work and estimate sources

The default current reading scope has a content-grounded baseline range of 40–60 minutes and an explicit point of 50 minutes. Its issue-time information cutoff is November 5, 2026 at 12:00 UTC.

The remaining-work example has a separately supplied current range of 20–30 minutes with point 25. Its prior recorded effort remains associated with the earlier measured scope.

The reopened presentation-remediation example uses the current E2 work episode inherited from Phase C. Historical completion and actuals identify E1. Current progress is open with system-default provenance and no user declaration ID.

The manual-override example includes the student's explicit current range of 55–75 minutes and point 65 for the named scope and episode. The source contains the override ID and knowledge time.

`fixtures/scenarios.json` identifies each current forecast, episode, remaining scope and source selection. The product records its actual issue-time baseline, chosen training population, policy version, model suggestion and effective user choice.
