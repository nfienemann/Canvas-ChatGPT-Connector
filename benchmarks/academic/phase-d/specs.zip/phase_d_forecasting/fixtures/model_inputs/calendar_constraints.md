# Synthetic weekly calendar constraints

The standard planning window is Monday, November 9, 2026 in America/New_York. Current task demand and deadline values are supplied in the selected constraint packet. Existing study blocks have stable logical IDs and provider-event IDs.

The cases cover additional work, an earlier deadline, a newly observed busy interval, a reopened episode and insufficient time. A locked or protected student-edited block carries its existing source values. Current independent commitments appear in the busy-event inventory.

The daylight-saving case uses November 1, 2026. Availability begins at 00:30 with offset −04:00 and ends at 02:30 with offset −05:00. A busy event occupies 01:15–01:45 in the first occurrence of the repeated hour. Every timestamp includes its offset so the actual elapsed interval is explicit.

The recovery case starts with plan revision 10 and named provider revisions. A stale proposal is followed by a rebase, an individually confirmed move and an uncertain create response. The test harness supplies the observation sequence for integration acceptance. The source packets preserve the student's edited reading-block title and note.

For a native planning journey, project the tasks, availability, busy events, existing blocks and relevant policy fields from `fixtures/schedules.json`. Capture the actual planner candidates and resulting provider observations with their source and revision identities.
