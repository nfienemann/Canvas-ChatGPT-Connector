#!/usr/bin/env python3
"""Evaluate bounded synthetic effort, forecast and candidate-plan records."""

import copy
import json
from datetime import datetime, timedelta, timezone
from fractions import Fraction
from pathlib import Path
from statistics import median
from zoneinfo import ZoneInfo


COHORT_FIELDS = ('user_id', 'task_family', 'scope_kind', 'baseline_policy')
BLOCK_IDENTITY_FIELDS = ('task_id', 'episode_id')
BLOCK_TIME_FIELDS = ('start', 'end')


def load(root, relative):
    return json.loads((Path(root) / relative).read_text(encoding='utf-8'))


def instant(value, zone=None):
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError('An explicit UTC offset is required')
    if zone:
        local = parsed.astimezone(ZoneInfo(zone))
        if local.replace(tzinfo=None) != parsed.replace(tzinfo=None) or local.utcoffset() != parsed.utcoffset():
            raise ValueError('Offset or local time does not match the declared timezone')
    return parsed.astimezone(timezone.utc)


def minutes(start, end):
    return Fraction(int((end - start).total_seconds()), 60)


def scalar(value):
    value = Fraction(value)
    return int(value) if value.denominator == 1 else str(value)


def union_intervals(intervals):
    merged = []
    for start, end in sorted(intervals):
        if end <= start:
            continue
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(end, merged[-1][1]))
        else:
            merged.append((start, end))
    return merged


def overlaps(left, right):
    return left[0] < right[1] and right[0] < left[1]


def subtract_intervals(windows, busy):
    remaining = union_intervals(windows)
    for busy_start, busy_end in union_intervals(busy):
        updated = []
        for start, end in remaining:
            if busy_end <= start or busy_start >= end:
                updated.append((start, end))
                continue
            if start < busy_start:
                updated.append((start, busy_start))
            if busy_end < end:
                updated.append((busy_end, end))
        remaining = updated
    return remaining


def actual_minutes(history, cutoff):
    selected = {}
    for observation in history['observations']:
        if instant(observation['known_at']) > cutoff or observation['scope_id'] != history['scope_id']:
            continue
        identifier = observation.get('logical_observation_id', observation['observation_id'])
        previous = selected.get(identifier)
        if previous and observation['revision'] == previous['revision'] and observation != previous:
            return None, [], 'conflicting_observation_revision'
        if previous is None or observation['revision'] > previous['revision']:
            selected[identifier] = observation
    records = [record for record in selected.values() if not record.get('retracted')]
    if not records:
        return None, [], 'missing_actual_observations'
    kinds = {record['kind'] for record in records}
    refs = sorted(f"{record['observation_id']}@{record['revision']}" for record in records)
    if kinds == {'duration_total'}:
        if len(records) != 1:
            return None, refs, 'ambiguous_multiple_totals'
        raw = records[0].get('minutes')
        if raw is None or Fraction(str(raw)) < 0:
            return None, refs, 'invalid_actual_minutes'
        return Fraction(str(raw)), refs, None
    if kinds == {'active_interval'}:
        covered = []
        scope = (instant(history['scope_start_at']), instant(history['scope_end_at']))
        for record in records:
            interval = (instant(record['start']), instant(record['end']))
            if interval[1] <= interval[0] or interval[0] < scope[0] or interval[1] > scope[1]:
                return None, refs, 'interval_outside_actual_scope'
            covered.append(interval)
        return sum((minutes(start, end) for start, end in union_intervals(covered)), Fraction()), refs, None
    return None, refs, 'mixed_actual_representations'


def comparable_pair(history, current):
    cutoff = instant(current['cutoff'])
    if history.get('is_target_outcome') or (
        history['episode_id'] == current['episode_id'] and history['scope_id'] == current['scope_id']
    ):
        return None, 'target_outcome'
    for field in COHORT_FIELDS:
        if history[field] != current[field]:
            return None, 'cohort_' + field
    completion = history['completion']
    if not completion['complete']:
        return None, 'unfinished_scope'
    if instant(completion['completed_at']) > cutoff:
        return None, 'completion_after_cutoff'
    if instant(completion['known_at']) > cutoff:
        return None, 'completion_not_known_at_cutoff'
    coverage = history['coverage']
    if coverage['state'] != 'complete' or instant(coverage['known_at']) > cutoff:
        return None, 'incomplete_actual_coverage'
    start = instant(history['scope_start_at'])
    eligible = [
        forecast for forecast in history['forecasts']
        if forecast['scope_id'] == history['scope_id']
        and forecast['baseline_policy'] == current['baseline_policy']
        and instant(forecast['frozen_at']) <= start
        and instant(forecast['known_at']) <= cutoff
    ]
    if not eligible:
        return None, 'no_eligible_frozen_baseline'
    forecast = min(eligible, key=lambda row: (-instant(row['frozen_at']).timestamp(), row['forecast_id']))
    actual, observation_refs, reason = actual_minutes(history, cutoff)
    if reason:
        return None, reason
    pair = {
        'history_id': history['history_id'],
        'training_unit_id': history.get('training_unit_id', history['episode_id'] + '|' + history['scope_id']),
        'episode_id': history['episode_id'],
        'scope_id': history['scope_id'],
        'scope_start_at': history['scope_start_at'],
        'scope_end_at': history['scope_end_at'],
        'completed_at': completion['completed_at'],
        'forecast': copy.deepcopy(forecast),
        'actual_minutes': scalar(actual),
        'observation_refs': observation_refs,
        'disjoint_subscope_coverage': history.get('disjoint_subscope_coverage', False),
    }
    return pair, None


def training_history(histories, current, policy):
    pairs = []
    excluded = []
    for history in histories:
        pair, reason = comparable_pair(history, current)
        if reason:
            excluded.append({'history_id': history['history_id'], 'reason': reason})
        else:
            pairs.append(pair)
    pairs.sort(key=lambda row: (
        -instant(row['completed_at']).timestamp(),
        -instant(row['scope_start_at']).timestamp(),
        -instant(row['forecast']['frozen_at']).timestamp(),
        row['history_id'],
    ))
    selected = []
    unique_pairs = []
    seen_pairs = set()
    for pair in pairs:
        key = (pair['episode_id'], pair['scope_id'], pair['forecast'].get('canonical_forecast_id', pair['forecast']['forecast_id']))
        if key in seen_pairs:
            excluded.append({'history_id': pair['history_id'], 'reason': 'duplicate_forecast_actual_pair'})
        else:
            seen_pairs.add(key)
            unique_pairs.append(pair)
    pairs = unique_pairs
    for pair in pairs:
        point = pair['forecast']['baseline']['point']
        if point is None or Fraction(str(point)) <= 0:
            reason = 'missing_baseline_point' if point is None else 'zero_baseline_point'
            excluded.append({'history_id': pair['history_id'], 'reason': reason})
            continue
        related = [other for other in selected if pair['episode_id'] == other['episode_id']]
        reason = None
        for other in related:
            if pair['scope_id'] == other['scope_id']:
                reason = 'duplicate_completed_scope'
                break
            left = (instant(pair['scope_start_at']), instant(pair['scope_end_at']))
            right = (instant(other['scope_start_at']), instant(other['scope_end_at']))
            if overlaps(left, right):
                reason = 'overlapping_completed_scope'
                break
            if not (pair['disjoint_subscope_coverage'] and other['disjoint_subscope_coverage']):
                reason = 'unverified_independent_subscope'
                break
        if reason:
            excluded.append({'history_id': pair['history_id'], 'reason': reason})
        else:
            selected.append(pair)
    selected.sort(key=lambda row: (-instant(row['completed_at']).timestamp(), row['training_unit_id']))
    for pair in selected[policy['history_limit']:]:
        excluded.append({'history_id': pair['history_id'], 'reason': 'history_limit'})
    selected = selected[:policy['history_limit']]
    return pairs, selected, sorted(excluded, key=lambda row: (row['history_id'], row['reason']))


def publish_range(raw):
    low = max(1, raw['low'].numerator // raw['low'].denominator)
    high = max(low, -(-raw['high'].numerator // raw['high'].denominator))
    half_up = None
    if raw['point'] is not None:
        rounded = raw['point'] + Fraction(1, 2)
        half_up = min(high, max(low, rounded.numerator // rounded.denominator))
    return {'low': low, 'point': half_up, 'high': high}


def forecast(histories, current, policy):
    pairs, selected, excluded = training_history(histories, current, policy)
    ratios = [Fraction(str(pair['actual_minutes'])) / Fraction(str(pair['forecast']['baseline']['point'])) for pair in selected]
    count = len(ratios)
    ratio_median = median(ratios) if ratios else None
    prior = policy['shrinkage_prior_weight']
    factor = (Fraction(prior) + count * ratio_median) / (prior + count) if count else Fraction(1)
    raw = {key: Fraction(str(value)) * factor if value is not None else None for key, value in current['baseline'].items()}
    baseline_state = 'point_and_range'
    if current.get('explicit_remaining_minutes') == 0 or current.get('planning_eligibility') == 'completed':
        raw = {key: Fraction() for key in ('low', 'point', 'high')}
        suggestion = {key: 0 for key in raw}
        baseline_state = 'completed_or_zero_remaining'
    elif raw['low'] is None or raw['high'] is None:
        suggestion = {'low': None, 'point': None, 'high': None}
        baseline_state = 'baseline_unknown'
    else:
        suggestion = publish_range(raw)
        if raw['point'] is None:
            baseline_state = 'range_only'
    published = copy.deepcopy(suggestion)
    override = current.get('manual_override')
    override_state = 'absent'
    if override:
        applicable = override['scope_id'] == current['scope_id'] and override['episode_id'] == current['episode_id'] and instant(override['known_at']) <= instant(current['cutoff'])
        override_state = 'applied' if applicable else 'outside_current_scope_or_cutoff'
        if baseline_state == 'completed_or_zero_remaining':
            applicable = False
            override_state = 'inapplicable_completed_scope'
        if applicable:
            values = override['values']
            if not 0 <= values['low'] <= values['high'] or (values['point'] is not None and not values['low'] <= values['point'] <= values['high']):
                raise ValueError('Invalid explicit manual forecast interval')
            published = copy.deepcopy(values)
    errors = []
    for pair in pairs:
        actual = Fraction(str(pair['actual_minutes']))
        values = pair['forecast']['published']
        point_error = actual - Fraction(str(values['point'])) if values['point'] is not None else None
        errors.append({
            'history_id': pair['history_id'],
            'inside_published_range': Fraction(str(values['low'])) <= actual <= Fraction(str(values['high'])),
            'point_error_minutes': scalar(point_error) if point_error is not None else None,
        })
    return {
        'forecast_id': current['forecast_id'],
        'cutoff': current['cutoff'],
        'scope_id': current['scope_id'],
        'episode_id': current['episode_id'],
        'baseline': copy.deepcopy(current['baseline']),
        'matched_pair_count': len(pairs),
        'training_count': count,
        'training_history_ids': [pair['history_id'] for pair in selected],
        'training_forecast_ids': [pair['forecast']['forecast_id'] for pair in selected],
        'actual_minutes': {pair['history_id']: pair['actual_minutes'] for pair in pairs},
        'ratio_median': str(ratio_median) if ratio_median is not None else None,
        'factor': str(factor),
        'raw': {key: str(value) if value is not None else None for key, value in raw.items()},
        'baseline_state': baseline_state,
        'calibration_suggestion': suggestion,
        'published': published,
        'planning_budget_minutes': published['high'],
        'history_support': 'cold_start' if count == 0 else 'limited_history' if count < 3 else 'supported_history',
        'support': 'user_override' if override_state == 'applied' else 'baseline_unknown' if baseline_state == 'baseline_unknown' else 'cold_start' if count == 0 else 'limited_history' if count < 3 else 'supported_history',
        'override_state': override_state,
        'excluded': excluded,
        'pair_errors': errors,
        'personal_progress': current['personal_progress'],
        'current_actual_minutes': current['current_actual_minutes'],
    }


def effective_free_intervals(plan):
    if plan['buffer_policy'] != 'end_only_per_supplied_availability_window':
        raise ValueError('Unsupported fixture availability buffer policy')
    as_of = instant(plan['as_of'], plan['timezone'])
    windows = []
    for window in plan['availability']:
        start = max(as_of, instant(window['start'], plan['timezone']))
        end = instant(window['end'], plan['timezone']) - timedelta(minutes=plan['buffer_minutes'])
        if end > start:
            windows.append((start, end))
    busy = [(instant(row['start'], plan['timezone']), instant(row['end'], plan['timezone'])) for row in plan['busy']]
    return subtract_intervals(windows, busy)


def block_signature(block):
    return tuple(block.get(field) for field in BLOCK_IDENTITY_FIELDS + BLOCK_TIME_FIELDS)


def evaluate_candidate(plan, candidate, free):
    old = {block['block_id']: block for block in plan['existing_blocks']}
    proposed = {block['block_id']: block for block in candidate['blocks']}
    tasks = {task['task_id']: task for task in plan['tasks']}
    reasons = []
    if len(proposed) != len(candidate['blocks']):
        reasons.append('duplicate_block_identity')
    for identifier, before in old.items():
        after = proposed.get(identifier)
        protected = before['locked'] or before['started'] or before['user_edited']
        if protected and after != before:
            reasons.append('protected_block_changed:' + identifier)
        if after and any(after[field] != before[field] for field in BLOCK_IDENTITY_FIELDS):
            reasons.append('existing_block_identity_rebound:' + identifier)
    as_of = instant(plan['as_of'], plan['timezone'])
    future_intervals = []
    supplied = {identifier: Fraction() for identifier in tasks}
    for identifier, block in proposed.items():
        task = tasks.get(block['task_id'])
        if task is None or task['episode_id'] != block['episode_id']:
            reasons.append('inactive_or_wrong_episode:' + identifier)
            continue
        if block['owner'] != 'canvasbridge':
            reasons.append('unowned_block_mutation:' + identifier)
        start = instant(block['start'], plan['timezone'])
        end = instant(block['end'], plan['timezone'])
        if end <= start:
            reasons.append('nonpositive_block:' + identifier)
            continue
        if end > instant(task['deadline'], plan['timezone']):
            reasons.append('after_deadline:' + identifier)
        if task.get('release_at') and start < instant(task['release_at'], plan['timezone']):
            reasons.append('before_release:' + identifier)
        if start < as_of and (identifier not in old or block != old[identifier]):
            reasons.append('rewrites_elapsed_block:' + identifier)
        remaining_start = max(start, as_of)
        if end <= remaining_start:
            continue
        interval = (remaining_start, end)
        if not any(remaining_start >= left and end <= right for left, right in free):
            reasons.append('outside_free_availability:' + identifier)
        future_intervals.append((remaining_start, end, identifier))
        supplied[block['task_id']] += minutes(remaining_start, end)
    ordered_intervals = sorted(future_intervals)
    for left, right in zip(ordered_intervals, ordered_intervals[1:]):
        if left[1] > right[0]:
            reasons.append('study_overlap:' + left[2] + '/' + right[2])
        elif minutes(left[1], right[0]) < plan['break_minutes']:
            reasons.append('interblock_break:' + left[2] + '/' + right[2])
    ordered_tasks = sorted(tasks.values(), key=lambda task: (task['priority'], instant(task['deadline']), task['task_id']))
    unmet = {task['task_id']: scalar(max(Fraction(), Fraction(task['required_minutes']) - supplied[task['task_id']])) for task in ordered_tasks}
    changed = sorted(identifier for identifier, before in old.items() if identifier not in proposed or block_signature(before) != block_signature(proposed[identifier]))
    moved = sorted(identifier for identifier in old.keys() & proposed.keys() if instant(old[identifier]['start']) != instant(proposed[identifier]['start']))
    removed = sorted(old.keys() - proposed.keys())
    added = sorted(proposed.keys() - old.keys())
    displacement = sum((abs(minutes(instant(old[identifier]['start']), instant(proposed[identifier]['start']))) for identifier in old.keys() & proposed.keys()), Fraction())
    duration_change = Fraction()
    for identifier in old.keys() & proposed.keys():
        before = old.get(identifier)
        after = proposed.get(identifier)
        old_duration = minutes(instant(before['start']), instant(before['end'])) if before else Fraction()
        new_duration = minutes(instant(after['start']), instant(after['end'])) if after else Fraction()
        duration_change += abs(new_duration - old_duration)
    score = (tuple(Fraction(str(unmet[task['task_id']])) for task in ordered_tasks), len(changed), displacement, duration_change, candidate['candidate_id'])
    return {
        'candidate_id': candidate['candidate_id'],
        'valid': not reasons,
        'reasons': sorted(set(reasons)),
        'unmet_minutes': unmet,
        'supplied_minutes': {key: scalar(value) for key, value in supplied.items()},
        'changed_existing_block_ids': changed,
        'changed_existing_block_count': len(changed),
        'moved_block_ids': moved,
        'removed_block_ids': removed,
        'added_block_ids': added,
        'start_displacement_minutes': scalar(displacement),
        'duration_change_minutes': scalar(duration_change),
        '_score': score,
    }


def choose_schedule(plan):
    free = effective_free_intervals(plan)
    results = [evaluate_candidate(plan, candidate, free) for candidate in plan['candidates']]
    valid = [result for result in results if result['valid']]
    selected = min(valid, key=lambda row: row['_score']) if valid else None
    free_minutes = sum((minutes(start, end) for start, end in free), Fraction())
    demand = sum(task['required_minutes'] for task in plan['tasks'])
    proof = plan.get('capacity_proof')
    proof_valid = bool(proof and plan['availability_coverage'] == proof['source_coverage'] == 'complete' and proof['kind'] == 'aggregate_free_capacity' and proof['buffer_policy'] == plan['buffer_policy'] and proof['demand_minutes'] == demand and Fraction(proof['free_minutes']) == free_minutes and proof['minimum_unscheduled_minutes'] == max(0, demand - free_minutes))
    residual = sum(Fraction(str(value)) for value in selected['unmet_minutes'].values()) if selected else Fraction(demand)
    if plan['availability_coverage'] != 'complete':
        status = 'availability_unverified'
    elif selected and residual == 0:
        status = 'feasible'
    elif proof_valid and proof['minimum_unscheduled_minutes'] > 0:
        status = 'infeasible_capacity'
    else:
        status = 'no_feasible_schedule_found'
    public_results = [{key: value for key, value in result.items() if key != '_score'} for result in results]
    public_selected = next((result for result in public_results if selected and result['candidate_id'] == selected['candidate_id']), None)
    return {
        'selected_candidate_id': selected['candidate_id'] if selected else None,
        'selected_block_ids': sorted(block['block_id'] for candidate in plan['candidates'] if selected and candidate['candidate_id'] == selected['candidate_id'] for block in candidate['blocks']),
        'status': status,
        'free_minutes': scalar(free_minutes),
        'required_minutes': demand,
        'unscheduled_minutes': scalar(residual),
        'capacity_proof_valid': proof_valid,
        'selection': public_selected,
        'candidates': public_results,
        'selected_blocks': copy.deepcopy(next(candidate['blocks'] for candidate in plan['candidates'] if selected and candidate['candidate_id'] == selected['candidate_id'])) if selected else [],
    }


def simulate_operations(initial_revision, initial_provider_revisions, operations, steps):
    revision = initial_revision
    plan_receipts = {}
    provider_revisions = copy.deepcopy(initial_provider_revisions)
    states = {operation['operation_id']: 'pending' for operation in operations}
    expected = {operation['operation_id']: operation for operation in operations}
    effects = {}
    outcomes = []
    write_attempts = 0
    lookups = 0
    for step in steps:
        identifier = step.get('operation_id')
        kind = step['kind']
        if kind == 'apply_plan':
            if identifier in plan_receipts:
                outcome = 'plan_receipt_replayed'
            elif step['expected_revision'] != revision:
                outcome = 'base_conflict'
            elif step.get('storage_failure'):
                outcome = 'storage_failure_unchanged'
            else:
                revision += 1
                plan_receipts[identifier] = revision
                outcome = 'plan_intent_committed'
        elif kind == 'provider_external_edit':
            provider_revisions[step['event_id']] = step['new_revision']
            outcome = 'external_provider_edit_observed'
        elif not plan_receipts:
            outcome = 'missing_committed_plan_intent'
        elif kind == 'recover_provider':
            lookups += 1
            if identifier in effects and effects[identifier]['event_id'] == step['event_id']:
                states[identifier] = 'confirmed'
                outcome = 'matching_effect_recovered'
            else:
                outcome = 'effect_unresolved'
        elif kind == 'provider_attempt':
            operation = expected[identifier]
            if step['event_id'] != operation['event_id'] or step.get('payload_sha256') != operation.get('payload_sha256') or step['expected_provider_revision'] != operation['expected_provider_revision']:
                outcome = 'operation_identity_conflict'
            elif identifier in effects:
                states[identifier] = 'confirmed'
                outcome = 'provider_receipt_replayed'
            elif provider_revisions.get(step['event_id']) != step['expected_provider_revision']:
                states[identifier] = 'failed'
                outcome = 'provider_revision_conflict'
            else:
                write_attempts += 1
                outcome = step['outcome']
                if outcome == 'failed_before_effect':
                    states[identifier] = 'failed'
                else:
                    effects[identifier] = {'effect_id': step['effect_id'], 'event_id': step['event_id']}
                    provider_revisions[step['event_id']] = 'revision_after_' + identifier
                    states[identifier] = 'confirmed' if outcome == 'confirmed' else 'outcome_unknown'
        else:
            raise ValueError('Unsupported bounded operation step')
        outcomes.append(outcome)
    confirmed = sum(state == 'confirmed' for state in states.values())
    if plan_receipts and confirmed == len(states):
        status = 'applied'
    elif confirmed:
        status = 'partially_applied'
    elif plan_receipts:
        status = 'accepted'
    else:
        status = 'proposed'
    return {
        'record_revision': revision,
        'plan_commit_count': len(plan_receipts),
        'provider_write_attempts': write_attempts,
        'provider_lookups': lookups,
        'actual_effect_count': len(effects),
        'confirmed_effect_count': confirmed,
        'pending_operation_count': len(states) - confirmed,
        'operation_states': states,
        'plan_apply_status': status,
        'outcomes': outcomes,
        'provider_revisions': provider_revisions,
    }


def evaluate(root, scenario):
    policy = load(root, 'fixtures/policy.json')
    if scenario['kind'] == 'forecast':
        all_history = {row['history_id']: row for row in load(root, 'fixtures/history.json')['histories']}
        result = forecast([all_history[identifier] for identifier in scenario['history_ids']], scenario['current'], policy)
        if scenario.get('holdout'):
            holdout = scenario['holdout']
            if instant(holdout['known_at']) > instant(holdout['evaluation_cutoff']) or instant(holdout['completion_at']) > instant(holdout['evaluation_cutoff']):
                raise ValueError('Holdout actual is unavailable at evaluation cutoff')
            if instant(holdout['scope_start_at']) < instant(scenario['current']['cutoff']) or instant(holdout['completion_at']) < instant(holdout['scope_start_at']) or instant(holdout['known_at']) < instant(holdout['completion_at']):
                result['holdout_evaluation'] = {'eligibility': 'nonprospective_or_inconsistent', 'reason': 'holdout_chronology'}
                return {'scenario_id': scenario['id'], **result}
            actual = holdout['actual_minutes']
            result['holdout_evaluation'] = {
                'eligibility': 'prospective',
                'actual_minutes': actual,
                'frozen_point': result['published']['point'],
                'point_error_minutes': actual - result['published']['point'],
                'absolute_point_error_minutes': abs(actual - result['published']['point']),
                'baseline_absolute_point_error_minutes': abs(actual - result['baseline']['point']),
                'inside_frozen_range': result['published']['low'] <= actual <= result['published']['high'],
            }
        return {'scenario_id': scenario['id'], **result}
    plans = {row['schedule_id']: row for row in load(root, 'fixtures/schedules.json')['schedules']}
    plan = plans[scenario['schedule_id']]
    result = choose_schedule(plan)
    if scenario.get('operation_steps'):
        result['execution'] = simulate_operations(plan['record_revision'], scenario['initial_provider_revisions'], scenario['provider_operations'], scenario['operation_steps'])
        execution = result['execution']
        previous = {row['provider_event_id']: copy.deepcopy(row) for row in plan['existing_blocks']}
        desired = {row['provider_event_id']: row for row in result['selected_blocks']}
        confirmed_effects = []
        unresolved = []
        for operation in scenario['provider_operations']:
            identifier = operation['operation_id']
            event_id = operation['event_id']
            state = execution['operation_states'][identifier]
            if state == 'confirmed':
                block = copy.deepcopy(desired[event_id])
                block['provider_revision'] = execution['provider_revisions'][event_id]
                previous[event_id] = block
                confirmed_effects.append({'operation_id': identifier, 'event_id': event_id, 'block': block})
            elif execution['plan_commit_count']:
                unresolved.append(identifier)
                if state == 'outcome_unknown' or (state == 'failed' and execution['provider_revisions'].get(event_id) != scenario['initial_provider_revisions'].get(event_id)):
                    previous.pop(event_id, None)
        result['previous_confirmed_blocks'] = copy.deepcopy(plan['existing_blocks'])
        result['confirmed_block_effects'] = confirmed_effects
        result['confirmed_calendar_projection'] = {'blocks': list(previous.values()), 'unresolved_operation_ids': unresolved, 'complete': execution['plan_apply_status'] == 'applied'}
        result['fully_applied_blocks'] = copy.deepcopy(result['confirmed_calendar_projection']['blocks']) if execution['plan_apply_status'] == 'applied' else None
    return {'scenario_id': scenario['id'], **result}
