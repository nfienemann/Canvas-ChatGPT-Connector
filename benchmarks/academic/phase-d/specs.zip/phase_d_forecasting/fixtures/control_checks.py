#!/usr/bin/env python3
"""Focused boundary controls for the bounded Phase D reference evaluator."""

import copy
import json
import runpy
from datetime import datetime, timedelta
from pathlib import Path


def read(root, relative):
    return json.loads((Path(root) / relative).read_text(encoding='utf-8'))


def make_history(identifier, actual=40, point=40, start=None, end=None, episode=None, scope_kind='whole_episode'):
    start = start or datetime.fromisoformat('2026-10-01T09:00:00-04:00')
    end = end or start + timedelta(minutes=max(actual, 1))
    scope = identifier + '/scope'
    return {
        'history_id': identifier,
        'user_id': 'SYNTHETIC-STUDENT-D',
        'task_family': 'reading',
        'scope_kind': scope_kind,
        'baseline_policy': 'content-v1',
        'episode_id': episode or identifier + '/E1',
        'scope_id': scope,
        'scope_start_at': start.isoformat(),
        'scope_end_at': end.isoformat(),
        'completion': {'complete': True, 'completed_at': end.isoformat(), 'known_at': (end + timedelta(hours=1)).isoformat(), 'basis': 'synthetic_complete_control_scope'},
        'coverage': {'state': 'complete', 'known_at': (end + timedelta(hours=1)).isoformat(), 'basis': 'synthetic_complete_control_measurement'},
        'forecasts': [{
            'forecast_id': identifier + '/F1', 'scope_id': scope,
            'frozen_at': (start - timedelta(minutes=1)).isoformat(),
            'known_at': (start - timedelta(minutes=1)).isoformat(),
            'baseline_policy': 'content-v1', 'baseline_origin': 'uncalibrated_control',
            'baseline': {'low': point, 'point': point, 'high': point},
            'published': {'low': point, 'point': point, 'high': point},
        }],
        'observations': [{
            'observation_id': identifier + '/actual', 'revision': 1,
            'known_at': (end + timedelta(hours=1)).isoformat(),
            'scope_id': scope, 'kind': 'duration_total', 'minutes': actual,
            'basis': 'synthetic_control_active_minutes',
        }],
    }


def run_controls(root):
    root = Path(root)
    model = runpy.run_path(str(root / 'fixtures/reference_forecasting.py'))
    policy = read(root, 'fixtures/policy.json')
    histories = {row['history_id']: row for row in read(root, 'fixtures/history.json')['histories']}
    scenarios = {row['id']: row for row in read(root, 'fixtures/scenarios.json')['scenarios']}
    schedules = {row['schedule_id']: row for row in read(root, 'fixtures/schedules.json')['schedules']}
    controls = read(root, 'fixtures/contract_controls.json')['controls']
    actual = {}
    extra_checks = []

    def extra(identifier, condition, detail):
        extra_checks.append({'id': 'control.' + identifier, 'passed': bool(condition), 'detail': detail})

    def current(number):
        return copy.deepcopy(scenarios[f'PHD-S{number:02d}']['current'])

    def issue(rows, target):
        return model['forecast'](rows, target, policy)

    def evaluate(number):
        return model['evaluate'](root, scenarios[f'PHD-S{number:02d}'])

    # Recent-history limiting follows independence selection and precedes publication.
    small = current(1)
    small['baseline'] = {'low': 1, 'point': 1, 'high': 1}
    zero_histories = [make_history(f'CONTROL-ZERO-{index:02d}', actual=0, point=1, start=datetime.fromisoformat('2026-10-01T09:00:00-04:00') + timedelta(days=index)) for index in range(21)]
    bounded = issue(zero_histories, small)
    actual['PHD-C01'] = {
        'training_count': bounded['training_count'],
        'factor': bounded['factor'],
        'published': bounded['published'],
        'history_limit_exclusions': sum(row['reason'] == 'history_limit' for row in bounded['excluded']),
    }
    extra('PHD-C01.recent_membership', 'CONTROL-ZERO-00' not in bounded['training_history_ids'] and 'CONTROL-ZERO-20' in bounded['training_history_ids'], 'Twenty most recent independent units are selected')

    # Missing point and missing range each retain their own publication shape.
    row_set = [histories[name] for name in ['H-R1', 'H-R2', 'H-R3']]
    range_target = current(1)
    range_target['baseline']['point'] = None
    range_result = issue(row_set, range_target)
    unknown = current(1)
    unknown['baseline'] = {'low': None, 'point': None, 'high': None}
    unknown_result = issue(row_set, unknown)
    completed = current(8)
    completed['planning_eligibility'] = 'completed'
    completed_result = issue([], completed)
    explicit_zero = current(8)
    explicit_zero['explicit_remaining_minutes'] = 0
    zero_result = issue([], explicit_zero)
    zero_pair = next(row for row in evaluate(4)['pair_errors'] if row['history_id'] == 'H-ZERO-BASE')
    actual['PHD-C02'] = {'range_only': range_result['published'], 'unknown_budget': unknown_result['planning_budget_minutes'], 'completed_budget': completed_result['planning_budget_minutes'], 'zero_base_point_error': zero_pair['point_error_minutes']}
    extra('PHD-C02.unknown_state', unknown_result['baseline_state'] == unknown_result['support'] == 'baseline_unknown', 'An unknown baseline retains unknown demand')
    extra('PHD-C02.completed_override', completed_result['override_state'] == zero_result['override_state'] == 'inapplicable_completed_scope' and zero_result['planning_budget_minutes'] == 0, 'Historical override preserves zero active demand for completed or explicit-zero scope')

    # Canonical forecast selection and independence prevent correlated row inflation.
    remaining_target = current(5)
    canonical = make_history('CONTROL-CANONICAL', actual=50, point=20, scope_kind='remaining_episode')
    canonical['forecasts'][0]['frozen_at'] = '2026-10-01T08:00:00-04:00'
    latest = copy.deepcopy(canonical['forecasts'][0])
    latest.update(forecast_id='CONTROL-LATEST-FROZEN', frozen_at='2026-10-01T08:59:00-04:00')
    latest['baseline'] = {'low': 40, 'point': 40, 'high': 40}
    latest['published'] = {'low': 40, 'point': 40, 'high': 40}
    canonical['forecasts'].append(latest)
    alias = copy.deepcopy(canonical)
    alias['history_id'] = 'ZZ-CONTROL-ALIAS'
    duplicate = issue([canonical, alias], remaining_target)
    outer = make_history('CONTROL-OUTER', 60, 40, start=datetime.fromisoformat('2026-10-02T10:00:00-04:00'), end=datetime.fromisoformat('2026-10-02T11:00:00-04:00'), episode='CONTROL-SHARED/E1', scope_kind='remaining_episode')
    inner = make_history('CONTROL-INNER', 30, 20, start=datetime.fromisoformat('2026-10-02T10:30:00-04:00'), end=datetime.fromisoformat('2026-10-02T11:00:00-04:00'), episode='CONTROL-SHARED/E1', scope_kind='remaining_episode')
    nested = issue([outer, inner], remaining_target)
    first = make_history('CONTROL-DISJOINT-1', 30, 20, start=datetime.fromisoformat('2026-10-03T10:00:00-04:00'), end=datetime.fromisoformat('2026-10-03T10:30:00-04:00'), episode='CONTROL-DISJOINT/E1', scope_kind='remaining_episode')
    second = make_history('CONTROL-DISJOINT-2', 20, 20, start=datetime.fromisoformat('2026-10-03T10:30:00-04:00'), end=datetime.fromisoformat('2026-10-03T11:00:00-04:00'), episode='CONTROL-DISJOINT/E1', scope_kind='remaining_episode')
    first['disjoint_subscope_coverage'] = second['disjoint_subscope_coverage'] = True
    disjoint = issue([first, second], remaining_target)
    actual['PHD-C03'] = {'duplicate_training_count': duplicate['training_count'], 'nested_training_count': nested['training_count'], 'nested_representative': nested['training_history_ids'][0], 'disjoint_training_count': disjoint['training_count'], 'disjoint_factor': disjoint['factor'], 'canonical_forecast': duplicate['training_forecast_ids'][0]}
    extra('PHD-C03.duplicate_pair', duplicate['matched_pair_count'] == 1 and any(row['reason'] == 'duplicate_forecast_actual_pair' for row in duplicate['excluded']), 'Repeated forecast joins retain one canonical pair')
    extra('PHD-C03.overlap_reason', any(row['reason'] == 'overlapping_completed_scope' for row in nested['excluded']), 'Overlapping remaining scopes retain the excluded-group reason')

    # Later information supports a newly issued forecast while the earlier output stays attributable.
    issued = evaluate(7)
    later_target = current(7)
    later_target['cutoff'] = '2026-11-07T12:00:00Z'
    later = issue([histories[name] for name in scenarios['PHD-S07']['history_ids']], later_target)
    target_outcome = make_history('CONTROL-TARGET', 1000, 40)
    target_outcome['is_target_outcome'] = True
    target_outcome['completion']['completed_at'] = current(1)['cutoff']
    target_outcome['completion']['known_at'] = current(1)['cutoff']
    target_outcome['coverage']['known_at'] = current(1)['cutoff']
    excluded_target = issue([target_outcome], current(1))
    retrospective = copy.deepcopy(scenarios['PHD-S07'])
    retrospective['holdout'].update(scope_start_at='2026-11-04T12:00:00Z', completion_at='2026-11-04T15:00:00Z', known_at='2026-11-04T16:00:00Z')
    rejected = model['evaluate'](root, retrospective)['holdout_evaluation']
    actual['PHD-C04'] = {'issued_point': issued['published']['point'], 'later_point': later['published']['point'], 'later_factor': later['factor'], 'target_excluded_count': sum(row['reason'] == 'target_outcome' for row in excluded_target['excluded'])}
    extra('PHD-C04.prospective_population', rejected.get('eligibility') == 'nonprospective_or_inconsistent' and 'absolute_point_error_minutes' not in rejected, 'Pre-issue outcomes retain an explicit nonprospective result')

    matching = evaluate(8)
    other_scope = current(8)
    other_scope['manual_override']['scope_id'] = 'ANOTHER-SCOPE'
    mismatched = issue([histories['H-CORRECTED']], other_scope)
    manual_range = current(8)
    manual_range['manual_override']['values'] = {'low': 30, 'point': None, 'high': 50}
    range_override = issue([], manual_range)
    actual['PHD-C05'] = {'matching_budget': matching['planning_budget_minutes'], 'different_scope_budget': mismatched['planning_budget_minutes'], 'different_scope_override_state': mismatched['override_state']}
    extra('PHD-C05.optional_point', range_override['published'] == {'low': 30, 'point': None, 'high': 50} and range_override['planning_budget_minutes'] == 50, 'A range-only current override preserves its null point and upper budget')

    # Observation correction and representation choices are tested before calibration.
    retracted = copy.deepcopy(histories['H-R1'])
    retracted['observations'].append({**copy.deepcopy(retracted['observations'][0]), 'revision': 2, 'known_at': '2026-11-01T12:00:00Z', 'retracted': True})
    negative = copy.deepcopy(histories['H-R1'])
    negative['observations'][0]['minutes'] = -1
    mixed = copy.deepcopy(histories['H-R1'])
    mixed['observations'].append({'observation_id': 'MIXED/interval', 'revision': 1, 'known_at': '2026-10-21T12:00:00Z', 'scope_id': mixed['scope_id'], 'kind': 'active_interval', 'start': mixed['scope_start_at'], 'end': mixed['scope_end_at']})
    conflict = copy.deepcopy(histories['H-R1'])
    conflict['observations'].append({**copy.deepcopy(conflict['observations'][0]), 'minutes': 41})
    reasons = {}
    for name, value in [('retracted', retracted), ('negative', negative), ('mixed', mixed), ('conflict', conflict)]:
        result = issue([value], current(1))
        reasons[name + '_reason'] = result['excluded'][0]['reason']
    actual['PHD-C06'] = reasons

    # Full block identity remains, while elapsed past minutes do not cover current remaining work.
    started = copy.deepcopy(schedules['PLAN-S09'])
    started['as_of'] = '2026-11-09T09:20:00-05:00'
    started['tasks'][0]['required_minutes'] = 20
    started['existing_blocks'][0].update(end='2026-11-09T09:30:00-05:00', started=True)
    started['existing_blocks'][1].update(user_edited=True, manual_title='Keep my title')
    old_started = copy.deepcopy(started['existing_blocks'])
    append = copy.deepcopy(old_started)
    additional = copy.deepcopy(old_started[0])
    additional.update(block_id='BLOCK-A2', provider_event_id='EVENT-BLOCK-A2', start='2026-11-09T09:30:00-05:00', end='2026-11-09T09:40:00-05:00', started=False)
    append.append(additional)
    rewritten = copy.deepcopy(old_started)
    rewritten[0].update(start='2026-11-09T09:20:00-05:00', end='2026-11-09T09:40:00-05:00')
    changed_title = copy.deepcopy(append)
    changed_title[1]['manual_title'] = 'Overwritten'
    started['candidates'] = [{'candidate_id':'old_short','blocks':old_started},{'candidate_id':'append_future','blocks':append},{'candidate_id':'rewrite_started','blocks':rewritten},{'candidate_id':'overwrite_user_title','blocks':changed_title}]
    started_result = model['choose_schedule'](started)
    original_block = next(row for row in started_result['selected_blocks'] if row['block_id'] == 'BLOCK-A1')
    old_result = next(row for row in started_result['candidates'] if row['candidate_id'] == 'old_short')
    actual['PHD-C07'] = {'selected_candidate_id':started_result['selected_candidate_id'],'old_candidate_unmet_a':old_result['unmet_minutes']['A'],'future_supplied_a':started_result['selection']['supplied_minutes']['A'],'original_start':original_block['start'],'original_end':original_block['end'],'changed_existing_block_count':started_result['selection']['changed_existing_block_count']}
    extra('PHD-C07.protected_manual_field', any('protected_block_changed:BLOCK-B1' in row['reasons'] for row in started_result['candidates'] if row['candidate_id'] == 'overwrite_user_title'), 'Current student-edited block fields remain protected')

    capacity = evaluate(14)
    limited_search = copy.deepcopy(schedules['PLAN-S14'])
    limited_search.pop('capacity_proof')
    limited_search['availability'][0]['end'] = '2026-11-09T12:00:00-05:00'
    for item in limited_search['tasks']:
        item['deadline'] = '2026-11-09T12:00:00-05:00'
    limited_search['candidates'] = [limited_search['candidates'][0]]
    search_result = model['choose_schedule'](limited_search)
    partial_availability = copy.deepcopy(schedules['PLAN-S09'])
    partial_availability['availability_coverage'] = 'partial'
    partial_result = model['choose_schedule'](partial_availability)
    actual['PHD-C08'] = {'proof_status':capacity['status'],'search_status':search_result['status'],'partial_availability_status':partial_result['status']}
    extra('PHD-C08.search_bound', search_result['free_minutes'] == search_result['required_minutes'] == 180 and not search_result['capacity_proof_valid'], 'The candidate set can miss a feasible schedule despite sufficient supplied total capacity')

    buffered = copy.deepcopy(schedules['PLAN-S09'])
    buffered['availability'][0]['end'] = '2026-11-09T10:00:00-05:00'
    buffered['buffer_minutes'] = 5
    buffered['existing_blocks'] = []
    buffered['tasks'][0]['required_minutes'] = 25
    buffered['tasks'][1]['required_minutes'] = 30
    adjacent = copy.deepcopy(schedules['PLAN-S09']['existing_blocks'])
    adjacent[0]['end'] = '2026-11-09T09:25:00-05:00'
    adjacent[1].update(start='2026-11-09T09:25:00-05:00',end='2026-11-09T09:55:00-05:00')
    buffered['candidates'] = [{'candidate_id':'trim_once','blocks':adjacent}]
    buffered_result = model['choose_schedule'](buffered)
    breaks = copy.deepcopy(buffered)
    breaks['buffer_minutes'] = 0
    breaks['break_minutes'] = 5
    separated = copy.deepcopy(adjacent)
    separated[1].update(start='2026-11-09T09:30:00-05:00',end='2026-11-09T10:00:00-05:00')
    breaks['candidates'].append({'candidate_id':'with_break','blocks':separated})
    break_result = model['choose_schedule'](breaks)
    actual['PHD-C09'] = {'buffered_free_minutes':buffered_result['free_minutes'],'buffered_status':buffered_result['status'],'break_status':break_result['status'],'break_candidate':break_result['selected_candidate_id']}

    rejected_times = {}
    for name, value in [('naive','2026-11-01T01:30:00'),('nonexistent','2027-03-14T02:30:00-05:00'),('wrong_offset','2026-11-09T09:00:00-04:00')]:
        try:
            model['instant'](value, 'America/New_York')
            rejected_times[name + '_rejected'] = False
        except ValueError:
            rejected_times[name + '_rejected'] = True
    actual['PHD-C10'] = {'fold_capacity_minutes':evaluate(15)['free_minutes'],**rejected_times}

    # Local intent and each external effect retain separate observable states.
    partial = copy.deepcopy(scenarios['PHD-S16'])
    partial['operation_steps'] = partial['operation_steps'][:4]
    partial_result = model['evaluate'](root, partial)
    stale = copy.deepcopy(scenarios['PHD-S16'])
    stale['operation_steps'] = stale['operation_steps'][:1]
    stale_result = model['evaluate'](root, stale)
    replay = copy.deepcopy(scenarios['PHD-S16'])
    replay['operation_steps'].append(copy.deepcopy(replay['operation_steps'][2]))
    replay_result = model['evaluate'](root, replay)
    external = copy.deepcopy(scenarios['PHD-S16'])
    external['operation_steps'] = [copy.deepcopy(external['operation_steps'][1]), {'kind':'provider_external_edit','event_id':'EVENT-BLOCK-A1','new_revision':'human-r2'}, copy.deepcopy(external['operation_steps'][2])]
    external_result = model['evaluate'](root, external)
    mismatch = copy.deepcopy(scenarios['PHD-S16'])
    mismatched_payload = copy.deepcopy(mismatch['operation_steps'][2])
    mismatched_payload['payload_sha256'] = '0' * 64
    mismatch['operation_steps'].append(mismatched_payload)
    mismatch_result = model['evaluate'](root, mismatch)
    actual['PHD-C11'] = {
        'partial_confirmed':partial_result['execution']['confirmed_effect_count'],
        'partial_pending':partial_result['execution']['pending_operation_count'],
        'partial_actual_effects':partial_result['execution']['actual_effect_count'],
        'partial_status':partial_result['execution']['plan_apply_status'],
        'stale_commits':stale_result['execution']['plan_commit_count'],
        'stale_status':stale_result['execution']['plan_apply_status'],
        'replayed_effects':replay_result['execution']['actual_effect_count'],
        'external_edit_state':external_result['execution']['operation_states']['MOVE-A-16'],
        'payload_mismatch_outcome':mismatch_result['execution']['outcomes'][-1],
    }
    extra('PHD-C11.partial_projection', partial_result['fully_applied_blocks'] is None and partial_result['confirmed_block_effects'][0]['block']['start'] == '2026-11-09T10:30:00-05:00' and partial_result['confirmed_calendar_projection']['unresolved_operation_ids'] == ['CREATE-C-16'], 'The confirmed move appears while uncertain create remains unresolved')
    failed = copy.deepcopy(partial)
    failed['operation_steps'][3]['outcome'] = 'failed_before_effect'
    failed_result = model['evaluate'](root, failed)
    extra('PHD-C11.partial_failure', failed_result['execution']['plan_apply_status'] == 'partially_applied' and failed_result['execution']['actual_effect_count'] == 1 and failed_result['fully_applied_blocks'] is None and failed_result['confirmed_block_effects'][0]['block']['start'] == '2026-11-09T10:30:00-05:00', 'A later failed operation preserves the individually confirmed move')
    extra('PHD-C11.stale_state', stale_result['fully_applied_blocks'] is None and not stale_result['confirmed_block_effects'] and stale_result['execution']['provider_write_attempts'] == 0, 'A rejected base produces a proposal with no confirmed apply effect')
    successful = evaluate(16)
    extra('PHD-C11.confirmed_versions', successful['fully_applied_blocks'] == successful['confirmed_calendar_projection']['blocks'] and next(row for row in successful['fully_applied_blocks'] if row['block_id'] == 'BLOCK-A1')['provider_revision'] == 'revision_after_MOVE-A-16', 'Successful readback carries the confirmed provider versions')
    extra('PHD-C11.provider_edit', external_result['execution']['provider_revisions']['EVENT-BLOCK-A1'] == 'human-r2' and external_result['execution']['actual_effect_count'] == 0, 'Concurrent provider revision is preserved')

    remaining_result = evaluate(5)
    episode_result = evaluate(6)
    prior = histories['H-PRIOR-EPISODE']
    actual['PHD-C12'] = {'remaining_pair_actual':remaining_result['actual_minutes']['H-REMAINING'],'prior_context_minutes':scenarios['PHD-S05']['prior_work_context_minutes'],'new_episode_actual':episode_result['current_actual_minutes'],'new_episode_progress':episode_result['personal_progress'],'prior_episode_actual':episode_result['actual_minutes']['H-PRIOR-EPISODE'],'prior_episode_progress':prior['personal_progress']['value']}
    extra('PHD-C12.episode_origin', scenarios['PHD-S06']['current']['progress_basis'] == 'system_default' and scenarios['PHD-S06']['current']['declaration_id'] is None and episode_result['episode_id'] == 'BL-WORK-PA-R01/E2', 'Reopened work retains current episode provenance')

    checks = []
    for control in controls:
        observed = actual[control['id']]
        for key, expected in control['expected'].items():
            checks.append({'id':'control.' + control['id'] + '.' + key,'passed':observed.get(key) == expected,'detail':control['title'] + ' — ' + key})
    return checks + extra_checks
