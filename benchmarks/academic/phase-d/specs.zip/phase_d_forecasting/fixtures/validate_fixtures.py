#!/usr/bin/env python3
"""Validate Phase D authored expectations, bounded controls and reference bytes."""

import argparse
import hashlib
import json
import runpy
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path


SCENARIO_IDS = {f'PHD-S{number:02d}' for number in range(1, 17)}
CASE_IDS = {f'PHD-T{number:02d}' for number in range(1, 29)}
MISSING = object()


def load(root, relative):
    return json.loads((root / relative).read_text(encoding='utf-8'))


def expectation_checks(expected, actual, prefix):
    checks = []
    if isinstance(expected, dict):
        values = actual if isinstance(actual, dict) else {}
        for key, value in expected.items():
            checks += expectation_checks(value, values.get(key, MISSING), prefix + '.' + key)
    else:
        checks.append({
            'id': prefix,
            'passed': actual is not MISSING and actual == expected,
            'detail': 'Independent authored expected value matches bounded evaluation',
        })
    return checks


def validate(root, verify_hashes=True):
    root = Path(root)
    checks = []

    def check(identifier, condition, detail):
        checks.append({'id': identifier, 'passed': bool(condition), 'detail': detail})

    model = runpy.run_path(str(root / 'fixtures/reference_forecasting.py'))
    control_model = runpy.run_path(str(root / 'fixtures/control_checks.py'))
    scenarios = load(root, 'fixtures/scenarios.json')
    expected = load(root, 'fixtures/expected.json')
    histories = load(root, 'fixtures/history.json')
    schedules = load(root, 'fixtures/schedules.json')
    policy = load(root, 'fixtures/policy.json')
    controls = load(root, 'fixtures/contract_controls.json')
    expected_by_id = {row['scenario_id']: row['expected'] for row in expected['results']}
    check('scenarios.identities', len(scenarios['scenarios']) == 16 and {row['id'] for row in scenarios['scenarios']} == SCENARIO_IDS, 'Sixteen unique scenarios')
    check('expected.identities', len(expected['results']) == 16 and set(expected_by_id) == SCENARIO_IDS, 'One independent expected vector per scenario')
    check('policy.history_limit', policy['history_limit'] == 20, 'Twenty most recent independent training scopes')
    check('policy.prior_weight', policy['shrinkage_prior_weight'] == 3, 'Reference shrinkage prior weight is three')
    check('policy.budget', policy['planning_budget'] == 'published_high', 'Current upper estimate is the default budget')
    check('policy.support', policy['support_labels'] == {'0': 'cold_start', '1_or_2': 'limited_history', '3_or_more': 'supported_history'}, 'Model support labels map directly to the contract')
    check('policy.buffer', policy['buffer_policy'] == 'end_only_per_supplied_availability_window', 'Window buffer policy is explicit')
    history_ids = {row['history_id'] for row in histories['histories']}
    schedule_ids = {row['schedule_id'] for row in schedules['schedules']}
    check('history.identities', len(history_ids) == len(histories['histories']), 'History examples have unique identities')
    check('schedule.identities', len(schedule_ids) == len(schedules['schedules']), 'Candidate schedule packets have unique identities')
    for filename, data in [('scenarios', scenarios), ('expected', expected), ('history', histories), ('schedules', schedules)]:
        check(filename + '.synthetic', data['synthetic'] and data['product_execution_count'] == data['actual_host_execution_count'] == 0, 'Data is explicitly synthetic with zero actual feature execution')
    check('controls.identities', len(controls['controls']) == len({row['id'] for row in controls['controls']}) == 12, 'Twelve unique supplemental control groups')
    for control in controls['controls']:
        check(control['id'] + '.acceptance_refs', set(control.get('acceptance_ids', [])) <= CASE_IDS, 'Supplemental acceptance references resolve')
        check(control['id'] + '.scenario_refs', set(control.get('scenario_ids', [])) <= SCENARIO_IDS, 'Supplemental scenario references resolve')
    for scenario in scenarios['scenarios']:
        identifier = scenario['id']
        if scenario['kind'] == 'forecast':
            check(identifier + '.input_refs', set(scenario['history_ids']) <= history_ids, 'Forecast history references resolve')
        else:
            check(identifier + '.input_refs', scenario['schedule_id'] in schedule_ids, 'Candidate schedule reference resolves')
        check(identifier + '.execution', scenario['execution_status'] == 'not_run' and scenario['actual_product_execution_count'] == scenario['actual_host_execution_count'] == 0, 'Actual product and host scenario execution remains pending')
        try:
            actual = model['evaluate'](root, scenario)
            if 'selected_blocks' in actual:
                actual['selected_block_ids'] = sorted(block['block_id'] for block in actual['selected_blocks'])
            checks += expectation_checks(expected_by_id[identifier], actual, identifier + '.expected')
        except Exception as error:
            check(identifier + '.evaluation', False, type(error).__name__ + ' during bounded evaluation')
    try:
        checks += control_model['run_controls'](root)
    except Exception as error:
        check('controls.evaluation', False, type(error).__name__ + ' during supplemental control evaluation')

    provenance = load(root, 'reference/provenance.json')
    check('reference.count', provenance['files_copied'] == len(provenance['files']) == 6, 'Six exact upstream reference files')
    if verify_hashes:
        for item in provenance['files']:
            path = Path(item['path'])
            safe = not path.is_absolute() and '..' not in path.parts
            source = root / 'reference' / path
            matches = safe and source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest() == item['sha256']
            if matches and 'bytes' in item:
                matches = source.stat().st_size == item['bytes']
            check('reference.hash.' + item['path'], matches, 'Reference bytes match their delivered source')
    index_path = root / 'fixtures/index.json'
    if index_path.is_file():
        index = load(root, 'fixtures/index.json')
        check('index.scenarios', set(index['scenario_ids']) == SCENARIO_IDS, 'Index scenario inventory is exact')
        check('index.controls', set(index['control_ids']) == {row['id'] for row in controls['controls']}, 'Index control inventory is exact')
        listed = [item['path'] for item in index['files']]
        check('index.unique', len(listed) == len(set(listed)), 'Index file identities are unique')
        if verify_hashes:
            for item in index['files']:
                relative = Path(item['path'])
                safe = not relative.is_absolute() and '..' not in relative.parts
                path = root / relative
                matches = safe and path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'] and path.stat().st_size == item['bytes']
                check('index.hash.' + item['path'], matches, 'Exact fixture data hash and length')
    else:
        check('index.exists', False, 'Frozen fixture index is required')
    return checks


def negative_controls(root):
    root = Path(root)
    controls = []

    def mutate_expected(data, scenario_id, update):
        row = next(item for item in data['results'] if item['scenario_id'] == scenario_id)
        update(row['expected'])

    mutations = [
        ('prior_weight_changed', 'fixtures/policy.json', lambda data: data.update(shrinkage_prior_weight=30), 'policy.prior_weight'),
        ('history_window_changed', 'fixtures/policy.json', lambda data: data.update(history_limit=2), 'policy.history_limit'),
        ('recorded_actual_corrupted', 'fixtures/history.json', lambda data: next(row for row in data['histories'] if row['history_id'] == 'H-R3')['observations'][0].update(minutes=0), 'PHD-S02.expected.factor'),
        ('source_deadline_corrupted', 'fixtures/schedules.json', lambda data: data['schedules'][0]['tasks'][0].update(deadline='2026-11-01T00:00:00-04:00'), 'PHD-S09.expected.selected_candidate_id'),
        ('cold_start_fabricated_personalization', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S01', lambda row: row.update(training_count=1)), 'PHD-S01.expected.training_count'),
        ('outward_rounding_corrupted', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S02', lambda row: row['published'].update(high=67)), 'PHD-S02.expected.published.high'),
        ('explicit_zero_invented_minutes', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S04', lambda row: row['actual_minutes'].update({'H-ZERO': 1})), 'PHD-S04.expected.actual_minutes.H-ZERO'),
        ('future_history_leaked', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S07', lambda row: row.update(training_count=3)), 'PHD-S07.expected.training_count'),
        ('override_discarded', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S08', lambda row: row.update(planning_budget_minutes=68)), 'PHD-S08.expected.planning_budget_minutes'),
        ('unnecessary_block_move', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S09', lambda row: row.update(selected_candidate_id='reshuffle')), 'PHD-S09.expected.selected_candidate_id'),
        ('shortfall_hidden', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S14', lambda row: row.update(unscheduled_minutes=0)), 'PHD-S14.expected.unscheduled_minutes'),
        ('dst_wall_time_used', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S15', lambda row: row.update(free_minutes=90)), 'PHD-S15.expected.free_minutes'),
        ('replay_duplicated_effect', 'fixtures/expected.json', lambda data: mutate_expected(data, 'PHD-S16', lambda row: row['execution'].update(actual_effect_count=3)), 'PHD-S16.expected.execution.actual_effect_count'),
    ]
    with tempfile.TemporaryDirectory(prefix='phase-d-fixture-controls-') as directory:
        work = Path(directory) / 'package'
        shutil.copytree(root, work)
        for identifier, relative, mutation, target_check in mutations:
            path = work / relative
            original = path.read_text(encoding='utf-8')
            data = json.loads(original)
            mutation(data)
            path.write_text(json.dumps(data), encoding='utf-8')
            checks = validate(work, verify_hashes=False)
            rejected = any(check['id'] == target_check and not check['passed'] for check in checks)
            controls.append({'id': identifier, 'passed': rejected, 'detail': 'Deliberate corrupted policy or oracle is rejected by its targeted semantic check with hashes disabled'})
            path.write_text(original, encoding='utf-8')
    return controls


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--negative-controls', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    checks = validate(root)
    controls = negative_controls(root) if args.negative_controls else []
    passed = all(item['passed'] for item in checks + controls)
    result = {
        'schema_version': 'phase-d-fixture-validation.v1',
        'executed_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'pass' if passed else 'fail',
        'product_execution_count': 0,
        'actual_host_execution_count': 0,
        'provider_execution_count': 0,
        'summary': {
            'checks': len(checks), 'passed': sum(item['passed'] for item in checks),
            'scenarios': 16, 'control_groups': 12, 'negative_controls': len(controls),
            'negative_controls_passed': sum(item['passed'] for item in controls),
        },
        'checks': checks,
        'negative_controls': controls,
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], **result['summary'], 'product_execution_count': 0, 'actual_host_execution_count': 0, 'provider_execution_count': 0, 'failed_checks': [item['id'] for item in checks + controls if not item['passed']]}, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
