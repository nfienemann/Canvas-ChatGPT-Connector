# Check an interrupted apply

The calendar update stopped partway through. Check which study-block changes were confirmed, reconcile any uncertain result and finish the remaining update through the existing workflow. Show the current saved plan and confirmed calendar status.

# Restore a previous change

Restore the schedule changes from that replan while retaining the appointment I moved afterward and my later work-progress entry. Explain any specific overlap that needs a decision.
