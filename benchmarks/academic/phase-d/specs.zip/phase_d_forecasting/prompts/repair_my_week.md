# Repair the accepted week

The brief changed and the presentation needs another revision. Update the remaining-work forecast and fit it into my existing study plan. Keep my locked appointments and preserve useful blocks. Explain any necessary moves and any work that still does not fit.

# Preserve a valid plan

Refresh my estimates from the latest recorded work. Keep the accepted schedule where it still covers the work and show any changed forecast or reservation slack.
