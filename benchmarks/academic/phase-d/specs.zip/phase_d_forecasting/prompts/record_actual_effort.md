# Record scoped actual work

I spent 45 minutes actively revising the current presentation draft today. That covers the technical explanation section, and that section is now finished. Record the time against that work episode and show which estimate it can be compared with.

# Correct a previous record

The earlier 45-minute entry included a 10-minute break. Correct the active work to 35 minutes, retain the original entry in its history, and update any current forecast that uses it.
