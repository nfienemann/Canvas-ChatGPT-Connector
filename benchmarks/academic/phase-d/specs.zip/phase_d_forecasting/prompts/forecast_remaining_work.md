# Forecast current work

How much time should I reserve for the remaining presentation revisions? Use the current requirements and my comparable completed work. Show the working range, the time you would schedule and how much personal history supports the adjustment.

# Current estimate override

For this revision episode, use my estimate of 40 to 60 minutes. Keep your modeled suggestion available and plan from my current estimate.
