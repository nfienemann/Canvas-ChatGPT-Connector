# Phase D implementation handoff

Implement the five PHD specifications against active Stage 6 observations, Phase C reconciled work and current planning/calendar interfaces. Deliver a normal workflow from recorded effort to a scoped forecast and a stable, recoverable plan update.

## 1. Bind the active implementation

Read repository instructions. Capture branch, commit, dirty diff fingerprint, runtime, host and current tool schemas in `templates/active_build_bindings.json`.

Resolve the candidate source map to active implementations. The reviewed public source includes positive `Effort` ranges, current progress, saved plan versions, deterministic planning, process feasibility, calendar markers and replay receipts. Bind the implemented Stage 6 frozen forecast/actual records and Phase C work episodes before adding overlapping storage.

The pinned `Effort.origin` enum has four values. Preserve its current meaning through a typed forecast association or deliberate compatible extension. Explicit zero actual duration belongs to its observation record. Current completed/zero-remaining work uses the eligibility adapter.

## 2. Preserve comparable actuals and forecasts

Accept explicit duration and supported active intervals through the current workflow. Keep logical observation identity, revision, effective work time, `known_at`, coverage, completion basis and work episode.

Deduplicate retries and linked alternate representations. Apply correction revisions at the selected knowledge cutoff. Union compatible intervals and account for pauses. Unresolved cross-task overlap remains localized to its affected observations.

Freeze the issued baseline and published forecast with the future work boundary it predicted. Pair complete actual work from that same scope. A remaining-work forecast uses work after its declared boundary. Duration summaries crossing that boundary require an explicit supported allocation.

Count independent measured scopes for learning. Multiple forecasts joined to one actual scope do not increase its training weight. Overlapping nested scopes retain one training unit unless measured disjoint work supports independent units. Preserve other prospective evaluations with their named populations.

## 3. Produce a current forecast

Use `contracts/forecast_policy.json` as the reference policy. Its defaults are twenty recent eligible units and prior weight three. History matches student, task family, scope kind and baseline policy. Completion and selected revision knowledge time are inclusive at the forecast cutoff, with the target outcome excluded.

Compute the median actual-to-positive-uncalibrated-baseline-point ratio and the declared shrinkage factor. Preserve exact raw arithmetic and publish the documented rounded range/point. Record the current upper-bound planning budget or an explicit supported alternative.

Maintain baseline, personalized suggestion and effective user override separately. A current scoped override controls the actual demand. A history correction changes subsequent forecasts while original predictions retain their evaluation identity. New or materially changed episodes use current scope and estimate applicability.

Use actual prospective completed pairs to compare point, range and budget behavior. Each metric retains its own denominator and paired baseline. Publish observed quality with workload, cohort and measurement context.

## 4. Repair the accepted plan

Bind one current planning/feasibility engine and declare its exact time policy. `planning.propose` and `processes.feasibility` differ in buffering. Use the selected definition consistently for capacity and schedules.

Assign persistent logical block IDs on the current plan path. Preserve IDs and owned provider-event mapping across moves. Capture the accepted base plan, current work/forecast versions, availability/busy snapshots and source timing.

Protect locked, started and applicable user-edited commitments. The pinned planner expects future pins, so a started-block adapter retains the original provider interval while only its future remainder consumes future capacity and credits current remaining demand.

Evaluate repair candidates in the contract's declared order. Feasibility and prioritized unmet work precede churn. Preserve a valid covering plan. Add capacity for deficits and consider relocating lower-priority flexible work when it helps higher-priority completion. Record affected block actions and reasons.

Report known unscheduled minutes, unknown demand, protected conflicts and unresolved dependencies. Reuse existing infeasibility certificates where supported. Preserve a bounded search failure's actual scope and avoid treating its candidate set as exhaustive when it is not.

## 5. Save, apply and recover

Persist the plan/forecast generation and provider operation intent coherently through current versioned state. Recheck work, history, plan and provider bases at affected mutations. Preserve concurrent user progress and calendar moves while rebasing the dependent proposal.

Track provider operations individually with stable block identity, expected provider revision, logical request, attempt and receipt. Study-block identity remains distinct from assignment deadline markers. An unchanged block generates no provider mutation.

A partially successful apply retains confirmed operations and unresolved attempts. Reconcile a lost response through current provider receipt or owned-event identity lookup before repeating a create. Restarted processing resumes the remaining operations with their original logical identities.

An explicit restoration creates a scoped compensating revision and matching owned calendar operations against current state. Preserve unrelated later edits and retain partial compensation status when relevant.

## 6. Explain and execute acceptance

Ordinary prompts in `prompts/` cover work logging, forecasting, week repair and recovery. The final answer should make current remaining scope, selected budget, history support, changed commitments, unscheduled work and actual confirmation status understandable.

Run `validate_package.py --negative-controls` and bind all sixteen scenarios to the actual interfaces. The fixture evaluator accepts authored records and bounded candidate sets. Actual product acceptance captures the source/progress adapters, forecast computation, current planner and store/provider operations.

Complete PHD-T01 through PHD-T28 with exact retained requests, responses, before/after state, calculation traces and receipts. Label in-process provider doubles, provider test accounts and live owned scopes according to the actual boundary. Track product runs, host journeys, provider calls and test-double effects independently.

Run focused existing effort, progress, planner, feasibility, state and calendar tests. Reuse applicable A/B/C and Stage 6 controls and comparable executed baselines. Deliver the implementation diff, actual case report, host captures, forecast/plan examples, restarted recovery results and Phase E interface handoff.
