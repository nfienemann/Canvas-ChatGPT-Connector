# Phase D — Personalized forecasting and stable replanning

Phase D learns from explicitly recorded comparable effort, forecasts current remaining work and repairs an accepted schedule with stable task and calendar identities. It extends Phase C's reconciled episodes and Stage 6's frozen forecast/actual observations.

Begin with `CODEX_HANDOFF.md`. The JSON preparation report is `report.json`, and actual implementation results belong in `templates/implementation_report.json`.

## Specification set

| Specification | Outcome |
| --- | --- |
| `PHD-01` | Scoped actual-effort observations, corrections and comparable frozen forecast history. |
| `PHD-02` | Versioned personalized forecasts with explicit baseline, support, rounding and user overrides. |
| `PHD-03` | Stable accepted-plan repair with current constraints, block identities and measured churn. |
| `PHD-04` | Normal workflow integration, coherent saved state and recoverable calendar effects. |
| `PHD-QA-01` | Actual adapter/host acceptance, prospective quality evaluation and upstream compatibility. |

The package includes 28 acceptance cases, 16 scenarios, 20 model invariants, eight bounded measures and a ten-check host rubric. Source mappings identify current implementation primitives. The synthetic evaluator receives authored records and candidate plans.

## Effort and forecasting

Actual duration records identify their user, work episode, measured scope, observation revision, work period, knowledge time and coverage. Explicit zero remains a valid measurement. A future remaining-work forecast keeps its original baseline and published values when a later progress update changes the current estimate.

The reference policy uses at most twenty recent eligible independent completed scopes from the same student, task family, scope kind and baseline policy. Its factor is

```text
factor = (3 + n × median(actual minutes / frozen baseline point)) / (3 + n)
```

With no eligible history, the factor is one. One or two pairs retain `limited_history` support. The factor scales the uncalibrated baseline once. Publication rounds the positive lower bound down with a one-minute minimum, rounds the upper bound up, and half-up rounds the point into that finalized range. The selected planning budget initially uses the upper bound, matching the existing planner.

These are versioned implementation choices. An active equivalent can supply the behavior with a recorded policy mapping and comparable acceptance evidence. The working range retains its estimation meaning. Prospective error and interval coverage use later compatible completed outcomes with their actual sample counts.

Current scoped user estimates control effective demand while the model suggestion remains inspectable. Partial actuals, unknown durations, range-only forecasts and unmatched scope retain the measurements they support. Completed or explicitly zero-remaining work maps through current eligibility, and reopened Phase C episodes receive their own demand.

## Schedule repair

The reference comparison first checks hard and protected constraints, then prioritized unmet minutes. Among candidates with equivalent service, it minimizes changed existing blocks, start displacement and duration changes, followed by a stable tie-break.

| Situation | Expected response |
| --- | --- |
| Updated estimate still fits accepted reservations | Preserve the accepted blocks and expose the current forecast. |
| More remaining work | Add useful capacity and repair the affected flexible allocation. |
| Earlier deadline or new busy time | Reconsider affected blocks, retaining applicable protected commitments and explicit conflicts. |
| Lower-priority flexible work prevents urgent work fitting | Consider moving that flexible allocation before accepting higher-priority shortfall. |
| Work resolves, retires or reopens | Apply the current episode's demand and owned-block lifecycle. |
| Capacity is insufficient | Report supported unscheduled minutes and the capacity proof or constraint reason. |
| Bounded search finds no complete candidate | Report the search result and its evaluated scope. |

Existing planning and process-feasibility engines supply time, availability, prerequisites and work accounting. Each result records its selected engine and buffer/break policy. The fixture uses an end-only buffer applied once per supplied availability window. Durations use UTC elapsed time, with local timezone context retained for display.

Locked, started and applicable student-edited blocks retain their ownership. A started block keeps its full logical/provider interval while only its future remainder consumes future capacity and credits current remaining demand. Block IDs survive moves, and provider updates use the stored owned-event mapping.

## Recovery and ordinary interaction

Accepted Stage 5 behavior supplies ordinary source, owned-state and calendar actions. Phase D uses current progress updates, Phase C reconciliation and planning requests as triggers.

The saved local plan generation and provider operations carry their own confirmation records. Partial provider success remains visible. After a lost response or restart, stable operation/block identity supports reconciliation before an unresolved create is retried. Current user edits are checked against expected state and provider versions.

## Contents and validation

- `specs/` contains five implementation specifications.
- `contracts/` defines observations, forecasts, repair policy, apply/recovery, execution capture and host fidelity.
- `fixtures/` contains authored effort histories, forecast inputs, candidate schedules, expected vectors and standalone checks.
- `reference/` contains a narrow exact upstream reference slice with provenance.
- `prompts/` contains ordinary work-log, forecast, plan-repair and recovery journeys.
- `templates/` contains active-build bindings and unexecuted run/report records.
- `evidence/` contains source mapping, design review and executed local validation.

Run the package validator with Python 3.11 or later. Named-zone checks use the runtime's IANA timezone database through Python's `zoneinfo`.

```bash
python /path/to/phase_d_forecasting/validate_package.py --negative-controls
```

The optional `--source-root` argument rechecks source bytes against a local checkout of the pinned public commit. The fixture validator can also run independently.

```bash
python /path/to/phase_d_forecasting/fixtures/validate_fixtures.py --negative-controls
```

Product completion requires the actual current-adapter and supported-host cases, including real persistence restart and the declared provider boundary. The supplied implementation templates start with zero product, host and provider executions.
