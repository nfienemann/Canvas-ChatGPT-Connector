#!/usr/bin/env python3
"""Validate the frozen Phase D specifications, reference policy and fixtures."""

import argparse
import hashlib
import json
import runpy
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path


SPEC_IDS = {'PHD-01', 'PHD-02', 'PHD-03', 'PHD-04', 'PHD-QA-01'}
CASE_IDS = {f'PHD-T{number:02d}' for number in range(1, 29)}
SCENARIO_IDS = {f'PHD-S{number:02d}' for number in range(1, 17)}
COMMIT = '29652557b5701df6eb9147ac232fd3c656449104'
CHECKSUM_EXCLUSIONS = {'SHA256SUMS', 'evidence/package_validation.json'}
STABILITY_ORDER = [
    'hard_and_protected_validity',
    'prioritized_unmet_vector',
    'changed_existing_block_count',
    'absolute_start_displacement_minutes',
    'absolute_duration_change_minutes',
    'stable_tie_break',
]


def load(root, relative):
    return json.loads((root / relative).read_text(encoding='utf-8'))


def validate_structure(root):
    checks = []

    def check(identifier, condition, detail):
        checks.append({'id': identifier, 'passed': bool(condition), 'detail': detail})

    json_files = sorted(root.rglob('*.json'))
    for path in json_files:
        json.loads(path.read_text(encoding='utf-8'))
    check('json.parse', bool(json_files), f'Parsed {len(json_files)} JSON files')

    specs = [load(root, path.relative_to(root)) for path in sorted((root / 'specs').glob('*.json'))]
    spec_by_id = {spec['id']: spec for spec in specs}
    check('spec.identities', len(specs) == 5 and set(spec_by_id) == SPEC_IDS, 'Five unique agreed specifications')
    cases = load(root, 'acceptance_cases.json')
    design = load(root, 'evidence/acceptance_design_review.json')
    check('cases.identities', len(cases['cases']) == 28 and {case['id'] for case in cases['cases']} == CASE_IDS, 'Twenty-eight unique acceptance cases')
    for spec in specs:
        identifier = spec['id']
        requirement_ids = [item['id'] for item in spec['requirements']]
        check(identifier + '.requirements', len(requirement_ids) == len(set(requirement_ids)) == 10, 'Ten unique detailed requirements')
        check(identifier + '.cases', set(spec['acceptance_cases']) <= CASE_IDS, 'Acceptance references resolve')
        check(identifier + '.dependencies', set(spec['dependencies']) <= SPEC_IDS - {identifier}, 'Dependencies resolve within supplied specifications')
        check(identifier + '.commit', spec['reviewed_public_commit'] == COMMIT, 'Source pin is consistent')
    check('cases.owner_links', all(case['owner_spec'] in spec_by_id and case['id'] in spec_by_id[case['owner_spec']]['acceptance_cases'] for case in cases['cases']), 'Every case resolves to its owner')
    check('cases.spec_coverage', set().union(*(set(spec['acceptance_cases']) for spec in specs)) == CASE_IDS, 'Specifications cover all acceptance cases')
    check('cases.scenario_links', all(set(case['scenario_ids']) <= SCENARIO_IDS for case in cases['cases']), 'Scenario references resolve')
    check('cases.scenario_coverage', set().union(*(set(case['scenario_ids']) for case in cases['cases'])) == SCENARIO_IDS, 'Every scenario has acceptance coverage')
    check('cases.prepared', cases['actual_product_executions'] == cases['actual_host_executions'] == 0 and all(case['execution_status'] == case['verdict'] == 'not_run' and case.get('observed_result') is None and not case['observed_evidence_refs'] for case in cases['cases']), 'Acceptance remains unexecuted')
    reviewed = {case['id']: case for case in design['acceptance_cases']}
    check('cases.review_alignment', all({key: case[key] for key in original} == original for case in cases['cases'] for original in [reviewed[case['id']]]), 'Case content agrees with the independent acceptance design')

    scope = load(root, 'scope_and_roadmap.json')
    order = scope['implementation_order']
    check('scope.roadmap', scope['selected_phase'] == 'D' and [item['phase'] for item in scope['phase_ownership']] == list('ABCDEF'), 'Agreed A–F roadmap is retained')
    check('scope.order', len(order) == 5 and set(order) == SPEC_IDS, 'Five-step implementation order')
    check('scope.topology', all(order.index(dependency) < order.index(spec['id']) for spec in specs for dependency in spec['dependencies']), 'Order satisfies specification dependencies')
    check('scope.execution', scope['actual_product_executions'] == scope['actual_host_executions'] == 0, 'Preparation has zero actual feature executions')

    contract = load(root, 'contracts/effort_forecast_contract.json')
    forecast = load(root, 'contracts/forecast_policy.json')
    replan = load(root, 'contracts/replanning_policy.json')
    apply = load(root, 'contracts/plan_apply_contract.json')
    host = load(root, 'contracts/host_fidelity_rubric.json')
    execution = load(root, 'contracts/execution_capture.json')
    check('contract.invariants', contract['invariants'] == design['invariant_suggestions'] and len(contract['invariants']) == len({item['id'] for item in contract['invariants']}) == 20, 'Twenty unique reviewed invariants')
    check('contract.actual_scope', {'actual_scope_id', 'work_episode_id', 'known_at', 'coverage', 'revision', 'measurement_basis'} <= set(contract['actual_observation']), 'Actual observations retain scope, revision and measurement basis')
    check('contract.forecast_scope', {'baseline_ref', 'training_snapshot_id', 'forecast_cutoff', 'work_episode_id', 'remaining_scope', 'raw_adjusted_values', 'published_range', 'published_point', 'planning_budget'} <= set(contract['forecast_record']), 'Forecasts retain frozen baseline, cutoff, scope and publication basis')
    check('contract.identity', set(contract['identity_axes']) == {'work', 'observation', 'forecast', 'plan'}, 'Four identity layers are explicit')
    check('contract.support', set(contract['enums']['forecast_support']) == {'cold_start', 'limited_history', 'supported_history', 'user_override', 'baseline_unknown'}, 'Forecast support includes sparse and missing-input results')
    check('contract.provider_states', {'confirmed', 'failed', 'outcome_unknown', 'pending'} <= set(contract['enums']['provider_operation_status']), 'Provider outcomes retain their independent confirmation state')
    check('forecast.reference_policy', forecast['policy_id'] == 'median_ratio_shrinkage_v1' and forecast['max_training_units'] == 20 and forecast['prior_weight'] == 3 and forecast['cutoff_inclusive'] is True, 'Versioned reference learning parameters are exact')
    check('forecast.empty_history', forecast['empty_history_factor'] == {'numerator': 1, 'denominator': 1}, 'Cold start retains the baseline factor')
    check('forecast.cohort', forecast['cohort_keys'] == ['student_scope', 'task_family', 'scope_kind', 'baseline_policy_version'], 'Declared cohort keys are complete')
    check('forecast.rounding', forecast['publication']['active_positive_low'] == 'max(1, floor(raw_low))' and forecast['publication']['active_positive_high'] == 'max(published_low, ceil(raw_high))' and forecast['publication']['active_positive_point'] == 'clamp(floor(raw_point + 1/2), published_low, published_high)' and forecast['publication']['default_budget'] == 'published_high', 'Reference publication and budget rules are exact')
    check('replan.order', replan['comparison_order'] == STABILITY_ORDER == design['agreed_model']['stable_policy_order'], 'Feasibility and prioritized service precede churn')
    check('replan.buffer', replan['buffer_binding']['fixture_policy'] == 'end_only_per_supplied_availability_window', 'Reference capacity policy is named')
    check('apply.capture', {'logical_block_id', 'logical_operation_id', 'attempt_id', 'expected_provider_revision', 'receipt_ref'} <= set(apply['operation_identity_fields']), 'Provider operations carry stable identity and expected-base evidence')
    check('host.rubric', len(host['checks']) == len({item['id'] for item in host['checks']}) == 10 and host['checks'] == design['host_fidelity_checks'], 'Ten reviewed host-fidelity checks')
    check('execution.levels', set(execution['execution_levels']) == {'deterministic_contract_test', 'current_adapter_integration', 'native_host_journey'}, 'Three distinct execution levels')

    scenarios = load(root, 'fixtures/scenarios.json')
    fixture_policy = load(root, 'fixtures/policy.json')
    check('fixtures.scenarios', len(scenarios['scenarios']) == 16 and {item['id'] for item in scenarios['scenarios']} == SCENARIO_IDS, 'Sixteen unique transition scenarios')
    check('fixtures.execution_scope', scenarios['synthetic'] and scenarios['evaluator_only'] and scenarios['product_execution_count'] == scenarios['actual_host_execution_count'] == 0 and all(item['execution_status'] == 'not_run' and item['actual_product_execution_count'] == item['actual_host_execution_count'] == 0 for item in scenarios['scenarios']), 'Fixture scenarios remain explicitly synthetic and unexecuted against the product')
    check('fixtures.policy_parameters', fixture_policy['history_limit'] == forecast['max_training_units'] and fixture_policy['shrinkage_prior_weight'] == forecast['prior_weight'] and fixture_policy['planning_budget'] == forecast['publication']['default_budget'], 'Fixture numeric choices match the contract')

    report = load(root, 'templates/implementation_report.json')
    capture = load(root, 'templates/product_run_capture.json')
    active_bindings = load(root, 'templates/active_build_bindings.json')
    summary = report['execution_summary']
    execution_counts = ['actual_product_executions', 'actual_host_executions', 'process_restarts_tested', 'provider_calls', 'confirmed_provider_effects', 'test_double_effects']
    check('templates.no_product_credit', report['phase_d_completion'] == 'prepared' and all(summary[key] == 0 for key in execution_counts) and not report['run_capture_refs'], 'Template claims zero actual feature, host, restart and provider evidence')
    check('templates.case_results', len(report['case_results']) == 28 and {item['case_id'] for item in report['case_results']} == CASE_IDS and all(item['execution_status'] == item['verdict'] == 'not_run' and not item['evidence_refs'] for item in report['case_results']), 'All actual case results remain pending')
    check('templates.summary', summary['scoped_cases'] == summary['not_run'] == 28 and summary['passed'] == summary['failed'] == summary['blocked'] == 0, 'Actual case accounting matches pending results')
    check('templates.measures', len(report['measures']) == len({item['id'] for item in report['measures']}) == 8 and all(item['observed'] is None and item['execution_status'] == 'not_run' and not item['evidence_refs'] for item in report['measures']), 'Eight measures retain null observations')
    null_capture_fields = ['run_id', 'tested_commit', 'forecast_ref', 'selected_plan_ref', 'local_receipt_ref', 'restart_read_ref', 'compensation_ref', 'final_answer_ref']
    empty_capture_fields = ['call_records', 'provider_operation_refs', 'confirmed_effect_refs', 'test_double_effect_refs']
    check('templates.capture', capture['execution_status'] == 'not_run' and all(capture[key] is None for key in null_capture_fields) and all(not capture[key] for key in empty_capture_fields), 'Capture template contains no fabricated forecast, operation or host result')
    check('templates.bindings', active_bindings['execution_status'] == 'not_run' and active_bindings['commit'] is None and len(active_bindings['bindings']) == 11 and all(item['support_status'] == 'not_checked' and item['actual_route_or_symbol'] is None for item in active_bindings['bindings']), 'Eleven current interfaces await active binding')
    check('templates.completion_model', report['completion_model'] == cases['completion_model'] == design['completion_model'] == execution['completion_model'], 'Completion rules agree across the package')

    bindings = load(root, 'evidence/source_bindings.json')
    capabilities = load(root, 'evidence/capability_map.json')
    files = bindings['files']
    anchors = [anchor for item in files for anchor in item['reviewed_anchors']]
    anchor_ids = {anchor['id'] for anchor in anchors}
    check('source.revision', bindings['reviewed_commit'] == capabilities['reviewed_commit'] == COMMIT, 'Source map shares the reviewed public pin')
    check('source.files', len(files) == len({item['path'] for item in files}) == bindings['files_verified'] == 45, 'Forty-five unique verified source files')
    check('source.anchors', len(anchors) == len(anchor_ids) == bindings['source_anchors'] == 143, 'One hundred forty-three unique source anchors')
    check('source.ranges', all(1 <= anchor['start_line'] <= anchor['end_line'] <= item['line_count'] for item in files for anchor in item['reviewed_anchors']), 'Anchor ranges fit their pinned files')
    check('source.hash_records', bindings['all_files_match_reviewed_commit'] and all(item['local_git_blob_verified'] and item['commit'] == COMMIT and len(item['sha256']) == 64 for item in files), 'Source hash records are complete')
    check('source.static_scope', bindings['product_feature_tests_executed'] == bindings['source_test_execution_count'] == capabilities['product_feature_tests_executed'] == capabilities['source_test_execution_count'] == 0 and not bindings['active_implementation_branch_verified'] and not bindings['installed_plugin_version_verified'], 'Static source review records its actual execution boundary')
    check('source.capabilities', len(capabilities['capabilities']) == 16 and all(set(item['source_anchor_refs']) <= anchor_ids and set(item['owner_specs']) <= SPEC_IDS for item in capabilities['capabilities']), 'Sixteen capabilities resolve sources and owners')
    check('source.routes', len(capabilities['route_contracts']) == 17 and all(set(item['source_anchor_refs']) <= anchor_ids for item in capabilities['route_contracts']), 'Seventeen current routes resolve source anchors')
    check('source.seams', len(capabilities['minimal_implementation_seams']) == 5 and all(set(item['source_anchor_refs']) <= anchor_ids and item['owner_spec'] in SPEC_IDS for item in capabilities['minimal_implementation_seams']), 'Five bounded seams resolve sources and owners')

    required = ['README.md', 'CODEX_HANDOFF.md', 'report.json', 'evidence/package_review.json', 'prompts/record_actual_effort.md', 'prompts/forecast_remaining_work.md', 'prompts/repair_my_week.md', 'prompts/check_recovery.md']
    check('package.deliverables', all((root / name).is_file() for name in required), 'All entry points, reports and prompts exist')
    if (root / 'report.json').is_file():
        preparation = load(root, 'report.json')
        check('report.prepared', preparation['phase_d_completion'] == 'prepared' and preparation['product_execution_count'] == preparation['actual_host_execution_count'] == preparation['provider_execution_count'] == 0, 'Preparation report preserves actual execution scope')
        check('report.counts', preparation['counts']['specifications'] == 5 and preparation['counts']['acceptance_cases'] == 28 and preparation['counts']['transition_scenarios'] == 16, 'Report counts match the supplied packet')
    return checks


def validate_checksums(root):
    expected = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file() and path.relative_to(root).as_posix() not in CHECKSUM_EXCLUSIONS}
    listed = set()
    checks = []
    for line in (root / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, relative = line.split('  ', 1)
        path = Path(relative)
        safe = not path.is_absolute() and '..' not in path.parts
        exists = safe and (root / path).is_file()
        matches = exists and hashlib.sha256((root / path).read_bytes()).hexdigest() == digest
        checks.append({'id': 'checksum.' + relative, 'passed': bool(matches and relative not in listed), 'detail': 'Exact SHA-256 and unique safe relative path'})
        listed.add(relative)
    checks.append({'id': 'checksum.inventory', 'passed': listed == expected, 'detail': f'Manifest covers {len(expected)} frozen files. The manifest and regenerable validation report are excluded.'})
    return checks


def validate_source_bytes(root, source_root):
    checks = []
    for item in load(root, 'evidence/source_bindings.json')['files']:
        path = source_root / item['path']
        matches = False
        if path.is_file():
            data = path.read_bytes()
            blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
            matches = blob == item['git_blob_sha'] and hashlib.sha256(data).hexdigest() == item['sha256']
        checks.append({'id': 'source_bytes.' + item['path'], 'passed': matches, 'detail': 'Exact pinned Git blob and SHA-256 verification'})
    return checks


def negative_controls(root):
    results = []
    mutations = [
        ('fabricated_product_completion', 'templates/implementation_report.json', 'templates.no_product_credit'),
        ('changed_prior_weight', 'contracts/forecast_policy.json', 'forecast.reference_policy'),
        ('churn_before_service', 'contracts/replanning_policy.json', 'replan.order'),
    ]
    with tempfile.TemporaryDirectory(prefix='phase-d-package-controls-') as directory:
        work = Path(directory) / 'package'
        shutil.copytree(root, work)
        for identifier, relative, check_id in mutations:
            path = work / relative
            original = path.read_text(encoding='utf-8')
            changed = json.loads(original)
            if identifier == 'fabricated_product_completion':
                changed['phase_d_completion'] = 'complete'
                changed['execution_summary']['actual_product_executions'] = 1
            elif identifier == 'changed_prior_weight':
                changed['prior_weight'] = 30
            else:
                order = changed['comparison_order']
                order[1], order[2] = order[2], order[1]
            path.write_text(json.dumps(changed), encoding='utf-8')
            checks = validate_structure(work)
            rejected = any(item['id'] == check_id and not item['passed'] for item in checks)
            results.append({'id': 'package.' + identifier, 'passed': rejected, 'detail': 'Targeted semantic rejection with checksum validation omitted'})
            path.write_text(original, encoding='utf-8')
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--source-root', type=Path, help='Optional checkout of the pinned public commit')
    parser.add_argument('--negative-controls', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    checks = validate_structure(root) + validate_checksums(root)
    fixture_validator = runpy.run_path(str(root / 'fixtures/validate_fixtures.py'))
    fixture_checks = fixture_validator['validate'](root)
    checks += [{**item, 'id': 'fixture.' + item['id']} for item in fixture_checks]
    if args.source_root:
        checks += validate_source_bytes(root, args.source_root.resolve())
    controls = []
    if args.negative_controls:
        controls += negative_controls(root)
        controls += [{**item, 'id': 'fixture.' + item['id']} for item in fixture_validator['negative_controls'](root)]
    passed = all(item['passed'] for item in checks + controls)
    result = {
        'schema_version': 'phase-d-package-validation.v1',
        'executed_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'pass' if passed else 'fail',
        'product_execution_count': 0,
        'actual_host_execution_count': 0,
        'provider_execution_count': 0,
        'summary': {
            'checks': len(checks), 'passed': sum(item['passed'] for item in checks),
            'fixture_checks': len(fixture_checks), 'negative_controls': len(controls),
            'negative_controls_passed': sum(item['passed'] for item in controls),
            'source_bytes_rechecked': args.source_root is not None,
        },
        'checksum_exclusions': sorted(CHECKSUM_EXCLUSIONS),
        'checks': checks,
        'negative_controls': controls,
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], **result['summary'], 'product_execution_count': 0, 'actual_host_execution_count': 0, 'provider_execution_count': 0, 'failed_checks': [item['id'] for item in checks + controls if not item['passed']]}, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
