#!/usr/bin/env python3
"""Validate the frozen Phase C specifications, fixtures and source bindings."""

import argparse
import hashlib
import json
import runpy
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path


SPEC_IDS = {"PHC-01", "PHC-02", "PHC-03", "PHC-04", "PHC-QA-01"}
CASE_IDS = {f"PHC-T{number:02d}" for number in range(1, 27)}
SCENARIO_IDS = {f"PHC-S{number:02d}" for number in range(1, 17)}
WORK_ACTIONS = {"keep", "update", "resolve", "retire", "create", "reopen", "review_needed"}
COMMIT = "29652557b5701df6eb9147ac232fd3c656449104"
CHECKSUM_EXCLUSIONS = {"SHA256SUMS", "evidence/package_validation.json"}


def load(root, relative):
    return json.loads((root / relative).read_text(encoding="utf-8"))


def validate_structure(root):
    checks = []

    def check(identifier, condition, detail):
        checks.append({"id": identifier, "passed": bool(condition), "detail": detail})

    json_files = sorted(root.rglob("*.json"))
    for path in json_files:
        json.loads(path.read_text(encoding="utf-8"))
    check("json.parse", bool(json_files), f"Parsed {len(json_files)} JSON files")

    specs = [load(root, path.relative_to(root)) for path in sorted((root / "specs").glob("*.json"))]
    spec_by_id = {spec["id"]: spec for spec in specs}
    check("spec.identities", len(specs) == 5 and set(spec_by_id) == SPEC_IDS, "Five unique agreed specifications")
    cases = load(root, "acceptance_cases.json")
    design = load(root, "evidence/acceptance_design_review.json")
    check("cases.identities", len(cases["cases"]) == 26 and {case["id"] for case in cases["cases"]} == CASE_IDS, "Twenty-six unique acceptance cases")
    for spec in specs:
        identifier = spec["id"]
        requirement_ids = [item["id"] for item in spec["requirements"]]
        check(identifier + ".requirements", len(requirement_ids) >= 10 and len(set(requirement_ids)) == len(requirement_ids), "Unique detailed requirements")
        check(identifier + ".cases", set(spec["acceptance_cases"]) <= CASE_IDS, "Acceptance references resolve")
        check(identifier + ".dependencies", set(spec["dependencies"]) <= SPEC_IDS - {identifier}, "Dependencies resolve to another supplied specification")
        check(identifier + ".commit", spec["reviewed_public_commit"] == COMMIT, "Source pin is consistent")
    check("cases.owner_links", all(case["owner_spec"] in spec_by_id and case["id"] in spec_by_id[case["owner_spec"]]["acceptance_cases"] for case in cases["cases"]), "Every case resolves to its owner specification")
    check("cases.spec_coverage", set().union(*(set(spec["acceptance_cases"]) for spec in specs)) == CASE_IDS, "Specifications cover all acceptance cases")
    check("cases.scenario_links", all(set(case["scenario_ids"]) <= SCENARIO_IDS for case in cases["cases"]), "Scenario references resolve")
    check("cases.scenario_coverage", set().union(*(set(case["scenario_ids"]) for case in cases["cases"])) == SCENARIO_IDS, "Every authored scenario has acceptance coverage")
    check("cases.prepared", cases["actual_product_executions"] == cases["actual_host_executions"] == 0 and all(case["execution_status"] == case["verdict"] == "not_run" and case["observed_result"] is None and not case["observed_evidence_refs"] for case in cases["cases"]), "Acceptance remains unexecuted")
    design_cases = {case["id"]: case for case in design["acceptance_cases"]}
    check("cases.review_alignment", all({key: case[key] for key in original} == original for case in cases["cases"] for original in [design_cases[case["id"]]]), "Acceptance content matches its independent design review")

    scope = load(root, "scope_and_roadmap.json")
    order = scope["implementation_order"]
    check("scope.roadmap", scope["selected_phase"] == "C" and [item["phase"] for item in scope["phase_ownership"]] == list("ABCDEF"), "Phase C retains the agreed A–F roadmap")
    check("scope.order", len(order) == 5 and set(order) == SPEC_IDS and scope["actual_product_executions"] == 0, "Implementation order and preparation status are explicit")
    check("scope.topology", all(order.index(dependency) < order.index(spec["id"]) for spec in specs for dependency in spec["dependencies"]), "Implementation order satisfies dependencies")

    contract = load(root, "contracts/change_contract.json")
    rules = load(root, "contracts/reconciliation_rules.json")
    host = load(root, "contracts/host_fidelity_rubric.json")
    execution = load(root, "contracts/execution_capture.json")
    enums = contract["enums"]
    check("contract.change_classes", set(enums["change_class"]) == {"alias_only", "content_equivalent", "content_changed", "unavailable", "incomparable"}, "Five comparison classes")
    check("contract.impacts", set(enums["impact_status"]) == {"unaffected", "affected", "unknown"}, "Three criterion impact decisions")
    check("contract.actions", set(enums["work_action"]) == WORK_ACTIONS and len(rules["actions"]) == 7 and {item["action"] for item in rules["actions"]} == WORK_ACTIONS, "Seven unique work decisions agree across contracts")
    check("contract.assessments", set(enums["inherited_assessment_status"]) == {"satisfied", "needs_work", "unknown", "conflict"}, "Phase B assessment states are retained")
    check("contract.precedence", enums["inherited_aggregate_priority"] == ["conflict", "needs_work", "unknown", "ready"], "Known findings retain precedence before unresolved scope")
    check("contract.invariants", len(contract["invariants"]) == 18 and len({item["id"] for item in contract["invariants"]}) == 18, "Eighteen unique transition invariants")
    check("contract.work_identity", set(contract["work_identity"]) == {"lineage", "episode", "occurrence"}, "Lineage, episode and occurrence retain explicit identity")
    check("contract.episode_default", rules["episode_default"] == {"personal_progress": "open", "progress_basis": "system_default", "declaration_id": None}, "New episode defaults have system provenance")
    check("contract.provenance_fields", {"original_assessment_id", "original_assessed_at", "original_assessor_basis", "dependency_proof_id", "carry_forward_validated_at", "measurement_original_hash"} <= set(contract["carry_forward"]), "Carry-forward preserves assessment and measurement provenance")
    check("contract.concurrent_binding", {"selected_base_revision", "selection_epoch", "source_parent_or_ordering", "observed_at"} <= set(contract["change_observation"]), "Observation chronology and current ordering have separate bindings")
    check("host.rubric", len(host["checks"]) == 10 and len({item["id"] for item in host["checks"]}) == 10, "Ten unique host fidelity checks")
    check("execution.levels", set(execution["execution_levels"]) == {"deterministic_contract_test", "current_adapter_integration", "native_host_journey"}, "Acceptance declares three execution levels")

    scenarios = load(root, "fixtures/scenarios.json")
    check("fixtures.scenarios", len(scenarios["scenarios"]) == 16 and {item["id"] for item in scenarios["scenarios"]} == SCENARIO_IDS, "Sixteen unique transition scenarios")
    check("fixtures.execution_scope", scenarios["synthetic"] and scenarios["evaluator_only"] and scenarios["product_execution_count"] == 0 and all(item["execution_status"] == "not_run" and item["actual_product_execution_count"] == item["actual_host_execution_count"] == 0 for item in scenarios["scenarios"]), "Authored scenarios retain synthetic, unexecuted product scope")

    report = load(root, "templates/implementation_report.json")
    capture = load(root, "templates/product_run_capture.json")
    active_bindings = load(root, "templates/active_build_bindings.json")
    summary = report["execution_summary"]
    check("templates.no_product_credit", report["phase_c_completion"] == "prepared" and summary["actual_product_executions"] == summary["actual_host_executions"] == summary["process_restarts_tested"] == 0 and report["run_capture_refs"] == [], "Report template claims zero actual product, host and restart execution")
    check("templates.case_results", len(report["case_results"]) == 26 and {item["case_id"] for item in report["case_results"]} == CASE_IDS and all(item["verdict"] == item["execution_status"] == "not_run" and not item["evidence_refs"] for item in report["case_results"]), "All actual acceptance results remain pending")
    check("templates.summary", summary["scoped_cases"] == summary["not_run"] == 26 and summary["passed"] == summary["failed"] == summary["blocked"] == 0, "Template case accounting matches its unexecuted records")
    check("templates.measures", len(report["measures"]) == 7 and len({item["id"] for item in report["measures"]}) == 7 and all(item["observed"] is None and item["execution_status"] == "not_run" and not item["evidence_refs"] for item in report["measures"]), "Seven bounded measures retain null observations")
    check("templates.capture", capture["execution_status"] == "not_run" and all(capture[key] is None for key in ["run_id", "tested_commit", "host_assessment_ref", "apply_receipt_ref", "restart_read_ref", "compensating_revision_ref", "final_answer_ref"]) and not capture["call_records"], "Run capture contains no fabricated invocation, receipt or host result")
    check("templates.bindings", active_bindings["execution_status"] == "not_run" and active_bindings["commit"] is None and len(active_bindings["bindings"]) == 10 and all(item["support_status"] == "not_checked" and item["actual_route_or_symbol"] is None for item in active_bindings["bindings"]), "Active implementation mapping awaits actual binding")
    check("templates.completion_model", report["completion_model"] == cases["completion_model"] == design["completion_model"] == execution["completion_model"], "Completion rules agree throughout the packet")

    bindings = load(root, "evidence/source_bindings.json")
    capabilities = load(root, "evidence/capability_map.json")
    files = bindings["files"]
    anchors = [anchor for item in files for anchor in item["reviewed_anchors"]]
    anchor_ids = {anchor["id"] for anchor in anchors}
    check("source.revision", bindings["reviewed_commit"] == capabilities["reviewed_commit"] == COMMIT, "Source records share the pinned public commit")
    check("source.files", len(files) == bindings["files_verified"] == 48 and len({item["path"] for item in files}) == 48, "Forty-eight unique reviewed files")
    check("source.anchors", len(anchors) == len(anchor_ids) == bindings["source_anchors"] == 175 and bindings["phase_c_added_anchors"] == 45, "One hundred seventy-five unique anchors including forty-five Phase C additions")
    check("source.ranges", all(1 <= anchor["start_line"] <= anchor["end_line"] <= item["line_count"] for item in files for anchor in item["reviewed_anchors"]), "All anchors lie inside their source files")
    check("source.hash_record", bindings["all_files_match_reviewed_commit"] and all(item["local_git_blob_verified"] and item["commit"] == COMMIT and len(item["sha256"]) == 64 and len(item["git_blob_sha"]) == 40 for item in files), "Pinned Git blob and SHA-256 records are complete")
    check("source.static_execution", bindings["product_feature_tests_executed"] == bindings["source_test_execution_count"] == capabilities["product_feature_tests_executed"] == capabilities["source_test_execution_count"] == 0 and not bindings["active_implementation_branch_verified"] and not bindings["installed_plugin_version_verified"], "Static review claims its actual execution scope")
    check("source.capabilities", len(capabilities["capabilities"]) == 16 and all(set(item["source_anchor_refs"]) <= anchor_ids and set(item["owner_specs"]) <= SPEC_IDS for item in capabilities["capabilities"]), "Sixteen capabilities resolve to sources and owner specs")
    check("source.routes", len(capabilities["route_contracts"]) == 12 and all(set(item["source_anchor_refs"]) <= anchor_ids for item in capabilities["route_contracts"]), "Twelve actual route contracts resolve source anchors")
    check("source.seams", len(capabilities["minimal_implementation_seams"]) == 5 and all(set(item["source_anchor_refs"]) <= anchor_ids and item["owner_spec"] in SPEC_IDS for item in capabilities["minimal_implementation_seams"]), "Five implementation seams resolve sources and owners")

    required_files = ["README.md", "CODEX_HANDOFF.md", "report.json", "prompts/review_changes.md", "prompts/replacement_unavailable.md", "prompts/recurring_work.md", "prompts/restore_reconciliation.md", "evidence/package_review.json"]
    check("package.deliverables", all((root / path).is_file() for path in required_files), "Entry points, prompts, report and review exist")
    if (root / "report.json").is_file():
        preparation = load(root, "report.json")
        check("report.prepared", preparation["phase_c_completion"] == "prepared" and preparation["product_execution_count"] == preparation["actual_host_execution_count"] == 0, "Preparation report retains zero product and host executions")
        check("report.case_counts", preparation["counts"]["specifications"] == 5 and preparation["counts"]["acceptance_cases"] == 26 and preparation["counts"]["transition_scenarios"] == 16, "Preparation report counts match the packet")
    return checks


def validate_checksums(root):
    expected = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file() and str(path.relative_to(root)) not in CHECKSUM_EXCLUSIONS}
    listed = set()
    checks = []
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        path = Path(relative)
        safe = not path.is_absolute() and ".." not in path.parts
        exists = safe and (root / path).is_file()
        valid = exists and hashlib.sha256((root / path).read_bytes()).hexdigest() == digest
        checks.append({"id": "checksum." + relative, "passed": bool(valid and relative not in listed), "detail": "Exact SHA-256 and unique safe relative path"})
        listed.add(relative)
    checks.append({"id": "checksum.inventory", "passed": listed == expected, "detail": f"Manifest covers {len(expected)} frozen files. The manifest and regenerable package-validation report are excluded."})
    return checks


def validate_source_bytes(root, source_root):
    checks = []
    for item in load(root, "evidence/source_bindings.json")["files"]:
        path = source_root / item["path"]
        matches = False
        if path.is_file():
            data = path.read_bytes()
            blob = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
            matches = blob == item["git_blob_sha"] and hashlib.sha256(data).hexdigest() == item["sha256"]
        checks.append({"id": "source_bytes." + item["path"], "passed": matches, "detail": "Exact pinned Git blob and SHA-256 verification"})
    return checks


def negative_controls(root):
    controls = []
    with tempfile.TemporaryDirectory(prefix="phase-c-package-controls-") as directory:
        work = Path(directory) / "package"
        shutil.copytree(root, work)
        path = work / "templates/implementation_report.json"
        original = path.read_text(encoding="utf-8")
        changed = json.loads(original)
        changed["phase_c_completion"] = "complete"
        changed["execution_summary"]["actual_product_executions"] = 1
        path.write_text(json.dumps(changed), encoding="utf-8")
        checks = validate_structure(work)
        controls.append({"id": "package.fabricated_product_completion", "passed": any(item["id"] == "templates.no_product_credit" and not item["passed"] for item in checks)})
        path.write_text(original, encoding="utf-8")
        path = work / "contracts/reconciliation_rules.json"
        changed = load(work, "contracts/reconciliation_rules.json")
        changed["actions"] = [item for item in changed["actions"] if item["action"] != "reopen"]
        path.write_text(json.dumps(changed), encoding="utf-8")
        checks = validate_structure(work)
        controls.append({"id": "package.missing_reopen_action", "passed": any(item["id"] == "contract.actions" and not item["passed"] for item in checks)})
    return controls


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--source-root", type=Path, help="Optional local checkout of the pinned public commit")
    parser.add_argument("--negative-controls", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    checks = validate_structure(root) + validate_checksums(root)
    fixture_validator = runpy.run_path(str(root / "fixtures/validate_fixtures.py"))
    fixture_checks = fixture_validator["validate"](root)
    checks += [{**item, "id": "fixture." + item["id"]} for item in fixture_checks]
    if args.source_root:
        checks += validate_source_bytes(root, args.source_root.resolve())
    controls = []
    if args.negative_controls:
        controls += negative_controls(root)
        controls += [{**item, "id": "fixture." + item["id"]} for item in fixture_validator["negative_controls"](root)]
        phase_b_root = root / "reference/phase_b_fixture"
        phase_b_validator = runpy.run_path(str(phase_b_root / "fixtures/validate_fixtures.py"))
        controls += [{**item, "id": "phase_b." + item["id"]} for item in phase_b_validator["negative_controls"](phase_b_root)]
        phase_a_root = phase_b_root / "reference/phase_a_fixture"
        phase_a_validator = runpy.run_path(str(phase_a_root / "validate_fixtures.py"))
        controls += [{**item, "id": "phase_a." + item["id"]} for item in phase_a_validator["negative_controls"](phase_a_root)]
    passed = all(item["passed"] for item in checks + controls)
    result = {
        "schema_version": "phase-c-package-validation.v1",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "pass" if passed else "fail",
        "product_execution_count": 0,
        "actual_host_execution_count": 0,
        "summary": {
            "checks": len(checks),
            "passed": sum(item["passed"] for item in checks),
            "fixture_checks": len(fixture_checks),
            "negative_controls": len(controls),
            "negative_controls_passed": sum(item["passed"] for item in controls),
            "source_bytes_rechecked": args.source_root is not None,
        },
        "checksum_exclusions": sorted(CHECKSUM_EXCLUSIONS),
        "checks": checks,
        "negative_controls": controls,
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], **result["summary"], "product_execution_count": 0, "actual_host_execution_count": 0, "failed_checks": [item["id"] for item in checks + controls if not item["passed"]]}, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
