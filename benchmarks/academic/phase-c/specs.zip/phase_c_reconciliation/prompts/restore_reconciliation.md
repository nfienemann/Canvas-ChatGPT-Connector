Reverse the selected reconciliation's own changes through the current recovery workflow. Preserve unrelated progress and edits recorded afterward.

Show any intervening changes that affect the requested recovery, the source/version basis of the resulting view and the actual confirmed recovery outcome.
