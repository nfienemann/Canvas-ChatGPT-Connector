#!/usr/bin/env python3
"""Bounded evaluator for authored Phase C transition inputs.

This model supplies local specification checks. It performs no host assessment,
plugin execution, source extraction, persistent store mutation or planner call.
"""

import copy
import hashlib
import json
import zipfile
from pathlib import Path


ACTIVE_LIFECYCLES = {"active", "review_needed"}
PROGRESS_FIELDS = ("personal_progress", "progress_basis", "progress_history", "manual_note")


def load(root, relative):
    return json.loads((Path(root) / relative).read_text(encoding="utf-8"))


def native_inventory(path):
    """Compare named uncompressed members independently of ZIP packaging."""
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Ambiguous duplicate native archive member name")
        return {name: hashlib.sha256(archive.read(name)).hexdigest() for name in sorted(names)}


def proof_covers(proof, selectors):
    return proof.get("coverage") == "complete" and set(selectors) <= set(proof.get("supported_selectors", []))


def timing_bridge_supported(proof):
    return (
        proof.get("kind") == "full_native_payload_equality"
        and proof_covers(proof, ["artifact:presentation_payload"])
        and proof.get("payload_membership_equal") is True
        and proof.get("all_payload_bytes_equal") is True
        and proof.get("duplicate_member_policy") == "reject_incomparable"
    )


def classify_impact(selectors, observations, proofs):
    relevant = set(selectors)
    changed = set()
    unknown = set()
    for observation in observations:
        changed.update(observation["changed_selectors"])
        unknown.update(observation["unknown_selectors"])
        if observation["change_class"] not in {"alias_only", "content_equivalent"}:
            continue
        prefix = {"BL-DECK": "artifact:", "BL-REFERENCES": "reference:"}.get(observation["subject_id"])
        subject_scope = {selector for selector in relevant if prefix and selector.startswith(prefix)}
        if not subject_scope:
            continue
        supplied = [proofs[identifier] for identifier in observation["comparison_proof_ids"]]
        if not any(proof_covers(proof, subject_scope) for proof in supplied):
            unknown.update(subject_scope)
        if "artifact:presentation_payload" in subject_scope and observation["change_class"] == "content_equivalent":
            if not any(timing_bridge_supported(proof) for proof in supplied):
                unknown.add("artifact:presentation_payload")
    if relevant & unknown:
        return "unknown"
    if relevant & changed:
        return "affected"
    return "unaffected"


def process_events(initial_heads, events, arrival_order):
    """Use declared parent relationships, retaining gaps and historical arrivals."""
    heads = copy.deepcopy(initial_heads)
    seen_versions = {subject: {version} for subject, version in heads.items()}
    seen_events = set()
    dispositions = []
    pending = []

    def apply_pending():
        progressed = True
        while progressed:
            progressed = False
            for entry in pending[:]:
                event = events[entry["event_id"]]
                subject = event["subject_id"]
                if event["parent_version_id"] == heads.get(subject):
                    heads[subject] = event["target_version_id"]
                    seen_versions.setdefault(subject, set()).add(event["target_version_id"])
                    entry["disposition"] = "applied_after_parent"
                    pending.remove(entry)
                    progressed = True

    for event_id in arrival_order:
        event = events[event_id]
        subject = event["subject_id"]
        entry = {"event_id": event_id}
        if event_id in seen_events:
            entry["disposition"] = "duplicate"
        elif event["target_version_id"] in seen_versions.get(subject, set()):
            entry["disposition"] = "historical_reference_only"
        elif event["parent_version_id"] == heads.get(subject):
            heads[subject] = event["target_version_id"]
            seen_versions.setdefault(subject, set()).add(event["target_version_id"])
            entry["disposition"] = "applied"
        else:
            entry["disposition"] = "pending_missing_parent"
            pending.append(entry)
        seen_events.add(event_id)
        dispositions.append(entry)
        apply_pending()
    return {"heads": heads, "dispositions": dispositions, "pending_event_ids": [entry["event_id"] for entry in pending], "missing_chain_followup_count": len(pending)}


def simulate_commit(initial_revision, steps):
    revision = initial_revision
    receipts = {}
    outcomes = []
    commit_count = 0
    for step in steps:
        kind = step["kind"]
        if kind == "external_progress":
            revision = step["new_revision"]
            outcome = "external_progress_committed"
        elif step["operation_id"] in receipts:
            outcome = "receipt_replayed"
        elif step["expected_revision"] != revision:
            outcome = "base_conflict"
        elif step.get("injected_storage_failure"):
            outcome = "storage_failure_unchanged"
        else:
            revision += 1
            receipts[step["operation_id"]] = revision
            commit_count += 1
            outcome = "committed"
        outcomes.append({"outcome": outcome, "record_revision": revision})
    return {"outcomes": outcomes, "final_revision": revision, "reconciliation_commit_count": commit_count, "receipts": receipts}


def occurrence_key(binding, row):
    return {key: binding[key] for key in ("assignment_id", "requirement_set_revision", "artifact_id", "artifact_sha256")} | {"requirement_id": row["requirement_id"], "gap_kind": row["gap_kind"]}


def current_lineage(work, assignment_id, requirement_id):
    candidates = [item for item in work if item["occurrence_key"]["assignment_id"] == assignment_id and item["occurrence_key"]["requirement_id"] == requirement_id]
    return candidates[-1] if candidates else None


def new_episode(work, binding, row, prior=None):
    requirement_id = row["requirement_id"]
    lineage_id = prior["lineage_id"] if prior else "BL-WORK-" + requirement_id
    if prior is None and any(item["lineage_id"] == lineage_id for item in work):
        lineage_id = binding["assignment_id"] + "/" + lineage_id
    episode_number = 1 + sum(item["lineage_id"] == lineage_id for item in work)
    episode_id = f"{lineage_id}/E{episode_number}"
    item = {
        "work_id": lineage_id if episode_number == 1 else f"{lineage_id}-E{episode_number}",
        "lineage_id": lineage_id, "episode_id": episode_id,
        "occurrence_key": occurrence_key(binding, row),
        "title": f"Address {requirement_id} {row['gap_kind'].replace('_', ' ')}.",
        "evidence_lifecycle": "active", "assessment_status_basis": "needs_work",
        "evidence_refs": copy.deepcopy(row["evidence_refs"]),
        "personal_progress": "open", "progress_basis": {"kind": "system_default", "declaration_id": None},
        "progress_history": [], "history": [], "estimated_minutes": None,
    }
    if prior:
        item["previous_episode_id"] = prior["episode_id"]
    work.append(item)
    return item


def reconcile_work(before, rows, removed_ids, binding, scenario):
    work = copy.deepcopy(before["work_items"])
    actions = []
    for requirement_id in removed_ids:
        prior = current_lineage(work, binding["assignment_id"], requirement_id)
        if prior and prior["evidence_lifecycle"] in ACTIVE_LIFECYCLES:
            prior["evidence_lifecycle"] = "retired"
            prior["retirement_basis"] = {"requirement_set_revision": binding["requirement_set_revision"], "reason": "complete_governing_membership_removal"}
            actions.append({"requirement_id": requirement_id, "action": "retire", "episode_id": prior["episode_id"]})
    for row in rows:
        requirement_id = row["requirement_id"]
        prior = current_lineage(work, binding["assignment_id"], requirement_id)
        status = row["assessment_status"]
        action = None
        if status == "needs_work":
            if prior is None:
                prior = new_episode(work, binding, row)
                action = "create"
            elif prior["evidence_lifecycle"] in {"resolved", "retired"} or requirement_id in scenario["material_fulfillment_change_ids"]:
                if prior["evidence_lifecycle"] in ACTIVE_LIFECYCLES:
                    prior["evidence_lifecycle"] = "retired"
                    prior["retirement_basis"] = {"reason": "material_fulfillment_replaced", "reconciliation_id": scenario["id"]}
                prior = new_episode(work, binding, row, prior)
                action = "reopen"
            else:
                target_key = occurrence_key(binding, row)
                updated = target_key != prior["occurrence_key"] or requirement_id in scenario["refresh_work_evidence_ids"]
                action = "update" if updated else "keep"
                if updated:
                    prior["history"].append({"occurrence_key": copy.deepcopy(prior["occurrence_key"]), "reconciliation_id": scenario["id"]})
                    prior["occurrence_key"] = target_key
                    prior["evidence_refs"] = copy.deepcopy(row.get("current_evidence_refs", row["evidence_refs"]))
                    prior["evidence_refresh_proof_ids"] = row.get("carry_forward_proof_ids", [])
                    if row.get("evidence_locator_remaps"):
                        prior["original_assessment_evidence_refs"] = copy.deepcopy(row["evidence_refs"])
                        prior["evidence_locator_remaps"] = copy.deepcopy(row["evidence_locator_remaps"])
                prior["evidence_lifecycle"] = "active"
        elif status == "satisfied" and prior and prior["evidence_lifecycle"] in ACTIVE_LIFECYCLES:
            prior["evidence_lifecycle"] = "resolved"
            prior["resolution_basis"] = {"assessment_id": row["assessment_id"], "artifact_sha256": binding["artifact_sha256"]}
            action = "resolve"
        elif status in {"unknown", "conflict"} and prior and prior["evidence_lifecycle"] in ACTIVE_LIFECYCLES:
            prior["evidence_lifecycle"] = "review_needed"
            prior["review_basis"] = {"current_artifact_sha256": binding["artifact_sha256"], "reason": row["unknown_reason"]}
            action = "review_needed"
        if action:
            actions.append({"requirement_id": requirement_id, "action": action, "episode_id": prior["episode_id"]})
    return work, sorted(actions, key=lambda row: row["requirement_id"])


def scoped_compensation(current, target, scenario):
    restored = copy.deepcopy(target)
    current_by_id = {item["work_id"]: item for item in current["work_items"]}
    target_ids = {item["work_id"] for item in restored["work_items"]}
    for item in restored["work_items"]:
        later = current_by_id.get(item["work_id"], {})
        for field in PROGRESS_FIELDS:
            if field in later:
                item[field] = copy.deepcopy(later[field])
        item["history"].append({"compensation_for": scenario["rollback_target_change_id"], "current_source_applicability": "exact_selected_baseline_sources_available"})
    restored["work_items"].extend(copy.deepcopy(item) for item in current["work_items"] if item["work_id"] not in target_ids)
    restored["parent_progress"] = copy.deepcopy(current["parent_progress"])
    restored["unrelated_work"] = copy.deepcopy(current["unrelated_work"])
    restored["record_revision"] = current["record_revision"] + 1
    return restored


def summarize(rows, work, membership_complete=True):
    counts = {status: sum(row["assessment_status"] == status for row in rows) for status in ("satisfied", "needs_work", "unknown", "conflict")}
    counts["requirements"] = len(rows)
    aggregate = next((status for status in ("conflict", "needs_work", "unknown") if counts[status]), "ready")
    if aggregate == "ready" and (not membership_complete or not rows):
        aggregate = "unknown"
    lifecycles = {status: sum(item["evidence_lifecycle"] == status for item in work) for status in ("active", "review_needed", "resolved", "retired")}
    current = [item for item in work if item["evidence_lifecycle"] in ACTIVE_LIFECYCLES]
    return {"readiness": aggregate, "counts": counts, "work_counts": lifecycles | {"current": len(current), "current_done": sum(item["personal_progress"] == "done" for item in current), "personal_done_records": sum(item["personal_progress"] == "done" for item in work)}, "planner_eligible_episode_ids": sorted(item["episode_id"] for item in work if item["evidence_lifecycle"] == "active" and item["personal_progress"] in {"open", "in_progress"}), "review_followup_count": int(bool(counts["unknown"] or counts["conflict"] or not membership_complete or not rows))}


def evaluate(root, scenario):
    inputs = load(root, "fixtures/change_inputs.json")
    events = {event["event_id"]: event for event in load(root, "fixtures/change_events.json")["events"]}
    proofs = {proof["proof_id"]: proof for proof in load(root, "fixtures/comparison_proofs.json")["proofs"]}
    assessments = {item["assessment_id"]: item for item in load(root, "fixtures/reassessment_inputs.json")["assessments"]}
    snapshots = {item["snapshot_id"]: item for item in inputs["initial_snapshots"]}
    requirement_sets = {item["requirement_set_revision"]: item for item in inputs["requirement_sets"]}
    dependencies = {item["requirement_id"]: item["selectors"] for item in inputs["dependency_selectors"]}
    before = snapshots[scenario.get("effective_reconciliation_snapshot_id", scenario["initial_snapshot_id"])]
    binding = scenario["target_binding"]
    if scenario.get("rollback_target_snapshot_id"):
        after = scoped_compensation(before, snapshots[scenario["rollback_target_snapshot_id"]], scenario)
        impacts = {row["requirement_id"]: "affected" for row in after["requirement_results"]}
        origins = {row["requirement_id"]: "restored" for row in after["requirement_results"]}
        actions = []
        removed = []
    else:
        target_set = requirement_sets[binding["requirement_set_revision"]]
        previous = {row["requirement_id"]: row for row in before["requirement_results"]}
        target_ids = [row["requirement_id"] for row in target_set["requirements"]]
        removed = sorted(set(previous) - set(target_ids))
        if removed and not (scenario["membership_complete"] and target_set["membership_complete"]):
            raise ValueError("Incomplete requirement membership cannot establish removal")
        observations = [events[identifier] for identifier in scenario["event_ids"]]
        alias_only = bool(observations) and all(observation["change_class"] == "alias_only" for observation in observations)
        reassessed = {row["requirement_id"]: row for row in assessments.get(scenario["reassessment_input_id"], {}).get("rows", [])}
        rows = []
        impacts = {identifier: "affected" for identifier in removed}
        origins = {identifier: "removed" for identifier in removed}
        proof_ids = sorted({identifier for observation in observations for identifier in observation["comparison_proof_ids"]})
        for requirement_id in target_ids:
            impact = classify_impact(dependencies[requirement_id], observations, proofs)
            if requirement_id not in previous:
                impact = "affected"
            if impact == "unaffected" and requirement_id in previous:
                row = copy.deepcopy(previous[requirement_id])
                origin = "unchanged" if alias_only else "carried_forward"
                if not alias_only:
                    row.update({"carry_forward_validated_at": scenario["reconciliation_at"], "carry_forward_proof_ids": proof_ids, "carry_forward_dependency_scope": dependencies[requirement_id], "carried_from_assessment_id": row["assessment_id"]})
                    locator_remaps = [copy.deepcopy(remap) for proof_id in proof_ids for remap in proofs[proof_id].get("evidence_locator_remaps", []) if remap["original_evidence_id"] in row["evidence_refs"]]
                    if locator_remaps:
                        replacements = {remap["original_evidence_id"]: remap["current_evidence_id"] for remap in locator_remaps}
                        row["current_evidence_refs"] = [replacements.get(reference, reference) for reference in row["evidence_refs"]]
                        row["evidence_locator_remaps"] = locator_remaps
            elif impact == "affected" and requirement_id in reassessed:
                row = copy.deepcopy(reassessed[requirement_id])
                origin = "reassessed"
            else:
                row = {"requirement_id": requirement_id, "assessment_status": "unknown", "evidence_coverage": "unavailable" if not binding["artifact_available"] else "partial", "unknown_reason": "current_dependency_evidence_unavailable" if impact == "unknown" else "current_reassessment_required", "version_match": "unresolved", "evidence_refs": [], "gap_kind": None, "assessment_id": None, "assessed_at": None, "assessor_basis": None}
                origin = "unknown"
            impacts[requirement_id] = impact
            origins[requirement_id] = origin
            rows.append(row)
        work, actions = reconcile_work(before, rows, removed, binding, scenario)
        after = {"binding": copy.deepcopy(binding), "membership_complete": scenario["membership_complete"] and target_set["membership_complete"], "requirement_results": rows, "work_items": work, "parent_progress": copy.deepcopy(before["parent_progress"]), "unrelated_work": copy.deepcopy(before["unrelated_work"]), "record_revision": before["record_revision"] + int(not alias_only)}
    result = {"scenario_id": scenario["id"], "impacts": impacts, "row_origins": origins, "row_statuses": {row["requirement_id"]: row["assessment_status"] for row in after["requirement_results"]}, "removed_requirement_ids": removed, "work_actions": actions, "after": after, **summarize(after["requirement_results"], after["work_items"], after["membership_complete"])}
    result["current_locator_evidence"] = {row["requirement_id"]: row["current_evidence_refs"] for row in after["requirement_results"] if "current_evidence_refs" in row}
    result["current_episode_progress"] = {item["episode_id"]: item["personal_progress"] for item in after["work_items"] if item["evidence_lifecycle"] in ACTIVE_LIFECYCLES}
    if scenario.get("arrival_order"):
        result["event_processing"] = process_events(scenario["original_heads"], events, scenario["arrival_order"])
    if scenario.get("operation_steps"):
        result["atomic_processing"] = simulate_commit(snapshots[scenario["initial_snapshot_id"]]["record_revision"], scenario["operation_steps"])
        if result["atomic_processing"]["reconciliation_commit_count"]:
            after["record_revision"] = result["atomic_processing"]["final_revision"]
            result["commit_status"] = "committed"
        else:
            result["proposed_transition"] = {key: copy.deepcopy(result[key]) for key in ("impacts", "row_origins", "row_statuses", "work_actions", "readiness", "counts", "work_counts", "planner_eligible_episode_ids")}
            result["proposed_transition"]["target_binding"] = copy.deepcopy(binding)
            after = copy.deepcopy(before)
            after["record_revision"] = result["atomic_processing"]["final_revision"]
            result.update({"after": after, "commit_status": "pending", "work_actions": [], "removed_requirement_ids": [], "row_statuses": {row["requirement_id"]: row["assessment_status"] for row in after["requirement_results"]}, "row_origins": {row["requirement_id"]: "unchanged" for row in after["requirement_results"]}, **summarize(after["requirement_results"], after["work_items"], after["membership_complete"])})
            result["current_episode_progress"] = {item["episode_id"]: item["personal_progress"] for item in after["work_items"] if item["evidence_lifecycle"] in ACTIVE_LIFECYCLES}
    if scenario.get("timing_equivalence_proof_id"):
        result["timing_derivation"] = copy.deepcopy(proofs[scenario["timing_equivalence_proof_id"]]["timing_derivation"])
    if scenario.get("rollback_target_snapshot_id"):
        result["compensated_episode_ids"] = sorted(item["episode_id"] for item in snapshots[scenario["rollback_target_snapshot_id"]]["work_items"])
    return result
