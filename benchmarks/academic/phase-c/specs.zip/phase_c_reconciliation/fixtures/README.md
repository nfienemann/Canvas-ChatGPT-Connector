# Phase C change and reconciliation fixture

This packet supplies 16 synthetic transition scenarios, 12 bounded contract controls and 10 targeted mutation checks. It reuses the exact Phase B fixture and its frozen Phase A coursework. The reference evaluator consumes authored observations and reassessment responses. Actual product execution and actual host execution remain zero.

## Files and execution

`change_inputs.json` holds immutable source versions, complete requirement inventories, dependency scopes and five before-state snapshots. `change_events.json` supplies the selected synthetic observations. `reassessment_inputs.json` supplies independently authored structured response rows and exact current-source anchors. `expected_transitions.json` states independently authored impact, assessment, work, progress, planner and transaction expectations.

Run the local validation from the package root.

```bash
python fixtures/validate_fixtures.py --negative-controls --report evidence/fixture_validation.json
```

The Python API exposes `validate(package_root)` and `negative_controls(package_root)`. Each returns records with `id`, `passed` and `detail`. The main validation includes the frozen Phase B validator, which includes Phase A. The ten mutation controls are specific to Phase C. The validator requires only the packaged `fixtures` and `reference` directories and Python's standard library.

`index.json` records frozen local file hashes. `reference/phase_b_provenance.json` records 47 copied files and their exact paths within the delivered Phase B archive. This dependency closure includes the prior fixture validator and its referenced contracts.

## Scenario expectations

| Scenario | Change exercised | Current assessment expectation | Work expectation |
| --- | --- | --- | --- |
| PHC-S01 | Same bytes under a new filename | Existing assessment payload unchanged | Keep three current episodes with zero readiness revision increment |
| PHC-S02 | Full-payload-identical PPTX repackage | Carry all four satisfied assessments | Retain three resolved historical episodes |
| PHC-S03 | Baseline becomes corrected with matching rehearsal | Reassess four criteria as satisfied | Resolve three episodes and retain personal progress |
| PHC-S04 | Explicit governing v3 current-source amendment | Reassess PA-R02 as needs work, carry other criteria | Reopen the established PA-R02 lineage in a new episode |
| PHC-S05 | Maximum duration becomes 400 seconds | Matching 410-second rehearsal exceeds the new limit by 10 seconds | Reopen PA-R04 in a new episode |
| PHC-S06 | Required implementation-risk criterion added | Four carried satisfied rows and one supported gap | Create the PA-R05 lineage |
| PHC-S07 | Complete source explicitly removes PA-R01 | Remaining two gaps and one satisfied criterion | Retire PA-R01 and update continuing occurrence bindings |
| PHC-S08 | Unrelated reference contact changes | Carry all existing criterion outcomes | Keep three current episodes |
| PHC-S09 | Advertised replacement cannot be read | Four current rows unknown, historical results retained | Three prior episodes require review and one grouped input followup |
| PHC-S10 | Replacement reader returns slides 1–5 only | PA-R02 and PA-R04 satisfied, PA-R01 and PA-R03 unknown | Resolve two episodes and retain one pending review |
| PHC-S11 | Changed deck has the old rehearsal | Three satisfied rows and unknown current timing | Resolve two episodes and retain PA-R04 for review |
| PHC-S12 | Reference formatting changes and PA-R02 is declared done | Carry original assessment with four verified current locator mappings | Update PA-R02 within its episode and retain its done declaration |
| PHC-S13 | Resolved defects recur | Three current gaps and one satisfied criterion | Reopen three current episodes while retaining prior done history |
| PHC-S14 | Overlap, duplicate arrival and late historical event | Final explicit v3 scope has one current gap | One coalesced revision, two resolves and one new reopened episode |
| PHC-S15 | Concurrent progress, stale base, storage failure and retry | Successful retry commits the corrected ready result once | Retain intervening done progress and replay the same receipt |
| PHC-S16 | Explicit rollback after later personal changes | Restore baseline applicability in a compensating revision | Restore prior evidence episodes while preserving later and unrelated progress |

## Native and source proof boundaries

The corrected native deck is repackaged with reversed physical ZIP entry order, a different compression method and new ZIP timestamps. Every one of its 55 named uncompressed members has the same digest. This covers presentation order, relationships, native notes, media and timing-relevant parts through complete native membership. Duplicate archive member names are rejected as incomparable. No native content is edited.

The original corrected rehearsal retains its measured artifact hash and 410-second duration. PHC-S02 adds derived applicability to the repackaged container through the complete native-payload proof. The text-only proof control cannot supply this bridge. PHC-S11 retains the historical 455-second rehearsal and leaves current timing unknown for the changed deck.

The original brief explicitly requires v2 for PA-R02. PHC-S04 supplies a complete governing amendment to v3 and the matching 24/150 measurement. Historical v1 and v2 sample values remain available for version-specific citation checks. PHC-C12 verifies that a newer reference alone leaves the explicit requirement version intact.

The formatting control preserves every nonempty reference line in the same order. Four original evidence anchors have explicit mappings to exact current quotes, line numbers and the formatted source hash. Carried assessments retain original evidence references and assessment provenance. Current work uses the current mapped references with retained lineage.

## Model packet controls

Each scenario lists its selected host files in `model_input_files`. An implementation runner must present only that scenario's selected packet as current coursework and preserve the declared initial state. The evaluator and frozen historical reference tree supply expected outcomes and provenance.

For PHC-S09, the advertised corrected deck is excluded from the selected host packet. Its frozen copy remains available to the evaluator for hash and expected-state verification. For PHC-S10, the runner injects the declared bounded reader failure for slides 6–7 and their notes. The fixture records zero actual fault-injection runs.

## State and transaction boundaries

Stable work lineage spans versions. Phase B occurrence identity remains bound to the requirement revision and selected native hash. Continuing equivalent fulfillment retains compatible personal progress. Resolved recurrence and materially changed fulfillment create a new open episode with a system-default basis and a null declaration ID. The prior declarations remain attributed to their original episodes. Current reopened episodes reach the planner even when the historical parent is done.

The event controls order observations through declared parents and selected source heads. A missing intermediate version remains pending with an explicit followup. An older historical event and a replay create no extra active-head transition. PHC-C01 and PHC-C02 map directly to PHC-T19.

The transaction model separates proposed reconciliation from a successful state change. Failure without a later successful retry retains the exact effective current snapshot and exposes the computed delta as pending. Receipt replay has one committed generation. The rollback control applies a scoped compensating revision, preserving later progress and unrelated manual fields.

## Implementation evidence still required

The local evaluator checks contracts and source-grounded fixture expectations. Source detection, semantic comparison, host judgment, persistent atomicity, restart behavior, automatic workflow integration and actual planner handoff require captured implementation runs under the package's Phase C acceptance cases. The local model receives authored dependency selectors and reassessment rows. Its passing checks carry zero implementation or host-execution credit.
