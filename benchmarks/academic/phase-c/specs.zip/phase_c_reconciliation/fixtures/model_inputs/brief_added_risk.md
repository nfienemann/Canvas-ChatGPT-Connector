# BenchLink presentation brief

Brief version BL-BRIEF-RISK-v2 applies to the BenchLink pitch.
This complete synthetic amendment retains PA-R01 through PA-R04 and adds PA-R05.
All company details, study data, roles, plans and rehearsal observations are synthetic coursework material.

## PA-R01 Required sections

Include the problem, proposed solution, current collision evidence, adoption plan and references.
Include a section titled Limitations and validation plan.
That section must name at least one limitation and one measurable validation step.

## PA-R02 Current collision evidence

Use BKS-2026-v2 for the current collision-rate claim.
Report 22 collisions in 120 synthetic test reservations, rounded to 18%.
The reference packet defines the field-specific supersession of the archived study.

## PA-R03 Source attribution

Identify the source version for every quantitative collision claim in a slide or its speaker notes.
Each cited source version must resolve to an included reference record with matching historical values.

## PA-R04 Rehearsal duration

The maximum presentation duration is 420 seconds.
Use the supplied measured synthetic rehearsal for the identified artifact version.
Use its elapsed_seconds value when assessing that recorded run.

## PA-R05 Implementation risk

Include a section titled Implementation risk and mitigation.
Name one operational implementation risk and one concrete mitigation.

## Submission materials

The packet contains a presentation, this brief, a reference packet and a synthetic rehearsal record.
Native speaker notes form part of the presentation evidence.
