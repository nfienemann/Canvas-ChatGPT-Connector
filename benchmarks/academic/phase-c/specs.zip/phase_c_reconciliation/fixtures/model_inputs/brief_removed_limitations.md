# BenchLink presentation brief

Brief version BL-BRIEF-REMOVE-R01-v2 applies to the BenchLink pitch.
This complete synthetic amendment removes PA-R01 from the required criterion set.
PA-R02, PA-R03 and PA-R04 retain their criterion identity and wording.
All company details, study data, roles, plans and rehearsal observations are synthetic coursework material.

## PA-R02 Current collision evidence

Use BKS-2026-v2 for the current collision-rate claim.
Report 22 collisions in 120 synthetic test reservations, rounded to 18%.
The reference packet defines the field-specific supersession of the archived study.

## PA-R03 Source attribution

Identify the source version for every quantitative collision claim in a slide or its speaker notes.
Each cited source version must resolve to an included reference record with matching historical values.

## PA-R04 Rehearsal duration

The maximum presentation duration is 420 seconds.
Use the supplied measured synthetic rehearsal for the identified artifact version.
Use its elapsed_seconds value when assessing that recorded run.

## Submission materials

The packet contains a presentation, this brief, a reference packet and a synthetic rehearsal record.
Native speaker notes form part of the presentation evidence.
