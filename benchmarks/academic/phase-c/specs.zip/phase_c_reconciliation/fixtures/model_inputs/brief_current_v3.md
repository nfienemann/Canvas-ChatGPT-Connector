# BenchLink presentation brief

Brief version BL-BRIEF-CURRENT-v2 applies to the BenchLink pitch.
This complete synthetic instructor amendment replaces only PA-R02 from BL-BRIEF-v1.
PA-R01, PA-R03 and PA-R04 retain their existing criterion identity and wording.
All company details, study data, roles, plans and rehearsal observations are synthetic coursework material.

## PA-R01 Required sections

Include the problem, proposed solution, current collision evidence, adoption plan and references.
Include a section titled Limitations and validation plan.
That section must name at least one limitation and one measurable validation step.

## PA-R02 Current collision evidence

Use BKS-2026-v3 for the current collision-rate claim.
Report 24 collisions in 150 synthetic test reservations, exactly 16%.
The reference packet defines the field-specific supersession of the archived study.

## PA-R03 Source attribution

Identify the source version for every quantitative collision claim in a slide or its speaker notes.
Each cited source version must resolve to an included reference record with matching historical values.

## PA-R04 Rehearsal duration

The maximum presentation duration is 420 seconds.
Use the supplied measured synthetic rehearsal for the identified artifact version.
Use its elapsed_seconds value when assessing that recorded run.

## Submission materials

The packet contains a presentation, this brief, a reference packet and a synthetic rehearsal record.
Native speaker notes form part of the presentation evidence.
