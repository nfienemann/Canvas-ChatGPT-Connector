# BenchLink synthetic reference packet

Every study, observation, date and project detail in this packet is synthetic.
The records describe fictional reservations for a fictional campus equipment room.

## BKS-2026-v1

Record status is archived.
Synthetic issue date is 2026-10-01.
The study recorded 13 collisions in 50 synthetic test reservations.
The reported collision rate is 26%, calculated as 13 / 50 × 100.
This record preserves the historical results of that synthetic sample.

## BKS-2026-v2

Record status is current.
Synthetic issue date is 2026-10-20.
The study recorded 22 collisions in 120 synthetic test reservations.
The reported collision rate is 18%, rounded from 18.33% to a whole percent.

## Field-specific source amendment

BKS-2026-v2 supersedes BKS-2026-v1 only for the current_collision_rate field.
Use BKS-2026-v2 when a presentation describes the current collision rate.
The archived BKS-2026-v1 sample retains its historical values and provenance.
The amendment applies to the collision count, reservation count and reported rate used for that current claim.

## Synthetic administrative contact

The equipment desk contact label is BenchLink Support Desk.
This contact label supplies administrative metadata for the reference packet.
