# BenchLink synthetic reference packet

Every study, observation, date and project detail in this packet is synthetic.
The records describe fictional reservations for a fictional campus equipment room.

## BKS-2026-v1

Record status is archived.
Synthetic issue date is 2026-10-01.
The study recorded 13 collisions in 50 synthetic test reservations.
The reported collision rate is 26%, calculated as 13 / 50 × 100.
This record preserves the historical results of that synthetic sample.

## BKS-2026-v2

Record status is archived.
Synthetic issue date is 2026-10-20.
The study recorded 22 collisions in 120 synthetic test reservations.
The reported collision rate is 18%, rounded from 18.33% to a whole percent.

## BKS-2026-v3

Record status is current.
Synthetic issue date is 2026-11-05.
The study recorded 24 collisions in 150 synthetic test reservations.
The reported collision rate is 16%, calculated as 24 / 150 × 100.

## Field-specific source amendment

BKS-2026-v3 supersedes BKS-2026-v2 only for the current_collision_rate field.
The archived v1 and v2 sample values and source identities remain available for historical attribution.
BL-BRIEF-CURRENT-v2 explicitly applies this source amendment to PA-R02.
