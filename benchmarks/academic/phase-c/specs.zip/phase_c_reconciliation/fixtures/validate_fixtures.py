#!/usr/bin/env python3
"""Validate the frozen Phase C specification fixture and its local evaluator."""

import argparse
import copy
import hashlib
import json
import re
import runpy
import shutil
import tempfile
import warnings
import zipfile
from datetime import datetime, timezone
from pathlib import Path


def load(root, relative):
    return json.loads((root / relative).read_text(encoding="utf-8"))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_controls(root, model, controls, scenarios, inputs, events):
    checks = []
    snapshots = {item["snapshot_id"]: item for item in inputs["initial_snapshots"]}
    for control in controls:
        kind = control["kind"]
        expected = control["expected"]
        passed = False
        if kind == "missing_parent":
            result = model["process_events"](control["initial_heads"], events, [control["event_id"]])
            passed = result["heads"]["BL-REFERENCES"] == expected["head"] and result["pending_event_ids"] == expected["pending_event_ids"] and result["missing_chain_followup_count"] == 1
        elif kind == "out_of_order_complete_chain":
            event_map = {item["event_id"]: item for item in control["events"]}
            result = model["process_events"](control["initial_heads"], event_map, control["arrival_order"])
            chronological = model["process_events"](control["initial_heads"], event_map, list(reversed(control["arrival_order"])))
            passed = result["heads"]["REFERENCE-CONTROL"] == expected["head"] and result["heads"] == chronological["heads"] and result["pending_event_ids"] == [] and result["dispositions"][0]["disposition"] == expected["first_disposition"]
        elif kind == "text_only_timing_proof":
            passed = model["timing_bridge_supported"](control["proof"]) is expected["timing_bridge_supported"]
        elif kind == "incomplete_membership":
            scenario = copy.deepcopy(scenarios["PHC-S07"])
            scenario["membership_complete"] = False
            try:
                model["evaluate"](root, scenario)
            except ValueError as error:
                passed = "membership" in str(error) and expected["transition_rejected"]
            satisfied_scenario = copy.deepcopy(scenarios["PHC-S02"])
            satisfied_scenario["membership_complete"] = False
            incomplete = model["evaluate"](root, satisfied_scenario)
            passed = passed and incomplete["readiness"] == expected["incomplete_all_satisfied_readiness"]
        elif kind == "assignment_isolation":
            scenario = copy.deepcopy(scenarios["PHC-S12"])
            old = snapshots[scenario["initial_snapshot_id"]]
            work = copy.deepcopy(old["work_items"])
            binding = copy.deepcopy(old["binding"])
            binding["assignment_id"] = "BL-ASSIGNMENT-OTHER"
            row = old["requirement_results"][1]
            prior = model["current_lineage"](work, binding["assignment_id"], row["requirement_id"])
            created = model["new_episode"](work, binding, row, prior)
            passed = prior is None and created["lineage_id"] != old["work_items"][1]["lineage_id"] and created["personal_progress"] == expected["new_progress"] and created["progress_basis"]["declaration_id"] is None
        elif kind == "incomplete_scope_proof":
            passed = model["proof_covers"](control["proof"], ["artifact:required_section_search_extent"]) is expected["absence_scope_covered"] and model["proof_covers"](control["proof"], ["artifact:quantitative_claim_inventory"]) is expected["universal_claim_scope_covered"]
        elif kind == "partial_summary_priority":
            result = model["summarize"](control["rows"], [])
            passed = result["readiness"] == expected["readiness"] and all(result["counts"][key] == value for key, value in expected.items() if key != "readiness")
        elif kind == "atomic_replay":
            result = model["simulate_commit"](control["initial_revision"], control["steps"])
            passed = result["final_revision"] == expected["final_revision"] and result["reconciliation_commit_count"] == expected["commit_count"] and result["outcomes"][-1]["outcome"] == expected["last_outcome"]
            failed_scenario = copy.deepcopy(scenarios["PHC-S15"])
            failed_scenario["operation_steps"] = failed_scenario["operation_steps"][:3]
            failed_result = model["evaluate"](root, failed_scenario)
            expected_state = snapshots["C-STATE-BASELINE-DONE-R02"]
            passed = passed and failed_result["after"] == expected_state and failed_result["work_actions"] == [] and failed_result["commit_status"] == "pending" and failed_result["proposed_transition"]["readiness"] == "ready" and failed_result["atomic_processing"]["reconciliation_commit_count"] == 0 and failed_result["atomic_processing"]["receipts"] == {}
        elif kind == "scoped_compensation":
            after = model["evaluate"](root, scenarios["PHC-S16"])["after"]
            item = next(item for item in after["work_items"] if item["lineage_id"] == "BL-WORK-PA-R01")
            passed = item["progress_basis"]["declaration_id"] == expected["declaration_id"] and after["unrelated_work"][0]["progress_basis"]["declaration_id"] == expected["unrelated_declaration_id"] and after["unrelated_work"][0]["manual_note"] == expected["manual_note"]
        elif kind == "duplicate_zip_member":
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "ambiguous.zip"
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", UserWarning)
                    with zipfile.ZipFile(path, "w") as archive:
                        archive.writestr("ppt/presentation.xml", b"first")
                        archive.writestr("ppt/presentation.xml", b"second")
                try:
                    model["native_inventory"](path)
                except ValueError:
                    passed = expected["comparison_rejected"]
        elif kind == "governing_requirement_preserved":
            scenario = copy.deepcopy(scenarios["PHC-S04"])
            scenario["target_binding"]["requirement_set_revision"] = "BL-REQUIREMENTS-v1"
            scenario["target_binding"]["source_versions"]["assignment_brief"] = "BL-BRIEF-v1"
            scenario["event_ids"] = ["CE-REFERENCES-CURRENT"]
            scenario["reassessment_input_id"] = None
            scenario["material_fulfillment_change_ids"] = []
            result = model["evaluate"](root, scenario)
            requirement = next(row for row in inputs["requirement_sets"][0]["requirements"] if row["requirement_id"] == "PA-R02")
            passed = expected["required_source"] in requirement["criterion"] and result["after"]["binding"]["requirement_set_revision"] == control["requirement_set_revision"] and result["row_statuses"]["PA-R02"] == "unknown"
        checks.append({"id": "control." + control["id"], "passed": bool(passed), "detail": control["title"]})
    return checks


def validate(root, check_index=True, include_prior=True):
    """Return named checks from the package root, including frozen Phase B/A."""
    root = Path(root)
    checks = []

    def check(identifier, condition, detail):
        checks.append({"id": identifier, "passed": bool(condition), "detail": detail})

    inputs = load(root, "fixtures/change_inputs.json")
    scenario_file = load(root, "fixtures/scenarios.json")
    expected_file = load(root, "fixtures/expected_transitions.json")
    event_file = load(root, "fixtures/change_events.json")
    proof_file = load(root, "fixtures/comparison_proofs.json")
    assessment_file = load(root, "fixtures/reassessment_inputs.json")
    control_file = load(root, "fixtures/contract_controls.json")
    model = runpy.run_path(str(root / "fixtures/reference_reconciliation.py"))
    provenance = load(root, "reference/phase_b_provenance.json")
    prior_root = root / "reference/phase_b_fixture"
    prior_inputs = load(prior_root, "fixtures/readiness_inputs.json")
    prior_validator = runpy.run_path(str(prior_root / "fixtures/validate_fixtures.py"))
    documents = {"inputs": inputs, "scenarios": scenario_file, "expected": expected_file, "events": event_file, "proofs": proof_file, "reassessments": assessment_file, "controls": control_file}
    for name, document in documents.items():
        check("scope." + name, document["evaluator_only"] and document["product_execution_count"] == 0, "Authored evaluator data with zero product execution credit")
    if check_index:
        index = load(root, "fixtures/index.json")
        check("index.scope", index["scenario_count"] == 16 and index["contract_control_count"] == 12 and index["evaluator_only"] and index["product_execution_count"] == 0, "Bounded local specification fixture")
        for item in index["files"]:
            path = root / item["path"]
            check("index." + item["path"], path.is_file() and sha256(path) == item["sha256"] and path.stat().st_size == item["bytes"], "Frozen fixture byte identity")
    check("reference.count", len(provenance["files"]) == provenance["files_copied"] == 47, "Required Phase B fixture dependencies copied exactly")
    for item in provenance["files"]:
        path = root / "reference" / item["path"]
        check("reference." + item["path"], path.is_file() and sha256(path) == item["sha256"] and path.stat().st_size == item["bytes"], "Delivered Phase B member retained byte-for-byte")
    if include_prior:
        checks.extend({**item, "id": "phase_b." + item["id"]} for item in prior_validator["validate"](prior_root))
    sources = {item["source_version_id"]: item for item in inputs["source_versions"]}
    snapshots = {item["snapshot_id"]: item for item in inputs["initial_snapshots"]}
    scenarios = {item["id"]: item for item in scenario_file["scenarios"]}
    expected = {item["scenario_id"]: item for item in expected_file["results"]}
    proofs = {item["proof_id"]: item for item in proof_file["proofs"]}
    events = {item["event_id"]: item for item in event_file["events"]}
    check("identities", len(sources) == 14 and len(snapshots) == 5 and len(scenarios) == len(expected) == 16 and set(scenarios) == set(expected), "Unique sources, snapshots and paired scenario expectations")
    check("input_counts", len(proofs) == 9 and len(events) == 17 and len(assessment_file["assessments"]) == 8 and len(control_file["controls"]) == 12, "Explicit bounded comparisons, observations and controls")
    for source in sources.values():
        for path in source["paths"]:
            check("source." + path, (root / path).is_file() and sha256(root / path) == source["sha256"], "Source aliases retain exact declared bytes")
    evidence_ids = {item["evidence_id"] for item in prior_inputs["evidence_catalog"]}
    for evidence in assessment_file["new_evidence"]:
        evidence_ids.add(evidence["evidence_id"])
        source = sources[evidence["source_version_id"]]
        path = root / evidence["path"]
        lines = path.read_text().splitlines()
        check("evidence." + evidence["evidence_id"], evidence["sha256"] == source["sha256"] and evidence["path"] in source["paths"] and lines[evidence["line"] - 1] == evidence["quote"], "Exact authored amendment anchor resolves")
    for requirement_set in inputs["requirement_sets"]:
        source = sources[requirement_set["source_version_id"]]
        text = (root / source["paths"][0]).read_text()
        ids = re.findall(r"^## (PA-R\d{2}) ", text, flags=re.MULTILINE)
        check("requirements." + requirement_set["requirement_set_revision"], ids == [row["requirement_id"] for row in requirement_set["requirements"]] and requirement_set["membership_complete"], "Complete source heading membership matches stable criteria")
        check("requirements." + requirement_set["requirement_set_revision"] + ".evidence", all(set(row["source_evidence_refs"]) <= evidence_ids for row in requirement_set["requirements"]), "Requirement source references resolve")
    for assessment in assessment_file["assessments"]:
        check("assessment." + assessment["assessment_id"] + ".basis", assessment["actual_product_or_host_execution"] is False and assessment["input_kind"] == "fixture_authored_reassessment", "Explicit independent host-response fixture")
        for row in assessment["rows"]:
            check("assessment." + assessment["assessment_id"] + "." + row["requirement_id"], set(row["evidence_refs"]) <= evidence_ids and row["assessment_id"] == assessment["assessment_id"] and row["actual_host_execution"] is False and (bool(row["unknown_reason"]) == (row["assessment_status"] == "unknown")), "Source-resolving typed reassessment with honest origin")
    correct_path = root / sources["BL-DECK-CORRECTED-v1"]["paths"][0]
    baseline_path = root / sources["BL-DECK-BASELINE-v1"]["paths"][0]
    repack_path = root / sources["BL-DECK-REPACKED-v2"]["paths"][0]
    correct_inventory = model["native_inventory"](correct_path)
    repack_inventory = model["native_inventory"](repack_path)
    baseline_inventory = model["native_inventory"](baseline_path)
    proof = proofs["C-PROOF-NATIVE-PAYLOAD-EQUAL"]
    check("native.payload", correct_inventory == repack_inventory == proof["entry_digests"] and len(correct_inventory) == proof["entry_count"] == 55, "All native entry payloads and complete named membership match")
    check("native.container", sha256(correct_path) != sha256(repack_path) and proof["native_content_edit_count"] == 0, "Constructed repackage changes container bytes while preserving native payload")
    with zipfile.ZipFile(correct_path) as before_zip, zipfile.ZipFile(repack_path) as after_zip:
        check("native.physical_order", before_zip.namelist() == list(reversed(after_zip.namelist())), "Physical archive ordering may change without logical slide-order change")
    check("native.ambiguity_policy", model["timing_bridge_supported"](proof), "Full native payload proof explicitly rejects duplicate member ambiguity")
    changed_names = [name for name in sorted(set(baseline_inventory) | set(correct_inventory)) if baseline_inventory.get(name) != correct_inventory.get(name)]
    check("native.actual_difference", changed_names == proofs["C-PROOF-NATIVE-CHANGED"]["changed_entry_names"] and len(changed_names) > 0, "Baseline/corrected semantic-change fixture has independently observed native changes")
    for source_id, seconds in [("BL-REHEARSAL-BASELINE-v1", 455), ("BL-REHEARSAL-CORRECTED-v1", 410)]:
        text = (root / sources[source_id]["paths"][0]).read_text()
        deck_id = source_id.replace("REHEARSAL", "DECK")
        check("timing." + source_id, f"elapsed_seconds = {seconds}" in text and f"artifact_sha256 = {sources[deck_id]['sha256']}" in text, "Original measured duration keeps its exact original native hash")
    derivation = proof["timing_derivation"]
    check("timing.derivation", derivation["measured_elapsed_seconds"] == 410 and derivation["original_measured_artifact_sha256"] == sources["BL-DECK-CORRECTED-v1"]["sha256"] and derivation["derived_current_artifact_sha256"] == sources["BL-DECK-REPACKED-v2"]["sha256"] and derivation["new_measurement_created"] is False, "Derived applicability preserves the original measurement lineage")
    original_refs = (root / sources["BL-REFERENCES-v1"]["paths"][0]).read_text()
    formatted_refs = (root / sources["BL-REFERENCES-FORMAT-v2"]["paths"][0]).read_text()
    normalize = lambda text: [line.strip() for line in text.splitlines() if line.strip()]
    check("reference.format_equivalence", normalize(original_refs) == normalize(formatted_refs) == proofs["C-PROOF-REFERENCE-FORMAT"]["normalized_lines"], "Full reference text survives a verified whitespace and locator change")
    contact_bytes = (root / sources["BL-REFERENCES-CONTACT-v2"]["paths"][0]).read_bytes()
    check("reference.contact_scope", contact_bytes.startswith(original_refs.encode()), "Original reference packet is an exact prefix of the unrelated metadata revision")
    current_brief = (root / sources["BL-BRIEF-CURRENT-v2"]["paths"][0]).read_text()
    current_refs = (root / sources["BL-REFERENCES-v3"]["paths"][0]).read_text()
    check("amendment.governing_scope", "replaces only PA-R02" in current_brief and "Use BKS-2026-v3" in current_brief and "BL-BRIEF-CURRENT-v2 explicitly applies" in current_refs and "24 collisions in 150" in current_refs and 24 / 150 * 100 == 16, "v3 current-source requirement has explicit governing amendment and exact arithmetic")
    check("amendment.historical_values", "13 collisions in 50" in current_refs and "22 collisions in 120" in current_refs, "Archived cited historical sample values remain available")
    check("amendment.limit", proofs["C-PROOF-LIMIT-AMENDMENT"]["current_limit_seconds"] == 400 and 410 - 400 == 10 and "400 seconds" in (root / sources["BL-BRIEF-LIMIT400-v2"]["paths"][0]).read_text(), "Existing 410-second measurement is ten seconds above amended limit")
    for scenario_id, scenario in scenarios.items():
        prefix = "scenario." + scenario_id
        check(prefix + ".zero_credit", scenario["execution_status"] == "not_run" and scenario["actual_product_execution_count"] == scenario["actual_host_execution_count"] == 0, "No local fixture check receives actual implementation credit")
        check(prefix + ".binding", scenario["target_binding"]["artifact_sha256"] == sources[scenario["target_binding"]["artifact_version_id"]]["sha256"], "Target selected artifact has the exact expected hash")
        check(prefix + ".packet", all(item["sha256"] == sources[item["source_version_id"]]["sha256"] and item["path"] in sources[item["source_version_id"]]["paths"] for item in scenario["model_input_files"]), "Host packet references exact selected source versions")
        try:
            actual = model["evaluate"](root, scenario)
        except (KeyError, ValueError, TypeError) as error:
            check(prefix + ".evaluation", False, str(error))
            continue
        for key, value in expected[scenario_id].items():
            if key in {"scenario_id", "expectation_basis"}:
                continue
            observed = actual["after"]["record_revision"] if key == "record_revision" else actual.get(key)
            check(prefix + ".expected." + key, observed == value, "Generic transition model agrees with independently authored " + key)
        before = snapshots[scenario.get("effective_reconciliation_snapshot_id", scenario["initial_snapshot_id"])]
        before_rows = {row["requirement_id"]: row for row in before["requirement_results"]}
        for row in actual["after"]["requirement_results"]:
            if actual["row_origins"][row["requirement_id"]] == "carried_forward":
                previous = before_rows[row["requirement_id"]]
                check(prefix + ".carry." + row["requirement_id"], all(row[key] == previous[key] for key in ("assessment_id", "assessed_at", "assessor_basis", "assessment_status", "evidence_refs")) and row["carry_forward_validated_at"] == scenario["reconciliation_at"] and bool(row["carry_forward_dependency_scope"]), "Original assessment provenance retained with separate scoped carry metadata")
            if actual["row_origins"][row["requirement_id"]] == "unchanged":
                check(prefix + ".alias_unchanged." + row["requirement_id"], row == before_rows[row["requirement_id"]], "Exact-byte alias leaves assessment payload and provenance unchanged")
        before_work = {item["work_id"]: item for item in before["work_items"]}
        for item in actual["after"]["work_items"]:
            old = before_work.get(item["work_id"])
            if old:
                check(prefix + ".progress." + item["work_id"], all(item.get(field) == old.get(field) for field in model["PROGRESS_FIELDS"]), "Existing personal progress, declarations and manual fields survive evidence changes")
            else:
                check(prefix + ".new_episode." + item["episode_id"], item["personal_progress"] == "open" and item["progress_basis"] == {"kind": "system_default", "declaration_id": None} and item["progress_history"] == [], "New episode uses unattributed system default progress")
            if item["evidence_lifecycle"] == "active":
                check(prefix + ".occurrence." + item["episode_id"], all(item["occurrence_key"][key] == scenario["target_binding"][key] for key in ("assignment_id", "artifact_id", "artifact_sha256", "requirement_set_revision")), "Current active occurrence retains Phase B version-bound identity")
        check(prefix + ".unrelated_state", actual["after"]["parent_progress"] == before["parent_progress"] and actual["after"]["unrelated_work"] == before["unrelated_work"], "Personal parent state and unrelated work remain attributable")
    missing_packet = scenarios["PHC-S09"]["model_input_files"]
    check("missing.packet_scope", all(item["source_version_id"] != "BL-DECK-CORRECTED-v1" for item in missing_packet), "Missing replacement is excluded from the scenario host packet")
    partial = scenarios["PHC-S10"]["fault_injection"]
    check("partial.scope", partial["returned_slide_indices"] == [1, 2, 3, 4, 5] and partial["unavailable_slide_indices"] == [6, 7] and partial["actual_injected_product_run"] is False, "Partial native coverage is a bounded runner instruction with zero observed execution")
    format_result = model["evaluate"](root, scenarios["PHC-S12"])
    format_rows = {row["requirement_id"]: row for row in format_result["after"]["requirement_results"]}
    format_work = next(item for item in format_result["after"]["work_items"] if item["lineage_id"] == "BL-WORK-PA-R02")
    format_proof = proofs["C-PROOF-REFERENCE-FORMAT"]
    new_evidence = {item["evidence_id"]: item for item in assessment_file["new_evidence"]}
    old_evidence = {item["evidence_id"]: item for item in prior_inputs["evidence_catalog"]}
    check("locator.remap_membership", len(format_proof["evidence_locator_remaps"]) == 4 and len(format_rows["PA-R02"].get("evidence_locator_remaps", [])) == 3 and len(format_rows["PA-R03"].get("evidence_locator_remaps", [])) == 1, "Every used reference-packet anchor has a scoped current locator")
    for remap in format_proof["evidence_locator_remaps"]:
        current = new_evidence[remap["current_evidence_id"]]
        original = old_evidence[remap["original_evidence_id"]]
        check("locator." + remap["current_evidence_id"], remap["quote"] == original["quote"] == current["quote"] and remap["source_version_id"] == current["source_version_id"] == "BL-REFERENCES-FORMAT-v2" and remap["sha256"] == current["sha256"] == sources["BL-REFERENCES-FORMAT-v2"]["sha256"] and remap["line"] == current["line"], "Current locator resolves exact quoted text under the reformatted source hash")
    check("locator.updated_work", format_work.get("evidence_refs") == format_rows["PA-R02"].get("current_evidence_refs") and format_work.get("original_assessment_evidence_refs") == format_rows["PA-R02"]["evidence_refs"] and format_work.get("evidence_locator_remaps") == format_rows["PA-R02"].get("evidence_locator_remaps"), "Current updated work uses verified current anchors while retaining original assessment lineage")
    checks.extend(validate_controls(root, model, control_file["controls"], scenarios, inputs, events))
    return checks


def negative_controls(root):
    """Apply ten targeted semantic mutations without relying on checksum failure."""
    root = Path(root)
    mutations = [
        ("PHC-N01", "fixtures/expected_transitions.json", lambda data: data["results"][0]["row_statuses"].update({"PA-R01": "satisfied"}), "scenario.PHC-S01.expected.row_statuses"),
        ("PHC-N02", "fixtures/comparison_proofs.json", lambda data: data["proofs"][1].update({"kind": "text_equivalence"}), "native.ambiguity_policy"),
        ("PHC-N03", "fixtures/comparison_proofs.json", lambda data: data["proofs"][1]["timing_derivation"].update({"original_measured_artifact_sha256": "0" * 64}), "timing.derivation"),
        ("PHC-N04", "fixtures/scenarios.json", lambda data: data["scenarios"][6].update({"membership_complete": False}), "scenario.PHC-S07.evaluation"),
        ("PHC-N05", "fixtures/expected_transitions.json", lambda data: data["results"][11]["current_episode_progress"].update({"BL-WORK-PA-R02/E1": "open"}), "scenario.PHC-S12.expected.current_episode_progress"),
        ("PHC-N06", "fixtures/expected_transitions.json", lambda data: data["results"][12].update({"planner_eligible_episode_ids": []}), "scenario.PHC-S13.expected.planner_eligible_episode_ids"),
        ("PHC-N07", "fixtures/expected_transitions.json", lambda data: data["results"][14]["atomic_processing"].update({"reconciliation_commit_count": 2}), "scenario.PHC-S15.expected.atomic_processing"),
        ("PHC-N08", "fixtures/change_events.json", lambda data: data["events"][11].update({"unknown_selectors": []}), "scenario.PHC-S10.expected.impacts"),
        ("PHC-N09", "fixtures/reassessment_inputs.json", lambda data: data["new_evidence"][0].update({"quote": "unsupported v4 amendment"}), "evidence.C-EV-V3-REQUIREMENT"),
        ("PHC-N10", "fixtures/comparison_proofs.json", lambda data: data["proofs"][1]["entry_digests"].pop("ppt/presentation.xml"), "native.payload"),
    ]
    results = []
    for identifier, relative, mutation, intended_check in mutations:
        with tempfile.TemporaryDirectory() as directory:
            changed_root = Path(directory) / "fixture"
            shutil.copytree(root / "fixtures", changed_root / "fixtures")
            shutil.copytree(root / "reference", changed_root / "reference")
            path = changed_root / relative
            data = json.loads(path.read_text())
            mutation(data)
            path.write_text(json.dumps(data))
            failed = [check["id"] for check in validate(changed_root, check_index=False, include_prior=False) if not check["passed"]]
            results.append({"id": identifier, "passed": intended_check in failed, "detail": "Targeted semantic mutation rejected by " + intended_check, "intended_check": intended_check, "failed_checks": failed})
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--negative-controls", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    checks = validate(args.root)
    mutations = negative_controls(args.root) if args.negative_controls else []
    report = {"schema_version": "phase-c-fixture-validation.v1", "generated_at": datetime.now(timezone.utc).isoformat(), "evaluator_only": True, "product_execution_count": 0, "actual_host_execution_count": 0, "summary": {"checks": len(checks), "passed": sum(item["passed"] for item in checks), "scenarios": 16, "contract_controls": 12, "negative_controls": len(mutations), "negative_controls_passed": sum(item["passed"] for item in mutations), "frozen_phase_b_files": 47}, "checks": checks, "negative_controls": mutations}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report["summary"]))
    failures = [item for item in checks + mutations if not item["passed"]]
    if failures:
        print(json.dumps(failures, indent=2))
    raise SystemExit(bool(failures))


if __name__ == "__main__":
    main()
