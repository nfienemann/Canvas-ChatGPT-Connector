# Phase C implementation handoff

Implement the five PHC specifications against the active Phase B readiness model. Deliver one coherent path from observed source change through criterion impact and remaining-work reconciliation to a saved change report.

## 1. Bind the active implementation

Read repository instructions and capture the active branch, commit, dirty diff fingerprint, runtime and tool schemas in `templates/active_build_bindings.json`.

Use actual A/B schemas and captures where available. The pinned evidence map identifies current candidate routes and primitives. Reuse existing process state, source/version identity, graph lineage, impact events and receipts.

Inspect `get_changes`, normal local import/version selection, `processes/impact.py`, `ProcessRepository`, graph `changes` and the current readiness/task adapter. The current generic impact machinery invalidates dependent records broadly. Extend its readiness projection with criterion-level dependency evidence and coherent current-selection views.

## 2. Observe and compare changes

Capture one logical before/after observation with canonical identity, selected base, version parents or ordering, current selection epoch and actual coverage. Preserve every attempt while deduplicating logical effects.

Follow current source continuation and completeness rules. Preserve missing/truncated comparison scope. Use actual version lineage and selected base at apply time. A late historical observation remains attributable to its historical scope.

For the repackaging control, compare unique canonical native part names and uncompressed bytes for the entire package. Logical presentation order is contained in the compared native parts. Retain the original rehearsal hash and an explicit equivalence derivation for the selected container.

## 3. Determine impact and reassess

Follow Phase B's requirement, artifact, evidence, measurement and work links. Record unaffected, affected or unknown per candidate criterion, together with the relevant dependency extent.

Carry forward only where the proof covers the governing criterion and relevant evidence/context. Preserve the original assessment basis/time and add proof/validation metadata. Universal and absence checks need their corresponding source extent accounted for.

Apply explicit requirement correspondence for additions, removals and modifications. The v3 fixture amendment changes the governing PA-R02 instruction directly. Keep the source's stated field scope and other criteria's independent evidence.

Use the current host workflow for qualitative targeted reassessment. Source reads and host work occur outside the final commit transaction. Deterministic current results can be used immediately when supported. Interrupted host work leaves an explicit pending stage and an accurate current-selection projection.

## 4. Reconcile work with provenance

Retain Phase B's version-bound occurrence key and introduce stable lineage plus episode identity where needed. Apply the seven decisions in `contracts/reconciliation_rules.json`.

| Decision | Required basis |
| --- | --- |
| Keep or update | Supported continuing fulfillment and established correspondence. |
| Resolve | Current source-grounded criterion satisfaction. |
| Retire | Supported requirement removal or nonapplicability. |
| Create | New supported gap with no established lineage. |
| Reopen | Recurring or materially changed fulfillment in an established lineage, including a previously active episode. |
| Review needed | An unresolved comparison, evidence or correspondence dependency. |

Preserve personal declarations and compatible manual fields. New episodes use system-default open progress with no invented declaration ID. Historical done state remains attributable to its original scope. Bind the current episode's eligibility through the planner adapter so supported new remediation is available.

Track the fulfillment scope of effort estimates. A changed scope exposes the old estimate's historical basis and the current missing/updated input. Phase D consumes those observations for calibrated forecasting and stable replanning.

## 5. Apply, resume and compensate

Build the reconciliation plan with expected record/source/work bases. Recheck those bindings at atomic apply and use current optimistic concurrency and replay receipts. Preserve a concurrent user update when rejecting or rebasing a stale plan.

Publish one coherent readiness/work generation and its receipt. Keep staged pending observations recoverable. If the response is lost after commit, retry with the same logical key and retrieve the confirmed effect.

Use a new scoped compensating revision for explicit rollback. The pinned general rollback restores a whole before-image, so bind or extend the current recovery path to preserve intervening unrelated progress and handle changed-again fields explicitly.

Return a concise report of what changed, what evidence carries forward, which criteria were reassessed or remain unresolved, and which work was kept, updated, resolved, retired, created or reopened. The saved report and final host answer identify the same committed generation.

## 6. Execute acceptance and deliver

Run `validate_package.py --negative-controls`, then bind the sixteen scenarios to the actual adapters. Test-authored assessment/transition inputs exercise deterministic integration. Native host journeys read the current source packet and produce their own assessments before oracle comparison.

Complete PHC-T01 through PHC-T26 with retrievable requests, responses, state images and receipts. Include actual process restart, uncertain-response replay, stale-base conflict and scoped rollback after unrelated progress. Preserve the observable submitted host boundary and final answer when internal context is unavailable.

Run or reuse applicable A/B fixture controls and focused existing source/change/state/task/planner tests. Compare earlier actual product captures when available and state matching scope before assigning a regression label.

Deliver the implementation diff, current schemas, completed case report, actual host transcripts, saved transition examples, recovery results and Phase D handoff. Actual product and host counts are derived from executed benchmark attempts. The supplied report templates begin at zero.
