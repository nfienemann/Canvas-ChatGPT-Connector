# Phase C — Change impact and remaining-work reconciliation

Phase C connects changed coursework to the saved readiness and work from Phase B. An ordinary refresh or revised-file review records the change, identifies affected criteria, carries forward supported valid evidence and reconciles current work.

## Specification set

| Specification | Outcome |
| --- | --- |
| `PHC-01` | Observe scoped version changes through current refresh/import paths with exact coverage, ordering and replay identity. |
| `PHC-02` | Determine criterion impact, prove carry-forward and reassess the relevant changed scope. |
| `PHC-03` | Reconcile work through stable lineage, version-bound occurrences and recurrence episodes. |
| `PHC-04` | Apply coherent generations atomically, recover interrupted work and explain the result through the plugin. |
| `PHC-QA-01` | Verify real source/host behavior, state transitions, restart/replay, compensation and A/B compatibility. |

Begin with `CODEX_HANDOFF.md`. The package includes 26 acceptance cases, 16 transition scenarios, 18 model invariants, seven bounded measures and a ten-check host rubric. `report.json` records preparation and local validation. Actual implementation results belong in `templates/implementation_report.json`.

## Expected behavior

| Change | Readiness and work response |
| --- | --- |
| Same-byte rename or reimport | Reuse identity and current assessment, with the alias observation recorded. |
| Native PowerPoint repackaging with every part payload equal | Carry the applicable review with an equivalence proof, retaining the original rehearsal hash and measurement basis. |
| Corrected deck and matching rehearsal | Reassess the changed dependency scope and resolve the supported baseline gaps. |
| Governing source amendment | Update the affected criterion and retain independent valid findings. |
| Duration limit changes from 420 to 400 seconds | Recalculate the scoped timing result from the matching recorded rehearsal and reconcile the resulting work. |
| Replacement file is missing or partially read | Keep proven current results useful and show pending review for unsupported affected rows. |
| A resolved defect recurs | Link a new current episode to the existing work lineage and preserve prior completion history. |

These are synthetic acceptance expectations. The actual product report captures observed behavior on the integrated build.

## Carry-forward and selective reassessment

Carry-forward requires equivalence of the governing criterion and its complete relevant evidence extent. That extent includes context, notes and claim populations used by absence or all-claims checks. A retained sentence can support a local observation while a newly added paragraph changes a broader criterion.

The native repackaging control compares canonical part names and every uncompressed part payload. Logical slide order, notes, media, embedded objects and timing content remain in those compared parts. ZIP compression, member ordering and timestamps can differ. The derived assessment links the selected container to the original recorded rehearsal without rewriting its measured artifact identity.

Carried rows retain the original assessor and assessment time, plus a new proof and validation time. Reassessed rows identify the new review. A pending changed-version view uses Phase B's current-selection rules, with unresolved affected rows unknown and supported current rows visible.

## Remaining-work semantics

The action vocabulary is `keep`, `update`, `resolve`, `retire`, `create`, `reopen` and `review_needed`.

Stable work lineage links versions. Each occurrence keeps its precise requirement/artifact binding, and each episode identifies a continuing or newly recurring fulfillment obligation.

Personal done declarations remain attached to their original episode and scope. A continuing same-scope gap can remain marked done while its evidence still needs work. A genuinely new episode starts with system-default open progress unless an actual applicable declaration is supplied. Evidence resolution and retirement retain their own reasons and history.

Reconciliation preserves applicable user notes and other manual fields. Reopened current episodes reach the planner through their current actionable scope, with historical completion and estimate provenance retained.

## Existing foundations

Use the existing process impact engine, evidence graph comparison, owned-state revisions, replay receipts, source identity and Phase B readiness/task adapters. Bind the pinned source map to the active implementation and close existing capabilities with evidence.

Stage 5 supplies the accepted current operating behavior. Deterministic impact runs through normal source-observation hooks. Host-needed reassessment uses the available review workflow and remains visibly pending until its actual execution.

Phase D receives reconciled current work, constraint changes, episode scope, estimate applicability and operation receipts for personalized forecasting and stable replanning.

## Package contents

- `specs/` contains five JSON specifications.
- `contracts/` defines change provenance, reconciliation rules, execution captures and host fidelity.
- `fixtures/` contains versioned source amendments, native-payload comparison proof, authored transitions and independent expected outcomes.
- `reference/` retains the frozen A/B inputs and contracts used by the scenarios.
- `prompts/` contains ordinary change-review, missing-input, progress and recovery tasks.
- `templates/` contains current-build bindings and unexecuted run/report records.
- `evidence/` contains source bindings, acceptance review and executed local checks.

## Validate the packet

Python 3.11 or later is sufficient for local validation.

```bash
python /path/to/phase_c_reconciliation/validate_package.py --negative-controls
```

The fixture validator can run independently.

```bash
python /path/to/phase_c_reconciliation/fixtures/validate_fixtures.py --negative-controls
```

The package validator's optional `--source-root` argument verifies source bytes against a local checkout of the pinned public commit. Product completion requires actual current-build source/store/task and supported-host acceptance, including persistence restart and recovery.
