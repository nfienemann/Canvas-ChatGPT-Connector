# BenchLink Phase A benchmark

This fixture is a small, inspectable presentation-review benchmark. BenchLink, its campus, study records, roles, project plans and timing observations are synthetic. The exported presentation files contain native editable text and native speaker notes.

## Packet conditions

| Case | Submitted files | Known condition |
| --- | --- | --- |
| `baseline` | Brief, deck, references, rehearsal | Three planted issues |
| `corrected` | Brief, deck, references, rehearsal | The three issues are corrected |
| `missing_deck` | Brief, references, rehearsal | Exactly `deck.pptx` is absent |

Each complete presentation has seven slides and seven native note parts. Four files fit a five-document workflow. Full deck inspection requires every slide and available notes surface to be read, including additional bounded calls when a route limits selected parts.

Use the exact input paths and hashes in `index.json`. Supply only a selected case's `model_input_files` and its `runner_context`. Oracle, build and preview files belong to the evaluator. Keep cases isolated so that a previous case's presentation cannot supply the missing-deck answer.

## Assignment requirements

| ID | Requirement | Baseline | Corrected |
| --- | --- | --- | --- |
| PA-R01 | Include the required sections, including Limitations and validation plan | Missing the required limitations and validation section | Section present on slide 6 |
| PA-R02 | Use current BKS-2026-v2 collision evidence | Slide 4 uses archived v1 values | Slide 4 uses v2 values |
| PA-R03 | Attribute quantitative collision claims to a resolvable source version | Resolves to archived v1 with matching historical values | Resolves to current v2 |
| PA-R04 | Keep the measured rehearsal within 420 seconds | 455 seconds, 35 seconds over | 410 seconds, 10 seconds remaining |

The baseline has exactly three planted issues. The archived citation remains traceable and numerically faithful to its historical sample. Its use as the current claim causes PA-F02.

The reference packet expressly scopes supersession to `current_collision_rate`. Archived v1 records 13 collisions in 50 reservations, exactly 26%. Current v2 records 22 collisions in 120 reservations, rounded from 18.33% to 18%. Historical v1 values retain their provenance.

## Native notes control

Slide 5 notes contain the fictional pilot-coordinator role, Equipment Desk Lead, and the marker `BL-NOTES-ONLY-204`. The role and marker are absent from visible slide text and supporting case files. This gives a positive control for actual notes extraction.

`oracle.json` records exact supporting-file lines, native OOXML parts and verbatim quotes. The missing-section oracle specifies all seven slide and note surfaces as the search scope. A complete artifact review can then be distinguished from a partial extraction by the recorded coverage.

## Missing-deck control

`cases/missing_deck` retains the baseline brief, references and rehearsal byte for byte. Its missing-input declaration identifies `deck.pptx`, immutable document version `BL-DECK-BASELINE-v1` and the known baseline hash.

Supply the case's `runner_context` when running it. A response can explain the current-source requirement from the brief and reference packet. It can also report that the retained 455-second synthetic rehearsal of BL-DECK-BASELINE-v1 exceeded 420 seconds by 35 seconds. The absent deck leaves its current section coverage, claims, citations and notes unevaluable.

## Independent validation

From the ZIP's package root, run the standard-library validator with Python 3.

```bash
python fixtures/validate_fixtures.py --negative-controls --report evidence/fixture_validation.json
```

The validator reads actual files. It checks SHA-256 hashes and sizes, precise oracle anchors, ordered native slide relationships, seven linked note parts in each deck, notes-only content, the three issues and corrected controls, timing associations, source arithmetic, exact missing-file scope and visual-review hashes. Four temporary tamper controls verify that changed source bytes, an accidentally supplied missing deck, a mismatched rehearsal version and a missing notes marker are detected.

`evidence/fixture_validation.json` records the executed preparation checks. `build/presentation_checks.json` records package, layout, font and Artifact Tool import checks. `visual_review.json` identifies the final deck bytes and fourteen individually inspected slide previews. The previews were rendered from the finalized PPTX imports at 1280 by 720 pixels.

CanvasBridge executions are zero. Native PowerPoint executions are zero. Phase A product runs should record current behavior and any capability gaps against this oracle in their own result records.

## Reproduction inputs

`build/decks.json` holds all authored slide and note text. `build/build_decks.mjs` builds and finalizes native PPTX files through `@oai/artifact-tool`. `build/assemble_packet.py` writes the supporting case files, rehearsal hash associations and evaluator metadata around those exports.

The delivered fixture was built with Artifact Tool 2.8.119 and runtime bundle 26.1030.10813 using DejaVu Sans. Frozen delivered bytes and their manifest hashes define `benchlink-phase-a-v1`. A fresh export can generate new package identifiers and hashes, so assign a new fixture version when replacing the frozen decks.

To rebuild in an equivalent authoring environment, use a new empty output tree. Copy `build/decks.json` into its `build` directory and copy the `.mjs` builder into a private work directory. Give that work directory a `node_modules` symlink to the runtime's `CODEX_PRIMARY_RUNTIME_NODE_MODULES`. The presentation skill's helper path defaults to `/root/.codex/skills/builtins/presentations` and can be supplied through `PRESENTATION_SKILL_DIR`.

```bash
"$CODEX_PRIMARY_RUNTIME_NODE" /absolute/private-work/build_decks.mjs \
  /absolute/new-output/fixtures \
  /absolute/private-work \
  /absolute/common-parent
```

The common parent must contain the output and private work trees. The builder requires `CODEX_PRIMARY_RUNTIME_PYTHON` and the installed presentation skill finalizers. It writes each finalized deck plus private validation receipts and previews. Inspect all fourteen rendered slides before setting the visual-review confirmation on the supporting-packet assembler.

```bash
python build/assemble_packet.py \
  /absolute/new-output/fixtures \
  /absolute/private-work \
  --visual-reviewed
```

Omitting `--visual-reviewed` records the visual review as pending. The standalone fixture validator requires a completed review record. Refresh the fixture version and manifest when publishing rebuilt bytes.
