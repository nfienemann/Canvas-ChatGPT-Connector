"""Validate frozen Phase A fixtures with the Python standard library.

This validates authored files and their oracle. Product execution is a separate step.
"""

import argparse
import copy
import hashlib
import json
import posixpath
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET


NS = {
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def xml_text(data):
    root = ET.fromstring(data)
    return "\n".join("".join(node.itertext()) for node in root.findall(".//a:t", NS))


def relationships(archive, part):
    rel_path = posixpath.join(posixpath.dirname(part), "_rels", posixpath.basename(part) + ".rels")
    root = ET.fromstring(archive.read(rel_path))
    results = {}
    for relationship in root:
        target = relationship.attrib["Target"]
        if target.startswith("/"):
            target = target.lstrip("/")
        else:
            target = posixpath.normpath(posixpath.join(posixpath.dirname(part), target))
        results[relationship.attrib["Id"]] = {
            "target": target,
            "type": relationship.attrib["Type"].rsplit("/", 1)[-1],
            "external": relationship.attrib.get("TargetMode") == "External",
        }
    return results


def read_deck(path):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC validation failed")
        presentation = ET.fromstring(archive.read("ppt/presentation.xml"))
        rels = relationships(archive, "ppt/presentation.xml")
        slides = []
        for slide_id in presentation.findall("p:sldIdLst/p:sldId", NS):
            relationship = rels[slide_id.attrib[f"{{{NS['r']}}}id"]]
            if relationship["type"] != "slide" or relationship["external"]:
                raise ValueError("Presentation slide relationship is invalid")
            slide_part = relationship["target"]
            note_rels = [item for item in relationships(archive, slide_part).values()
                         if item["type"] == "notesSlide"]
            if len(note_rels) != 1 or note_rels[0]["external"]:
                raise ValueError(f"Expected one native notes relationship for {slide_part}")
            notes_part = note_rels[0]["target"]
            slides.append({"part": slide_part, "text": xml_text(archive.read(slide_part)),
                           "notes_part": notes_part, "notes": xml_text(archive.read(notes_part))})
        return slides


def walk_anchors(value):
    if isinstance(value, dict):
        if "path" in value and "quote" in value:
            yield value
        for child in value.values():
            yield from walk_anchors(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_anchors(child)


def parse_rehearsal(path):
    return dict(line.split(" = ", 1) for line in path.read_text(encoding="utf-8").splitlines()
                if " = " in line)


def validate(root):
    checks = []

    def check(identifier, condition, detail):
        checks.append({"id": identifier, "passed": bool(condition), "detail": detail})

    index = json.loads((root / "index.json").read_text(encoding="utf-8"))
    oracle = json.loads((root / "oracle.json").read_text(encoding="utf-8"))
    check("schema.index", index["schema_version"] == "phase-a-fixture-index.v1", index["schema_version"])
    check("schema.oracle", oracle["schema_version"] == "phase-a-fixture-oracle.v1", oracle["schema_version"])
    check("scope.synthetic", index.get("synthetic") is True, "Fixture is labeled synthetic")
    check("scope.product_executions", index["product_execution_count"] == oracle["product_execution_count"] == 0,
          "CanvasBridge execution count is zero")
    check("scope.cases", [case["case_id"] for case in index["cases"]] == ["baseline", "corrected", "missing_deck"],
          "Three declared packet conditions")
    check("scope.requirements", {item["id"] for item in oracle["requirements"]} == {"PA-R01", "PA-R02", "PA-R03", "PA-R04"},
          "Four assignment requirement IDs")
    manifest_path = root / "SHA256SUMS"
    check("manifest.exists", manifest_path.is_file(), "Whole-fixture checksum manifest is present")
    if manifest_path.is_file():
        for number, line in enumerate(manifest_path.read_text(encoding="utf-8").splitlines(), 1):
            expected_hash, relative_path = line.split("  ", 1)
            path = root / relative_path
            check(f"manifest.file.{number}", path.is_file() and sha256(path) == expected_hash, relative_path)

    for case in index["cases"]:
        case_id = case["case_id"]
        expected_names = {Path(item["path"]).name for item in case["model_input_files"]}
        actual_names = {path.name for path in (root / "cases" / case_id).iterdir()}
        check(f"{case_id}.input_scope", expected_names == actual_names, "Case directory matches its exact input set")
        for item in case["model_input_files"]:
            file_path = root / item["path"]
            exists = file_path.is_file()
            check(f"{case_id}.{file_path.name}.hash", exists and sha256(file_path) == item["sha256"], item["path"])
            check(f"{case_id}.{file_path.name}.bytes", exists and file_path.stat().st_size == item["bytes"], item["path"])

    for number, anchor in enumerate(walk_anchors(oracle), 1):
        path = root / anchor["path"]
        try:
            if "part" in anchor:
                with zipfile.ZipFile(path) as archive:
                    text = xml_text(archive.read(anchor["part"]))
                location = f"{anchor['path']}#{anchor['part']}"
            else:
                lines = path.read_text(encoding="utf-8").splitlines()
                text = lines[anchor["line"] - 1]
                location = f"{anchor['path']} line {anchor['line']}"
            check(f"oracle.anchor.{number}", anchor["quote"] in text, location)
        except (KeyError, ValueError, OSError, IndexError, zipfile.BadZipFile) as error:
            check(f"oracle.anchor.{number}", False, str(error))

    notes_control = oracle["notes_extraction_control"]
    decks = {}
    for case_id in ("baseline", "corrected"):
        deck_path = root / "cases" / case_id / "deck.pptx"
        try:
            slides = read_deck(deck_path)
            decks[case_id] = slides
            check(f"{case_id}.native_slides", len(slides) == 7, "Seven ordered native slides")
            check(f"{case_id}.native_notes", len(slides) == 7 and all(slide["notes"].strip() for slide in slides),
                  "Seven relationship-linked native note parts contain text")
            visible = "\n".join(slide["text"] for slide in slides)
            notes = "\n".join(slide["notes"] for slide in slides)
            check(f"{case_id}.notes_only_marker", notes.count(notes_control["marker"]) == 1 and notes_control["marker"] not in visible,
                  "Marker occurs once in native notes and zero times in visible slide text")
            check(f"{case_id}.notes_only_fact", notes_control["fact"] in slides[4]["notes"] and "Equipment Desk Lead" not in visible,
                  "Pilot coordinator fact is present in slide 5 notes")
            check(f"{case_id}.all_slides_synthetic", all("Synthetic coursework" in slide["text"] for slide in slides),
                  "Every slide carries the synthetic label")
        except (KeyError, ValueError, OSError, ET.ParseError, zipfile.BadZipFile) as error:
            check(f"{case_id}.native_package", False, str(error))

    if "baseline" in decks:
        all_text = "\n".join(slide["text"] + "\n" + slide["notes"] for slide in decks["baseline"])
        check("baseline.required_section_absent", "limitations and validation plan" not in all_text.lower(),
              "All seven slide and note surfaces searched")
        check("baseline.current_claim_archived", "Current collision rate is 26% in 50 synthetic test reservations." in decks["baseline"][3]["text"]
              and "BKS-2026-v1" in decks["baseline"][3]["text"], "Slide 4 contains the intentionally stale current claim")
    if "corrected" in decks:
        slide = decks["corrected"][5]["text"]
        check("corrected.required_section_present", all(value in slide for value in ["Limitations and validation plan", "Limitation", "30 new synthetic booking attempts", "every overlap"]),
              "Slide 6 includes the required heading, limitation and measurable validation")
        check("corrected.current_claim_current", "Current collision rate is 18% in 120 synthetic test reservations." in decks["corrected"][3]["text"]
              and "BKS-2026-v2" in decks["corrected"][3]["text"], "Slide 4 cites the current source and rounded percentage")

    for case_id, expected_seconds in [("baseline", 455), ("corrected", 410), ("missing_deck", 455)]:
        record = parse_rehearsal(root / "cases" / case_id / "rehearsal.txt")
        deck_case = "baseline" if case_id == "missing_deck" else case_id
        expected_version = f"BL-DECK-{deck_case.upper()}-v1"
        check(f"{case_id}.rehearsal_binding", record["artifact_version_id"] == expected_version
              and record["artifact_sha256"] == sha256(root / "cases" / deck_case / "deck.pptx"),
              "Measured record binds to the exact known deck bytes and version")
        check(f"{case_id}.rehearsal_seconds", int(record["elapsed_seconds"]) == expected_seconds,
              f"Synthetic measured duration is {expected_seconds} seconds")
        check(f"{case_id}.rehearsal_measurement_kind", record["measurement_kind"] == "synthetic_timed_observation",
              "Record identifies a synthetic observed duration")

    check("arithmetic.v1", 13 / 50 * 100 == 26, "13 of 50 equals 26 percent")
    check("arithmetic.v2", round(22 / 120 * 100) == 18, "22 of 120 rounds to 18 percent")
    check("arithmetic.baseline", 455 - 420 == 35, "Recorded baseline exceeds the limit by 35 seconds")
    check("arithmetic.corrected", 420 - 410 == 10, "Recorded corrected control has 10 seconds remaining")

    missing = index["cases"][2]["missing_inputs"]
    check("missing_deck.exact_omission", len(missing) == 1 and missing[0]["path"] == "cases/missing_deck/deck.pptx"
          and not (root / missing[0]["path"]).exists(), "Only the expected deck is intentionally omitted")
    check("missing_deck.known_hash", missing[0]["known_sha256"] == sha256(root / "cases/baseline/deck.pptx"),
          "Missing input declaration names the same baseline artifact bytes")
    for filename in ("brief.md", "references.md", "rehearsal.txt"):
        check(f"missing_deck.{filename}.retained", (root / "cases/missing_deck" / filename).read_bytes()
              == (root / "cases/baseline" / filename).read_bytes(), "Supporting record is byte-identical to baseline")
    check("oracle.baseline_findings", oracle["cases"][0]["expected_finding_ids"] == ["PA-F01", "PA-F02", "PA-F03"],
          "Exactly three planted baseline issues")
    check("oracle.corrected_findings", oracle["cases"][1]["expected_finding_ids"] == [], "Corrected control clears the three issues")
    check("oracle.attribution_control", oracle["cases"][0]["requirement_status"]["PA-R03"] == "passes",
          "Baseline historical source attribution remains resolvable")

    visual = json.loads((root / "visual_review.json").read_text(encoding="utf-8"))
    check("visual.review_record", visual["result"] == "pass" and len(visual["slides"]) == 14
          and all(slide["reviewed_at_full_size"] and not slide["review_findings"] for slide in visual["slides"]),
          "Recorded visual review covers all fourteen final slides")
    for preview in visual["slides"]:
        path = root / preview["path"]
        check(f"visual.{preview['case_id']}.{preview['slide_number']}", path.is_file() and sha256(path) == preview["sha256"],
              preview["path"])
    for deck in visual["decks"]:
        check(f"visual.deck.{Path(deck['path']).parent.name}", sha256(root / deck["path"]) == deck["sha256"],
              "Visual review identifies the delivered deck bytes")

    return checks


def negative_controls(root):
    results = []
    with tempfile.TemporaryDirectory(prefix="phase-a-fixture-validator-") as temporary:
        work = Path(temporary) / "fixtures"
        shutil.copytree(root, work)
        altered = work / "cases/baseline/brief.md"
        original = altered.read_bytes()
        altered.write_bytes(original + b"\nTamper probe\n")
        checks = validate(work)
        results.append({"id": "tampered_source_hash", "passed": any(item["id"] == "baseline.brief.md.hash" and not item["passed"] for item in checks)})
        altered.write_bytes(original)

        extra_deck = work / "cases/missing_deck/deck.pptx"
        shutil.copyfile(work / "cases/baseline/deck.pptx", extra_deck)
        checks = validate(work)
        results.append({"id": "unexpected_missing_case_deck", "passed": any(item["id"] == "missing_deck.exact_omission" and not item["passed"] for item in checks)})
        extra_deck.unlink()

        rehearsal_path = work / "cases/corrected/rehearsal.txt"
        original = rehearsal_path.read_text(encoding="utf-8")
        rehearsal_path.write_text(original.replace("artifact_version_id = BL-DECK-CORRECTED-v1", "artifact_version_id = BL-DECK-BASELINE-v1"), encoding="utf-8")
        checks = validate(work)
        results.append({"id": "wrong_rehearsal_version", "passed": any(item["id"] == "corrected.rehearsal_binding" and not item["passed"] for item in checks)})
        rehearsal_path.write_text(original, encoding="utf-8")

        oracle_path = work / "oracle.json"
        original_oracle = json.loads(oracle_path.read_text(encoding="utf-8"))
        changed_oracle = copy.deepcopy(original_oracle)
        changed_oracle["notes_extraction_control"]["marker"] = "MISSING-NOTES-MARKER"
        oracle_path.write_text(json.dumps(changed_oracle), encoding="utf-8")
        checks = validate(work)
        results.append({"id": "notes_marker_mismatch", "passed": any(item["id"] == "baseline.notes_only_marker" and not item["passed"] for item in checks)})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--negative-controls", action="store_true")
    args = parser.parse_args()
    root = args.fixtures.resolve()
    checks = validate(root)
    controls = negative_controls(root) if args.negative_controls else []
    passed = all(check["passed"] for check in checks + controls)
    report = {
        "schema_version": "phase-a-fixture-validation.v1",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "fixture_id": "benchlink-phase-a-v1",
        "status": "pass" if passed else "fail",
        "validation_scope": "Frozen fixture integrity, native slide and notes contents, exact oracle anchors, arithmetic, input omissions and recorded visual review",
        "product_execution_count": 0,
        "native_powerpoint_execution_count": 0,
        "summary": {"checks": len(checks), "passed": sum(check["passed"] for check in checks),
                    "negative_controls": len(controls), "negative_controls_passed": sum(check["passed"] for check in controls),
                    "cases": 3, "native_decks": 2, "native_slides": 14, "native_note_parts": 14,
                    "rendered_slides_reviewed": 14},
        "checks": checks,
        "negative_controls": controls,
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], **report["summary"], "product_execution_count": 0}, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
