# Phase B — Persistent assignment readiness

Phase B adds a durable assignment review to the current CanvasBridge plugin. A student can review a brief and draft, retain the requirement-level evidence, return in another session and see what remains for the selected artifact version.

The saved result connects the assignment, requirement-set revision, artifact versions, source evidence, assessments and remediation work. Existing assignment lifecycle and personal progress supply their own observations alongside that review.

## Specification set

| Specification | Outcome |
| --- | --- |
| `PHB-01` | Persist scoped requirement, artifact and assessment identities through the existing process store. |
| `PHB-02` | Accept typed source-grounded host assessments and preserve criterion-level evidence and coverage. |
| `PHB-03` | Derive coherent readiness, stable remediation and grouped review followups. |
| `PHB-04` | Complete the review, save, return and explicit revised-version review journey through the current plugin. |
| `PHB-QA-01` | Verify actual persistence, fresh retrieval, host interpretation and regression behavior. |

Begin implementation with `CODEX_HANDOFF.md`. The package includes 24 acceptance cases, 14 deterministic scenarios, 9 aggregation controls, 15 model invariants and a 10-check host-response rubric. `report.json` records preparation and validation, while `templates/implementation_report.json` starts with zero product executions.

## First useful result

The student asks to review the selected BenchLink presentation against its brief and remember the result. The host reads the sources, submits typed assessments and receives the confirmed saved revision. In a later session, the student asks what remains. CanvasBridge retrieves the saved requirement states, evidence and work links.

| Canonical packet | Required criterion results | Supported remediation |
| --- | --- | --- |
| Baseline | 1 satisfied, 3 need work | Add the required section, update the current-source claim, revise and rehearse within the limit. |
| Corrected | 4 satisfied | Zero current remediation items for the four reviewed criteria. |
| Missing deck | 3 unknown, 1 needs work for the named recorded rehearsal | One timing item and one grouped deck followup covering the three unavailable content assessments. |

These are authored expectations for the supplied synthetic packet. Actual Phase B results are recorded during implementation.

## Readiness behavior

Each criterion carries its required/applicability basis, assessment result, evidence coverage, version binding and rationale. The assessment states are `satisfied`, `needs_work`, `unknown` and `conflict`.

The aggregate gives priority to conflict, then supported required work, then unresolved required scope, then ready. Counts retain the applicable-required denominator and show optional and excluded criteria. Empty or unreviewed inventories are unknown. Incomplete inventory prevents ready while preserving supported conflict or needs_work results. A fully reviewed nonempty scope with zero applicable required criteria reports that population and the supported exclusions explicitly.

Coverage is local to the criterion. A missing deck can leave content questions open while the supplied rehearsal still supports its recorded timing calculation. A source-grounded qualitative host assessment retains its basis and remains usable after save and retrieval.

Supported issues in applicable required criteria produce persistent remediation. Optional suggestions can become work through an explicit user request. Unknown and conflict rows produce grouped review followups. Marking a task done records personal progress. If the selected draft still has an unmet criterion, the view shows the declaration and the evidence-backed result together.

## Version and retrieval scope

`saved_snapshot` returns the stored review for its named versions and assessment time, with current evidence availability. `current_selection` compares an explicitly selected requirement/artifact binding with that review. A mismatched or unverified selection receives a review-needed result and a historical reference. An explicit new-version review creates the current assessment for that selection.

Phase C consumes the retained links for automatic change impact and cross-version work reconciliation. Phase D supplies personalized forecasting and stable replanning. Stage 5 is accepted complete and supplies the current operating behavior.

## Reuse grounded in source

The pinned public-source map covers 44 files and 130 anchors at commit `29652557b5701df6eb9147ac232fd3c656449104`. Bind those candidates to the active implementation and Phase A captures before making changes.

| Existing foundation | Phase B integration |
| --- | --- |
| `AcademicRecord` and `ProcessRepository` | Typed readiness payload, coherent revisions, replay receipts and durable retrieval. |
| Closed process request union | A narrow readiness operation with validated source references and host interpretation basis. |
| Evidence graph and provenance primitives | Source/version/locator lineage for requirement assessments. |
| Native readers and requirement checks | Full relevant excerpts, slide/notes identity and criterion-local coverage. |
| Existing task/progress and planning models | Stable remediation IDs, personal progress and current planner inputs. |

The source map identifies concrete adapter work around flattened locators, all-or-error saved-source retrieval and independent child-task progress. Active implementations may already cover these seams. Evidence-backed closure of an implemented requirement is part of the handoff.

## Package layout

- `specs/` contains five JSON specifications.
- `contracts/` defines the logical readiness model, deterministic projection, host rubric and execution captures.
- `fixtures/` contains authored assessment inputs, fourteen scenarios, independent expected outputs and nine aggregation controls.
- `reference/phase_a_fixture/` preserves the complete canonical Phase A presentation fixture byte for byte.
- `prompts/` contains native review, recall, revised-version, partial-input and planning tasks.
- `templates/` contains active-build bindings and unexecuted runtime-report structures.
- `evidence/` contains source review, acceptance design and executed local validation.

The native host receives the selected coursework files and ordinary task prompt. The evaluator uses the authored assessments and oracle after capturing native output. Store/projection integration also uses the explicitly labeled authored assessment inputs.

## Validation

Run the package validator with Python 3.11 or later.

```bash
python /path/to/phase_b_readiness/validate_package.py --negative-controls
```

The fixture validator runs independently.

```bash
python /path/to/phase_b_readiness/fixtures/validate_fixtures.py
```

The optional package-validator argument `--source-root` verifies the reviewed source bytes against a local checkout of the pinned public commit. Local fixture results provide the acceptance oracle. Phase B completion requires actual current-build and supported-host evidence for the implementation cases, including a real persistence-serving process restart.
