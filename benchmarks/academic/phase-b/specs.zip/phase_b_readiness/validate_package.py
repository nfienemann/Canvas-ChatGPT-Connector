#!/usr/bin/env python3
"""Validate the frozen Phase B spec set, synthetic scenarios and reference packet."""

import argparse
import hashlib
import json
import runpy
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path


SPEC_IDS = {"PHB-01", "PHB-02", "PHB-03", "PHB-04", "PHB-QA-01"}
CASE_IDS = {f"PHB-T{number:02d}" for number in range(1, 25)}
SCENARIO_IDS = {f"PHB-S{number:02d}" for number in range(1, 15)}
COMMIT = "29652557b5701df6eb9147ac232fd3c656449104"
CHECKSUM_EXCLUSIONS = {"SHA256SUMS", "evidence/package_validation.json"}


def load(root, relative):
    return json.loads((root / relative).read_text(encoding="utf-8"))


def validate_structure(root):
    checks = []

    def check(identifier, condition, detail):
        checks.append({"id": identifier, "passed": bool(condition), "detail": detail})

    json_files = sorted(root.rglob("*.json"))
    for path in json_files:
        json.loads(path.read_text(encoding="utf-8"))
    check("json.parse", bool(json_files), f"Parsed {len(json_files)} JSON files")

    specs = [json.loads(path.read_text(encoding="utf-8")) for path in sorted((root / "specs").glob("*.json"))]
    spec_by_id = {spec["id"]: spec for spec in specs}
    check("spec.identities", len(specs) == 5 and set(spec_by_id) == SPEC_IDS, "Five unique agreed specification IDs")
    cases = load(root, "acceptance_cases.json")
    check("cases.identities", len(cases["cases"]) == 24 and {case["id"] for case in cases["cases"]} == CASE_IDS, "Twenty-four unique acceptance cases")
    for spec in specs:
        identifier = spec["id"]
        requirement_ids = [item["id"] for item in spec["requirements"]]
        check(identifier + ".requirements", len(requirement_ids) >= 10 and len(set(requirement_ids)) == len(requirement_ids), "Unique detailed requirements")
        check(identifier + ".cases", set(spec["acceptance_cases"]) <= CASE_IDS, "All case references resolve")
        check(identifier + ".dependencies", set(spec["dependencies"]) <= SPEC_IDS - {identifier}, "All dependencies resolve to another supplied spec")
        check(identifier + ".commit", spec["reviewed_public_commit"] == COMMIT, "Pinned public source revision is consistent")
    check("cases.owner_links", all(case["owner_spec"] in spec_by_id and case["id"] in spec_by_id[case["owner_spec"]]["acceptance_cases"] for case in cases["cases"]), "Every case resolves to its owning specification")
    check("cases.spec_coverage", set().union(*(set(spec["acceptance_cases"]) for spec in specs)) == CASE_IDS, "The five specifications cover all acceptance IDs")
    check("cases.scenario_links", all(set(case["scenario_ids"]) <= SCENARIO_IDS for case in cases["cases"]), "All scenario references resolve")
    check("cases.prepared", cases["actual_product_executions"] == 0 and all(case["execution_status"] == case["verdict"] == "not_run" for case in cases["cases"]), "Prepared acceptance claims zero product execution")

    scope = load(root, "scope_and_roadmap.json")
    check("scope.roadmap", scope["selected_phase"] == "B" and [item["phase"] for item in scope["phase_ownership"]] == list("ABCDEF"), "Phase B fits the agreed A–F roadmap")
    check("scope.order", set(scope["implementation_order"]) == SPEC_IDS and scope["actual_product_executions"] == 0, "Implementation order and preparation status are explicit")

    contract = load(root, "contracts/readiness_contract.json")
    projection = load(root, "contracts/readiness_projection.json")
    host = load(root, "contracts/host_fidelity_rubric.json")
    check("contract.assessment_enum", set(contract["enums"]["assessment_status"]) == {"satisfied", "needs_work", "unknown", "conflict"}, "Four assessment states")
    check("contract.applicability_enum", set(contract["enums"]["applicability"]) == {"applicable", "not_applicable", "unknown"}, "Three explicit applicability states")
    check("contract.invariants", len(contract["invariants"]) == 15 and len({item["id"] for item in contract["invariants"]}) == 15, "Fifteen unique readiness invariants")
    check("contract.precedence", [item["status"] for item in projection["ordered_aggregate_rules"]] == ["conflict", "needs_work", "unknown", "ready"], "Known conflict and work retain priority before unresolved scope")
    check("contract.zero_applicable", projection["zero_applicable_population_rule"]["status"] == "ready" and projection["zero_applicable_population_rule"]["applicable_required_denominator"] == 0, "Supported nonempty zero-applicable scope has an explicit ready result and denominator")
    check("contract.views", set(contract["view_modes"]) == {"saved_snapshot", "current_selection"}, "Saved retrieval and explicit current-selection projection have declared semantics")
    check("contract.count_mapping", set(projection["fixture_count_mapping"]) == set(projection["counts"]), "Every logical count maps to a fixture output field")
    check("host.rubric", len(host["checks"]) == 10 and len({item["id"] for item in host["checks"]}) == 10, "Ten unique host fidelity checks")

    scenarios = load(root, "fixtures/scenarios.json")
    controls = load(root, "fixtures/contract_controls.json")
    check("fixtures.scenarios", len(scenarios["scenarios"]) == 14 and {item["id"] for item in scenarios["scenarios"]} == SCENARIO_IDS, "Fourteen bounded readiness scenarios")
    check("fixtures.controls", len(controls["controls"]) == 9 and {item["id"] for item in controls["controls"]} == {f"PHB-C{number:02d}" for number in range(1, 10)}, "Nine aggregation and applicability controls")
    incomplete = next(item for item in controls["controls"] if item["id"] == "PHB-C09")
    check("fixtures.incomplete_inventory", incomplete["expected_summary_status"] == "unknown" and incomplete.get("membership_complete") is False, "Satisfied observed rows cannot clear incomplete requirement membership")

    report = load(root, "templates/implementation_report.json")
    capture = load(root, "templates/product_run_capture.json")
    check("templates.no_product_credit", report["phase_b_completion"] == "prepared" and report["execution_summary"]["actual_product_executions"] == report["execution_summary"]["actual_host_executions"] == report["execution_summary"]["process_restarts_tested"] == 0 and report["run_capture_refs"] == [], "Unexecuted templates claim zero current-product, host or restart evidence")
    check("templates.case_results", len(report["case_results"]) == 24 and {item["case_id"] for item in report["case_results"]} == CASE_IDS and all(item["verdict"] == item["execution_status"] == "not_run" for item in report["case_results"]), "Every actual acceptance verdict is pending")
    check("templates.measures", len(report["measures"]) == 6 and all(item["observed"] is None and item["execution_status"] == "not_run" for item in report["measures"]), "Six bounded measures retain null observed values")
    check("templates.capture", capture["execution_status"] == "not_run" and capture["save_receipt_ref"] is None and capture["retrieval_ref"] is None and capture["final_answer_ref"] is None, "Run capture contains no fabricated receipt or host result")
    check("templates.completion_model", report["completion_model"] == cases["completion_model"], "Implementation completion model is consistent")

    bindings = load(root, "evidence/source_bindings.json")
    capabilities = load(root, "evidence/capability_map.json")
    files = bindings["files"]
    anchors = [anchor for item in files for anchor in item["reviewed_anchors"]]
    anchor_ids = {anchor["id"] for anchor in anchors}
    check("source.revision", bindings["reviewed_commit"] == capabilities["reviewed_commit"] == COMMIT, "Source records share the checked commit")
    check("source.files", len(files) == bindings["files_verified"] == 44 and len({item["path"] for item in files}) == 44, "Forty-four unique reviewed files")
    check("source.anchors", len(anchors) == len(anchor_ids) == bindings["source_anchors"] == 130, "One hundred thirty unique source anchors")
    check("source.ranges", all(1 <= anchor["start_line"] <= anchor["end_line"] <= item["line_count"] for item in files for anchor in item["reviewed_anchors"]), "All anchors fall within their pinned source files")
    check("source.hash_record", bindings["all_files_match_reviewed_commit"] and all(item["local_git_blob_verified"] for item in files), "The source-review record reports verified pinned Git blobs")
    check("source.static_execution", bindings["product_feature_tests_executed"] == bindings["source_test_execution_count"] == capabilities["product_feature_tests_executed"] == 0 and not bindings["active_implementation_branch_verified"], "Static source review claims zero feature/test executions on the active build")
    check("source.capabilities", len(capabilities["capabilities"]) == 14 and all(set(item["source_anchor_refs"]) <= anchor_ids for item in capabilities["capabilities"]), "Fourteen capabilities resolve their source anchors")
    check("source.routes", len(capabilities["route_contracts"]) == 7 and len(capabilities["minimal_implementation_seams"]) == 5, "Seven source-bound route contracts and five narrow implementation seams")

    required_files = ["README.md", "CODEX_HANDOFF.md", "report.json", "prompts/review_and_remember.md", "prompts/recall_readiness.md", "prompts/review_revised_version.md", "prompts/missing_deck.md", "prompts/progress_and_plan.md", "examples/expected_baseline_view.md", "evidence/package_review.json"]
    check("package.deliverables", all((root / path).is_file() for path in required_files), "All entry points, prompts, report and review are supplied")
    if (root / "report.json").is_file():
        preparation = load(root, "report.json")
        check("report.prepared", preparation["phase_b_completion"] == "prepared" and preparation["product_execution_count"] == 0, "Preparation report preserves the actual execution boundary")
    return checks


def validate_checksums(root):
    expected = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file() and str(path.relative_to(root)) not in CHECKSUM_EXCLUSIONS}
    listed = set()
    checks = []
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        path = Path(relative)
        safe = not path.is_absolute() and ".." not in path.parts
        exists = safe and (root / path).is_file()
        valid = exists and hashlib.sha256((root / path).read_bytes()).hexdigest() == digest
        checks.append({"id": "checksum." + relative, "passed": bool(valid and relative not in listed), "detail": "Exact SHA-256 and unique safe relative path"})
        listed.add(relative)
    checks.append({"id": "checksum.inventory", "passed": listed == expected, "detail": f"Manifest covers {len(expected)} frozen files. Manifest and regenerable package-validation report are excluded."})
    return checks


def validate_source_bytes(root, source_root):
    checks = []
    for item in load(root, "evidence/source_bindings.json")["files"]:
        path = source_root / item["path"]
        matches = False
        if path.is_file():
            data = path.read_bytes()
            blob = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
            matches = blob == item["git_blob_sha"] and hashlib.sha256(data).hexdigest() == item["sha256"]
        checks.append({"id": "source_bytes." + item["path"], "passed": matches, "detail": "Exact pinned Git blob and SHA-256 verification"})
    return checks


def negative_controls(root):
    controls = []
    with tempfile.TemporaryDirectory(prefix="phase-b-package-controls-") as directory:
        work = Path(directory) / "package"
        shutil.copytree(root, work)
        path = work / "templates/implementation_report.json"
        original = path.read_text(encoding="utf-8")
        changed = json.loads(original)
        changed["phase_b_completion"] = "complete"
        changed["execution_summary"]["actual_product_executions"] = 1
        path.write_text(json.dumps(changed), encoding="utf-8")
        checks = validate_structure(work)
        controls.append({"id": "fabricated_product_completion", "passed": any(item["id"] == "templates.no_product_credit" and not item["passed"] for item in checks)})
        path.write_text(original, encoding="utf-8")
        path = work / "contracts/readiness_projection.json"
        changed = load(work, "contracts/readiness_projection.json")
        changed["ordered_aggregate_rules"][1], changed["ordered_aggregate_rules"][2] = changed["ordered_aggregate_rules"][2], changed["ordered_aggregate_rules"][1]
        path.write_text(json.dumps(changed), encoding="utf-8")
        checks = validate_structure(work)
        controls.append({"id": "changed_readiness_precedence", "passed": any(item["id"] == "contract.precedence" and not item["passed"] for item in checks)})
    return controls


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--source-root", type=Path, help="Optional local checkout of the pinned public commit")
    parser.add_argument("--negative-controls", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    checks = validate_structure(root) + validate_checksums(root)
    fixture_validator = runpy.run_path(str(root / "fixtures/validate_fixtures.py"))
    fixture_checks = fixture_validator["validate"](root)
    checks += [{**item, "id": "fixture." + item["id"]} for item in fixture_checks]
    if args.source_root:
        checks += validate_source_bytes(root, args.source_root.resolve())
    controls = []
    if args.negative_controls:
        controls += negative_controls(root)
        controls += fixture_validator["negative_controls"](root)
        reference_validator = runpy.run_path(str(root / "reference/phase_a_fixture/validate_fixtures.py"))
        controls += [{**item, "id": "phase_a." + item["id"]} for item in reference_validator["negative_controls"](root / "reference/phase_a_fixture")]
    passed = all(item["passed"] for item in checks + controls)
    result = {
        "schema_version": "phase-b-package-validation.v1", "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "pass" if passed else "fail", "product_execution_count": 0,
        "summary": {"checks": len(checks), "passed": sum(item["passed"] for item in checks), "fixture_checks": len(fixture_checks), "negative_controls": len(controls), "negative_controls_passed": sum(item["passed"] for item in controls), "source_bytes_rechecked": args.source_root is not None},
        "checksum_exclusions": sorted(CHECKSUM_EXCLUSIONS), "checks": checks, "negative_controls": controls
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], **result["summary"], "product_execution_count": 0, "failed_checks": [item["id"] for item in checks + controls if not item["passed"]]}, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
