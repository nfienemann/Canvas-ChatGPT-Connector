# Phase B implementation handoff

Implement persistent assignment readiness through the existing CanvasBridge plugin and process store. The first completed journey reviews an assignment, saves its requirement-level evidence and retrieves the same useful result in a fresh session.

## 1. Bind the current implementation

Read the active repository instructions and record the tested branch, commit, dirty diff fingerprint, runtime and tool schemas in a copy of `templates/active_build_bindings.json`.

Use actual Phase A bindings and captures where available. The pinned source map in `evidence/` supplies candidate symbols and route shapes. Reuse already-complete foundations and attach evidence when closing an implemented requirement.

Inspect `AcademicRecord`, `ProcessRepository`, the process request union and existing source/provenance primitives. A readiness payload can use the assignment record kind if compatible with the active implementation. Add the smallest typed operation/service extension needed for structured host assessments, and use the existing save/read flow.

Inspect the independent remediation-task progress binding explicitly. The historical connected-work progress tool expects an existing connected Work row. Use the current operations adapter or a narrow typed readiness-store progress update for the new child-task IDs.

## 2. Build the durable vertical slice

1. Resolve canonical assignment scope and explicit logical artifact/version identities.
2. Persist a scoped requirement set with stable IDs, source anchors, revision, applicability and inventory coverage.
3. Accept typed host assessments with exact source/version references, rationale and actual interpretation basis.
4. Validate reference structure, scope, available quote/locator binding and criterion coverage.
5. Save a coherent readiness snapshot through current revision and replay machinery.
6. Retrieve the confirmed snapshot in a fresh context and after restarting the persistence-serving process.
7. Project current readiness, stable supported remediation and grouped review followups.

The host performs qualitative review. The backend validates structural bindings, retains provenance, computes the deterministic projection and persists the result. Ordinary source-grounded host interpretations remain usable under the readiness contract after save and retrieval.

Reuse current source-lifecycle behavior for access freshness and refresh. Preserve immutable content versions and assessment time. Return supported accessible data with precise source availability at affected criteria. Historical references retain their identity while content follows current source availability.

## 3. Apply the readiness and work rules

Implement `contracts/readiness_projection.json` from one coherent snapshot. Applicable required conflict has first priority, followed by supported work, unresolved scope and ready. Keep exact counts and the requirement-inventory coverage guard.

Use criterion-local evidence. A relevant observed passage can establish an individual result. A missing-section conclusion requires its stated search extent. All-claims citation checks require coverage of their claim population. Preserve native slide and speaker-note identity through the evidence adapter.

Persist remediation for supported `needs_work` findings in applicable required criteria. Optional suggestions can become work through an explicit user request. Use stable identity based on assignment, requirement-set revision, artifact binding, criterion and gap kind. Repeated same-version reviews reuse matching work IDs and retain personal progress.

Group unknown/conflict followups by shared missing input or unresolved issue. The missing-deck case has one grouped followup covering R01–R03. Its named baseline rehearsal supports one timing remediation item.

A done declaration persists through the actual task-progress adapter. An unresolved draft requirement stays visible with its evidence. Explicit rereview can establish a new assessment revision.

Map supported remediation into current `IndependentWork` or `WorkItem` planning inputs. Keep unknown deadlines and effort explicit. Supplied and host-estimated fields carry their actual basis.

## 4. Wire the ordinary plugin journey

Register the typed readiness workflow through the existing plugin/process registry. Use the current accepted Stage 5 behavior for routine reads and owned-state saves.

| Journey | Prompt and expected operation |
| --- | --- |
| Review and remember | `prompts/review_and_remember.md` reads the packet, creates typed assessments and returns the saved revision after the store confirms the commit. |
| Return later | `prompts/recall_readiness.md` retrieves saved state in a fresh host context. |
| Review a revised artifact | `prompts/review_revised_version.md` binds and assesses the explicitly selected corrected version. |
| Missing artifact | `prompts/missing_deck.md` preserves available findings and grouped followups. |
| Progress and planning | `prompts/progress_and_plan.md` exercises actual task progress and the current planning adapter. |

Use `saved_snapshot` for retrieval of the named stored review. Use `current_selection` to compare an explicitly selected binding. A new selected version receives a review-needed projection until its explicit review is saved. Keep the previous review reference for history.

## 5. Validate expected behavior and execute the implementation

Run `validate_package.py --negative-controls`. The reference subtree preserves the Phase A native decks, notes, brief, sources and rehearsal records with their original hashes.

The fourteen fixture scenarios contain test-authored assessment inputs and independently specified expected outputs. Use them for deterministic contract/store and current-adapter integration tests. The nine small controls test aggregation, applicability and incomplete requirement-inventory edges.

Execute the 24 acceptance cases against the actual implementation. The native host journeys read the coursework through current tools and produce their own assessments. Capture those outputs before evaluator comparison.

The fresh retrieval journey starts from its genuinely committed readiness record. Record the actual process stop/restart and post-restart read. Test current source freshness handling, replay, concurrent revisions, atomic failed saves and child-task progress through their real adapters.

Use case-bound source selection and fresh host contexts for independent fixture controls. In the missing-deck control, keep the deck absent from that case's accessible inventory and inspect actual retrievals. Resume and historical-lookup journeys deliberately reference their previously saved record identities.

## 6. Complete acceptance and hand off Phase C

Fill `templates/implementation_report.json` with actual case results, run captures, persisted examples, host review and focused regression results. All critical and major cases for the advertised scope must pass. Failed, blocked and unexecuted cases remain visible with a concrete reproduction and smallest component.

Run or reuse the Phase A fixture controls and replay the applicable native matrix on the current build. Compare earlier actual product captures when available and record matching scope before assigning a regression label.

Deliver the implementation diff, tested schemas, source/locator adapter mapping, save/retrieve evidence, work/progress examples, actual host transcripts and the completed case report. The Phase C handoff identifies retained requirement, artifact-version, finding, work and history links for automatic change impact and cross-version reconciliation.
