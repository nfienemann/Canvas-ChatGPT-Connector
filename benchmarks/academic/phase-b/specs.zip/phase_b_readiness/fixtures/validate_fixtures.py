#!/usr/bin/env python3
"""Validate frozen Phase B fixture inputs and evaluator expectations."""

import argparse
import copy
import hashlib
import json
import runpy
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree


def load(root, relative):
    return json.loads((root / relative).read_text(encoding="utf-8"))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def anchor_resolves(root, evidence):
    path = root / evidence["file_path"]
    locator = evidence["locator"]
    try:
        if "line" in locator:
            lines = path.read_text(encoding="utf-8").splitlines()
            return lines[locator["line"] - 1] == evidence["quote"]
        with zipfile.ZipFile(path) as package:
            part = ElementTree.fromstring(package.read(locator["part"]))
        texts = [node.text or "" for node in part.iter() if node.tag.rsplit("}", 1)[-1] == "t"]
        return evidence["quote"] in "\n".join(texts)
    except (OSError, KeyError, IndexError, zipfile.BadZipFile, ElementTree.ParseError):
        return False


def validate(root):
    """Accept the Phase B package root and return named local checks."""
    checks = []

    def check(identifier, condition, detail):
        checks.append({"id": identifier, "passed": bool(condition), "detail": detail})

    inputs = load(root, "fixtures/readiness_inputs.json")
    scenario_file = load(root, "fixtures/scenarios.json")
    expected_file = load(root, "fixtures/expected_readiness.json")
    control_file = load(root, "fixtures/contract_controls.json")
    fixture_index = load(root, "fixtures/index.json")
    provenance = load(root, "reference/phase_a_provenance.json")
    projector = runpy.run_path(str(root / "fixtures/reference_projection.py"))
    reference_validator = runpy.run_path(str(root / "reference/phase_a_fixture/validate_fixtures.py"))

    for name, document in (("inputs", inputs), ("scenarios", scenario_file), ("expected", expected_file), ("controls", control_file)):
        check(f"scope.{name}", document["evaluator_only"] and document["product_execution_count"] == 0, "Authored evaluator input with zero product execution credit")
    check("index.scope", fixture_index["evaluator_only"] and fixture_index["product_execution_count"] == 0 and fixture_index["scenario_count"] == 14 and fixture_index["contract_control_count"] == 9, "Fixture index describes the bounded evaluator inputs")
    for item in fixture_index["files"]:
        path = root / item["path"]
        check("index." + item["path"], path.is_file() and sha256(path) == item["sha256"] and path.stat().st_size == item["bytes"], "Frozen fixture file matches the index")
    check("reference.count", provenance["files_copied"] == len(provenance["files"]) == 35, "Thirty-five exact Phase A fixture members")
    for item in provenance["files"]:
        path = root / "reference" / item["path"]
        check("reference." + item["path"], path.is_file() and sha256(path) == item["sha256"] and path.stat().st_size == item["bytes"], "Copied member matches its delivered Phase A bytes")
    for result in reference_validator["validate"](root / "reference/phase_a_fixture"):
        checks.append({**result, "id": "phase_a." + result["id"]})

    requirements = inputs["requirement_set"]["requirements"]
    requirement_ids = {row["requirement_id"] for row in requirements}
    check("requirements.membership", len(requirements) == len(requirement_ids) == 4 and requirement_ids == {"PA-R01", "PA-R02", "PA-R03", "PA-R04"}, "All four stable Phase A requirement IDs are reused")
    check("requirements.scoped", all(type(row["required"]) is bool and row["required"] and row["applicability"] == "applicable" for row in requirements), "The primary source brief supplies four applicable required criteria")
    check("requirements.revision", inputs["requirement_set"]["requirement_set_revision"] == "BL-REQUIREMENTS-v1" and inputs["requirement_set"]["membership_complete"], "Requirement membership has an explicit revision and completeness")

    sources = {row["source_version_id"]: row for row in inputs["source_versions"]}
    evidence = {row["evidence_id"]: row for row in inputs["evidence_catalog"]}
    check("source.identities", len(sources) == len(inputs["source_versions"]) == 6, "Six unique immutable source versions")
    check("evidence.identities", len(evidence) == len(inputs["evidence_catalog"]) == 28, "Twenty-eight exact source anchors")
    for source in sources.values():
        for path in source["paths"]:
            check("source." + path, (root / path).is_file() and sha256(root / path) == source["sha256"], "Every source alias has its declared hash")
    for item in evidence.values():
        source = sources.get(item["source_version_id"])
        check("evidence." + item["evidence_id"] + ".binding", source is not None and item["source_sha256"] == source["sha256"] and item["file_path"] in source["paths"], "Evidence names the exact source version and hash")
        check("evidence." + item["evidence_id"] + ".anchor", anchor_resolves(root, item), "Exact quote resolves to its supplied line or native OOXML part")
    for requirement in requirements:
        check("requirement." + requirement["requirement_id"] + ".basis", all(ref in evidence for ref in requirement["source_evidence_refs"] + requirement["applicability_basis"]["evidence_refs"]), "Criterion and applicability use source-bound evidence")

    payloads = {row["assessment_id"]: row for row in inputs["assessment_payloads"]}
    check("assessments.identities", len(payloads) == len(inputs["assessment_payloads"]) == 7, "Seven authored structured assessment payloads")
    baseline_hash = sources["BL-DECK-BASELINE-v1"]["sha256"]
    corrected_hash = sources["BL-DECK-CORRECTED-v1"]["sha256"]
    for item in payloads.values():
        prefix = "assessment." + item["assessment_id"]
        rows = item["requirement_results"]
        check(prefix + ".fixture_basis", item["input_kind"] == "fixture_authored_structured_host_assessment" and item["actual_product_or_host_execution"] is False, "The supplied payload is explicitly authored test data")
        check(prefix + ".membership", len(rows) == 4 and {row["requirement_id"] for row in rows} == requirement_ids, "Assessment covers the exact criterion membership")
        check(prefix + ".artifact_binding", item["binding"]["artifact_sha256"] == sources[item["binding"]["artifact_version_id"]]["sha256"], "Primary artifact version and content hash agree")
        check(prefix + ".statuses", all(row["assessment_status"] in projector["ASSESSMENT_STATUSES"] and row["evidence_coverage"] in projector["COVERAGE_VALUES"] and row["version_match"] in projector["VERSION_MATCHES"] for row in rows), "Assessment, coverage and applicability use the agreed enums")
        check(prefix + ".unknown_reasons", all(bool(row["unknown_reason"]) if row["assessment_status"] == "unknown" else row["unknown_reason"] is None for row in rows), "Unknown rows have concrete reasons")
        check(prefix + ".evidence_refs", all(ref in evidence for row in rows for ref in row["evidence_refs"]), "Assessment evidence references resolve")
        check(prefix + ".version_guard", all(row["assessment_status"] == "unknown" for row in rows if row["version_match"] != "current"), "Unusable version evidence leaves the current criterion unknown")
        check(prefix + ".conflict_candidates", all(len(row.get("candidate_assessments", [])) >= 2 for row in rows if row["assessment_status"] == "conflict"), "A conflict retains its actual authored alternatives")

    scenarios = {row["id"]: row for row in scenario_file["scenarios"]}
    expected = {row["scenario_id"]: row for row in expected_file["results"]}
    check("scenarios.identities", len(scenarios) == len(scenario_file["scenarios"]) == scenario_file["scenario_count"] == 14 and set(scenarios) == {f"PHB-S{number:02d}" for number in range(1, 15)}, "Fourteen unique bounded scenario IDs")
    check("expected.identities", len(expected) == len(expected_file["results"]) == 14 and set(expected) == set(scenarios), "One independently authored expectation for each scenario")
    for identifier, scenario in scenarios.items():
        output = expected[identifier]
        projection = projector["project"](requirements, output["requirement_results"], inputs["requirement_set"]["membership_complete"])
        prefix = "scenario." + identifier
        check(prefix + ".execution", scenario["execution_status"] == "not_run" and scenario["actual_product_execution_count"] == 0, "Current-product execution is pending")
        check(prefix + ".inputs", all(ref in payloads for ref in scenario["authored_assessment_input_refs"]), "Authored assessment inputs resolve")
        check(prefix + ".model_files", all((root / item["path"]).is_file() and sha256(root / item["path"]) == item["sha256"] for item in scenario["model_input_files"]), "Exact model-facing source selection is declared")
        rehearsal = next(item for item in scenario["model_input_files"] if item["role"] == "measured_rehearsal")
        check(prefix + ".rehearsal_selection", rehearsal["sha256"] == scenario["selected_binding"]["supporting_source_hashes"]["rehearsal"], "Scenario source selection matches its bound rehearsal version")
        check(prefix + ".summary", projection["summary_status"] == output["summary_status"], "Independent projection matches the explicit expected summary")
        check(prefix + ".counts", projection["counts"] == output["counts"], "Exact criterion populations and statuses match")
        check(prefix + ".current_binding", output["selected_artifact_sha256"] == scenario["selected_binding"]["artifact_sha256"] and output["assignment_id"] == scenario["assignment_id"], "Expected current view uses the selected assignment and artifact")
        work = output["current_work_items"]
        identities = [projector["work_identity"](item) for item in work]
        check(prefix + ".work_identity", len(identities) == len(set(identities)), "Current remediation work has stable unique keys")
        check(prefix + ".work_scope", all(item["work_key"]["assignment_id"] == output["assignment_id"] and item["work_key"]["artifact_id"] == scenario["selected_binding"]["artifact_id"] and item["work_key"]["artifact_sha256"] == output["selected_artifact_sha256"] and item["work_key"]["requirement_set_revision"] == scenario["requirement_set_revision"] for item in work), "Remediation belongs to the exact current binding")
        result_by_id = {row["requirement_id"]: row for row in output["requirement_results"]}
        check(prefix + ".work_basis", all(result_by_id[item["work_key"]["requirement_id"]]["assessment_status"] == "needs_work" and result_by_id[item["work_key"]["requirement_id"]]["gap_kind"] == item["work_key"]["gap_kind"] and all(ref in evidence for ref in item["evidence_refs"]) for item in work), "Persisted remediation has a supported needs-work gap and resolving evidence")
        check(prefix + ".work_counts", len(work) == output["current_work_item_count"] and sum(item["personal_progress"] == "open" for item in work) == output["open_work_item_count"] and sum(item["personal_progress"] == "done" for item in work) == output["done_work_item_count"], "Work and personal-progress counts match exactly")
        check(prefix + ".historical_work", len(output["historical_work_items"]) == output["historical_work_item_count"] and all(item["work_key"]["artifact_sha256"] != output["selected_artifact_sha256"] for item in output["historical_work_items"]), "Prior-version work retains its historical binding")
        check(prefix + ".followup_counts", len(output["review_followups"]) == output["review_followup_count"] and all(not item["persisted_as_task"] for item in output["review_followups"]), "Review followups are grouped with explicit conversion state")
        check(prefix + ".followup_scope", all(set(item["requirement_ids"]) <= {row["requirement_id"] for row in output["requirement_results"] if row["assessment_status"] in {"unknown", "conflict"}} for item in output["review_followups"]), "Review followups identify their unresolved criteria")

    check("invariant.baseline", expected["PHB-S01"]["counts"]["satisfied"] == 1 and expected["PHB-S01"]["counts"]["needs_work"] == 3 and expected["PHB-S01"]["current_work_item_count"] == 3, "The baseline has one satisfied criterion and three supported gaps")
    check("invariant.saved_retrieval", scenarios["PHB-S02"]["view_mode"] == "saved_snapshot" and expected["PHB-S02"]["requirement_results"] == expected["PHB-S01"]["requirement_results"], "Saved retrieval preserves the named-version assessment")
    check("invariant.availability", scenarios["PHB-S02"]["availability_control"]["expected_saved_assessment_mutations"] == 0 and not scenarios["PHB-S02"]["availability_control"]["observed_new_artifact_version"], "Access availability alone preserves the named saved assessment")
    check("invariant.corrected", expected["PHB-S03"]["summary_status"] == "ready" and expected["PHB-S03"]["current_work_item_count"] == 0 and expected["PHB-S03"]["historical_work_item_count"] == 3, "Explicit corrected review clears current gaps and retains baseline work history")
    missing = expected["PHB-S04"]
    check("invariant.missing_deck", missing["counts"]["unknown"] == 3 and missing["counts"]["needs_work"] == 1 and missing["current_work_item_count"] == 1 and missing["review_followup_count"] == 1, "Missing deck leaves three unknown checks and one attributed timing gap")
    check("invariant.missing_timing", missing["requirement_results"][3]["assessed_scope"] == "recorded_rehearsal" and missing["requirement_results"][3]["evidence_coverage"] == "complete", "Available recorded arithmetic has criterion-local complete evidence")
    check("invariant.alias", expected["PHB-S06"]["current_work_items"] == expected["PHB-S01"]["current_work_items"] and scenarios["PHB-S06"]["expected_logical_artifact_versions"] == 1, "Same-byte reimport retains requirement and work identities")
    check("invariant.new_version", expected["PHB-S07"]["summary_status"] == "unknown" and expected["PHB-S07"]["current_work_item_count"] == 0 and scenarios["PHB-S07"]["saved_snapshot_expectation"]["artifact_sha256"] == baseline_hash and expected["PHB-S07"]["selected_artifact_sha256"] == corrected_hash, "New selected bytes await review while the historical snapshot remains addressable")
    check("invariant.rehearsal_mismatch", expected["PHB-S08"]["requirement_results"][3]["assessment_status"] == "unknown" and expected["PHB-S08"]["requirement_results"][3]["version_match"] == "mismatch" and scenarios["PHB-S08"]["current_artifact_measured_duration_seconds"] is None, "Old rehearsal stays outside the corrected deck's current timing result")
    check("invariant.personal_done", expected["PHB-S09"]["requirement_results"] == expected["PHB-S01"]["requirement_results"] and expected["PHB-S09"]["done_work_item_count"] == 1, "A declared done task preserves the artifact assessment")
    check("invariant.repeat_keys", [projector["work_identity"](item) for item in expected["PHB-S10"]["current_work_items"]] == [projector["work_identity"](item) for item in expected["PHB-S01"]["current_work_items"]] and expected["PHB-S10"]["done_work_item_count"] == 1, "Retries and repeated same-version review reuse work keys and retain progress")
    check("invariant.conflict", expected["PHB-S11"]["summary_status"] == "conflict" and expected["PHB-S11"]["current_work_item_count"] == 2 and expected["PHB-S11"]["review_followup_count"] == 1, "Conflict is visible alongside independently supported remediation")
    check("invariant.partial", expected["PHB-S12"]["counts"]["satisfied"] == 2 and expected["PHB-S12"]["counts"]["unknown"] == 2, "Partial handoff retains criterion-local useful results")
    check("invariant.assignment_scope", scenarios["PHB-S13"]["assignment_id"] != scenarios["PHB-S01"]["assignment_id"] and expected["PHB-S13"]["current_work_item_count"] == 0 and expected["PHB-S13"]["counts"]["unknown"] == 4, "Matching content hash does not supply another assignment's assessment")
    check("invariant.invalid_save", scenarios["PHB-S14"]["expected_rejected_save_attempts"] == 2 and expected["PHB-S14"]["requirement_results"] == expected["PHB-S03"]["requirement_results"] and scenarios["PHB-S14"]["expected_prior_record_revision_change"] == 0 and not scenarios["PHB-S14"]["rejected_updates_promote_readiness"] and "Last confirmed corrected snapshot" in scenarios["PHB-S14"]["expected_view_basis"], "Rejected updates leave the last confirmed corrected snapshot intact")

    controls = control_file["controls"]
    check("controls.identities", len(controls) == 9 and {item["id"] for item in controls} == {f"PHB-C{number:02d}" for number in range(1, 10)}, "Nine small evaluator-only contract controls")
    for control in controls:
        result = projector["project"](control["rows"], control["rows"], control["membership_complete"])
        check("control." + control["id"] + ".summary", result["summary_status"] == control["expected_summary_status"], "Explicit expected summary matches the scope projection")
        check("control." + control["id"] + ".counts", result["counts"]["applicable_required"] == control["expected_applicable_required"] and result["counts"]["unknown_applicability_required"] == control["expected_unknown_applicability_required"] and result["counts"]["optional"] == control["expected_optional"] and result["counts"]["not_applicable_required"] == control["expected_excluded_required"], "Optional and applicability populations retain exact counts")
        check("control." + control["id"] + ".required_remediation", result["counts"]["needs_work"] == control["expected_automatic_required_remediation_candidates"], "Automatic remediation candidates follow applicable required gaps")
        for row in control["rows"]:
            basis = row["applicability_basis"]
            if basis["kind"] == "source_explicit":
                path = root / basis["source_path"]
                check("control." + control["id"] + ".basis." + row["requirement_id"], sha256(path) == basis["source_sha256"] and path.read_text().splitlines()[basis["line"] - 1] == basis["quote"], "Supplemental applicability basis resolves exactly")
    return checks


def negative_controls(root):
    results = []
    with tempfile.TemporaryDirectory(prefix="phase-b-fixture-controls-") as directory:
        work = Path(directory) / "package"
        shutil.copytree(root / "fixtures", work / "fixtures")
        shutil.copytree(root / "reference", work / "reference")

        def run_control(identifier, relative, mutate, expected_failure):
            path = work / relative
            original = path.read_text(encoding="utf-8")
            document = json.loads(original)
            mutate(document)
            path.write_text(json.dumps(document), encoding="utf-8")
            checks = validate(work)
            results.append({"id": identifier, "passed": any(item["id"] == expected_failure and not item["passed"] for item in checks)})
            path.write_text(original, encoding="utf-8")

        run_control("wrong_evidence_hash", "fixtures/readiness_inputs.json", lambda data: data["evidence_catalog"][0].update({"source_sha256": "0" * 64}), "evidence.EV-PA-R01.binding")
        run_control("unresolvable_evidence_locator", "fixtures/readiness_inputs.json", lambda data: data["evidence_catalog"][0]["locator"].update({"line": 999}), "evidence.EV-PA-R01.anchor")
        run_control("cross_assignment_work_leak", "fixtures/expected_readiness.json", lambda data: data["results"][12]["current_work_items"].append(copy.deepcopy(data["results"][0]["current_work_items"][0])), "scenario.PHB-S13.work_scope")
        run_control("task_done_promotes_assessment", "fixtures/expected_readiness.json", lambda data: data["results"][8]["requirement_results"][0].update({"assessment_status": "satisfied"}), "invariant.personal_done")
        run_control("empty_inventory_ready", "fixtures/contract_controls.json", lambda data: data["controls"][0].update({"expected_summary_status": "ready"}), "control.PHB-C01.summary")
        run_control("old_rehearsal_promoted", "fixtures/expected_readiness.json", lambda data: data["results"][7]["requirement_results"][3].update({"assessment_status": "satisfied", "version_match": "current"}), "invariant.rehearsal_mismatch")
        run_control("duplicate_retry_work", "fixtures/expected_readiness.json", lambda data: data["results"][9]["current_work_items"].append(copy.deepcopy(data["results"][9]["current_work_items"][0])), "scenario.PHB-S10.work_identity")
        run_control("unknown_applicability_ready", "fixtures/contract_controls.json", lambda data: data["controls"][3].update({"expected_summary_status": "ready"}), "control.PHB-C04.summary")
        run_control("incomplete_membership_ready", "fixtures/contract_controls.json", lambda data: data["controls"][8].update({"expected_summary_status": "ready"}), "control.PHB-C09.summary")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--negative-controls", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    checks = validate(root)
    controls = negative_controls(root) if args.negative_controls else []
    passed = all(item["passed"] for item in checks + controls)
    result = {
        "schema_version": "phase-b-fixture-validation.v1", "fixture_id": "benchlink-phase-b-v1",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(), "status": "pass" if passed else "fail",
        "product_execution_count": 0, "actual_host_execution_count": 0,
        "validation_scope": "Exact Phase A fixture reuse, authored Phase B assessment bindings, independent readiness projections, work identity invariants and contract controls",
        "summary": {"checks": len(checks), "passed": sum(item["passed"] for item in checks), "scenarios": 14, "contract_controls": 9, "source_versions": 6, "evidence_anchors": 28, "authored_assessments": 7, "phase_a_files_reused": 35, "negative_controls": len(controls), "negative_controls_passed": sum(item["passed"] for item in controls)},
        "checks": checks, "negative_controls": controls
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], **result["summary"], "product_execution_count": 0, "failed_checks": [item["id"] for item in checks + controls if not item["passed"]]}, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
