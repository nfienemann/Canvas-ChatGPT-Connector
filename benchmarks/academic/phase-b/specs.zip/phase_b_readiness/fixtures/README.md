# Phase B readiness fixtures

This fixture set tests persistent assignment readiness with the exact BenchLink coursework bytes delivered in Phase A. It supplies fourteen bounded scenarios, seven authored structured assessment payloads and nine small aggregation controls.

The source packets contain two native seven-slide presentations with speaker notes, a brief, references and associated synthetic rehearsal records. All organizations, observations and assessment records are synthetic.

## Files and evidence roles

| File | Purpose |
| --- | --- |
| `readiness_inputs.json` | Scoped assignment identities, the four source-derived requirements, six immutable source versions, 28 exact evidence anchors and seven authored assessment inputs. |
| `scenarios.json` | Fourteen test intents with exact selected source files, version bindings, declared missing inputs and expected storage behavior. |
| `expected_readiness.json` | Explicit per-scenario statuses, criterion counts, current and historical work, review followups and retained assessment identities. |
| `contract_controls.json` | Nine independently stated controls for optional rows, applicability, incomplete inventory, empty inventory, version mismatch and summary precedence. |
| `control_requirements.md` | Exact synthetic source basis for the optional and applicability controls. |
| `reference_projection.py` | Small evaluator calculation of required-scope counts and summary state. |
| `validate_fixtures.py` | Standard-library source, binding, expectation and invariant checks. |
| `../reference/phase_a_provenance.json` | Exact SHA-256 provenance for all 35 copied Phase A members. |

Paths in the Phase B scenario files resolve from the Phase B package root. Paths inside the copied Phase A index resolve from `reference/phase_a_fixture/`.

The structured assessment payloads are deliberately authored test inputs for deterministic persistence and projection acceptance. Qualitative host acceptance uses the selected coursework files and an ordinary review request in a fresh context. The implementing process captures the actual review, save, retrieval and final host answer.

## Expected primary scenario states

| Scenario | State | Expected current result |
| --- | --- | --- |
| PHB-S01 | `needs_work` | One satisfied criterion, three supported gaps and three remediation work items. |
| PHB-S02 | `needs_work` | The same named saved assessment and work identities survive a fresh session. Current source availability remains visible. |
| PHB-S03 | `ready` | Four satisfied criteria for the explicitly reviewed corrected version. Three baseline work items retain their historical binding. |
| PHB-S04 | `needs_work` | Three artifact-dependent criteria are unknown. The named baseline rehearsal supports one timing gap and one work item. One grouped followup requests the missing deck. |
| PHB-S05 | `unknown` | Four recorded criteria await their first assessment. |
| PHB-S06 | `needs_work` | A second import of identical bytes reuses the existing assignment-scoped artifact version, requirements and work. |
| PHB-S07 | `unknown` | The explicitly selected new version awaits review. The baseline assessment remains retrievable by its saved identity. |
| PHB-S08 | `unknown` | Three corrected-deck criteria are satisfied. The old rehearsal remains associated with the baseline deck, leaving current timing unknown. |
| PHB-S09 | `needs_work` | Three assessed gaps remain visible while personal work state is two open and one done. |
| PHB-S10 | `needs_work` | A retry and repeated same-version review preserve three work identities and the user's done state. |
| PHB-S11 | `conflict` | An unresolved source-applicability conflict retains both candidate interpretations alongside two supported remediation items. |
| PHB-S12 | `unknown` | Partial slide/notes coverage supports two bounded checks and leaves two artifact-wide checks unknown. |
| PHB-S13 | `unknown` | Identical bytes in another assignment await that assignment's own assessment. The first assignment retains its original state. |
| PHB-S14 | `ready` | The last confirmed corrected snapshot remains intact after two invalid evidence updates are rejected. |

The mixed-version case PHB-S08 explicitly selects the corrected deck and the baseline rehearsal in its `model_input_files`. PHB-S12 supplies a structured handoff covering parts 1–5, so its artifact-wide checks retain that coverage limit until further review.

## State and work rules

Each assessment pins its requirement-set revision, logical artifact identity, exact artifact hash and supporting-source hashes. Per-criterion status uses `satisfied`, `needs_work`, `unknown` or `conflict`. Evidence coverage and version matching have their own fields.

The current summary evaluates applicable required criteria. Its precedence is conflict, known work, unknown review and ready. Empty requirement inventory stays unknown. Incomplete membership also prevents ready while preserving observed conflicts and known work. A complete nonempty inventory with supported exclusions can show zero applicable required criteria and its exclusion basis.

Optional criteria stay visible. Their unmet suggestions can become tasks through an explicit user request. Automatic remediation candidates come from supported, applicable required `needs_work` criteria.

Work identity uses the assignment, requirement-set revision, logical artifact ID, artifact hash, requirement ID and gap kind. A repeated review reuses matching work and preserves personal progress. Supporting-source versions stay attached to the assessment. Unknown and conflict rows produce grouped review followups, with optional task conversion through the current task flow.

`saved_snapshot` retrieval reports the stored assessment for its named versions and assessment time. `current_selection` projection compares the explicitly selected binding. Current file access availability remains a separate observation from changed content identity.

## Execute local fixture checks

Use Python 3.11 or later from any working directory.

```bash
python /path/to/phase_b_readiness/fixtures/validate_fixtures.py --negative-controls
```

To save a local check report, use a path outside the frozen fixture files.

```bash
python /path/to/phase_b_readiness/fixtures/validate_fixtures.py --negative-controls --report /path/to/fixture_validation.json
```

The validator imports the copied Phase A checks, verifies all exact source anchors and evaluates the explicitly authored Phase B expectations. Its nine intentional-tamper controls exercise evidence hashes, locator resolution, assignment scope, task completion, empty and incomplete inventory, unknown applicability, rehearsal version association and duplicate work.

The callable `validate(package_root)` returns named local checks. `negative_controls(package_root)` returns the tamper-control results. The evaluator's `project(requirements, assessment_results, membership_complete)` requires explicit requirement-membership completeness.

## Actual implementation acceptance

Capture real current-adapter requests and responses for saving and retrieving readiness. Exercise a real persistence boundary and fresh-host retrieval. Review the coursework through the active reading and model path, preserve exact source bindings and compare the resulting state with the evaluator oracle.

The report in `../evidence/fixture_validation.json` records local validation. Product and actual-host execution counts are initialized to zero. The implementing process records each actual run, its tested revision, persistence evidence, host output and any remaining acceptance failure.
