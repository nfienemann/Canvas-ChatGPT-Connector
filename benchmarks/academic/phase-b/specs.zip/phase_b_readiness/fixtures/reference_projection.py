"""Small evaluator projection for authored Phase B states.

This module reads no product data and performs no persistence or host execution.
"""

from collections import Counter


ASSESSMENT_STATUSES = {"satisfied", "needs_work", "unknown", "conflict"}
VERSION_MATCHES = {"current", "mismatch", "unverified"}
APPLICABILITY_VALUES = {"applicable", "not_applicable", "unknown"}
COVERAGE_VALUES = {"complete", "partial", "unavailable"}


def project(requirements, assessment_results, membership_complete):
    """Return explicit criterion counts and the agreed required-scope summary."""
    results = {row["requirement_id"]: row for row in assessment_results}
    required = [row for row in requirements if row["required"]]
    applicable = [row for row in required if row["applicability"] == "applicable"]
    unknown_applicability = [row for row in required if row["applicability"] == "unknown"]
    effective = []
    for requirement in applicable:
        result = results.get(requirement["requirement_id"], {})
        status = result.get("assessment_status", "unknown")
        if result.get("version_match", "unverified") != "current":
            status = "unknown"
        effective.append(status)

    statuses = Counter(effective)
    if not requirements:
        summary = "unknown"
    elif statuses["conflict"]:
        summary = "conflict"
    elif statuses["needs_work"]:
        summary = "needs_work"
    elif not membership_complete or unknown_applicability or statuses["unknown"]:
        summary = "unknown"
    else:
        summary = "ready"

    counts = {
        "requirements": len(requirements),
        "required": len(required),
        "applicable_required": len(applicable),
        "optional": len(requirements) - len(required),
        "not_applicable_required": sum(row["applicability"] == "not_applicable" for row in required),
        "unknown_applicability_required": len(unknown_applicability),
        **{status: statuses[status] for status in ("satisfied", "needs_work", "unknown", "conflict")}
    }
    return {"summary_status": summary, "counts": counts}


def work_identity(item):
    key = item["work_key"]
    return tuple(key[field] for field in ("assignment_id", "requirement_set_revision", "artifact_id", "artifact_sha256", "requirement_id", "gap_kind"))
