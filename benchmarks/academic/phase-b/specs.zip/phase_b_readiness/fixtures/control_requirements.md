# Synthetic requirement-scope controls

These statements are authored only for deterministic Phase B aggregation controls.

CR-OPTIONAL is an optional visual polish suggestion for this fixture scope.
CR-EXEMPT is explicitly not applicable to the selected synthetic assignment scope.
CR-UNKNOWN requires a scope decision that has not been supplied.
