This is the revised BenchLink deck and its associated rehearsal record. Review this explicitly selected version against the supplied assignment brief and references, including its speaker notes, and save its readiness.

Show the current criterion results and remaining work. Keep the earlier review reference available for a later historical lookup.
