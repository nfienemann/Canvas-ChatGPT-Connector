"""Wall-clock test of the unmodified grade audit deadlines through MCP."""

import asyncio
from copy import deepcopy
from time import monotonic

import httpx

from canvas_bridge import grade_audit
from tests.test_grade_audit import grade_data as grade_data
from tests.test_mcp_contract import running as running
from tests.test_permission_consistency_contract import client_session


async def test_default_grade_budget_after_22_slow_detail_reads(
    running, bridge, seeded, grade_data, token_factory, monkeypatch
):
    base = bridge.synthetic.data["assignments"]["11"][0]
    rows = []
    for i in range(1, 23):
        record = deepcopy(base)
        record.update(id=i, name=f"Assessment {i}")
        record["submission"]["assignment_id"] = i
        rows.append(record)
    bridge.synthetic.data["assignments"]["11"] = rows
    completed = []
    defpath = "/api/v1/courses/11/assignments"

    async def handle(req):
        if req.url.path == defpath:
            return httpx.Response(200, json=rows)
        if req.url.path.startswith(defpath + "/"):
            i = int(req.url.path.rsplit("/", 1)[1])
            await asyncio.sleep(2.85)
            completed.append(i)
            return httpx.Response(200, json=rows[i - 1])
        return bridge.synthetic.handle(req)

    monkeypatch.setattr(
        bridge.synthetic, "client", lambda: httpx.AsyncClient(transport=httpx.MockTransport(handle))
    )
    original = grade_audit.syllabus_documents
    stalls = []

    async def slow_syllabus(*args):
        stalls.append(monotonic())
        await asyncio.sleep(45)
        return await original(*args)

    monkeypatch.setattr(grade_audit, "syllabus_documents", slow_syllabus)
    assert (grade_audit.GRADE_REQUEST_SECONDS, grade_audit.AUTOMATIC_SYLLABUS_SECONDS) == (90, 30)
    async with client_session(
        running, token_factory(scope="academic:read"), read_timeout=115
    ) as session:
        start = monotonic()
        reply = await session.call_tool(
            "audit_course_grade", {"connection_id": seeded, "course_id": grade_data}
        )
        elapsed = monotonic() - start
    result = reply.structuredContent
    print(
        "grade stress details=",
        len(completed),
        "discovery_started_s=",
        round(stalls[0] - start, 2) if stalls else None,
        "wall_s=",
        round(elapsed, 2),
        "status=",
        result and result["status"],
        "reason=",
        result and result["data"].get("reason_code"),
        "stage=",
        result and result["data"].get("timeout_stage"),
    )
    assert len(completed) == 22 and stalls and elapsed < 95
    assert (
        result["status"] == "partial_data" and result["data"]["classification"] == "indeterminate"
    )
    assert result["data"]["reason_code"] == "TASK_BUDGET_EXCEEDED"
    assert result["data"]["timeout_stage"] == "syllabus_discovery_and_read"
    assert "calculation" not in result["data"]
