"""Synthetic incident reproducers and control workloads. Run against a frozen CanvasBridge tree."""

import asyncio
import hashlib
import random

import httpx
import pytest

from canvas_bridge.academic_rules import deadline_findings
from canvas_bridge.authorization import RequestAuthorization, request_authorization
from canvas_bridge.canvas import CanvasClient
from canvas_bridge.course_files import read_file
from canvas_bridge.domain import DomainError
from canvas_bridge.policy import Endpoint
from canvas_bridge.request_limits import RequestLimits
from tests.test_academic_intelligence import source_doc
from tests.test_domain_planning import task
from tests.test_file_reading import readable as readable
from tests.test_file_reading import scientific_pdf


async def test_cancelled_leader_isolated_from_independent_assignment_requests(bridge):
    arrived, release = asyncio.Event(), asyncio.Event()
    count = 0

    async def transport(req):
        nonlocal count
        count += 1
        arrived.set()
        await release.wait()
        return httpx.Response(200, json={"id": 3, "name": "Fixture"})

    async with httpx.AsyncClient(transport=httpx.MockTransport(transport)) as http:

        async def read():
            token = request_authorization.set(RequestAuthorization("get_assignment_details"))
            try:
                client = CanvasClient(
                    bridge.registry.require("synthetic", True), "fixture", bridge.settings, http
                )
                client.bind_usage(bridge, "fixture", scope="epoch-one")
                return await client.one(Endpoint.ASSIGNMENT, course="11", assignment="3")
            finally:
                request_authorization.reset(token)

        leader = asyncio.create_task(read())
        await asyncio.wait_for(arrived.wait(), 5)
        followers = [asyncio.create_task(read()) for _ in range(16)]
        try:
            # Allow each already scheduled reader to join the suspended request.
            enrolled = asyncio.Event()
            asyncio.get_running_loop().call_soon(enrolled.set)
            await asyncio.wait_for(enrolled.wait(), timeout=5)
            assert [size for _, size in bridge.upstream_cache.flights.values()] == [16]
            leader.cancel()
            await asyncio.gather(leader, return_exceptions=True)
        finally:
            release.set()
        outcomes = await asyncio.gather(*followers, return_exceptions=True)
        assert not bridge.upstream_cache.flights
        retry = await read()
        assert retry["id"] == 3
        cancellations = sum(isinstance(value, asyncio.CancelledError) for value in outcomes)
        print(
            "assignment clients=17; explicit cancels=1; follower cancellations=",
            cancellations,
            "HTTP attempts incl fresh retry=",
            count,
        )
        assert cancellations == 0


@pytest.mark.parametrize("relation", ["next", "next last", "last next"])
async def test_all_advertised_pages_reached(bridge, relation):
    ids = list(range(1, 151))
    requests = []

    def transport(req):
        page = int(req.url.params.get("page", 1))
        requests.append(page)
        rows = ids[(page - 1) * 100 : page * 100]
        headers = (
            {"Link": f'<{req.url.copy_set_param("page", 2)}>; rel="{relation}"'}
            if page == 1
            else {}
        )
        return httpx.Response(
            200, json=[{"id": n, "name": f"Task {n}"} for n in rows], headers=headers
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(transport)) as http:
        client = CanvasClient(
            bridge.registry.require("synthetic", True), "fixture", bridge.settings, http
        )
        try:
            response = await client.collection(Endpoint.ASSIGNMENTS, course="11")
        finally:
            await client.close()
    observed = {int(row["id"]) for row in response.items}
    print(
        "fixture=150 records; relation=",
        relation,
        "returned=",
        len(observed),
        "complete=",
        response.complete,
        "pages=",
        requests,
    )
    assert not response.complete or set(ids) == observed


@pytest.mark.parametrize("suffix", ["&include%5B%5D=", "&as_user_id=", "&page=2", "&per_page=1"])
async def test_ambiguous_or_changed_query_not_dispatched(bridge, suffix):
    requests = []

    def transport(req):
        requests.append(str(req.url))
        headers = (
            {"Link": f'<{req.url.copy_set_param("page", 2)}{suffix}>; rel="next"'}
            if len(requests) == 1
            else {}
        )
        return httpx.Response(200, json=[{"id": len(requests)}], headers=headers)

    async with httpx.AsyncClient(transport=httpx.MockTransport(transport)) as http:
        client = CanvasClient(
            bridge.registry.require("synthetic", True), "fixture", bridge.settings, http
        )
        try:
            result = await client.collection(Endpoint.ASSIGNMENTS, course="11")
        finally:
            await client.close()
    print("query append=", suffix, "dispatches=", len(requests), "complete=", result.complete)
    assert len(requests) == 1 and not result.complete


@pytest.mark.parametrize("port", ["bad", "65536"])
async def test_malformed_pagination_is_structured_partial(bridge, port):
    requests = []

    def transport(req):
        requests.append(1)
        nxt = str(req.url.copy_set_param("page", 2)).replace(".invalid/", f".invalid:{port}/")
        return httpx.Response(200, json=[{"id": 1}], headers={"Link": f'<{nxt}>; rel="next"'})

    async with httpx.AsyncClient(transport=httpx.MockTransport(transport)) as http:
        client = CanvasClient(
            bridge.registry.require("synthetic", True), "fixture", bridge.settings, http
        )
        try:
            result = await client.collection(Endpoint.ASSIGNMENTS, course="11")
        finally:
            await client.close()
    assert not result.complete and result.failure and len(requests) == 1


def test_deadline_extension_preserves_current_date():
    item = task("fictional-quiz").model_dump(mode="json")
    item.update(title="Quiz 12", effective_due={"kind": "local_date", "local_date": "2026-11-09"})
    line = "Quiz 12 was originally due on November 2, 2026, but the deadline has been extended to November 9, 2026."
    result = deadline_findings([source_doc(line)], [item], "UTC", True)
    print(
        "extension findings=",
        [(f["kind"], f["obligation"]["raw_date"], f["match"]) for f in result["findings"]],
    )
    assert not [f for f in result["findings"] if f["kind"] == "conflicting_deadlines"]
    assert any(
        c["outcome"] == "same_at_available_precision" and c["work_id"] == item["id"]
        for c in result["comparisons"]
    )


@pytest.mark.parametrize("seed", [17, 517, 9901])
async def test_sparse_pdf_chunk_walk(bridge, owner, seeded, readable, seed):
    course, ref = readable
    pages = [f"Marker {i} in a synthetic study. " * 5 for i in range(1, 26)]
    data = scientific_pdf(pages)
    bridge.synthetic.data["file_bodies"]["51"] = data
    bridge.synthetic.data["files"]["11"][0]["size"] = len(data)
    order = random.Random(seed).sample(range(1, 26), 10)  # noqa: S311 - reproducible fixture order.
    for pos in order:
        r = await read_file(bridge, owner, seeded, ref, page_start=pos)
        assert [p["page"] for p in r.data["passages"]] == [pos]
    args = {"file_id": ref, "length": 157}
    seen = set()
    recovered = {n: "" for n in range(1, 26)}
    for _ in range(180):
        reply = await read_file(bridge, owner, seeded, **args)
        assert reply.data["content_hash"] == hashlib.sha256(data).hexdigest()
        for p in reply.data["passages"]:
            assert p["page_offset"] == len(recovered[p["page"]])
            recovered[p["page"]] += p["text"]
        more = reply.data["continuation"]
        if not more:
            break
        pos = (more["page_start"], more["page_end"], more["offset"])
        assert pos not in seen
        seen.add(pos)
        args = {**more, "length": 157}
    else:
        pytest.fail("PDF traversal did not terminate")
    assert [s.strip() for s in recovered.values()] == [s.strip() for s in pages]


def test_randomized_admission_recovers_after_every_wave():
    now = [10.0]
    limits = RequestLimits(
        total=16, per_key=4, burst=20, rate=5, clock=lambda: now[0], wall_time=lambda: now[0]
    )
    rng = random.Random(70041)  # noqa: S311 - reproducible synthetic admission waves.
    for _ in range(120):
        now[0] += 40
        leases = []
        for _attempt in range(100):
            key = f"tenant-{rng.randrange(12)}"
            try:
                leases.append(limits.acquire(key))
            except DomainError:
                pass
            assert 0 <= limits.active <= 16 and limits.buckets[key].active <= 4
        rng.shuffle(leases)
        for lease in leases:
            lease.close()
        assert limits.active == 0
        assert all(b.active == 0 for b in limits.buckets.values())
