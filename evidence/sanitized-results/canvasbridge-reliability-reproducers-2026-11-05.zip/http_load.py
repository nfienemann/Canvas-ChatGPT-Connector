"""Authenticated loopback load against two disjoint synthetic owners."""

import asyncio
import math
import statistics
from collections import Counter
from time import perf_counter

from canvas_bridge.auth import principal_id
from tests.conftest import seed
from tests.test_mcp_contract import running as running
from tests.test_permission_consistency_contract import client_session


async def test_mixed_owner_bursts_and_final_recovery(
    running, bridge, owner, seeded, token_factory, settings
):
    second = principal_id(settings.issuer_url, "fixture-second")
    other = await seed(bridge, second, "fixture-second-connection")
    bridge.store.save_local(
        owner, seeded, "preferences", "default", {"timezone": "America/New_York"}, 0
    )
    bridge.store.save_local(
        second, other, "preferences", "default", {"timezone": "Europe/Berlin"}, 0
    )
    times = []
    counts = Counter()

    def check(body, zone):
        return [r["value"].get("timezone") for r in body["data"]["records"]] == [zone]

    async def read(session, ref, zone):
        started = perf_counter()
        try:
            async with asyncio.timeout(15):
                response = await session.call_tool("get_saved_study_state", {"connection_id": ref})
        except Exception as exc:
            counts[type(exc).__name__] += 1
            return
        finally:
            times.append(perf_counter() - started)
        body = response.structuredContent
        if body and body["status"] == "ok":
            assert check(body, zone), "owner-mismatched or missing data"
            counts["scoped_success"] += 1
        else:
            counts[body["status"] if body else "missing_envelope"] += 1

    tok1 = token_factory(scope="academic:read")
    tok2 = token_factory(scope="academic:read", sub="fixture-second")
    async with client_session(running, tok1) as a, client_session(running, tok2) as b:
        for _ in range(4):
            calls = [
                read(a, seeded, "America/New_York")
                if i % 2 == 0
                else read(b, other, "Europe/Berlin")
                for i in range(32)
            ]
            await asyncio.gather(*calls)
            await asyncio.sleep(0.3)
    await asyncio.sleep(2)
    for token, ref, zone in [(tok1, seeded, "America/New_York"), (tok2, other, "Europe/Berlin")]:
        async with client_session(running, token) as session:
            response = await session.call_tool("get_saved_study_state", {"connection_id": ref})
            assert response.structuredContent and check(response.structuredContent, zone)
    print(
        "128 authenticated reads, two owner-specific expected values; outcomes=",
        dict(counts),
        "client_p50_ms=",
        round(statistics.median(times) * 1000),
        "p95_ms=",
        round(sorted(times)[math.ceil(0.95 * len(times)) - 1] * 1000),
        "post_load=2/2",
    )
    assert counts == {"scoped_success": 128}
