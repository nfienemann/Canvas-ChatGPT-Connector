# Reproduce the November 5 reliability findings

These six modules exercise CanvasBridge with fictional records, an in-memory SQLite database, and local HTTP test servers. They are separate from normal pytest discovery. The checked cases include both expected failures on the audited checkout and passing controls.

Use the CanvasBridge checkout and its locked development environment. Extract this archive into `.local/nuclear-repro` under the repository root. From the root, run the following in PowerShell.

```powershell
$probeFiles = (Get-ChildItem -LiteralPath '.local/nuclear-repro' -Filter '*.py' -File).FullName
.\.venv\Scripts\python.exe -m pytest -c pyproject.toml -p tests.conftest @probeFiles -q -s --tb=short
```

To reproduce one failure, append `-k cancelled_leader`, `-k explicit_deadline_extension_at_mcp`, `-k duplicate_page`, `-k status_check_after`, or `-k oversize-metadata`. The grade latency control takes approximately 90 seconds. Request counts and assertions are deterministic fixtures. Wall times depend on machine load.

| Module | Boundary exercised |
| --- | --- |
| `stress_probes.py` | Cancellation of a shared assignment read, pagination validation, date matching, random-access PDF chunk reconstruction, and 12,000 admission attempts |
| `mcp_probes.py` | Public workload and course consistency tools, page completeness, malformed continuations, scope checks, and explicit deadline amendments |
| `file_recovery_probes.py` | File extraction status before, during and after a synthetic HTTP 429 or 403 |
| `inventory_scale.py` | All 1,000 file IDs across 10 source pages, and the byte ceiling for 100 wide records |
| `http_load.py` | Four bursts of 32 authenticated reads shared between two owners with distinct expected values, followed by fresh-session recovery |
| `grade_latency.py` | Default 90-second grade deadline under 22 delayed assignment-detail responses and a delayed automatic syllabus phase |

Application and test source baseline: `5bd086356e730b01b5a9f1be9de106446ef049c6` plus the uncommitted contents frozen for the audit. The 870-file manifest fingerprint is `2601ecf57e5e8ed73921a9a9fafee0f9aec1aa4e0c95ee3f1c54e6dff5c837b2`. The commit alone does not identify this build.
