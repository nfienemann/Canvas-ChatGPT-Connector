"""Recovery after a short, real HTTP error at the fictional file metadata route."""

import httpx
import pytest

from tests.test_file_reading import readable as readable
from tests.test_mcp_contract import running as running
from tests.test_permission_consistency_contract import client_session


@pytest.mark.parametrize("http_error", [429, 403])
async def test_status_check_after_fresh_access_recovers(
    running, bridge, owner, seeded, readable, token_factory, monkeypatch, http_error
):
    _, file_id = readable
    args = {"connection_id": seeded, "file_id": file_id}
    old = bridge.synthetic.handle
    injected = [False]
    downloads = []

    def handle(req):
        if req.url.path.endswith("/download"):
            downloads.append(req.url.path)
        if req.url.path.endswith("/courses/11/files/51") and injected[0]:
            return httpx.Response(
                http_error, headers={"Retry-After": "3"} if http_error == 429 else {}
            )
        return old(req)

    monkeypatch.setattr(bridge.synthetic, "handle", handle)
    async with client_session(running, token_factory(scope="academic:read")) as session:

        async def call(name):
            result = await session.call_tool(name, args)
            assert result.structuredContent
            return result.structuredContent

        first = await call("read_course_file")
        assert first["status"] == "ok" and first["data"]["page_count"] == 3
        expected_hash = first["data"]["content_hash"]
        warm = await call("get_file_extraction_status")
        assert warm["data"]["indexed"]
        injected[0] = True
        rejected = await call("get_file_extraction_status")
        assert rejected["status"] == ("retry_later" if http_error == 429 else "permission_denied")
        assert not rejected["sources"]
        injected[0] = False
        # Advance only the synthetic ledger time beyond its provider hold.
        clock = bridge.usage.clock
        monkeypatch.setattr(bridge.usage, "clock", lambda: clock() + 5)
        recovered = await call("get_file_extraction_status")
        assert recovered["status"] == "ok"
        data = recovered["data"]
        prior = len(downloads)
        reread = await call("read_course_file")
        assert reread["data"]["content_hash"] == expected_hash
    print(
        "HTTP",
        http_error,
        "after fresh successful metadata:",
        {
            key: data.get(key)
            for key in ("access_state", "state", "indexed", "page_count", "extraction_outcome")
        },
        "extra downloads to read same bytes=",
        len(downloads) - prior,
    )
    assert data["access_state"] == "available"
    if http_error == 403:
        assert not data["indexed"] and len(downloads) > prior
    else:
        assert data["indexed"] and data["content_hash"] == expected_hash and len(downloads) == prior
    assert data["state"] != "inaccessible"
