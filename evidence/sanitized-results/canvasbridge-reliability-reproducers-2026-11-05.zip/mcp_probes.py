"""Public MCP replays and authorization controls for the synthetic stress report."""

from copy import deepcopy
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from tests.test_academic_intelligence import academic as academic
from tests.test_mcp_contract import running as running
from tests.test_permission_consistency_contract import client_session


@pytest.mark.parametrize(
    "variant",
    [
        "plain",
        "multi",
        "case",
        "duplicate_page",
        "opaque",
        "invalid_port",
        "other_course",
        "switch_user",
        "denied_page_2",
    ],
)
async def test_workload_reports_every_due_item_or_marks_source_incomplete(
    running, bridge, owner, seeded, token_factory, monkeypatch, variant
):
    course = bridge.selected(owner, seeded)[1][0]
    anchor = datetime(2026, 11, 5, 12, tzinfo=UTC)
    base = bridge.synthetic.data["assignments"]["11"][0]
    rows = []
    for i in range(1, 151):
        row = deepcopy(base)
        row.update(
            id=i,
            name=f"Fixture task {i}",
            course_id=11,
            due_at=anchor.isoformat(),
            published=True,
            locked_for_user=False,
        )
        rows.append(row)
    path = "/api/v1/courses/11/assignments"
    previous = bridge.synthetic.handle
    calls = []
    escaped = []

    def transport(req):
        if req.url.path == "/api/v1/courses/12/assignments" or req.url.params.get("as_user_id"):
            escaped.append(req.url.path)
        if req.url.path != path:
            return previous(req)
        value = (req.url.params.get_list("page") or ["1"])[-1]
        page = 2 if value == "bookmark:fixture-2" else int(value)
        calls.append(page)
        if page == 2 and variant == "denied_page_2":
            return httpx.Response(403)
        link = str(req.url.copy_set_param("page", 2))
        if variant == "invalid_port":
            link = link.replace(".invalid/", ".invalid:bad/")
        if variant == "other_course":
            link = link.replace("/courses/11/", "/courses/12/")
        if variant == "switch_user":
            link += "&as_user_id=777"
        if variant == "duplicate_page":
            link += "&page=3"
        if variant == "opaque":
            link = str(req.url.copy_set_param("page", "bookmark:fixture-2"))
        rel = {"multi": "next last", "case": "NeXt"}.get(variant, "next")
        return httpx.Response(
            200,
            json=rows[(page - 1) * 100 : page * 100],
            headers={"Link": f'<{link}>; rel="{rel}"'} if page == 1 else {},
        )

    monkeypatch.setattr(bridge.synthetic, "handle", transport)
    args = {
        "connection_id": seeded,
        "course_ids": [course.id],
        "start": (anchor - timedelta(days=1)).isoformat(),
        "end": (anchor + timedelta(days=1)).isoformat(),
        "timezone": "UTC",
        "limit": 10,
    }
    async with client_session(running, token_factory(scope="academic:read")) as session:
        replies = []
        while True:
            reply = await session.call_tool("get_workload", args)
            assert reply.structuredContent is not None, (
                "missing structured MCP response",
                reply.isError,
            )
            body = reply.structuredContent
            replies.append(body)
            cursor = body["meta"].get("next_cursor")
            if not cursor:
                break
            assert len(replies) < 20
            args["cursor"] = cursor
    items = [item["id"] for body in replies for item in body["data"].get("items", [])]
    code = replies[0]["data"].get("reason_code")
    status = replies[0]["status"]
    complete = replies[0]["data"].get("workload_scope", {}).get("collection_complete")
    print(
        "public workload:",
        variant,
        "status=",
        status,
        "code=",
        code,
        "complete=",
        complete,
        "unique=",
        len(set(items)),
        "observed_provider_pages=",
        calls,
        "client_pages=",
        len(replies),
        "out_of_scope_sends=",
        len(escaped),
    )
    assert not escaped
    if variant in {"plain", "multi", "case", "duplicate_page", "opaque"}:
        assert len(items) == len(set(items)) == 150 or complete is False
    elif variant in {"switch_user", "other_course", "denied_page_2"}:
        assert not items
        assert calls == ([1, 2] if variant == "denied_page_2" else [1])
        assert status == "permission_denied"
    else:
        assert status == "partial_data" and complete is False and items, (status, code)


async def test_explicit_deadline_extension_at_mcp(running, bridge, seeded, academic, token_factory):
    line = "Quiz 12 was originally due on November 2, 2026, but the deadline has been extended to November 9, 2026."
    bridge.synthetic.data["assignments"]["11"][0].update(
        name="Quiz 12", due_at="2026-11-09T15:00:00Z"
    )
    bridge.synthetic.data["course_details"]["11"]["syllabus_body"] = "<p>" + line + "</p>"
    async with client_session(running, token_factory(scope="academic:read")) as session:
        result = await session.call_tool(
            "audit_course_consistency", {"connection_id": seeded, "course_id": academic.id}
        )
    body = result.structuredContent
    assert body and body["status"] in {"ok", "partial_data"}, body and body["summary"]
    findings = [
        (f.get("kind"), f.get("obligation", {}).get("raw_date")) for f in body["data"]["findings"]
    ]
    print("public consistency findings=", findings)
    assert ("conflicting_deadlines", "November 2, 2026") not in findings
