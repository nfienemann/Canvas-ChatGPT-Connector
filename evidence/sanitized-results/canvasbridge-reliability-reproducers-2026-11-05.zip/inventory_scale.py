"""10 pages of repeated filenames with unique IDs; bounded output and recovery."""

import json
from time import perf_counter

import httpx
import pytest

from tests.test_course_files import file_record
from tests.test_mcp_contract import running as running
from tests.test_permission_consistency_contract import client_session


@pytest.mark.parametrize(
    "count,title,filename",
    [
        (1000, "Synthetic lab notes", "notes.pdf"),
        (100, "多" * 600, "sheet.pdf"),
        (100, "多" * 900, "sheet.pdf"),
    ],
    ids=["ten-pages", "wide-metadata", "oversize-metadata"],
)
async def test_resumable_inventory_reaches_every_admitted_id(
    running, bridge, owner, seeded, token_factory, monkeypatch, count, title, filename
):
    course = bridge.selected(owner, seeded)[1][0]
    orig = bridge.synthetic.handle
    path = "/api/v1/courses/11/files"
    page_calls = []

    def provider(req):
        if req.url.path == path:
            page = int(req.url.params.get("page", 1))
            page_calls.append(page)
            last = min(page * 100, count)
            rows = [
                file_record(
                    id=i, filename=filename, display_name=title, updated_at="2026-11-05T10:00:00Z"
                )
                for i in range(100 * (page - 1) + 1, last + 1)
            ]
            headers = (
                {"Link": f'<{req.url.copy_set_param("page", page + 1)}>; rel="next"'}
                if last < count
                else {}
            )
            return httpx.Response(200, json=rows, headers=headers)
        if req.url.path.endswith(("/assignments", "/modules", "/folders")):
            return httpx.Response(200, json=[])
        return orig(req)

    monkeypatch.setattr(bridge.synthetic, "handle", provider)
    args = {"course_id": course.id, "connection_id": seeded, "inventory_mode": "resumable"}
    seen = set()
    reports = []
    sizes = []
    steps = 0
    async with client_session(
        running, token_factory(scope="academic:read"), read_timeout=90
    ) as session:
        for _ in range(30):
            start = perf_counter()
            reply = await session.call_tool("list_course_files", args)
            data = reply.structuredContent
            assert data is not None
            reports.append(
                (data["status"], data["data"].get("reason_code"), round(perf_counter() - start, 2))
            )
            sizes.append(len(json.dumps(data, ensure_ascii=False).encode()))
            seen.update(str(file["canvas_file_id"]) for file in data["data"].get("files", []))
            steps += 1
            cursor = data["meta"].get("next_cursor")
            if not cursor:
                break
            args["cursor"] = cursor
    print(
        "inventory count=",
        count,
        "title chars=",
        len(title),
        "verified IDs=",
        len(seen),
        "steps=",
        steps,
        "provider pages=",
        page_calls,
        "max envelope bytes=",
        max(sizes),
        "max client seconds=",
        max(t for _, _, t in reports),
        "final=",
        reports[-1][:2],
    )
    assert reports[-1][0] == "ok" and seen == {str(i) for i in range(1, count + 1)}
    assert data["data"]["inventory_progress"]["distinct_verified_files"] == count
