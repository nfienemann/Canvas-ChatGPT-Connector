# remaining-estimate

1005 of 1290 known work minutes fit. 285 are unscheduled, including 90 limited by capacity and 195 blocked by prerequisites. Use the student's revised 30 minutes for the operations capacity calculation. That removes 90 minutes from the baseline upper estimate. Finance still needs time for valuation and the work that depends on it. The scoped confirmed baseline reminders need no changes.

## Proposed study blocks

| Start | End | Minutes | Student work |
| --- | --- | ---: | --- |
| Oct 29 17:00 EDT | Oct 29 17:45 EDT | 45 | MKT320-A05 / Source review and identify missing design evidence |
| Oct 29 17:55 EDT | Oct 29 18:40 EDT | 45 | OPS330-A05 / Review process boundary and missing reliability evidence |
| Oct 29 18:50 EDT | Oct 29 19:35 EDT | 45 | FIN310-A03 / Review financial assumptions and resolve word-limit conflict |
| Oct 29 19:45 EDT | Oct 29 20:00 EDT | 15 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 14:00 EDT | Oct 30 14:45 EDT | 45 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 14:55 EDT | Oct 30 15:40 EDT | 45 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 15:50 EDT | Oct 30 16:00 EDT | 10 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 17:00 EDT | Oct 30 17:20 EDT | 20 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 17:30 EDT | Oct 30 18:00 EDT | 30 | MKT320-A05 / Student evaluates causal scope, survey limitations and economics |
| Oct 31 09:00 EDT | Oct 31 09:30 EDT | 30 | MKT320-A05 / Student evaluates causal scope, survey limitations and economics |
| Oct 31 09:40 EDT | Oct 31 10:25 EDT | 45 | MKT320-A05 / Student writes recommendation and decision rule |
| Oct 31 10:35 EDT | Oct 31 11:20 EDT | 45 | MKT320-A05 / Student writes recommendation and decision rule |
| Oct 31 11:30 EDT | Oct 31 11:45 EDT | 15 | MKT320-A05 / Student writes recommendation and decision rule |
| Oct 31 11:55 EDT | Oct 31 12:00 EDT | 5 | MKT320-A05 / Assemble memo, editable calculations and contribution appendix |
| Nov 01 13:00 EST | Nov 01 13:45 EST | 45 | MKT320-A05 / Assemble memo, editable calculations and contribution appendix |
| Nov 01 13:55 EST | Nov 01 14:00 EST | 5 | MKT320-A05 / Assemble memo, editable calculations and contribution appendix |
| Nov 01 14:10 EST | Nov 01 14:40 EST | 30 | OPS330-A05 / Student calculates stage capacities and staffing scenarios |
| Nov 01 14:50 EST | Nov 01 15:35 EST | 45 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 01 15:45 EST | Nov 01 16:30 EST | 45 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 01 16:40 EST | Nov 01 17:00 EST | 20 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 02 18:00 EST | Nov 02 18:10 EST | 10 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 02 18:20 EST | Nov 02 19:05 EST | 45 | OPS330-A05 / Student writes decision, evidence owners and operating guardrail |
| Nov 02 19:15 EST | Nov 02 19:30 EST | 15 | OPS330-A05 / Student writes decision, evidence owners and operating guardrail |
| Nov 02 19:40 EST | Nov 02 20:00 EST | 20 | MKT320-A05 / Check exported files, requirements and submission evidence (pinned) |
| Nov 03 15:00 EST | Nov 03 15:45 EST | 45 | OPS330-A05 / Student writes decision, evidence owners and operating guardrail |
| Nov 03 15:55 EST | Nov 03 16:00 EST | 5 | OPS330-A05 / Student writes decision, evidence owners and operating guardrail |
| Nov 03 16:10 EST | Nov 03 16:55 EST | 45 | OPS330-A05 / Assemble memo, calculations and data-assumption appendix |
| Nov 03 17:05 EST | Nov 03 17:25 EST | 20 | OPS330-A05 / Assemble memo, calculations and data-assumption appendix |
| Nov 03 17:35 EST | Nov 03 17:55 EST | 20 | OPS330-A05 / Check exported files, requirements and submission evidence |
| Nov 04 18:00 EST | Nov 04 18:45 EST | 45 | FIN310-A03 / Student builds annual incremental cash-flow schedule |
| Nov 04 18:55 EST | Nov 04 19:40 EST | 45 | FIN310-A03 / Student builds annual incremental cash-flow schedule |
| Nov 04 19:50 EST | Nov 04 20:35 EST | 45 | FIN310-A03 / Student builds annual incremental cash-flow schedule |
| Nov 04 20:45 EST | Nov 04 21:00 EST | 15 | FIN310-A03 / Student calculates base/downside valuation and payback |

## Remaining outside the schedule

- FIN310-A03 / Student calculates base/downside valuation and payback — 90 work minutes. insufficient capacity.
- FIN310-A03 / Student writes conditional recommendation and assumptions — 110 work minutes. prerequisite unallocated.
- FIN310-A03 / Assemble memo, schedule, valuation and authorship statement — 65 work minutes. prerequisite unallocated.
- FIN310-A03 / Check exported files, requirements and submission evidence — 20 work minutes. prerequisite unallocated.

Outstanding receipt checks cover FIN310-A03-S6, MKT320-A05-S6, OPS330-A05-S6. Each is already included in the workload.

## Calendar review

The scoped confirmed baseline reminders need no changes. No provider write was executed.

The source review in the main report applies to the selected courses. The controlled dates and progress changes are scenario assumptions. The exact selections and versions are in the corresponding MCP requests and responses.
