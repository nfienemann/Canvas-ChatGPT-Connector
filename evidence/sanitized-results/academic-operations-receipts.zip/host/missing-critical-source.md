# missing-critical-source

900 of 1335 known work minutes fit. 435 are unscheduled, including 0 limited by capacity and 435 blocked by prerequisites. The selected investment case is unavailable. Leave finance recovery unestimated and its five dependent stages on hold. Continue marketing and operations from the surviving sources. Add recovery time only after the case becomes available. The scoped confirmed baseline reminders need no changes.

## Proposed study blocks

| Start | End | Minutes | Student work |
| --- | --- | ---: | --- |
| Oct 29 17:00 EDT | Oct 29 17:45 EDT | 45 | MKT320-A05 / Source review and identify missing design evidence |
| Oct 29 17:55 EDT | Oct 29 18:40 EDT | 45 | OPS330-A05 / Review process boundary and missing reliability evidence |
| Oct 29 18:50 EDT | Oct 29 19:35 EDT | 45 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 29 19:45 EDT | Oct 29 20:00 EDT | 15 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 14:00 EDT | Oct 30 14:45 EDT | 45 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 14:55 EDT | Oct 30 15:25 EDT | 30 | MKT320-A05 / Student verifies experimental counts and calculation workbook |
| Oct 30 15:35 EDT | Oct 30 16:00 EDT | 25 | MKT320-A05 / Student evaluates causal scope, survey limitations and economics |
| Oct 30 17:00 EDT | Oct 30 17:35 EDT | 35 | MKT320-A05 / Student evaluates causal scope, survey limitations and economics |
| Oct 30 17:45 EDT | Oct 30 18:00 EDT | 15 | MKT320-A05 / Student writes recommendation and decision rule |
| Oct 31 09:00 EDT | Oct 31 09:45 EDT | 45 | MKT320-A05 / Student writes recommendation and decision rule |
| Oct 31 09:55 EDT | Oct 31 10:40 EDT | 45 | MKT320-A05 / Student writes recommendation and decision rule |
| Oct 31 10:50 EDT | Oct 31 11:35 EDT | 45 | MKT320-A05 / Assemble memo, editable calculations and contribution appendix |
| Oct 31 11:45 EDT | Oct 31 11:55 EDT | 10 | MKT320-A05 / Assemble memo, editable calculations and contribution appendix |
| Nov 01 13:00 EST | Nov 01 13:45 EST | 45 | OPS330-A05 / Student calculates stage capacities and staffing scenarios |
| Nov 01 13:55 EST | Nov 01 14:40 EST | 45 | OPS330-A05 / Student calculates stage capacities and staffing scenarios |
| Nov 01 14:50 EST | Nov 01 15:20 EST | 30 | OPS330-A05 / Student calculates stage capacities and staffing scenarios |
| Nov 01 15:30 EST | Nov 01 16:15 EST | 45 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 01 16:25 EST | Nov 01 17:00 EST | 35 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 02 18:00 EST | Nov 02 18:40 EST | 40 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 02 18:50 EST | Nov 02 19:30 EST | 40 | OPS330-A05 / Student writes decision, evidence owners and operating guardrail |
| Nov 02 19:40 EST | Nov 02 20:00 EST | 20 | MKT320-A05 / Check exported files, requirements and submission evidence (pinned) |
| Nov 03 15:00 EST | Nov 03 15:45 EST | 45 | OPS330-A05 / Student writes decision, evidence owners and operating guardrail |
| Nov 03 15:55 EST | Nov 03 16:20 EST | 25 | OPS330-A05 / Student writes decision, evidence owners and operating guardrail |
| Nov 03 16:30 EST | Nov 03 17:15 EST | 45 | OPS330-A05 / Assemble memo, calculations and data-assumption appendix |
| Nov 03 17:25 EST | Nov 03 17:45 EST | 20 | OPS330-A05 / Assemble memo, calculations and data-assumption appendix |
| Nov 03 17:55 EST | Nov 03 18:00 EST | 5 | OPS330-A05 / Check exported files, requirements and submission evidence |
| Nov 04 18:00 EST | Nov 04 18:15 EST | 15 | OPS330-A05 / Check exported files, requirements and submission evidence |

## Remaining outside the schedule

- FIN310-A03 / Recover missing critical investment case before finalizing valuation — Duration unknown. effort unknown.
- FIN310-A03 / Student builds annual incremental cash-flow schedule — 135 work minutes. prerequisite unallocated.
- FIN310-A03 / Student calculates base/downside valuation and payback — 105 work minutes. prerequisite unallocated.
- FIN310-A03 / Student writes conditional recommendation and assumptions — 110 work minutes. prerequisite unallocated.
- FIN310-A03 / Assemble memo, schedule, valuation and authorship statement — 65 work minutes. prerequisite unallocated.
- FIN310-A03 / Check exported files, requirements and submission evidence — 20 work minutes. prerequisite unallocated.

Outstanding receipt checks cover FIN310-A03-S6, MKT320-A05-S6, OPS330-A05-S6. Each is already included in the workload.

## Calendar review

The scoped confirmed baseline reminders need no changes. No provider write was executed.

The source review in the main report applies to the selected courses. The controlled dates and progress changes are scenario assumptions. The exact selections and versions are in the corresponding MCP requests and responses.
