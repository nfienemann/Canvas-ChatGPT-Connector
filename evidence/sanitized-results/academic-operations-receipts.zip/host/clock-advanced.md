# clock-advanced

375 of 1380 known work minutes fit. 1005 are unscheduled, including 380 limited by capacity and 625 blocked by prerequisites. As of noon November 2, assembly for marketing cannot finish ahead of the pinned 19:40–20:00 EST file check. The pin remains visible for a decision. Move it after assembly within the deadline, or add enough earlier time for the prerequisite work. Elapsed blocks provide no completion evidence. The scoped confirmed baseline reminders need no changes.

## Proposed study blocks

| Start | End | Minutes | Student work |
| --- | --- | ---: | --- |
| Nov 02 18:00 EST | Nov 02 18:45 EST | 45 | MKT320-A05 / Source review and identify missing design evidence |
| Nov 02 18:55 EST | Nov 02 19:30 EST | 35 | OPS330-A05 / Review process boundary and missing reliability evidence |
| Nov 03 15:00 EST | Nov 03 15:10 EST | 10 | OPS330-A05 / Review process boundary and missing reliability evidence |
| Nov 03 15:20 EST | Nov 03 16:05 EST | 45 | FIN310-A03 / Review financial assumptions and resolve word-limit conflict |
| Nov 03 16:15 EST | Nov 03 17:00 EST | 45 | OPS330-A05 / Student calculates stage capacities and staffing scenarios |
| Nov 03 17:10 EST | Nov 03 17:55 EST | 45 | OPS330-A05 / Student calculates stage capacities and staffing scenarios |
| Nov 04 18:00 EST | Nov 04 18:30 EST | 30 | OPS330-A05 / Student calculates stage capacities and staffing scenarios |
| Nov 04 18:40 EST | Nov 04 19:25 EST | 45 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 04 19:35 EST | Nov 04 20:20 EST | 45 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |
| Nov 04 20:30 EST | Nov 04 21:00 EST | 30 | OPS330-A05 / Student calculates inventory inputs and summarizes observations |

## Remaining outside the schedule

- MKT320-A05 / Student verifies experimental counts and calculation workbook — 135 work minutes. insufficient capacity.
- MKT320-A05 / Student evaluates causal scope, survey limitations and economics — 60 work minutes. prerequisite unallocated.
- MKT320-A05 / Student writes recommendation and decision rule — 105 work minutes. prerequisite unallocated.
- MKT320-A05 / Assemble memo, editable calculations and contribution appendix — 55 work minutes. prerequisite unallocated.
- MKT320-A05 / Check exported files, requirements and submission evidence — 20 work minutes. pinned prerequisite conflict.
- OPS330-A05 / Student writes decision, evidence owners and operating guardrail — 110 work minutes. insufficient capacity.
- OPS330-A05 / Assemble memo, calculations and data-assumption appendix — 65 work minutes. prerequisite unallocated.
- OPS330-A05 / Check exported files, requirements and submission evidence — 20 work minutes. prerequisite unallocated.
- FIN310-A03 / Student builds annual incremental cash-flow schedule — 135 work minutes. insufficient capacity.
- FIN310-A03 / Student calculates base/downside valuation and payback — 105 work minutes. prerequisite unallocated.
- FIN310-A03 / Student writes conditional recommendation and assumptions — 110 work minutes. prerequisite unallocated.
- FIN310-A03 / Assemble memo, schedule, valuation and authorship statement — 65 work minutes. prerequisite unallocated.
- FIN310-A03 / Check exported files, requirements and submission evidence — 20 work minutes. prerequisite unallocated.

Outstanding receipt checks cover FIN310-A03-S6, MKT320-A05-S6, OPS330-A05-S6. Each is already included in the workload.

## Calendar review

The scoped confirmed baseline reminders need no changes. No provider write was executed.

The source review in the main report applies to the selected courses. The controlled dates and progress changes are scenario assumptions. The exact selections and versions are in the corresponding MCP requests and responses.
