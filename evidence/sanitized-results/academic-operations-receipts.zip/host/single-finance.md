# single-finance

480 of 480 known work minutes fit. 0 are unscheduled, including 0 limited by capacity and 0 blocked by prerequisites. All six finance steps fit when finance has the windows to itself. Begin with the case assumptions and clarify the two word ranges. The final 20 minutes cover the export and submission-evidence check. The scoped confirmed baseline reminders need no changes.

## Proposed study blocks

| Start | End | Minutes | Student work |
| --- | --- | ---: | --- |
| Oct 29 17:00 EDT | Oct 29 17:45 EDT | 45 | FIN310-A03 / Review financial assumptions and resolve word-limit conflict |
| Oct 29 17:55 EDT | Oct 29 18:40 EDT | 45 | FIN310-A03 / Student builds annual incremental cash-flow schedule |
| Oct 29 18:50 EDT | Oct 29 19:35 EDT | 45 | FIN310-A03 / Student builds annual incremental cash-flow schedule |
| Oct 29 19:45 EDT | Oct 29 20:00 EDT | 15 | FIN310-A03 / Student builds annual incremental cash-flow schedule |
| Oct 30 14:00 EDT | Oct 30 14:30 EDT | 30 | FIN310-A03 / Student builds annual incremental cash-flow schedule |
| Oct 30 14:40 EDT | Oct 30 15:25 EDT | 45 | FIN310-A03 / Student calculates base/downside valuation and payback |
| Oct 30 15:35 EDT | Oct 30 16:00 EDT | 25 | FIN310-A03 / Student calculates base/downside valuation and payback |
| Oct 30 17:00 EDT | Oct 30 17:35 EDT | 35 | FIN310-A03 / Student calculates base/downside valuation and payback |
| Oct 30 17:45 EDT | Oct 30 18:00 EDT | 15 | FIN310-A03 / Student writes conditional recommendation and assumptions |
| Oct 31 09:00 EDT | Oct 31 09:45 EDT | 45 | FIN310-A03 / Student writes conditional recommendation and assumptions |
| Oct 31 09:55 EDT | Oct 31 10:40 EDT | 45 | FIN310-A03 / Student writes conditional recommendation and assumptions |
| Oct 31 10:50 EDT | Oct 31 10:55 EDT | 5 | FIN310-A03 / Student writes conditional recommendation and assumptions |
| Oct 31 11:05 EDT | Oct 31 11:50 EDT | 45 | FIN310-A03 / Assemble memo, schedule, valuation and authorship statement |
| Nov 01 13:00 EST | Nov 01 13:20 EST | 20 | FIN310-A03 / Assemble memo, schedule, valuation and authorship statement |
| Nov 01 13:30 EST | Nov 01 13:50 EST | 20 | FIN310-A03 / Check exported files, requirements and submission evidence |

Outstanding receipt checks cover FIN310-A03-S6. Each is already included in the workload.

## Calendar review

The scoped confirmed baseline reminders need no changes. No provider write was executed.

The source review in the main report applies to the selected courses. The controlled dates and progress changes are scenario assumptions. The exact selections and versions are in the corresponding MCP requests and responses.
