# earlier-deadline-pin-conflict

The scenario moves marketing to October 30 at 23:59 EDT. The retained November 2 check is too late. Choose an earlier available time and rerun planning. The deadline reminder can be reviewed separately. Review the update to the marketing reminder only.


## Calendar review

Review the update to the marketing reminder only. No provider write was executed.
- Update MKT320-A05 at Oct 30 23:59 EDT.

The source review in the main report applies to the selected courses. The controlled dates and progress changes are scenario assumptions. The exact selections and versions are in the corresponding MCP requests and responses.
