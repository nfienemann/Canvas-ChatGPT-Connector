# Stage 6 host review

These are the Codex host's answers after reading the three captured local MCP responses from this build. Each answer corresponds to the named HTTP receipt in the ZIP. The installed connector available in this session did not advertise the new analytics tools.

### Two-week review

> Across the three synthetic courses, the week of October 19 had one on-time, one late and one missed deadline among three known outcomes. The week of October 26 had two on time, one late and zero missed among three known outcomes. Each week had a fourth due item with unknown timeliness. The missed rate fell by 33⅓ percentage points among known outcomes.
>
> At the November 2 cutoff, you had marked two of three known declarations done for the first due cohort and three of three for the second. One declaration was unknown each week. Those are your declarations about the work due that week. The records do not show the day you completed it.
>
> The first accepted plan overlapped recorded busy time for 90 of 180 scheduled study minutes. The second overlapped for 30 of 150. Both used complete busy coverage, but they used different snapshots. The proposed plans had zero observed overlap in their hypothetical schedules.
>
> Three of four completed work scopes had comparable forecasts and recorded actuals each week. The actual fell inside its forecast range for one of three pairs in the first week and three of three in the second. The mean absolute error of the explicit point forecasts fell from 20 to 10 minutes. One completed scope lacked a comparable pair each week.
>
> The first week recorded four requests, five attempts and two confirmed effects. The second recorded three requests, three attempts and three effects. You recorded 25 manual minutes across two sessions in the first week and 10 across two sessions in the second. That is a 15-minute difference in recorded coordination. Its cause is unknown.
>
> The windows ran from local midnight October 19 to October 26, and from October 26 to November 2, in New York. They contained 168 and 169 elapsed hours. Both the state and evidence cutoffs were midnight November 2.

Receipt `http-baseline.json`. Report ID `962a0ba608b042b5f0505812553f7d9ada9be7a07a010743a8da59f54bebae28`.

### Week with sparse observations

> For October 26 through November 1 in the sparse synthetic record, both known deadline outcomes were on time. The other two outcomes are unknown. At the November 2 cutoff, both known personal declarations were marked done, with two unknown. Only two of four completed work scopes had comparable effort records. Both actuals were in range, and the explicit point forecasts had a mean absolute error of 15 minutes. The saved plan had zero observed overlap with the available busy intervals. Busy coverage was partial, so the total overlap is unknown. Two manual sessions were recorded. One had a duration of six minutes and the other had no recorded duration.

Receipt `http-partial_observations-baseline.json`. Report ID `1e93ba83bfdcb4dde766f53ce1d254d080f6d10881caaeb76bb8ade79a621fab`.

### Later evidence

> With the state cutoff held at November 2 and evidence admitted through November 4, the corrected deadline moves one missed item from the first week into the second. The two due cohorts now contain three and five items. The first week has zero missed among two known outcomes, and the second has one missed among four known outcomes. One outcome remains unknown in each week. Across both weeks the missed rate is still one of six known outcomes. The changed deadline affects where the work is counted. Recorded effort and coordination activity are unchanged.

Receipt `http-correction_after_cutoff-baseline.json`. Report ID `a06e6a176eaa3a363cb92f2e068921ffa77325f1ac0aa48fcb8ad1a7795b76a7`. A separate HTTP test exercised a linked, immutable restatement after an explicit duration correction. Both versions are in `http-owned-duration.json`.

| Host check | Local review |
| --- | --- |
| HF01 quantities and scope | Pass. Counts, durations and cohort sizes match the three selected synthetic courses. |
| HF02 denominators and missing coverage | Pass. Rates retain known denominators and unknowns. Partial busy coverage limits the overlap claim. |
| HF03 basis of progress | Pass. Personal done declarations are attributed to their due cohort at the cutoff. |
| HF04 basis of effort and activity | Pass. Scheduled, forecast, actual and manual minutes have distinct labels. |
| HF05 time and corrections | Pass. The answer preserves both cutoffs, the clock change and the corrected due cohort. |
| HF06 comparison units | Pass. Missed-rate change uses percentage points. Duration changes use minutes. |
| HF07 strength of claims | Pass. Synthetic scope is explicit. Causation and grade improvement are not claimed. |
| HF08 usefulness with missing data | Pass. The sparse answer gives available results and identifies the absent busy intervals and duration. |

This review covers these Codex interpretations of the local plugin responses. For installed-client acceptance, point an isolated client at the tested build, issue the same synthetic requests and score that client's actual replies. No production deployment, live coursework, external calendar operation or database migration was used.
